#include "stdafx.h"
#include <boost/filesystem/operations.hpp>
#include <SAMToolsLib.h>
#include <exception.h>
#include "BAMFileIndexer.h"

namespace BAM
{

void FileIndexer::CreateIndexFile(FileResolver::Ptr files)
{
    if(bam_index_build2(ToRef(files->GetSortedBAMFile()), ToRef(files->GetBAMIndexFile()))) {

        throw KError("Error while creating BAM index file for %1") << files->GetSortedBAMFile();
    }
}

bool FileIndexer::HasIndex(FileResolver::Ptr files)
{
    if(CheckFileProperties(files)) {

        //check if index is at least loadable
        bam_index_t* index=bam_index_load_directly(ToRef(files->GetBAMIndexFile()));

        if(index!=nullptr) {

            bam_index_destroy(index);
            return true;
        }
    }
    return false;
}


bool FileIndexer::CheckFileProperties(FileResolver::Ptr files)
{
    using namespace boost::filesystem;

    //TODO: sanity check on header or something

    if(exists(files->GetBAMIndexFile())) {

        std::time_t lastWrite=last_write_time(files->GetBAMIndexFile());

        if(lastWrite >= last_write_time(files->GetSortedBAMFile()))
            return true;
    }

    return false;
}

}
#include "stdafx.h"

#ifdef AMGNU
#include <sys/sysinfo.h>
#include <fstream>
#endif

#include "CE_Algorithm.h"

#include "boost/make_shared.hpp"

#include "debugstr.h"

#include "CE_CommandLine.h"
#include "CE_FilesCommunication.h"
#include "CEVersionInfo.h"



namespace engine
{


bool CheckVersionInfo( const tools::CommandLine& commandline )
{
    if ( commandline.GetExtraArguments().PrintVersion() ){
        PrintVersionInfo();
        return true;
    } else {
        return false;
    }
}

/**
    \param argc Number of command line arguments
    \param argv The command line arguments vector
*/
Algorithm::Algorithm() {}

int Algorithm::Execute( int argc, char* argv[] )
{
    try {
        return ExecuteThrow(argc, argv);
    }
    catch ( std::exception& e ) {
        std::cerr << PM("Error: " ) << e.what() << std::endl;
#ifndef AMGNU
        debug_str << PM("Error: " ) << e.what() << std::endl;
#endif
        GetLogger()->AddError( e.what() );
        return 1;
    }
    catch ( ... ) {
        std::cerr << PM("***Unknown exception occurred***")  << std::endl;
#ifndef AMGNU
        debug_str << PM("***Unknown exception occurred***")  << std::endl;
#endif
        GetLogger()->AddError( PM("***Unknown exception occurred***") );
        return 2;
    }
}

int Algorithm::ExecuteThrow(int argc, char* argv[])
{
    tools::CommandLine commandLine;

    // Give derived classes a chance to add optional arguments
    AddOptionalExtraArguments( commandLine.GetExtraArguments() );

    commandLine.Init( argc, argv, *GetLogger() );

    if ( CheckVersionInfo(commandLine) )
        return 0;

    // Clear messages.txt + write something in it
    {
        // Should always be true, first argument is the executable
        if ( argc > 0 ) {
            Str::Path::Val algorithm = argv[0];
            GetLogger()->CreateLogFile(
                Logger::GetAllMessagesFilename(),
                LogMessageType::Message(),
                RawMessage( PM("Starting algorithm %1 (%2)"), algorithm.filename().string(), GetVersionInfo() ).c_str() );
        }
    }

    // Prepare the environment
    ExecuteEnvironment env;
    env.Update( commandLine );

    // Prepare the communication
    boost::shared_ptr<FilesCommunication> filesCommunication = CreateFilesCommunication();
    communication::CalcCommunication comm( filesCommunication.get() );

    LogEnvironment( env, comm );

    // Run the algorithm
    GetLogger()->SetProgress(   0 );
    int retVal = ExecuteImpl( commandLine.GetArgCount(),
        commandLine.GetOldstyleArgVector(),
        env,
        comm );
    GetLogger()->SetProgress( 100 );
	GetLogger()->SetProgressMessage( PM("Computation finished!") );
    //GetLogger()->AddMessage ( LogMessageType::Message(), PM("Computation finished!") );
	/*
	GetLogger()->AddMessage : 
		will only write the message in the complete log file, 
		not in the file containing the last message only
	GetLogger()->SetProgressMessage
		makes the system write in both the complete log file 
		and the file containing the last line of the log
	*/

    return retVal;
}

engine::FilesCommunication::Ptr Algorithm::CreateFilesCommunication()
{
    return boost::make_shared<FilesCommunication>( GetLogger() );
}

Logger* Algorithm::GetLogger()
{
    return &logger_;
}

void Algorithm::LogEnvironment(const ExecuteEnvironment& env, const communication::CalcCommunication& comm) const
{
    using namespace communication;

    if ( env.HasMaxNumThreads() )
        comm.Send( CalcMessage(RawMessage(PM("Caller requested %1 threads"), env.GetMaxNumThreads()).c_str()) );
    else
        comm.Send( CalcMessage(PM("No maximum number of threads specified")) );

    comm.Send( CalcMessage(RawMessage(PM("Local directory: %1"), env.localDir).c_str()) );

	{
#ifdef AMGNU
#ifdef __SYSTEM_OS_INFO__ // activate debug block by local definition of the macro or through build system
		// temporary debugging, OS information reporting on CE
		{
			std::ifstream ifs("/etc/os-release");
			std::string content((std::istreambuf_iterator<char>(ifs)), std::istreambuf_iterator<char>());
			comm.Send(communication::CalcMessage(RawMessage(content.c_str()).str()));
		}

		std::string os{OS_DISTRO};
		if (os.empty())
		{
			comm.Send(communication::CalcMessage(RawMessage("Macro OS_DISTRO not available!!!").str()));
		}
		else
		{
			comm.Send(communication::CalcMessage(RawMessage("Macro OS_DISTRO: %1", os).str()));
		}

		auto constexpr megabyte = 1024U * 1024U;
		auto ToMB = [&megabyte](uintmax_t value)
		{
			return value / megabyte;
		};
		// disk space info
		{
			auto const spaceInfo = boost::filesystem::space(".");
			comm.Send(communication::CalcMessage(TXT("Local storage information:")));
			comm.Send(communication::CalcMessage(RawMessage(TXT(" >> capacity: %1 MB"), ToMB(spaceInfo.capacity)).str()));
			comm.Send(communication::CalcMessage(RawMessage(TXT(" >> available: %1 MB"), ToMB(spaceInfo.available)).str()));
		}

		// memory info
		{
			struct sysinfo si;
			sysinfo(&si);
			comm.Send(communication::CalcMessage(TXT("System memory information:")));
			comm.Send(communication::CalcMessage(RawMessage(TXT(" >> total ram: %1 MB"), ToMB(si.totalram)).str()));
		}
#endif // __SYSTEM_OS_INFO__
#endif // AMGNU
	}
}

void Algorithm::PrepareManualRun(const ExecuteEnvironment& env)
{
    GetLogger()->SetResultsDir  ( env.resultsDir.string() );
}

void Algorithm::SetVerbose()
{
    GetLogger()->SetVerbose(true);
}

} // namespace engine

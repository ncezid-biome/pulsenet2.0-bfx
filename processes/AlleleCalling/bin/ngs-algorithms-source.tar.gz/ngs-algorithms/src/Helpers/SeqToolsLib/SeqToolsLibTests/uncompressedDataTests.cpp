#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "filereader.h"
#include "filewriter.h"

#include "TestSequenceFiles.h"
#include "OutputManager.h"

#include "Sequence.h"
#include "NamedSequence.h"


struct uncompressedTestFicture
{
};

BOOST_FIXTURE_TEST_SUITE( rawFastaReadWriteTests, uncompressedTestFicture );

BOOST_AUTO_TEST_CASE(fastq_ReadEmpty_GetSeqReturnsEmpty)
{
    const test::SequenceFile seqfile = test::SequenceFiles::GetEmptySequenceFile_Fastq(Compression::None);

    {
        FastQFileReader reader( seqfile.filename.string() );
        seq::NamedSequence sequence;
        reader.getNextSeq( sequence );

        seq::Sequence emptysequence("");

        BOOST_CHECK_EQUAL( sequence.GetName(), Str::Text::Val() );
        BOOST_CHECK_EQUAL( sequence.GetData(), emptysequence );
    }
}

BOOST_AUTO_TEST_CASE(fastq_ReadSingleSeq_Ok)
{
    const test::SequenceFile seqfile = test::SequenceFiles::GetSingleLineSequenceFile_Fastq(Compression::None);

    {
        FastQFileReader reader( seqfile.filename.string() );
        seq::NamedSequence sequence;
        reader.getNextSeq( sequence );

        BOOST_CHECK_EQUAL( seqfile.sequences[0].name, sequence.GetName() );
        BOOST_CHECK_EQUAL( seq::Sequence(seqfile.sequences[0].sequence), sequence.GetData() );
        BOOST_CHECK      ( ! reader.hasMore() );
    }
}

BOOST_AUTO_TEST_CASE(fasta_ReadFiveSeqs_Ok)
{
    const test::SequenceFile seqfile = test::SequenceFiles::GetFiveSeqsFile_Fasta(Compression::None);

    {
        FastaFileReader reader( seqfile.filename.string() );
        seq::NamedSequence rsequence;

        for ( auto& sequence : seqfile.sequences ){
            reader.getNextSeq( rsequence );

            BOOST_CHECK_EQUAL( sequence.name,                    rsequence.GetName() );
            BOOST_CHECK_EQUAL( seq::Sequence(sequence.sequence), rsequence.GetData() );
        }

        BOOST_CHECK( ! reader.hasMore() );
    }
}

BOOST_AUTO_TEST_SUITE_END();

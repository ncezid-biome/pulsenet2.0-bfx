/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#include "stdafx.h"
#include "settings.h"


Settings::Settings()
{
}
Settings::~Settings()
{
}
Str::Text::Val Settings::getStringSetting(const Id& id) const
{
	Settings::Val val = getSetting(id);
	return val;
}
Str::Path::Val Settings::getPathSetting(const Id& id) const
{
	Settings::Val val = getSetting(id);
	return Str::Path::Val(val);
}
bool Settings::getBoolSetting(const Id& id) const
{
	Settings::Val val = getSetting(id);
	return atoi(ToRef(val))!=0;
}
int Settings::getIntSetting(const Id& id) const
{
	Settings::Val val = getSetting(id);
	return atoi(ToRef(val));
}
double Settings::getDoubleSetting(const Id& id) const
{
	Settings::Val val = getSetting(id);
	return atof(ToRef(val));
}
Str::Text::Vec Settings::getStringVecSetting(const Id& id) const
{
	Str::Text::Vec vals;
	Settings::Val val = getSetting(id);
	size_t pos = val.find_first_of('|'), newpos;
	if (pos==std::string::npos) vals.push_back(val);
	else {
		vals.push_back(val.substr(0, pos));
		while (pos!=std::string::npos) {
			pos+=1;
			newpos = val.find_first_of('|', pos);
			if (newpos==std::string::npos) { vals.push_back(val.substr(pos, newpos)); }
			else vals.push_back(val.substr(pos, newpos-pos));
			pos = newpos;
		}
	}
	return vals;
}
Str::Path::Vec Settings::getPathVecSetting(const Id& id) const
{
	Str::Path::Vec paths;
	Str::Text::Vec buffer = getStringVecSetting(id);
	for(size_t i=0; i<buffer.size(); ++i) {
		paths.push_back(Str::Path::Val(buffer[i].c_str()));
	}
	return paths;

}

Settings::BoolVec Settings::getBoolVecSetting(const Id& id) const
{
	BoolVec vals;
	Settings::Val val = getSetting(id);
	size_t pos = val.find_first_of('|'), newpos;
	if (pos==std::string::npos) vals.push_back(atoi(val.c_str())==1);
	else {
		vals.push_back(atoi(val.substr(0, pos).c_str()));
		while (pos!=std::string::npos) {
			pos+=1;
			newpos = val.find_first_of('|', pos);
			if (newpos==std::string::npos) { vals.push_back(atoi(val.substr(pos, newpos).c_str())); }
			else vals.push_back(atoi(val.substr(pos, newpos-pos).c_str()));
			pos = newpos;
		}
	}
	return vals;
}


SubSettings::SubSettings(const Settings& parent, const Id& prefix)
	: parent_(parent), prefix_(prefix)
{
}
SubSettings::Val SubSettings::getSetting(const Id& id) const
{
	return parent_.getSetting(prefix_+" > "+id);
}
bool SubSettings::hasSetting(const Id& id) const
{
	return parent_.hasSetting(prefix_+" > "+id);
}
	



namespace SettingIds {
	Settings::Id WorkingDir = "WorkingDir";
	Settings::Id LogFile = "LogFile";
	Settings::Id OutputDir = "OutputDir";
};
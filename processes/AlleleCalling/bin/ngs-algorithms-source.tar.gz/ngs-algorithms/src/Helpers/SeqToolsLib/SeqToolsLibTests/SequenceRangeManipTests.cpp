#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "SequenceRangeManip.h"
#include "SequenceFileName.h"
#include "Sequence.h"

using namespace seq;

struct SequenceRangeManipTestsFixture
{
    SequenceRangeManipTestsFixture()
        : acgt( PM("acgt") )
        , atgc( PM("atgc") )
    {
    }

    Sequence acgt;
    Sequence atgc;
};

BOOST_FIXTURE_TEST_SUITE( SequenceRangeManipTests, SequenceRangeManipTestsFixture );

BOOST_AUTO_TEST_CASE( SplitIntoACGTPieces_EmptyInput_Ok )
{
    Str::Text::Vec result = SplitIntoACGTPieces(Str::Text::Val(""));
    BOOST_REQUIRE_EQUAL(result.size(),    1);
    BOOST_REQUIRE_EQUAL(result[0].size(), 0);
}

BOOST_AUTO_TEST_CASE( SplitIntoACGTPieces_RubbishInput_EmptyOutput )
{
    Str::Text::Vec result = SplitIntoACGTPieces(Str::Text::Val("!!!!"));
    BOOST_REQUIRE_EQUAL(result.size(),    1);
    BOOST_REQUIRE_EQUAL(result[0].size(), 0);
}

BOOST_AUTO_TEST_CASE( SplitIntoACGTPieces_SingleSeq_Ok )
{
    Str::Text::Vec result = SplitIntoACGTPieces(acgt);
    BOOST_REQUIRE_EQUAL(result.size(), 1);
    BOOST_REQUIRE_EQUAL(result[0],     acgt);
}

BOOST_AUTO_TEST_CASE( SplitIntoACGTPieces_TwoSeqs_Ok )
{
    Str::Text::Vec result = SplitIntoACGTPieces(acgt + PM("N") + atgc);
    BOOST_REQUIRE_EQUAL(result.size(), 2);
    BOOST_REQUIRE_EQUAL(result[0],     acgt);
    BOOST_REQUIRE_EQUAL(result[1],     atgc);
}

BOOST_AUTO_TEST_CASE( SplitIntoACGTPieces_MultipleSeparators_Ok )
{
    Str::Text::Vec result = SplitIntoACGTPieces(acgt +  PM("NNNN") + atgc);
    BOOST_REQUIRE_EQUAL(result.size(), 2);
    BOOST_REQUIRE_EQUAL(result[0],     acgt);
    BOOST_REQUIRE_EQUAL(result[1],     atgc);
}

BOOST_AUTO_TEST_CASE( SplitIntoACGTPieces_StartsWithSep_Ok )
{
    Str::Text::Vec result = SplitIntoACGTPieces(Sequence("N") + acgt);
    BOOST_REQUIRE_EQUAL(result.size(), 1);
    BOOST_REQUIRE_EQUAL(result[0],     acgt);
}

BOOST_AUTO_TEST_CASE( SplitIntoACGTPieces_EndsWithSep_Ok )
{
    Str::Text::Vec result = SplitIntoACGTPieces(acgt + PM("N"));
    BOOST_REQUIRE_EQUAL(result.size(), 1);
    BOOST_REQUIRE_EQUAL(result[0],     acgt);
}

BOOST_AUTO_TEST_CASE( ReverseComplementCopy_EmptyString_Ok )
{
    Str::Text::Val result;
    ReverseComplementCopy(Str::Text::Val(""), result);
    BOOST_REQUIRE_EQUAL(result.size(), 0);
}

BOOST_AUTO_TEST_CASE( ReverseComplementCopy_actg_Ok )
{
    Str::Text::Val result(4, 0);
    ReverseComplementCopy(Str::Text::Val(PM("ACGT")), result);
    BOOST_REQUIRE_EQUAL(result, Sequence(PM("ACGT")));
}

BOOST_AUTO_TEST_CASE( ReverseComplementCopy_atgc_Ok )
{
    Str::Text::Val result(4, 0);
    ReverseComplementCopy(Str::Text::Val(PM("ATGC")), result);
    BOOST_REQUIRE_EQUAL(result, Sequence(PM("GCAT")));
}

BOOST_AUTO_TEST_SUITE_END();

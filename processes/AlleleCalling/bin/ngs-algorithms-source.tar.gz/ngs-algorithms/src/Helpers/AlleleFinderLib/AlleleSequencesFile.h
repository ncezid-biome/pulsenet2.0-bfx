#pragma once

#include "FileRotator.h"

#include "CalcCommunication.h"


/**
    Contains all the alleles, as exported from the database.

    Storage on disk: similar to AlleleInfoFile, see there for in-depth comments

    Input name: e.g. 'allalleles.fasta.gz'

    Want to create allalleles_0.fasta, allalleles_1.fasta. -> unzip to the
    rotated name.
*/
class AlleleSequencesFile
{
public:
    typedef boost::shared_ptr<AlleleSequencesFile>       Ptr;
    typedef boost::shared_ptr<const AlleleSequencesFile> ConstPtr;

public:
    AlleleSequencesFile( const Str::Path::Val& filename, const communication::CalcCommunication& comm );

    void           DecompressIfNeeded( const communication::CalcCommunication& comm );
    Str::Path::Val GetFilename() const;

    void           FromLocalFile( const communication::CalcCommunication& comm, const Str::Path::Val& source );
    void           MakeMissingFile( const communication::CalcCommunication& comm );

private:
    Str::Path::Val GetNextSharedName() const;

    struct FinalSequenceFile
    {
        FinalSequenceFile( const Str::Path::Val& ioriginalName, const communication::CalcCommunication& comm );

        /** Input name, possibly with compression extension */
        Str::Path::Val originalName;

        FileRotatorItf::Ptr fileRotator;
    };

    bool VerifyFilename(const FinalSequenceFile& fileInfo);

private:
    /**
        Contains the required info to get access to the final file
    */   
    FinalSequenceFile     fileInfo_;
    /**
        Store the name of the actual allalleles.fasta file, does not change
        if the rotation is changed in the meanwhile
    */
    Str::Path::Val        filename_;
};

#pragma once
#include <StringDef.h>
#include <stdint.h>

namespace BAM
{

#pragma pack(push, 1)

struct AuxEntry {

    char tag[2];
    char type;
    union {
        char A;
        int8_t c;
        uint8_t C;
        int16_t s;
        uint16_t S;
        int32_t i;
        uint32_t I;
        float f;
        //1kib should be enough for everybody ;)
        char Z[1024 + 1];
    };

    template<typename T, T AuxEntry::*M, char C> static Str::Text::Val Create(Str::ID::Arg t, T value, size_t len = sizeof(T))
    {
        AuxEntry ae;

        strncpy(ae.tag, t, 2);
        ae.type = C;
        ae.*M = value;

        return Str::Text::Val((char*)&ae, 2 + 1 + len);
    }

    template<typename T> static Str::Text::Val Create(Str::ID::Arg t, T value);

};

#pragma pack(pop)

}
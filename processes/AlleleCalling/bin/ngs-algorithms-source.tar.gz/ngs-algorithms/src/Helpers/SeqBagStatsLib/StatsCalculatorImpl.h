#pragma once

#include "OwnedFactory.h"
#include "CalcCommunication.h"

#include "SplitSequenceFiles.h"

class SRSStatsCalculatorSettings;
class SeqBagInfo;

namespace engine
{
    class ExecuteEnvironment;
} // namespace engine

/**
    \note When adding an implementation: add it to the CreateFactory implementation here.
*/
class StatsCalculatorImpl
{
public:
    typedef boost::shared_ptr<StatsCalculatorImpl> Ptr;

    typedef OwnedFactory<StatsCalculatorImpl> Factory;
    static Factory::Ptr CreateFactory();

public:
    virtual ~StatsCalculatorImpl(){}

    virtual StatsCalculatorImpl* Clone() const = 0;
    virtual Str::ID::Val         GetFactoryType() const = 0;

    virtual void                Apply( const SRSStatsCalculatorSettings& settings,
                                       const engine::ExecuteEnvironment& env,
                                       const communication::CalcCommunication& comm) const;

	 virtual void                Apply( const SRSStatsCalculatorSettings& settings,
										SeqBagInfo& returnInfo,
										const engine::ExecuteEnvironment& env,
										const communication::CalcCommunication& comm) const;

	virtual void                Apply( const SRSStatsCalculatorSettings& settings,
									   SeqBagInfo& returnInfo,
									   std::string& info, std::string& stats,
                                       const engine::ExecuteEnvironment& env,
                                       const communication::CalcCommunication& comm) const;

private:
    virtual void CheckPre           ( const SRSStatsCalculatorSettings& settings,
                                      const engine::ExecuteEnvironment& env,
                                      const communication::CalcCommunication& comm) const =0;
    virtual void ParseFiles         ( const SRSStatsCalculatorSettings& settings,
                                      SplitSequenceFiles&               downloadedfiles,
                                      const engine::ExecuteEnvironment& env,
                                      const communication::CalcCommunication& comm) const;
	 virtual void ApplyImpl          ( const SRSStatsCalculatorSettings& settings,
                                      const SplitSequenceFiles&         downloadedfiles,
									  SeqBagInfo& returnInfo,
									  std::string& info, std::string& stats,
                                      const engine::ExecuteEnvironment& env,
                                      const communication::CalcCommunication& comm) const=0;
	
};

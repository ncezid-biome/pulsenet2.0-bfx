#include "stdafx.h"

#include "BAMLevelFileReader.h"
#include <boost/interprocess/file_mapping.hpp>
#include <exception.h>
#include <translate.h>

namespace BAM
{

void LevelFileReader::Open(Str::Path::Ref file)
{

    using namespace boost::interprocess;

    {
        file_mapping fileMapping(file, read_only);
        mapped_region mappedRegion(fileMapping, read_only);

        mappedRegion_.swap(mappedRegion);
    }

    data_=static_cast<const char*>(mappedRegion_.get_address());
    header_=reinterpret_cast<const Header*>(data_);

    //basic sanity check
    const size_t expectedSize=header_->blockHeadersOffset + header_->numberOfBlockHeaders*sizeof(BlockHeader);

    if(strncmp(PM("BLF0"), header_->signature, 4) || expectedSize > mappedRegion_.get_size()) {

        throw KError("Invalid BLF file: wrong signature or size");
    }

    blockHeaders_=reinterpret_cast<const BlockHeader*>(data_ + header_->blockHeadersOffset);
}

void LevelFileReader::Close() {

    data_=nullptr;
    header_=nullptr;
    blockHeaders_=nullptr;
    
    //close memory map by stealing it from mappedRegion_ and going out of scope
    boost::interprocess::mapped_region dummyMap(std::move(mappedRegion_));
}

int LevelFileReader::CompareByBlockAddress(const BlockHeader* a, const BlockHeader* b)
{
    if(a->blockAddress<b->blockAddress)
        return -1;
    else if(a->blockAddress>b->blockAddress)
        return 1;
    return 0;
}

LevelFileTypes::ReadLevel LevelFileReader::GetLevelForRead(BamTold bamTold) const
{

    const BlockHeader query= { GetBlockAddress(bamTold), 0 };

    //do a binary search over the array of BlockHeaders, comparing by BlockAddress
    const BlockHeader* match=static_cast<const BlockHeader*>(bsearch(&query,
                             blockHeaders_, header_->numberOfBlockHeaders, sizeof(BlockHeader),
                             (int (*)(const void*, const void*)) CompareByBlockAddress));

    if(match!=nullptr) {

        //now we simply scan the entire block for the offset we seek

        //todo: move pointer calc into method with sanity checks
        const ReadInfo* readLevel=reinterpret_cast<const ReadInfo*>(data_ + match[0].fileOffset);
        const ReadInfo* endOfReadLevels=reinterpret_cast<const ReadInfo*>(data_ + match[1].fileOffset);

        while(readLevel<endOfReadLevels) {

            if(readLevel->blockOffset==GetBlockOffset(bamTold)) {

                return readLevel->readLevel;
            }

            readLevel++;
        }
    }
    return 0;
}

}
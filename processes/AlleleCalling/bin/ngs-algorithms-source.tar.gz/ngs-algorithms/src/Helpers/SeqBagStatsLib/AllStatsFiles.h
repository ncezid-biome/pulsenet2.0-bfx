#pragma once

#include "SequenceFiles.h"


namespace stats
{

class AllStatsFiles
{
public:
    SequenceFiles readFiles;

    bool IsEmpty() const;
};

} // namespace stats
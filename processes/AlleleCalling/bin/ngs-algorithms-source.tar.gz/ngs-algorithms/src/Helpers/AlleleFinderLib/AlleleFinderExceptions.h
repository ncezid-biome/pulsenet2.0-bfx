#pragma once

#include "exception_helper.h"


ADD_EXCEPTION(MissingAllelException)
ADD_EXCEPTION(MalformedAlleleFileException)

class BLASTNException : public KError
{
public:
    BLASTNException( int exitCode );
};

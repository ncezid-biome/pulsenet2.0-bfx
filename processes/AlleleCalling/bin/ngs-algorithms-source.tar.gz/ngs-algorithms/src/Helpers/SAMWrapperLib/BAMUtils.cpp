#include "stdafx.h"
#include "BAMUtils.h"

namespace BAM
{
}
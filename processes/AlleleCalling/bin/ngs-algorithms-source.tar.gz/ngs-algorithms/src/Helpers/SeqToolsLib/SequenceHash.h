#pragma once

#include <functional>


namespace seq
{


class Sequence;

/**
    Use as hashing function for hash maps with Sequence keys
*/
struct SequenceHash
{
    size_t operator()( const Sequence& sequence ) const;

    std::hash<Str::Text::Val> stringhash;
};


} // namespace seq

#include "stdafx.h"

#include "allelefindersettings.h"

#include "CalcCommunication.h"

#include "filereader.h"
#include "allelefinder.h"

#include "CE_FileSystem.h"
#include "CE_LogAction.h"


#define OPTION_HELP "help"
#define OPTION_SETTINGSFILE "settingsFile"
#define OPTION_ALGORITHM "algorithm"
#define OPTION_K "k"
#define OPTION_MINCOVERAGE "minCoverage"
#define OPTION_MINFWDCOVERAGE "minCoverageFwd"
#define OPTION_MINREVCOVERAGE "minCoverageRev"
#define OPTION_ALLELEFILE "alleleFile"
#define OPTION_ALLELEFILETYPE "alleleFileType"
#define OPTION_ALLELEINFOFILE "alleleInfo"
#define OPTION_KMERTABLEFILE "kmerTableFile"
#define OPTION_CREATEKMERTABLE "createKMerTable"
#define OPTION_READFILES "readFile"
#define OPTION_READFILETYPES "readFileType"
#define OPTION_LOGDIR "logDir"
#define OPTION_RESULTDIR "resultDir"
#define OPTION_MINQUAL "minQual"
#define OPTION_MAXNVIOLATIONS "maxNViolations"
#define OPTION_QUALOFFSET "qualOffset"
#define OPTION_THRESHOLDFORLOCUSPRESENCE "minLocusCoverage"
#define OPTION_THRESHOLDFORKEYWORDCOVERAGE "minKeywordCoverage"


AlleleFinderSettings::AlleleFinderSettings()
    : engine::ProgramOptions("Allele finder")
	, alleleFileType		(FastaFileReader::GetTypeName())
	, createKMerTable_		( false )
	, algorithmType			(KMerAlleleFinder::GetTypeName())
	, k						(21)
	, minCoverage			(1)
	, minCoverageFwd		(1)
	, minCoverageRev		(1)
	, minQual				(20)
	, maxNViolations		(0)
	, qualOffset			(33)
	, thresholdForLocusPresence		(0.75)
	, thresholdForKeywordCoverage	(1.0)
	//, findNewAlleles				(true)
	//, huntForStartStop			(true)
	//, extraBasesForStartStop		(18)
{
	AddOption(OPTION_ALLELEFILE,"allele file", alleleFileName_, Str::Path::Val(""));
	AddOption(OPTION_ALLELEINFOFILE,"allele info file", alleleInfoFileName_, Str::Path::Val(""));
    AddOption(OPTION_ALLELEFILETYPE, "allele file type", alleleFileType, alleleFileType);
    AddOption(OPTION_KMERTABLEFILE, "k-mer table file", kmerTableFile_, Str::Path::Val(""));
    AddOption(OPTION_CREATEKMERTABLE, "create k-mer table", createKMerTable_, createKMerTable_);
    AddListOption(OPTION_READFILES, "read files", readFiles);
	AddListOption(OPTION_READFILETYPES, "read file types (default is fastq.gz)", readFileTypes);
    AddOption(OPTION_ALGORITHM, "algorithm", algorithmType, algorithmType);
    AddOption(OPTION_K, "k-mer size", k, k);
    AddOption(OPTION_MINCOVERAGE, "minimum coverage", minCoverage, minCoverage);
    AddOption(OPTION_MINFWDCOVERAGE, "minimum forward coverage", minCoverageFwd, minCoverageFwd);
	AddOption(OPTION_MINREVCOVERAGE, "minimum reverse coverage", minCoverageRev, minCoverageRev);
	AddOption(OPTION_MINQUAL, "base quality threshold", minQual, minQual);
    AddOption(OPTION_MAXNVIOLATIONS, "maximum number of quality threshold violations", maxNViolations, maxNViolations);
	AddOption(OPTION_QUALOFFSET, "quality offset", qualOffset, qualOffset);
	AddOption(OPTION_THRESHOLDFORLOCUSPRESENCE, "keyword coverage threshold for calling a locus as present", thresholdForLocusPresence, thresholdForLocusPresence);
	AddOption(OPTION_THRESHOLDFORKEYWORDCOVERAGE, "keyword coverage threshold for calling a locus as a match", thresholdForKeywordCoverage, thresholdForKeywordCoverage);
	
	/*
	AddOption("findNewAlleles", "look for new alleles", findNewAlleles, findNewAlleles);
	AddListOption("startCodon", "start codons", startCodons);
	AddListOption("stopCodon", "stop codons", stopCodons);
	AddOption("huntForStartStop",  "hunt for start and stop codons", huntForStartStop, huntForStartStop);
	AddOption("extraBasesForStartStop",  "extra bases to hunt for start and stop codons", extraBasesForStartStop, extraBasesForStartStop);
	
	Init();
	*/
}
AlleleFinderSettings::~AlleleFinderSettings()
{
}
//void AlleleFinderSettings::Init()
//{
//    if (startCodons.empty()) {
//        startCodons.push_back(PM("ATG"));
//        startCodons.push_back(PM("GTG"));
//        startCodons.push_back(PM("TTG"));
//    }                                  
//    if (stopCodons.empty()) {
//        stopCodons.push_back(PM("TAG"));
//        stopCodons.push_back(PM("TAA"));
//        stopCodons.push_back(PM("TGA"));
//    }
//}
bool AlleleFinderSettings::ParseAndSetup(int argc, char* argv[], const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm)
{
    //parse the command line
    bool showHelp = ParseCmdLine(argc, argv, env, comm);

    //add missing file types with default file type
    for(size_t i = readFileTypes.size(); i < readFiles.size(); ++i)
        readFileTypes.push_back( PM("fastq.gz") );

    // Make sure path input is sane
    for ( auto& path : readFiles )
        sanitizePath( path );

	sanitizePath( alleleFileName_ );
	sanitizePath( alleleInfoFileName_ );
    sanitizePath( kmerTableFile_ );

	// provide a reasonable default if not available
	if (alleleInfoFileName_.empty())
	{
		// the allele info file is normally located besides the other allele files
		alleleInfoFileName_ = Str::Path::Val(alleleFileName_.parent_path() / "alleleinfo.txt");
	}

	//true = everything ok, false = show the help stuff
    return !showHelp;
}


bool AlleleFinderSettings::HasAlleleFile() const
{
    return ! alleleFileName_.empty();
}



AlleleFinderData::AlleleFinderData( const AlleleFinderSettings& settings, const communication::CalcCommunication& comm )
	: alleleInfoFile_(settings.alleleInfoFileName_, comm)
{
    CreateAlleleFile( settings, comm );
    CreateKMerTable ( settings, comm );
}

bool AlleleFinderData::HasAlleleFile() const
{
    return alleleFile_.get() != nullptr;
}

AlleleSequencesFile::ConstPtr AlleleFinderData::GetAlleleFile() const
{
    if ( ! alleleFile_ )
        throw InternalError( PM("Allele info file has not been initialized") );

    return alleleFile_;
}

AlleleSequencesFile::Ptr AlleleFinderData::GetAlleleFile()
{
    return boost::const_pointer_cast<AlleleSequencesFile>( static_cast<const AlleleFinderData*>(this)->GetAlleleFile() );
}

void AlleleFinderData::CreateAlleleFile( const AlleleFinderSettings& settings, const communication::CalcCommunication& comm )
{
    if ( ! settings.alleleFileName_.empty() ) {
        engine::LogBlock log( RawMessage(PM("Creating allele file from '%1'"), settings.alleleFileName_).c_str(), comm );

        alleleFile_.reset( new AlleleSequencesFile(settings.alleleFileName_, comm) );

        log.LogSuccess();
    }
}

Str::Path::Val AlleleFinderData::GetAlleleInfoFileName() const
{
    return alleleInfoFile_.GetFilename();
}

/**
    Create the KMer table. You should use this method only once, store the returned
    AlleleKMerTable::Ptr if you need to use it multiple times!

    \note Transfers ownership of returned pointer.
*/
void AlleleFinderData::CreateKMerTable( const AlleleFinderSettings& settings, const communication::CalcCommunication& comm )
{
    SeqFileReaderPtr reader = SeqFileReader::AutoDetect(GetAlleleFile()->GetFilename(), settings.alleleFileType)->Clone();
	comm.Send( communication::CalcMessage( Message("Opening file of type: '%1'...") << reader->GetFactoryType() ) );
    reader->init(GetAlleleFile()->GetFilename(), 5000000);

    Str::Text::Val qual;
    size_t i=0;

    //--- create the kmer table ---------------------------------------------------------------
    if (settings.createKMerTable_) {
        {
            engine::LogBlock log( RawMessage(PM("Initializing kmer table data from allele data '%1'"), GetAlleleFile()->GetFilename()).c_str(), comm );

            kmerTable_.reset( new AlleleKMerTable(settings.k) );
            kmerTable_->Fill( *reader, allelesInfo_, comm );

            log.LogSuccess();
        }

        if (!settings.kmerTableFile_.empty()) {
            engine::LogBlock log( RawMessage(PM("Saving kmer table to '%1'"), settings.kmerTableFile_).c_str(), comm );

            AlleleKMerTableIO tableIO( kmerTable_.get(), settings.kmerTableFile_, comm );
            tableIO.Store( comm );

            log.LogSuccess();
        }
    }
    //--- read in the kmer table --------------------------------------------------------------
    else {
        {
            engine::LogBlock log( RawMessage(PM("Reading kmer table from '%1'"), settings.kmerTableFile_).c_str(), comm );

            kmerTable_.reset( new AlleleKMerTable() );
            AlleleKMerTableIO tableIO( kmerTable_.get(), settings.kmerTableFile_, comm );
            tableIO.Read();

            log.LogSuccess();
        }

        //--- read in the allele names --------------------------------------------------------
        {
            engine::LogBlock log( RawMessage(PM("Reading allele names from '%1'"), GetAlleleFile()->GetFilename()).c_str(), comm );


            while (reader->hasMore()) {
                seq::NamedSequence sequence;
                reader->getNextSeq(sequence);
                allelesInfo_.push_back(AlleleKMerTable::ShortAlleleInfo(sequence.GetName(), sequence.GetData().GetLength()));
                ++i;
            }

            log.LogSuccess();
        }
    }

    kmerTable_->ReportStats( comm );
}



AlleleKMerTable::AllelesInfo&			  AlleleFinderData::GetAllelesInfo()
{
    return allelesInfo_;
}

const AlleleKMerTable::AllelesInfo&            AlleleFinderData::GetAllelesInfo() const
{
    return allelesInfo_;
}

AlleleKMerTable::Ptr AlleleFinderData::GetKMerTable()
{
    if ( ! kmerTable_ )
        throw InternalError( PM("KMer table has not been initialized") );

    return kmerTable_;
}

size_t AlleleFinderData::GetAlleleCount() const
{
    return allelesInfo_.size();
}

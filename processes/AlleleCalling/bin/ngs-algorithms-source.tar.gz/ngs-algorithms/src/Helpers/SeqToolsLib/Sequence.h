#pragma once

#include <iostream>
#include <memory>
#include "boost/shared_ptr.hpp"
#include "StringDef.h"


namespace seq
{

struct SequenceHash;


/**
    The mother class: encapsulates sequence data

    You an put Sequence objects in a vector directly, use either of these methods:

    \code
    vec.emplace_back();
    vec.push_back(std::move(seq));
    \endcode

    To use with boost algorithms:

    \code
    // Don't actually use this code, use StartsWithStartCodon instead
    const Str::Text::Val codon = "ATG";
    boost::algorithm::starts_with(std::make_pair(sequence.begin(), sequence.end()), codon);
    \endcode

*/
class Sequence
{
public:
	typedef boost::shared_ptr<Sequence> Ptr;
	typedef boost::shared_ptr<const Sequence> ConstPtr;

    typedef Str::Text::Val::iterator       iterator;
    typedef Str::Text::Val::const_iterator const_iterator;

public:
    Sequence();
    Sequence( Sequence&& rhs ) throw(); // noexcept not known in VS2012
    explicit Sequence( const Str::Text::Val& sequence );
    ~Sequence();
    
    Sequence& operator=( Sequence&& rhs );
    bool operator==( const Sequence& rhs ) const;
    bool operator!=( const Sequence& rhs ) const;

    // Inspection
    size_t      GetLength() const;
    bool        IsEmpty() const;
    Sequence    Sub(size_t start, size_t stop) const;
    const Str::Text::Val& ToString() const;
    bool        Contains( const Sequence& other ) const;
    Sequence    Copy() const;
    const char* c_str() const;
    size_t      Hash( const SequenceHash& hasher ) const;
    void        Swap( Sequence& other );

          char& operator[](size_t index);
    const char& operator[](size_t index) const;

    // Manipulation
    void      clear         ();
    Sequence& Resize        ( size_t size );
    Sequence& Set           ( const Str::Text::Val& sequence );
    Sequence& AppendVerbatim( const Str::Text::Val& string   );
    Sequence& AppendSequence( const Str::Text::Val& sequence );
    Sequence& Insert        ( size_t pos, const Str::Text::Val& sequence );
	/**
	 * \brief Trim ambiguous bases from both ends of the sequence.
	 *
	 * 
	 */
	Sequence& TrimAmbiguous();

    Sequence operator+( const Str::Text::Val& string   ) const;
    Sequence operator+( const Sequence&       sequence ) const;

    // Iterators
    iterator       begin();
    iterator       end();
    const_iterator begin() const;
    const_iterator end() const;
    const_iterator GetIter(size_t pos) const;

private:
    /**
        Not provided because inefficient, can be used without paying attention. If
        needed a Copy method should be added to the interface to make copy a 
        deliberate action. Otherwise: use move assignment/construction.
    */
    Sequence( const Sequence& rhs );
    Sequence& operator=( const Sequence& rhs );

private:
    struct OpaquePointer;
    std::unique_ptr<OpaquePointer> d_;
};


std::ostream& operator<<( std::ostream& stream, const Sequence& sequence );

bool          operator==( const Str::Text::Val& string, const Sequence& sequence );

Sequence::iterator       begin( Sequence& sequence );
Sequence::iterator       end  ( Sequence& sequence );
Sequence::const_iterator begin( const Sequence& sequence );
Sequence::const_iterator end  ( const Sequence& sequence );

inline void swap(Sequence& a, Sequence& b) { a.Swap(b); } // koenig lookup.

} // namespace seq

namespace std
{
    // specialize std::hash
    template <>
    struct hash<seq::Sequence> : private std::hash<Str::Text::Val>
    {
        typedef seq::Sequence argument_type;
        typedef std::size_t result_type;
        result_type operator()(const argument_type& s) const;
    };
}
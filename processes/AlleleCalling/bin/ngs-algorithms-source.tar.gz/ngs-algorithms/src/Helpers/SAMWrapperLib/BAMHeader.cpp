#include "stdafx.h"
#include "BAMHeader.h"
#include <sstream>

const char* BAM::Header::sortingText_[]={"unknown", "unsorted", "queryname", "coordinate"};

/**
 * Add a new reference sequence to the BAM header.
 * \returns The ReferenceID corresponding to the reference that was added. 
 */
BAM::BAMTypes::ReferenceID BAM::Header::AddReference(Str::ID::Arg name, size_t length)
{

    ReferenceInfo refInfo= {Str::ID::Val(name), length};
    references_.push_back(refInfo);

    return references_.size()-1;
}

namespace
{
struct bam_header_deleter {

    void operator()(bam_header_t* header) const
    {
        //bam_header_destroy shouldn't try to free these arrays, so we null them
        delete[] header->target_len;
        header->target_len = nullptr;

        delete[] header->target_name;
        header->target_name = nullptr;

        free(header->text);
        header->text = nullptr;

        bam_header_destroy(header);
    }
};
}

BAM::Header::RawHeaderPtr BAM::Header::CreateRawHeader() const
{
    RawHeaderPtr header(bam_header_init(), bam_header_deleter());

    //fill reference info

    size_t refCount=references_.size();

    const char** names=new const char*[refCount];
    uint32_t* lengths=new uint32_t[refCount];
    
    for(size_t m=0; m<refCount; m++) {

        names[m]=references_[m].name.c_str();
        lengths[m]=references_[m].length;
    }

    header->n_targets=refCount;
    header->target_len=lengths;
    header->target_name=const_cast<char**>(names);

    //build @HD
    
    std::stringstream ss;
    ss << "@HD\tVN:" << version_ << "\tSO:" << sortingText_[sorting_] << std::endl;

    const std::string headerText=ss.str();

    header->text=strdup(headerText.c_str());
    header->l_text=headerText.length();

    return header;
}


void BAM::Header::WriteToBAMFile(bamFile file) const
{
    //destruction of the header happens in bam_header_deleter
    bam_header_write(file, CreateRawHeader().get());
}

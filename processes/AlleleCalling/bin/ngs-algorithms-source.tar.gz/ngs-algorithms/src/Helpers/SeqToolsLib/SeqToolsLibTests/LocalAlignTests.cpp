#include "stdafx.h"

#include "boost/test/unit_test.hpp"
#include "align.h"

using namespace local_alignment;

struct LocalAlignTestFixture {

    LocalAlignTestFixture()
    {
        //read should incur no more that this much penalty
        params.threshold_maxpenalty = 5;
        //the weighted score should be at least 0.9 to accept the alignment
        params.threshold_seqid = 0.9;
    }

    void SetParamsToSilly()
    {
        params.maxoffset = 30;
        params.score_match = 1.0f;
        params.score_mismatch = 0.99f;

        params.score_opengap1 = 0.5f;
        params.score_extendgap1 = -0.2f;

        params.score_opengap2 = 0.7f;
        params.score_extendgap2 = 0.1f;

    }

    void SetParamsToSane()
    {
        params.maxoffset = 5;
        params.score_match = 1.0f;
        params.score_mismatch = -1.0f;

        params.score_opengap1 = -1.1f;
        params.score_extendgap1 = -2.1f;

        params.score_opengap2 = -1.2f;
        params.score_extendgap2 = -2.2f;

    }

    LAParams<float> params;
    LATable<float> laTable; //is it not "le table?"
    LABuffer alignedRead;
    LABuffer alignedRef;
    AlignScores scores;

    LA<float> aligner;
};

BOOST_FIXTURE_TEST_SUITE( localAlignTests, LocalAlignTestFixture );

BOOST_AUTO_TEST_CASE(local_align_exact)
{

    int pos = 12;
    const char* ref = "ACTACTGACTGGACTGCAATGCTGAATTCGGGAATCGACTGCACAACCAGT";
    const char* seq =             "ACTGCAATGCTGAATTCGG";

    SetParamsToSane();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, 12 );
    BOOST_CHECK( scores.accepted );
    BOOST_CHECK_EQUAL( scores.weightedscore, strlen(seq));
    BOOST_CHECK_EQUAL( scores.length, strlen(seq) );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, strlen(seq) );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 0 );
    BOOST_CHECK_EQUAL( scores.sequence_identity(), 1 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), strlen(seq) );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), seq );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), strlen(seq) );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), seq );
}

BOOST_AUTO_TEST_CASE(local_align_deletion)
{
    //a single base is removed from the read

    int pos = 14;
    const char* ref = "ACTACTTTGACTGGACTGCAATGCTGAATTCGGGAATCGACTGCT";
    const char* seq =               "ACTGCAATGCTAATTCGG";
    const char* rref =              "ACTGCAATGCTGAATTCGG";
    const char* rseq =              "ACTGCAATGCT-AATTCGG";

    SetParamsToSane();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, 14 );
    BOOST_CHECK( scores.accepted );
    BOOST_CHECK_CLOSE( scores.weightedscore, strlen(seq) + params.score_opengap1, 1 );
    BOOST_CHECK_EQUAL( scores.length, strlen(rseq) );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, strlen(seq) );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 1 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 0 );
    BOOST_CHECK( scores.sequence_identity() < 1 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), strlen(rseq) );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), rseq );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), strlen(rref) );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), rref );
}

BOOST_AUTO_TEST_CASE(local_align_insert)
{
    //a single base is inserted into the read

    int pos = 11;
    const char* ref = "ACTACGACTGGACTGCAATGCTGAATTCGGGAATCGACTGCACACACCAGT";
    const char* seq =            "ACTGCTAATGCTGAATTCGG";
    const char* rref =           "ACTGC-AATGCTGAATTCGG";

    SetParamsToSane();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, 11 );
    BOOST_CHECK( scores.accepted );
    BOOST_CHECK_CLOSE( scores.weightedscore, strlen(seq) - 1 + params.score_opengap2, 1 );
    BOOST_CHECK_EQUAL( scores.length, strlen(seq) );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, strlen(seq) - 1 );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 1 );
    BOOST_CHECK( scores.sequence_identity() < 1 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), strlen(seq) );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), seq );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), strlen(rref) );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), rref );
}

BOOST_AUTO_TEST_CASE(local_align_mutation)
{
    //a single base is mutated

    int pos = 12;
    const char* ref = "ACTACTGACTGGACTGCAATGCTGATCGGGAATCGACTGCACAACCAGT";
    const char* seq =             "ACTGCAATGCTTATCGG";
    const char* rref =            "ACTGCAATGCTGATCGG";

    SetParamsToSane();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, 12 );
    BOOST_CHECK( scores.accepted );
    BOOST_CHECK_CLOSE( scores.weightedscore, strlen(seq) - 1 + params.score_mismatch, 1 );
    BOOST_CHECK_EQUAL( scores.length, strlen(seq) );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, strlen(seq) - 1 );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 1 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 0 );
    BOOST_CHECK( scores.sequence_identity() < 1 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), strlen(seq) );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), seq );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), strlen(rref) );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), rref );
}

BOOST_AUTO_TEST_CASE(local_align_deletion_insert_mutation)
{
    //one insert, one deletion, one mutation

    int pos = 16;
    const char* ref = "ACTACTGACTTTCTGGACTGAATGCTGATCGGGAATCGACTGCACAACCAGT";
    const char* seq =                 "ACTGCAATACTGATGG";
    const char* rseq =                "ACTGCAATACTGAT-GG";
    const char* rref =                "ACTG-AATGCTGATCGG";

    SetParamsToSane();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, 16 );
    BOOST_CHECK( !scores.accepted );
    BOOST_CHECK_CLOSE( scores.weightedscore, strlen(rseq) - 3 + params.score_mismatch + params.score_opengap1 + params.score_opengap2, 1 );
    BOOST_CHECK_EQUAL( scores.length, strlen(rseq) );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, strlen(rseq) - 3 );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 1 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 1 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 1 );
    BOOST_CHECK( scores.sequence_identity() < 1 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), strlen(rseq) );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), rseq );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), strlen(rref) );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), rref );
}

BOOST_AUTO_TEST_CASE(local_align_offset_pos)
{

    //an exact match, but the initial position is off by the threshold

    int pos = 18 + 5;
    const char* ref = "ACTACTGACTGGACTGCAATGCTGAATTCGGGAATACTAGTTCGACTGCACAACCAGT";
    const char* seq =                   "ATGCTGAATTCGGGAATACTAGT";

    SetParamsToSane();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, 18 );
    BOOST_CHECK( scores.accepted );
    BOOST_CHECK_EQUAL( scores.weightedscore, strlen(seq));
    BOOST_CHECK_EQUAL( scores.length, strlen(seq) );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, strlen(seq) );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 0 );
    BOOST_CHECK_EQUAL( scores.sequence_identity(), 1 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), strlen(seq) );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), seq );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), strlen(seq) );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), seq );
}

BOOST_AUTO_TEST_CASE(local_align_offset_neg)
{

    //an exact match, but the initial position is off by the threshold

    int pos = 8 - 5;
    const char* ref = "ACTACTGACTGGACTGCAATGCTGAATTCGGGAATACTAGTTCGACTGCACAACCAGT";
    const char* seq =         "CTGGACTGCAATGCTGAAT";

    SetParamsToSane();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, 8 );
    BOOST_CHECK( scores.accepted );
    BOOST_CHECK_EQUAL( scores.weightedscore, strlen(seq));
    BOOST_CHECK_EQUAL( scores.length, strlen(seq) );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, strlen(seq) );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 0 );
    BOOST_CHECK_EQUAL( scores.sequence_identity(), 1 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), strlen(seq) );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), seq );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), strlen(seq) );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), seq );
}

BOOST_AUTO_TEST_CASE(local_align_starts_before)
{
    //read starts before reference

    int pos = -1; //oops
    const char* ref =    "AGTGACT";
    const char* seq =  "TCAGT";
    const char* rref = "NNAGT";

    SetParamsToSane();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, -2 );
    BOOST_CHECK( !scores.accepted );
    BOOST_CHECK_EQUAL( scores.weightedscore, strlen(seq) - 2 );
    BOOST_CHECK_EQUAL( scores.length, strlen(seq) );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 2 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, strlen(seq) - 2 );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 0 );
    BOOST_CHECK_EQUAL( scores.sequence_identity(), 3.0 / 5.0 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), strlen(seq) );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), seq );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), strlen(rref) );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), rref );
}

BOOST_AUTO_TEST_CASE(local_align_ends_after)
{

    //read ends after reference

    int pos = 11; //oops, accidental offset of one
    const char* ref =  "ACTACTGACTGTGCACAACCAGT";
    const char* seq =             "TGCACAACCAGTGCTA";
    const char* rref =            "TGCACAACCAGTNNNN";

    SetParamsToSane();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, 11 );
    BOOST_CHECK( !scores.accepted );
    BOOST_CHECK_EQUAL( scores.weightedscore, strlen(seq) - 4 );
    BOOST_CHECK_EQUAL( scores.length, strlen(seq) );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 4 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, strlen(seq) - 4 );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 0 );
    BOOST_CHECK_CLOSE( scores.sequence_identity(), 12.0 / 16.0, 1 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), strlen(seq) );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), seq );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), strlen(rref) );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), rref );
}


BOOST_AUTO_TEST_CASE(local_align_ends_before)
{
    //read starts and ends before the reference

    int pos = -10;
    const char* ref =           "ACTACTGACTGGACTGCAAT";
    const char* seq = "ACTAGTCGAA";

    SetParamsToSane();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, -10 );
    BOOST_CHECK( !scores.accepted );
    BOOST_CHECK_EQUAL( scores.weightedscore, 0);
    BOOST_CHECK_EQUAL( scores.length, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, 0 );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 0 );
    BOOST_CHECK_EQUAL( scores.sequence_identity(), 0 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), 0 );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), "" );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), 0 );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), "" );
}

BOOST_AUTO_TEST_CASE(local_align_starts_after)
{
    //read starts and ends before the reference

    int pos = 4;
    const char* ref = "ACTA";
    const char* seq =     "ACCGAA";

    SetParamsToSane();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, 4 );
    BOOST_CHECK( !scores.accepted );
    BOOST_CHECK_EQUAL( scores.weightedscore, 0);
    BOOST_CHECK_EQUAL( scores.length, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, 0 );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 0 );
    BOOST_CHECK_EQUAL( scores.sequence_identity(), 0 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), 0 );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), "" );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), 0 );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), "" );
}

BOOST_AUTO_TEST_CASE(local_align_empty_seq)
{
    //read starts and ends before the reference

    int pos = std::numeric_limits<int>::max();
    const char* ref = "ACTACTACGTCAAACCTGTGG";
    const char* seq = "";

    SetParamsToSane();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, std::numeric_limits<int>::max() );
    BOOST_CHECK( !scores.accepted );
    BOOST_CHECK_EQUAL( scores.weightedscore, 0);
    BOOST_CHECK_EQUAL( scores.length, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, 0 );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 0 );
    BOOST_CHECK_EQUAL( scores.sequence_identity(), 0 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), 0 );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), "" );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), 0 );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), "" );
}

BOOST_AUTO_TEST_CASE(local_align_empty_ref)
{
    //read starts and ends before the reference

    int pos = 5;
    const char* ref = "";
    const char* seq = "ACTACTGCCTGTGG";

    SetParamsToSane();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, 5 );
    BOOST_CHECK( !scores.accepted );
    BOOST_CHECK_EQUAL( scores.weightedscore, 0);
    BOOST_CHECK_EQUAL( scores.length, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, 0 );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 0 );
    BOOST_CHECK_EQUAL( scores.sequence_identity(), 0 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), 0 );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), "" );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), 0 );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), "" );
}

BOOST_AUTO_TEST_CASE(local_align_ref_is_substring)
{
    //reference is a substring of the read; contains junk

    int pos = -2;
    const char* ref =    "efgh";
    const char* seq =  "cdefghijk";
    const char* rseq = "NNefghNNN";

    SetParamsToSane();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, -2 );
    BOOST_CHECK( !scores.accepted );
    BOOST_CHECK_EQUAL( scores.weightedscore, strlen(ref));
    BOOST_CHECK_EQUAL( scores.length, strlen(seq) );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 2 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 3 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, strlen(ref) );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 0 );
    BOOST_CHECK_EQUAL( scores.sequence_identity(), 4.0 / 9.0 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), strlen(seq) );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), seq );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), strlen(rseq) );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), rseq );
}

BOOST_AUTO_TEST_CASE(local_align_silly)
{
    //silly input, should always produce the same (silly) output

    int pos = 10;
    const char* ref =  "dit is een string met ham en kaas";
    const char* seq =            "sinterklaas";
    const char* rseq = "s-i-n-t-e-r-k-l-a-a-s-";
    const char* rref = "di-t- -i-s- -e-e-n- -s";

    SetParamsToSilly();

    aligner.align(seq, nullptr, strlen(seq), ref, strlen(ref), params, laTable, scores, pos, alignedRead, alignedRef);

    BOOST_CHECK_EQUAL( pos, 0 );
    BOOST_CHECK( !scores.accepted );
    BOOST_CHECK_CLOSE( scores.weightedscore, 13.48, 1 );
    BOOST_CHECK_EQUAL( scores.length, strlen(rseq) );
    BOOST_CHECK_EQUAL( scores.n_begingaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_begingaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps1, 0 );
    BOOST_CHECK_EQUAL( scores.n_endgaps2, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap1, 0 );
    BOOST_CHECK_EQUAL( scores.n_extendgap2, 0 );
    BOOST_CHECK_EQUAL( scores.n_matches, 0 );
    BOOST_CHECK_EQUAL( scores.n_mismatches, 1 );
    BOOST_CHECK_EQUAL( scores.n_opengap1, 11 );
    BOOST_CHECK_EQUAL( scores.n_opengap2, 10 );
    BOOST_CHECK_CLOSE( scores.sequence_identity(), 0, 1 );

    alignedRead.startFwd();
    alignedRef.startFwd();

    BOOST_CHECK_EQUAL( alignedRead.getFwdSize(), strlen(rseq) );
    BOOST_CHECK_EQUAL( alignedRead.getFwdPos(), rseq );

    BOOST_CHECK_EQUAL( alignedRef.getFwdSize(), strlen(rref) );
    BOOST_CHECK_EQUAL( alignedRef.getFwdPos(), rref );
}

BOOST_AUTO_TEST_SUITE_END();


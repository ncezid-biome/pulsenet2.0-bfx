#pragma once

#include "ACGTTable.h"
#include "ACGTacgtTable.h"


namespace seq
{


template<typename T_It>
bool AreAllBasesACGTacgt( T_It begin, T_It end  )
{
    const ACGTacgtTable::Table& table = ACGTacgtTable::Get();

    return std::all_of( begin, end, [&table](char base){ return table[base]; });
}

template<typename T_It>
size_t CountNonACGT( T_It begin, T_It end  )
{
    const ACGTTable::Table& table = ACGTTable::Get();

    size_t cnt = 0;
    // Use "it" because we need begin later on for the subtraction
    for( T_It it = begin; it != end; ++it )
        cnt += table[*it];

    return end - begin - cnt; 
}

template<typename T_It>
bool AreAllBasesN( T_It begin, T_It end  )
{
    for ( ; begin < end; ++begin )
        if ( *begin != 'N' )
            return false;

    return true;
}


} // namespace seq

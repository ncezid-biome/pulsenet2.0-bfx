#pragma once

#include "SequenceFiles.h"


class SplitSequenceFiles
{
public:
    SequenceFiles singleFiles;
    SequenceFiles pairedFiles;

    bool IsEmpty() const;
    void Log( const communication::CalcCommunication& comm ) const;
};


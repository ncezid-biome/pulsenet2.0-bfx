/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#ifndef SETTINGS_FILE_H
#define SETTINGS_FILE_H

#include "settings.h"
#include <unordered_map>


/*
	A settings file is a text file with one setting per line. Order is of no importance. 
	The structure of each line is:
		<setting identifier>=<setting value> 
*/

class SettingsFromFile : public Settings {
private:
	std::unordered_map<std::string, std::string> settings_;
private:
	void read(Str::Path::Arg filename);
public:
	SettingsFromFile(Str::Path::Arg file);
	~SettingsFromFile();
	
	virtual bool hasSetting(const Id& id) const;
	virtual Val getSetting(const Id& id) const;
};

#endif

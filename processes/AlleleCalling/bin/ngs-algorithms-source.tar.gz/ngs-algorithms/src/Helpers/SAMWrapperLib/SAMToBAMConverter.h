#pragma once
#include <PathDef.h>
#include "SAMWrapper.h"

namespace BAM
{

class STW_DLLPORT SAMToBAMConverter
{

public:

    void ConvertFile(const Str::Path::Val& input, const Str::Path::Val& output);

private:
    static bool CopyReads(samfile_t* samInput, samfile_t* bamOutput);
};

}








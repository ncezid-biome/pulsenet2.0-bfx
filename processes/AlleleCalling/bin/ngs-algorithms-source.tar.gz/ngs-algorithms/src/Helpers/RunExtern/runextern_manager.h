#pragma once
#include "userbreak.h"

#include "runextern_application.h"
#include "runextern_listener.h"
#include "runextern_process.h"
#include "runextern_processPool.h"


namespace runextern
{


class ExternAppManager
{		
public:
    ExternAppManager();

	/**
	 * \brief Run an ExternalApp object.
	 * \remarks Prefer #runCmd method.
	 */
    void runApp(const ExternalApp& app, const ProcessInfo& info, Reporter& comm, bool interpretXml=false);

	/**
	 * \brief Starts a child process executing the given command line.
	 * \return The exit code of the child process.
	 * \remarks Blocks execution until completion of child process.
	 */
    int runCmd(const ProcessCmdLine& cmdline, const ProcessInfo& info, Reporter& comm, bool interpretXml=false);

private:
    ProcessPool::Ptr processes_;
};


}

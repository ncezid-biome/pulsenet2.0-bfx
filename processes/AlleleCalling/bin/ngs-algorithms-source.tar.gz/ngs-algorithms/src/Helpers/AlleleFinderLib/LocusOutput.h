#pragma once
#include "StringDef.h"
#include <unordered_map>
#include "xmlwrapper.h"

class LocusOutput {
public:
    struct Allele {
        int id;
        double kwCoverage;
        double sequenceIdentity, eValue;
        int bitScore;
        int start, stop;
		double repeatScore;
        int alignmentLength;
        int nonACGT;
        bool fwd;
        Str::Text::Val contigId;		
        int nMismatches;
        int nGapOpens;		
        Str::Text::Val sequence, seqBefore, seqAfter;
        bool requiresStartStop, startsWithStart, stopsWithStop, fullLength, hasInternalStop;


        Allele() : id(-1), sequenceIdentity(-1), eValue(-1), bitScore(-1), start(-1), stop(-1), repeatScore(0), alignmentLength(-1), fwd(true), nMismatches(-1), nGapOpens(-1), kwCoverage(-1), nonACGT(-1), requiresStartStop(false), startsWithStart(false), stopsWithStop(false), fullLength(false), hasInternalStop(false) {}
    };
    struct Locus {
        Str::Text::Val locus;
        std::vector<Allele> alleles;
    };
private:
    typedef std::unordered_map<Str::Text::Val, Locus> LocusMap;
	LocusMap loci_;
public:
    LocusOutput();
    ~LocusOutput();

    void addLocus(const Locus& locus);
    void addAllele(Str::Text::Arg locus, const Allele& allele);

    void toString(Str::Text::Val& xml) const;
    void toXml(XmlBlock& n) const;

	typedef LocusMap::const_iterator const_iterator;
	const_iterator begin() const { return loci_.begin(); }
	const_iterator end() const { return loci_.end(); }
};
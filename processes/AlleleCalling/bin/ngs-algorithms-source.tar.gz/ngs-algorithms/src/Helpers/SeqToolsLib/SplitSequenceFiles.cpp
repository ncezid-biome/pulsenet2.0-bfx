#include "stdafx.h"

#include "SplitSequenceFiles.h"




bool SplitSequenceFiles::IsEmpty() const
{
    return singleFiles.isEmpty() && pairedFiles.isEmpty();
}

void SplitSequenceFiles::Log(const communication::CalcCommunication& comm) const
{
    singleFiles.Log( PM("Single-end files"), comm );
    pairedFiles.Log( PM("Paired-end files"), comm );
}


#pragma once
/**
    \file SequenceRangeManip.h

    Associated tests in SequenceRangeManipTests
*/

#include <algorithm>

#include "boost/algorithm/string/classification.hpp"
#include "boost/algorithm/string/split.hpp"
#include "boost/algorithm/string/case_conv.hpp"

#include "Checks.h"

#include "RevComplTable.h"
#include "CapitalTable.h"
#include "IUPACCapitalTable.h"


namespace seq
{

template<typename T_it>
void Reverse( T_it begin, T_it end )
{
    std::reverse(begin, end);
}

template<typename T_container>
void Reverse( T_container& container )
{
    std::reverse(begin(container), end(container));
}

template<typename T_it>
void Complement( T_it begin, T_it end )
{
    const RevComplTable::Table& table = RevComplTable::Get();
    std::for_each( begin, end, [&table](char& base){ base = table[base]; } );
}

template<typename T_container>
void Complement( T_container& container )
{
    const RevComplTable::Table& table = RevComplTable::Get();
    std::for_each( begin(container), end(container), [&table](char& base){ base = table[base]; } );
}

template<typename T_it>
void ReverseComplement( T_it begin, T_it end )
{
    if (begin == end)
        return;
    
    const RevComplTable::Table& table = RevComplTable::Get();

    if (end - begin == 1) {
        *begin = table[*begin];
        return;
    }

    // Move end to valid position
    --end;
    for ( ; begin <= end; ++begin, --end ){
        char tmp = *begin;
        *begin = table[*end];
        *end   = table[tmp];
    }

    // in case of an odd length, the last round of the for loop will have begin == end.
    // the basepair is reverse complemented twice, but that's alright as a copy has been taken.
}

template<typename T_container>
void ReverseComplement( T_container& container )
{
    ReverseComplement( begin(container), end(container) );
}

/**
    Required: end-begin == destinationend - destinationbegin

    \sa ReverseComplement
    \note Different source and dest iterators: former should be const, latter non-const
*/
template<typename T_itsource, typename T_itdest>
void ReverseComplementCopy( T_itsource begin, T_itsource end, T_itdest destinationbegin, T_itdest destinationend )
{
    if (begin == end)
        return;

    check::IsEqual(destinationend-destinationbegin, end-begin, PM("Invalid iterators for ReverseComplementCopy"));

    const RevComplTable::Table& table = RevComplTable::Get();

    for ( ; begin < end; ++begin ){
        // On first pass: moves end to valid end position. At the end: good it's here
        // because when ++begin becomes equal to end, --destinationend would
        // take us off of the beginning of the string -> invalid iterator.
        --destinationend;

        *destinationend = table[*begin];
    }

    // in case of an odd length, the last round of the for loop will have begin == end.
    // the basepair is reverse complemented twice, but that's alright as a copy has been taken.
}

template<typename T_Container>
void ReverseComplementCopy( const T_Container& sequence, T_Container& destination )
{
    ReverseComplementCopy(begin(sequence), end(sequence), begin(destination), end(destination));
}

/**
    Replaces non-ACTG bases with N!

    \sa SequenceToUpperCase
*/
template<typename T_it>
void ActgToUpperCase( T_it begin, T_it end )
{
    const CapitalTable::Table& table = CapitalTable::Get();
    std::for_each( begin, end, [&table](char& base){ base = table[base]; } );
}

template<typename T_container>
void ActgToUpperCase( T_container& container )
{
    ActgToUpperCase( begin(container), end(container) );
}

/**
    Makes the sequence upper-case, does not check the bases themselves

    \sa ActgToUpperCase
*/
template<typename T_it>
void SequenceToUpperCase( T_it begin, T_it end )
{
    // Convert to upper: clear the '32' bit, 0x20 in hex. And with the
    // inverted bit string (~).
    for ( T_it it = begin; it != end; ++it )
    {
        if (*it >= 'a' && *it <= 'z')  // let's keep it sane! we can has spacez an dashez and othr things.
        {
            *it &= ~0x20;
        }
    }
}

template<typename T_container>
void SequenceToUpperCase( T_container& container )
{
    SequenceToUpperCase( begin(container), end(container) );
}

/**
    No ref: uses move constructor or copy constructor, then do what you want.
*/
template<typename T_container>
T_container SequenceToUpperCaseCopy( T_container container )
{
    SequenceToUpperCase( begin(container), end(container) );
    return container;
}

/**
    Split a sequence into subsequences containing only acgtACGT bases. The split occurs on every
    non-acgtACGT base. No empty subsequences are present in the output.
*/
template<typename T_it>
Str::Text::Vec SplitIntoACGTPieces(T_it begin, T_it end)
{
    Str::Text::Vec parts;

    // First skip invalid chars in front/at the back, otherwise empty parts are created by boost::split
    auto is_any_of_acgt_ACGT = boost::is_any_of(PM("acgtACGT"));
    while( begin < end && !is_any_of_acgt_ACGT(*begin) )
        ++begin;

    while( begin < end && !is_any_of_acgt_ACGT(*(end-1)) )
        --end;

    // Use token_compress_on to collapse multiple separator occurrences into a single separation
    auto range = boost::iterator_range<T_it>(begin,end);
    boost::algorithm::split( parts, range,
                             ! is_any_of_acgt_ACGT,
                             boost::algorithm::token_compress_on );

    return parts;
}

template<typename T_container>
Str::Text::Vec SplitIntoACGTPieces(const T_container& container)
{
    return SplitIntoACGTPieces(begin(container), end(container));
}

/**
    Replaces non-UIPAC bases with N!

    \sa SequenceToUpperCase
*/
template<typename T_it>
void IUPACToUpperCase( T_it begin, T_it end )
{
    const IUPACCapitalTable::Table& table = IUPACCapitalTable::Get();
    std::for_each( begin, end, [&table](char& base){ base = table[base]; } );
}

template<typename T_container>
void IUPACToUpperCase( T_container& container )
{
    IUPACToUpperCase( begin(container), end(container) );
}


} // namespace seq

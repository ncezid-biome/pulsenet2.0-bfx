#pragma once

#include "BAMIterator.h"

namespace BAM
{

class Read
{

public:
    Read();

    Read(Read&& other);

    Read& operator= (Read&& other);

    virtual ~Read();

    bool ReadFrom(BAM::Iterator& it);

    bam1_t* operator * () const;

    bool IsFirstRead() const;

    bool IsLastRead() const;

    bool isPairedEnd() const;

public:
    bam1_t* read;

private:
    Read (const Read& other);
    Read& operator= (const Read& other);

};

}


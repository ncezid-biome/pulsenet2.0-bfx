#pragma once

#include "boost/shared_ptr.hpp"
#include "boost/make_shared.hpp"


class ThreadSafeFileWriters;
typedef boost::shared_ptr<ThreadSafeFileWriters> ThreadSafeFileWritersPtr;

class SeqFileWriter;
typedef boost::shared_ptr<SeqFileWriter> SeqFileWriterPtr;

#include "stdafx.h"

#include "NamedSequence.h"
#include "Sequence.h"


namespace seq
{
 
struct NamedSequence::OpaquePointer
{
    OpaquePointer()
        : name()
        , data()
    {
    }

    OpaquePointer(const Str::Text::Val& name, const Str::Text::Val& sequence)
        : name( name )
        , data( sequence )
    {
    }

    Str::Text::Val name;
    Sequence       data;
};

NamedSequence::NamedSequence()
    : d_( new OpaquePointer() )
{
}

NamedSequence::NamedSequence(const Str::Text::Val& name, const Str::Text::Val& sequence)
    : d_( new OpaquePointer(name, sequence) )
{
}

NamedSequence::NamedSequence(NamedSequence&& rhs) throw()
    : d_( std::move(rhs.d_) )
{
}

NamedSequence::~NamedSequence() throw()
{
}

const Str::Text::Val& NamedSequence::GetName() const
{
    return d_->name;
}

Sequence& NamedSequence::GetData()
{
    return d_->data;
}

const Sequence& NamedSequence::GetData() const
{
    return d_->data;
}

bool NamedSequence::IsEmpty() const
{
    return GetName().empty() && GetData().IsEmpty();
}

/**
    Move assignment, cheap assignmnet of a temporary object
    
    \code
    sequence = NamedSequence(...);
    \endcode
*/
NamedSequence& NamedSequence::operator=(NamedSequence&& rhs)
{
    d_ = std::move( rhs.d_ );
    return *this;
}



} // namespace seq

#pragma once
#include "AlignmentWithScore.h"

namespace SeqBAM
{

namespace Bowtie2Filter
{

class AlignmentPair
{

public:
    typedef int MatchPosition;

public:
    AlignmentPair();

    AlignmentPair(const AlignmentWithScore* one, const AlignmentWithScore* two);

    MatchPosition matchPosition() const;

public:
    const AlignmentWithScore* first;
    const AlignmentWithScore* second;
    double score;

private:
    MatchPosition pos;
};

}
}
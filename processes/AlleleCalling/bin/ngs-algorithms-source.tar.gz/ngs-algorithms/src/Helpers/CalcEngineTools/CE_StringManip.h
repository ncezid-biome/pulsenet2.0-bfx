#pragma once

#include "StringDef.h"


namespace engine
{

namespace tools
{


Str::Text::Val getFormattedTimeString();


} // namespace tools

} // namespace engine
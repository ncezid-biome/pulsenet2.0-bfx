#pragma once

#include <cstdint>
#include "BAMLevelFileTypes.h"

namespace BAM
{

class LevelFile: public LevelFileTypes
{

public:

//pack the structs below tightly
#pragma pack(1)

    typedef struct {
        char signature[4];
        FileOffset blockHeadersOffset;
        uint32_t numberOfBlockHeaders;
    } Header;

    typedef struct {
        BlockAddress blockAddress:48;
        FileOffset fileOffset;
    } BlockHeader;

    typedef struct {
        BlockOffset blockOffset;
        ReadLevel readLevel;
    } ReadInfo;

#pragma pack()

protected:

    inline static BlockAddress GetBlockAddress(BamTold bamTold)
    {
        return bamTold >> 16;
    }

    inline static BlockOffset GetBlockOffset(BamTold bamTold)
    {
        return bamTold & 0xFFFF;
    }

};

}
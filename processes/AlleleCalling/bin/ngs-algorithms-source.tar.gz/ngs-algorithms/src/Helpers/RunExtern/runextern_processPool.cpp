#include "stdafx.h"

#include "runextern_processPool.h"

#include "exception.h"

#ifndef AMGNU
#include "WindowsProcessPool.h"
#else
#include "UnixProcessPool.h"
#endif


namespace runextern
{
    

ProcessPool::Ptr ProcessPool::Create()
{
	// TODO add BoostProcessPool, which encapsulates Boost.Process
	// use a default argument to maintain previous default functionality

#ifndef AMGNU
    return Ptr(new WindowsProcessPool());
#else
    return Ptr(new UnixProcessPool());
#endif
}


} // namespace runextern

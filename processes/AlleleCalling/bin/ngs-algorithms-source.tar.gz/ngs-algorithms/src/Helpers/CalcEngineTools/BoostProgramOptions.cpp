#include "stdafx.h"
/**
    \file BoostProgramOptions.cpp

    Contains definitions for stuff not found in boost_program_options.dll, giving
    linker errors. Include this file in your executable solution when using
    the boost program_options library

    \note This file should have become obsolete with the cleaner macro defined in UseBoostProgramOptions.h. 
          The problem with using that macro is that it prevents delay-loading the boost program_options
          dll -> sticking with this shabby solution for now.
*/

#include "boost/program_options.hpp"

// On Windows this is needed, on Linux it gives a crash because of a double free. Don't
// know why the behavior is different as the boost version is the same and the linking
// is also the same.
#ifndef AMGNU
namespace boost
{
    namespace program_options
    {
        //BOOST_PROGRAM_OPTIONS_DECL std::string arg("arg");
        //BOOST_PROGRAM_OPTIONS_DECL const unsigned options_description::m_default_line_length(80);
    } // namespace program_options
} // namespace boost
#endif

#pragma once

#include "exception.h"


/**
    Thrown if a child (donwnload) process has exited with a non-zero exit code
*/
class ChildProcessExitWithErrorException : public KError
{
public:
    ChildProcessExitWithErrorException( int exitcode )
        : KError( PM("Child process exited with exit code %1\n")  )
        , exitcode ( exitcode  )
    {
        (*this) << exitcode;
    }

    int exitcode;
};

#pragma once
/**
    \file runextern_UnixDefines.h

    Some defines that are present in Windows but not in Unix-based systems
*/


#ifdef AMGNU

#define ERROR_NOT_ENOUGH_MEMORY 8L
#define ERROR_BROKEN_PIPE       109L
#define ERROR_PROCESS_ABORTED   1067L

#endif

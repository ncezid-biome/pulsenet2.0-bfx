#ifndef INCLUDED_GETOPT_PORT_H
#define INCLUDED_GETOPT_PORT_H

//#ifndef GETOPT_STATIC_LIB
//#  ifdef GETOPT_BUILD
//#    define GETOPT_DLLPORT __declspec(dllexport)
//#  else
//#    define GETOPT_DLLPORT __declspec(dllimport)
//#  endif
//#else
#  define GETOPT_DLLPORT
//#endif

#if defined(__cplusplus)
extern "C" {
#endif

extern const int no_argument;
extern const int required_argument;
extern const int optional_argument;

GETOPT_DLLPORT extern char* optarg;
GETOPT_DLLPORT extern int optind, opterr, optopt;

struct option {
  const char* name;
  int has_arg;
  int* flag;
  int val;
};

GETOPT_DLLPORT int getopt(int argc, char* const argv[], const char* optstring);

GETOPT_DLLPORT int getopt_long(int argc, char* const argv[],
  const char* optstring, const struct option* longopts, int* longindex);

#if defined(__cplusplus)
}
#endif

#endif // INCLUDED_GETOPT_PORT_H

#pragma once

#include "PathDef.h"
#include "CalcCommunication.h"


class SequenceFile
{
public:
    Str::Path::Vec files;
    Str::ID::Val   filetype;
    bool paired;
};

class SequenceFiles
{
public:
    std::vector<SequenceFile> files;

    void merge(const SequenceFiles& other);
    bool isEmpty() const;
    void Log( const Str::Text::Val& info, const communication::CalcCommunication& comm ) const;
};

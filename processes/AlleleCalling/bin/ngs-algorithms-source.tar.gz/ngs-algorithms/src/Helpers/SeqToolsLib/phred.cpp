#include "stdafx.h"
#include "phred.h"
#include "helper.h"
#include <cmath>

double errorprobs[64];

char toPhredQual(double err)
{
	ASSERT(err>=0.0); ASSERT(err<=1.0);
	if (err==0) return 63;
	err= floor(-log(err) / PHREDC); 
	if (err>63.0) return 63;
	else return ncast<char>(err);
}
double toErrorProb(char phredQual)
{
	//ASSERT(phredQual>=0); ASSERT(phredQual<=63);
	//return errorprobs[phredQual];
	return exp(- PHREDC * phredQual);
}
void initErrorProbs() 
{
	for(char i=0; i<=63; ++i) errorprobs[i]=exp(- PHREDC * i);
}
#pragma once
/**
    \file CE_CommunicationHandlers.h

    Declarations for handlers for the messages in CE_Communication.h
*/

#include "CalcListener.h"

#include "CE_LogMessageType.h"


namespace communication
{


class CalcCreateResultFileHandler: public communication::CalcInfoHandler
{
public:
    typedef std::function<void (const Str::Text::Val&, const Str::Text::Val&, const Str::ID::Val&)> Functor;

public:
    CalcCreateResultFileHandler( Functor f );

    virtual Ptr  Clone() const override;
    virtual Str::Text::Val GetName() const override;

    virtual void Handle() override;
    virtual void FromXml(pugi::xml_node& nd) override;

private:
    Functor        f_;
    Str::Text::Val filename_;
    Str::Text::Val content_;
	Str::ID::Val   compressionTypeId_;
};

class CalcAppendLogfileHandler: public communication::CalcInfoHandler
{
public:
    typedef std::function<void (const Str::Text::Val&,
                                const engine::LogMessageType&,
                                const Str::Text::Val&)> Functor;

public:
    CalcAppendLogfileHandler( Functor f );

    virtual Ptr  Clone() const override;
    virtual Str::Text::Val GetName() const override;

    virtual void Handle() override;
    virtual void FromXml(pugi::xml_node& nd) override;

private:
    Functor             f_;
    Str::Text::Val      filename_;
    engine::LogMessageType messageType_;
    Str::Text::Val      content_;
};

class CalcLogMessageHandler: public communication::CalcInfoHandler
{
public:
    typedef std::function<void (const engine::LogMessageType&,
                                const Str::Text::Val&)> Functor;

public:
    CalcLogMessageHandler( Functor f );

    virtual Ptr  Clone() const override;
    virtual Str::Text::Val GetName() const override;

    virtual void Handle() override;
    virtual void FromXml(pugi::xml_node& nd) override;

private:
    Functor             f_;
    engine::LogMessageType messageType_;
    Str::Text::Val      content_;
};


} // namespace communication

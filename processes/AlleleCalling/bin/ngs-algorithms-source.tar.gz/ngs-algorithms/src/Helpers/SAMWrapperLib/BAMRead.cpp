#include "stdafx.h"
#include "BAMRead.h"
#include "SAMWrapper.h"

namespace BAM
{


Read::Read() : read(stl_bam_init1())
{

}

Read::Read(Read&& other): read(other.read)
{
    other.read = nullptr;
}

Read& Read::operator=(Read&& other)
{
    std::swap(read, other.read);
    return *this;
}

bam1_t* Read::operator*() const
{
    return read;
}

Read::~Read()
{
    stl_bam_destroy1(read);
}

bool Read::ReadFrom(BAM::Iterator& it)
{
    return it.GetNextReadInto(read);
}

bool Read::IsFirstRead() const
{
    return (read->core.flag & (BAM_FPAIRED | BAM_FREAD1)) == (BAM_FPAIRED | BAM_FREAD1);
}

bool Read::IsLastRead() const
{
    return (read->core.flag & (BAM_FPAIRED | BAM_FREAD2)) == (BAM_FPAIRED | BAM_FREAD2);
}

bool Read::isPairedEnd() const
{
    return read->core.flag & BAM_FPAIRED;
}

}

#include "stdafx.h"

#include "boost/test/unit_test.hpp"
#include "Bowtie2DiscriminationFilter.h"
#include "BAMIterator.h"
#include "BAMCigar.h"

struct Bowtie2FilterTestsFixture {


    Bowtie2FilterTestsFixture(): defSett(0.5, 0.251, 10000), lowSett(0.5, 0.01, 10000)
    {
    }

    Str::Path::Val getDataFilePath(const Str::Text::Val& filename)
    {
        //this needs compiler flag /FC to get the full path
        Str::Path::Val thisFile(__FILE__);

        return (thisFile.parent_path() / "Data" / filename);
    }

    void expectRead(BAM::Iterator& it, Str::Text::Arg name, Str::Text::Arg cigar, int pos=0)
    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(Str::Text::Val(bam1_qname(al)), Str::Text::Val(name));
        BOOST_CHECK_EQUAL(BAM::Cigar::ToRLEString(al), Str::Text::Val(cigar));
        BOOST_CHECK_EQUAL(pos, al->core.pos);
    }

    SeqBAM::Bowtie2Filter::DiscriminationSettings defSett;
    SeqBAM::Bowtie2Filter::DiscriminationSettings lowSett;
};

BOOST_FIXTURE_TEST_SUITE( Bowtie2FilterTests, Bowtie2FilterTestsFixture );

BOOST_AUTO_TEST_CASE(filter_single)
{
    Str::Path::Val outFile = GetTempDir() / "filter_single.bam";

    SeqBAM::Bowtie2Filter::DiscriminationFilter filter(defSett);
    filter.Filter(getDataFilePath("filter_single.sam"), outFile);

    BAM::Iterator it;
    it.Open(outFile);

    bam1_t* al = it.GetNextRead();

    BOOST_CHECK_EQUAL(bam1_qname(al), "r1");

    BOOST_CHECK_EQUAL(al->core.pos, 319923);
    BOOST_CHECK_EQUAL(al->core.mpos, -1);

    BOOST_CHECK_EQUAL(BAM::Cigar::ToRLEString(al), "70M");

    BOOST_CHECK_CLOSE(bam_aux2f(bam_aux_get(al, "DI")), 0.257142872, 1);

    //there are 12 alignments, but two are coinciding and one has a score that is too low
    BOOST_CHECK_EQUAL(bam_aux2i(bam_aux_get(al, "DG")), 11);

    //the chosen one has a perfect score
    BOOST_CHECK_EQUAL(bam_aux2f(bam_aux_get(al, "SC")), 1);
    BOOST_CHECK_EQUAL(bam_aux2i(bam_aux_get(al, "AS")), 0);

    //there should be only one (chops off head)
    BOOST_CHECK_EQUAL(it.GetNextRead() == nullptr, true);

    it.Close();
}

BOOST_AUTO_TEST_CASE(filter_group)
{
    Str::Path::Val outFile = GetTempDir() / "filter_group.bam";

    SeqBAM::Bowtie2Filter::DiscriminationFilter filter(defSett);
    filter.Filter(getDataFilePath("filter_group.sam"), outFile);

    BAM::Iterator it;
    it.Open(outFile);

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "single");
        BOOST_CHECK_EQUAL(bam_aux_get(al, "DG") == nullptr, true);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "pair");
        BOOST_CHECK_EQUAL(bam_aux2i(bam_aux_get(al, "DG")), 2);
        BOOST_CHECK_EQUAL(al->core.pos, 263021);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "triplet");
        BOOST_CHECK_EQUAL(bam_aux2i(bam_aux_get(al, "DG")), 3);
        BOOST_CHECK_EQUAL(al->core.pos, 305528);
        BOOST_CHECK_CLOSE(bam_aux2f(bam_aux_get(al, "DI")), 0.5, 1);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "single_unmapped");
        BOOST_CHECK_EQUAL(bam_aux_get(al, "DG") == nullptr, true);
        BOOST_CHECK_EQUAL(al->core.pos, -1);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "pair2");
        BOOST_CHECK_EQUAL(bam_aux2i(bam_aux_get(al, "DG")), 2);
        BOOST_CHECK_EQUAL(al->core.pos, 319653);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "pair_unmapped");
        BOOST_CHECK_EQUAL(bam_aux_get(al, "DG") == nullptr, true);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "pair_1_unmapd");
        //first alignment is actually unmapped
        BOOST_CHECK_EQUAL(bam_aux2i(bam_aux_get(al, "DG")), 1);
        BOOST_CHECK_EQUAL(al->core.pos, 234667);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "pair_low_disc");
        BOOST_CHECK_EQUAL(bam_aux2i(bam_aux_get(al, "DG")), 2);
        BOOST_CHECK_CLOSE(bam_aux2f(bam_aux_get(al, "DI")), 0.25, 1);
        //discrimination too low: set as unmapped
        BOOST_CHECK_EQUAL(al->core.pos, -1);
        BOOST_CHECK_EQUAL(al->core.mtid, -1);
        BOOST_CHECK_EQUAL(al->core.flag & BAM_FUNMAP, BAM_FUNMAP);
    }

    BOOST_CHECK_EQUAL(it.GetNextRead() == nullptr, true);

    it.Close();
}

BOOST_AUTO_TEST_CASE(filter_paired)
{
    Str::Path::Val outFile = GetTempDir() / "filter_paired.bam";

    SeqBAM::Bowtie2Filter::DiscriminationFilter filter(lowSett);
    filter.Filter(getDataFilePath("filter_paired.sam"), outFile);

    BAM::Iterator it;
    it.Open(outFile);

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "alternate_pairs");
        BOOST_CHECK_EQUAL(bam_aux2i(bam_aux_get(al, "DG")), 4 * 3);
        BOOST_CHECK_EQUAL(al->core.pos, 320154);
        BOOST_CHECK_EQUAL(al->core.mpos, 320357);
        BOOST_CHECK_EQUAL(al->core.isize, 273);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "alternate_pairs");
        BOOST_CHECK_EQUAL(al->core.pos, 320357);
        BOOST_CHECK_EQUAL(al->core.mpos, 320154);
        BOOST_CHECK_EQUAL(al->core.isize, -273);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "pair1");
        BOOST_CHECK_EQUAL(bam_aux_get(al, "DG") == nullptr, true);
        BOOST_CHECK_EQUAL(al->core.pos, 53025);
        BOOST_CHECK_EQUAL(al->core.mpos, 52608);
        BOOST_CHECK_EQUAL(al->core.isize, -487);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "pair1");
        BOOST_CHECK_EQUAL(al->core.pos, 52608);
        BOOST_CHECK_EQUAL(al->core.mpos, 53025);
        BOOST_CHECK_EQUAL(al->core.isize, 487);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "pair2");
        BOOST_CHECK_EQUAL(bam_aux_get(al, "DG") == nullptr, true);
        BOOST_CHECK_EQUAL(al->core.pos, 106569);
        BOOST_CHECK_EQUAL(al->core.mpos, 106160);
        BOOST_CHECK_EQUAL(al->core.isize, -479);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "pair2");
        BOOST_CHECK_EQUAL(al->core.pos, 106160);
        BOOST_CHECK_EQUAL(al->core.mpos, 106569);
        BOOST_CHECK_EQUAL(al->core.isize, 479);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "pair_alt");
        BOOST_CHECK_EQUAL(bam_aux2i(bam_aux_get(al, "DG")), 1 * 2);
        BOOST_CHECK_CLOSE(bam_aux2f(bam_aux_get(al, "SC")), 137.0 / 140.0, 1);
        BOOST_CHECK_CLOSE(bam_aux2f(bam_aux_get(al, "DI")), ((137.0 / 140.0 - 135.0 / 140.0) / (1.0 - lowSett.minSeqId)), 1);

        BOOST_CHECK_EQUAL(al->core.pos, 46569);
        BOOST_CHECK_EQUAL(al->core.mpos, 37555);
        BOOST_CHECK_EQUAL(al->core.isize, -9084);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "pair_alt");

        BOOST_CHECK_EQUAL(al->core.pos, 37555);
        BOOST_CHECK_EQUAL(al->core.mpos, 46569);
        BOOST_CHECK_EQUAL(al->core.isize, 9084);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "pair_substr");
        BOOST_CHECK_EQUAL(bam_aux2i(bam_aux_get(al, "DG")), 1);
        BOOST_CHECK_CLOSE(bam_aux2f(bam_aux_get(al, "SC")), 1, 1);
        BOOST_CHECK_CLOSE(bam_aux2f(bam_aux_get(al, "DI")), 1, 1);

        BOOST_CHECK_EQUAL(al->core.pos, 113884);
        BOOST_CHECK_EQUAL(al->core.mpos, 113894);
        BOOST_CHECK_EQUAL(al->core.isize, 70);
    }

    {
        bam1_t* al = it.GetNextRead();
        BOOST_CHECK_EQUAL(bam1_qname(al), "pair_substr");

        BOOST_CHECK_EQUAL(al->core.pos, 113894);
        BOOST_CHECK_EQUAL(al->core.mpos, 113884);
        BOOST_CHECK_EQUAL(al->core.isize, -70);
    }

    BOOST_CHECK_EQUAL(it.GetNextRead() == nullptr, true);

    it.Close();
}

BOOST_AUTO_TEST_CASE(filter_mixed)
{
    Str::Path::Val outFile = GetTempDir() / "filter_mixed.bam";

    SeqBAM::Bowtie2Filter::DiscriminationFilter filter(lowSett);
    filter.Filter(getDataFilePath("filter_mixed.sam"), outFile);

    BAM::Iterator it;
    it.Open(outFile);

    expectRead(it, "alternate_pairs", "70M", 320154);
    expectRead(it, "alternate_pairs", "70M", 320357);
    expectRead(it, "pair", "4M", 263021);
    expectRead(it, "pair1", "70M", 53025);
    expectRead(it, "pair1", "70M", 52608);
    expectRead(it, "pair2", "70M", -1);
    expectRead(it, "pair_1_unmapd", "5M", 234667);
    expectRead(it, "pair_alt", "70M", 46569);
    expectRead(it, "pair_alt", "70M", 37555);
    //with these settings, the discrimination is fine
    expectRead(it, "pair_low_disc", "8M", 263021);
    expectRead(it, "pair_substr", "70M", 113884);
    expectRead(it, "pair_substr", "24M", 113894);
    expectRead(it, "pair_unmapped", "4M", 175096);
    expectRead(it, "r1", "70M", 319923);
    expectRead(it, "single", "4M", 132716);
    expectRead(it, "single_unmapped", "4M", -1);
    expectRead(it, "triplet", "4M", 305528);

    it.Close();
}

BOOST_AUTO_TEST_SUITE_END();

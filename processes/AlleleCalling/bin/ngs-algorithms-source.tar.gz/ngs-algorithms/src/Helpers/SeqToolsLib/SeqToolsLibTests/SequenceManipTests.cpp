#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "SequenceManip.h"
#include "SequenceFileName.h"

using namespace seq;

struct SequenceManipTestsFixture
{
    SequenceManipTestsFixture()
        : acgt( PM("acgt") )
        , atgc( PM("atgc") )
    {
    }

    Sequence acgt;
    Sequence atgc;
};

BOOST_FIXTURE_TEST_SUITE( SequenceManipTests, SequenceManipTestsFixture );


BOOST_AUTO_TEST_CASE( Reverse_ACGT )
{
    Reverse(acgt);
    BOOST_REQUIRE_EQUAL(acgt, Sequence(PM("tgca")));
}

BOOST_AUTO_TEST_CASE( Complement_ACGT )
{
    Complement(acgt);
    BOOST_REQUIRE_EQUAL(acgt, Sequence(PM("tgca")));
}

BOOST_AUTO_TEST_CASE( ReverseComplement_ACGT )
{
    ReverseComplement(acgt);
    BOOST_REQUIRE_EQUAL(acgt, Sequence(PM("acgt")));
}

BOOST_AUTO_TEST_CASE( ReverseComplement_ATGC )
{
    ReverseComplement(atgc);
    BOOST_REQUIRE_EQUAL(atgc, Sequence(PM("gcat")));
}

BOOST_AUTO_TEST_CASE( ReverseComplement_ACCGT )
{
    Sequence seq(PM("accgt"));
    ReverseComplement(seq);
    BOOST_REQUIRE_EQUAL(seq, Sequence(PM("acggt")));
}

BOOST_AUTO_TEST_CASE( ReverseComplementCopy_Empty )
{
    Sequence revcompl = ReverseComplementCopy(Sequence(""));
    BOOST_REQUIRE_EQUAL(revcompl, Sequence(PM("")));
}

BOOST_AUTO_TEST_CASE( ReverseComplementCopy_ACGT )
{
    Sequence revcompl = ReverseComplementCopy(acgt);
    BOOST_REQUIRE_EQUAL(acgt,     Sequence(PM("acgt")));
    BOOST_REQUIRE_EQUAL(revcompl, Sequence(PM("acgt")));
}

BOOST_AUTO_TEST_CASE( ReverseComplementCopy_ATGC )
{
    Sequence revcompl = ReverseComplementCopy(atgc);
    BOOST_REQUIRE_EQUAL(atgc,     Sequence(PM("atgc")));
    BOOST_REQUIRE_EQUAL(revcompl, Sequence(PM("gcat")));
}

BOOST_AUTO_TEST_SUITE_END();

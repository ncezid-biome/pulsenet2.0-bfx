#pragma once
#include <boost/shared_ptr.hpp>
#include "PathDef.h"
#include "SAMWrapper.h"
#include "BAMFileResolver.h"

namespace BAM
{

class STW_DLLPORT BasicFileResolver: public FileResolver
{
public:
    typedef boost::shared_ptr<BasicFileResolver> Ptr;

public:

    BasicFileResolver(const Str::Path::Val& inputFile)
    {
        SetBasePath(Str::Path::Val(inputFile).replace_extension());
    }

    virtual Str::Path::Val GetBAMFile() const;

    virtual Str::Path::Val GetSortedBAMFile() const;

    virtual Str::Path::Val GetBAMIndexFile() const;

    virtual Str::Path::Val GetBAMPileFile() const;

    virtual Str::Path::Val GetBAMLevelFile() const;

    virtual Str::Path::Val GetReferenceFile() const;

    virtual void SetBamFile(Str::Path::Val bamFile);

    virtual void SetSortedBamFile(Str::Path::Val sortedBamFile);

protected:

    void SetBasePath(Str::Path::Val basePath);
    void SetSortedBasePath(Str::Path::Val basePath);

private:

    Str::Path::Val basePath_;
    Str::Path::Val sortedBasePath_;

    Str::Path::Val bamFile_;
    Str::Path::Val sortedBamFile_;
};

}
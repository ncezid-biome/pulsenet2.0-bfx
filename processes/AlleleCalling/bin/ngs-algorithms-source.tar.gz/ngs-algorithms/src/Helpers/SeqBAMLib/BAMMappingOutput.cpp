#include "stdafx.h"
#include "BAMMappingOutput.h"
#include "BAMFileLoader.h"
#include "CalcCommunicationImpl.h"
#include "BAMCoverageProvider.h"
#include "BAMCoverageProviderWithInserts.h"
#include "srsmapping_consensus.h"
#include "srsmapping_output.h"
#include "filewriter.h"
#include "TempFileResolver.h"

namespace SeqBAM
{

MappingFiles MappingOutput(const communication::CalcCommunication& comm, const MappingSettings& settings, const engine::ExecuteEnvironment& env, const Str::Path::Val& bamFile) {

    CoverageProvider cp;
    CoverageStatistics cs;
	return MappingOutput(comm, settings, env, bamFile, cp, cs);
}

MappingFiles MappingOutput(const communication::CalcCommunication& comm, const MappingSettings& settings, const engine::ExecuteEnvironment& env, const Str::Path::Val& bamFile, CoverageStatistics& cs)
{
	CoverageProvider cp;
    return MappingOutput(comm, settings, env, bamFile, cp, cs);
}

MappingFiles MappingOutput(const communication::CalcCommunication& comm, const MappingSettings& settings, const engine::ExecuteEnvironment& env, const Str::Path::Val& bamFile, CoverageProvider& cp)
{
	CoverageStatistics cs;
    return MappingOutput(comm, settings, env, bamFile, cp, cs);
}

MappingFiles MappingOutput(const communication::CalcCommunication& comm, const MappingSettings& settings, const engine::ExecuteEnvironment& env, const Str::Path::Val& bamFile, CoverageProvider& cp, CoverageStatistics& cs)
{
    comm.Send( communication::CalcMessage(Message("Loading SAM/BAM file %1...") << bamFile ) );

    //custom loader to avoid creating pile file and level files
    BAM::FileLoader loader(false, false);
    BAM::FileResolver::Ptr files = loader.Load(comm, bamFile, env.localDir);

    comm.Send( communication::CalcMessage(TXT("Determining coverage profiles...")) );

    cp.Fill(files);

	//calculate average coverages
	cs.avgCoverageFwd = 0.0;
	cs.avgCoverageRev = 0.0;
	cs.avgCoveragesFwd.resize(0);
	cs.avgCoveragesRev.resize(0);

	double totLen = 0;
	for (size_t i=0; i<cp.contigNames_.size(); ++i) {
		double avgCovFwd = 0.0, avgCovRev = 0.0;
		for (size_t j=0; j<cp.coverages_[i].size(); ++j) {
			avgCovFwd += (1.0*cp.coverages_[i][j].totFwdWithGaps());
			avgCovRev += (1.0*cp.coverages_[i][j].totRevWithGaps());
		}
		totLen += (1.0*cp.coverages_[i].size());
		cs.avgCoverageFwd += avgCovFwd;
		cs.avgCoverageRev += avgCovRev;
		
		if (avgCovFwd) avgCovFwd /= (1.0*cp.coverages_[i].size());
		cs.avgCoveragesFwd.push_back(avgCovFwd);
		if (avgCovRev) avgCovRev /= (1.0*cp.coverages_[i].size());
		cs.avgCoveragesRev.push_back(avgCovRev);
	}
	if (cs.avgCoverageFwd) cs.avgCoverageFwd /= totLen;
	if (cs.avgCoverageRev) cs.avgCoverageRev /= totLen;

    MappingFiles outputFiles;

    comm.Send( communication::CalcMessage(TXT("Determining consensus sequences...")) );

    {
        ConsensusCalculator cc(settings.consensus);

        outputFiles.consensusFile = env.localDir / "consensus.fasta";

        FastaFileWriter writer;
        if(settings.doOutputConsensus)
            writer.init(outputFiles.consensusFile);

        std::vector<BAM::BAMTypes::ReferenceInfo> refInfos = cp.GetReferencesInfo();

		comm.Send( communication::CalcMessage(Message("Consensus calling thresholds for respectively single, double and triple base: %1, %2, %3")
			<< settings.consensus.sbThreshold << settings.consensus.dbThreshold << settings.consensus.tbThreshold ) );
        for(size_t m = 0; m < cp.contigNames_.size(); m++) {

            Str::Text::Val consensus;
            cc.calcConsensus(cp.coverages_[m], consensus);

            if (settings.doOutputConsensus)
                writer.writeSeq(cp.contigNames_[m], consensus);
        }
    }

    comm.Send( communication::CalcMessage(TXT("Writing coverage profiles...")) );

    if (settings.doOutputCoverage) {

        outputFiles.allfwdcoverages = env.localDir / "forward.cov";
        outputFiles.allrevcoverages = env.localDir / "reverse.cov";

        comm.Send(communication::CalcMessage(Message(TXT("\tWriting %1 and %2..."), outputFiles.allfwdcoverages.filename(), outputFiles.allrevcoverages.filename())));

        //write full coverage profile
        SRSMappingCoverageWriter writer;
        writer.init(ToRef(outputFiles.allfwdcoverages), ToRef(outputFiles.allrevcoverages));

        std::vector<const SRSMappingCoverage*> covs;
        for(size_t i = 0; i < cp.contigNames_.size(); ++i)
            covs.push_back(&cp.coverages_[i]);

        writer.writeCoverage(covs);

    }

	if (settings.doOutputInserts) {
		
		Str::Path::Val outputWithInserts = env.localDir / ("outputWithInserts.txt");

            
		SeqBAM::CoverageProviderWithInserts cp;
		cp.Fill(files);

		std::ofstream os(ToRef(outputWithInserts));

		for(size_t m = 0; m < cp.contigNames_.size(); m++) {

			os << ">>>" << cp.contigNames_[m] << "\t" << cp.coverages_[m].size() << std::endl;

			// i is for insert
			size_t i = 0;

			for(size_t p = 0; p < cp.coverages_[m].size(); p++) {

				const SRSMappingCoverage::Counts& c = cp.coverages_[m][p];
				//don't output the coverages if they are not an insert
				//os << p << "\t" << c.fwdA() << "\t" << c.fwdC() << "\t" << c.fwdG() << "\t" << c.fwdT() << "\t" << c.revA() << "\t" << c.revC() << "\t" << c.revG() << "\t" << c.revT() << "\t" << c.totFwdWithGaps() << "\t" << c.totRevWithGaps() << std::endl;

				if(m < cp.insertPositions.size()) {

					//print insert coverages for this position
					os << p << std::endl;
					for(; i < cp.insertPositions[m].size() && cp.insertPositions[m][i] == p; i++) {

						const SRSMappingCoverage::Counts& c = cp.insertCoverage[m][i];
						os << "+" << "\t" << c.fwdA() << "\t" << c.fwdC() << "\t" << c.fwdG() << "\t" << c.fwdT() << "\t" << c.revA() << "\t" << c.revC() << "\t" << c.revG() << "\t" << c.revT() << "\t" << c.totFwdWithGaps() << "\t" << c.totRevWithGaps() << std::endl;
					}
				}
			}
		}
		outputFiles.outputWithInserts = outputWithInserts;
	}

    if(settings.doOutputIndividualCoverages) {

        for(size_t i = 0; i < cp.contigNames_.size(); ++i) {

            Str::Path::Val fwd = env.localDir / (cp.contigNames_[i] + "_forward.cov");
            Str::Path::Val rev = env.localDir / (cp.contigNames_[i] + "_reverse.cov");

            comm.Send(communication::CalcMessage(Message(TXT("\tWriting %1 and %2..."), fwd.filename(), rev.filename())));

            {
                SRSMappingCoverageWriter writer;
                writer.init(ToRef(fwd), ToRef(rev));
                writer.writeCoverage(cp.coverages_[i]);
            }

            outputFiles.fwdcoverages.push_back(fwd);
            outputFiles.revcoverages.push_back(rev);
        }
    }


    return outputFiles;
}
}

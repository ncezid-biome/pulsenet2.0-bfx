#pragma once
#include <StringDef.h>
#include <stdint.h>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <SAMToolsLib.h>
#include "SAMWrapper.h"
#include "BAMTypes.h"
#include "BAMCigar.h"
#include "BAMAux.h"

namespace BAM
{

/**
 * This class can be used to write a single Alignments to a BAM file.
 */
class STW_DLLPORT Alignment: protected BAMTypes
{
    //somewhat dirty...
    friend class AlignmentTemplate;

public:

    typedef boost::shared_ptr<Alignment> Ptr;

public:

    //by default, an alignment is unmapped
    Alignment(): refID_(NOREFERENCE), position_(NOPOSITION), flags_(BAM_FUNMAP), cigarLen_(1), mate_(nullptr), templateLength_(0)
    {

    }

    void SetCigar(const BAM::Cigar::CigarOps& cigarOps);

    void SetCigar(Str::Text::Arg cigar);

    void SetSequence(Str::Text::Arg sequence);

    void SetQuality(Str::Text::Arg quality);

    void SetName(Str::Text::Arg name)
    {
        name_=name;
    }

    void SetReferenceInfo(ReferenceID refID, ReferencePosition position)
    {
        refID_=refID;
        position_=position;

        //mark read as mapped only if both refID and position are valid
        if(refID_!=NOREFERENCE && position_!=NOPOSITION)
            flags_&=~BAM_FUNMAP;
        else
            flags_|=BAM_FUNMAP;
    }

    void WriteToBAMFile(bamFile file) const;

    /**
     * Set the flags of this alignment. This method should be called before \sa SetReferenceInfo,
     * otherwise the mapped/unmapped information may be overwritten.
     */
    void SetFlags(uint16_t flags)
    {
        flags_=flags;
    }

    template<typename T> void AddAux(Str::ID::Arg tag, T value)
    {
        aux_.append(AuxEntry::Create(tag, value));
    }

    void AddAuxString(Str::ID::Arg tag, Str::Text::Arg value);

private:

    //dont copy my floppy
    Alignment(const Alignment& other) {}

    typedef struct {

        union {

            uint8_t raw;

            //first base is stored in low nibble, second base in high nibble
            struct {

                uint8_t b2:4;
                uint8_t b1:4;
            };
        };
    } TwoBases;

    typedef boost::shared_ptr<TwoBases[]> Sequence;

    static_assert(sizeof(TwoBases)==1, "sizeof(TwoBases) should be 1 for correct operation");

    typedef boost::shared_ptr<uint8_t[]> Quality;

private:

    void SetMate(Alignment::Ptr mate);

    void ResetMate() {
        mate_.reset();
    }

    inline size_t getTwoBasesLength() const {
        return (sequenceLen_ + 1) >> 1;
    }

private:

    size_t cigarLen_;
    Cigar::Cigar cigar_;

    size_t sequenceLen_;
    Sequence sequence_;

    size_t qualityLen_;
    Quality quality_;

    ReferenceID refID_;
    ReferencePosition position_;

    ReferencePosition templateLength_;

    Alignment::Ptr mate_;

    uint16_t flags_;
    Str::Text::Val name_;

    Str::Text::Val aux_;
};

}

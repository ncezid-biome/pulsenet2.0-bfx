#pragma once

#include "StringDef.h"
#include "PathDef.h"

#include "CE_LogMessageType.h"


namespace engine
{


/**
    See also the LogAction class for easy logging of actions

    \sa LogAction
*/
class Logger
{
public:
    Logger();

    void CreateResultFile  ( const Str::Text::Val& filename,
                             const Str::Text::Val& content,
							 const Str::ID::Val& compressionTypeId);
    
    void CreateLogFile( const Str::Text::Val& filename,
                        const engine::LogMessageType& messageType,
                        const Str::Text::Val& content);
    void AppendLogFile( const Str::Text::Val& filename,
                        const engine::LogMessageType& messageType,
                        const Str::Text::Val& content);

    void SetProgress       ( int progress );
    void SetProgressMessage( Str::Text::Val progressMessage );
    void SetProgress       ( int progress, const Str::Text::Val& message );

    void AddMessage   ( LogMessageType messageType, const Str::Text::Val& message );
    void AddWarning   ( const Str::Text::Val& warning );
    void AddError     ( const Str::Text::Val& error   );

    void SetResultsDir  ( const Str::Text::Val& resultsDir );
    void SetDoCompressionType( const Str::Text::Val& compressionType);

    bool IsVerbose      () const
    {
        return isVerbose_;
    }
    void SetVerbose     ( bool isVerbose    );

    void IncreaseIndent();
    void DecreaseIndent();

    //
    const Str::Path::Val GetResultsPath();
    static const Str::Path::Val GetResultsPath( const Str::Path::Val& basePath );
    const Str::Path::Val GetLogsPath();
    static const Str::Path::Val GetLogsDir();
    static const Str::Text::Val GetProgressFilename();
    static const Str::Text::Val GetAllMessagesFilename();
    static const Str::Text::Val GetMessageFilename();
    static const Str::Text::Val GetWarningsFilename();
    static const Str::Text::Val GetErrorFilename();

private:
    static const Str::Path::Val GetResultsDirname();

    static const int indentAmount = 2;

private:
    Str::Path::Val resultsDir_;
	Str::Text::Val doCompressionType_;	///< Should result file be compressed? An empty string means no compression.
    bool           isVerbose_;
    int            currentIndent_;
};


} // namespace engine

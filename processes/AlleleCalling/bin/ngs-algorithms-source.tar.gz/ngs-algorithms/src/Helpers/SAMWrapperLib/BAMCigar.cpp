#include "stdafx.h"
#include "BAMCigar.h"
#include <sstream>

namespace BAM
{
namespace Cigar
{

CigarOps FromRLEString(Str::Text::Arg cigarStr)
{
    char* end;
    const char* cigarString = cigarStr.c_str();
    uint32_t length;

    CigarOps cigar;
    CigarOp cigarOp;

    while((length = strtoul(cigarString, &end, 10)) > 0) {

        //check if there is an operator present after the parsed number
        if(end && *end) {

            cigarOp.length = length;
            cigarOp.op = GetNibbleForCigarOp(*end);

            cigar.push_back(cigarOp);

            cigarString = end + 1;
        }
        else
            break;
    }

    return cigar;
}

Str::Text::Val ToRLEString(const CigarOps& cigarOps)
{
    std::ostringstream ss;

    for(const CigarOp& op : cigarOps)
        ss << op.length << bam_cigar_opchr(op.op);

    return ss.str();
}

Str::Text::Val ToRLEString(const CigarOp* cigarOps, size_t len)
{
    std::ostringstream ss;

    for(size_t i = 0; i < len; i++)
        ss << cigarOps[i].length << bam_cigar_opchr(cigarOps[i].op);

    return ss.str();
}

Str::Text::Val ToRLEString(bam1_t* read)
{
    return ToRLEString(reinterpret_cast<const CigarOp*>(bam1_cigar(read)), read->core.n_cigar);
}

//does RLE on the cigarStr
CigarOps FromLongString(const Str::Text::Val& cigarStr)
{
    CigarOp cigarOp;
    CigarOps cigarOps;

    if(cigarStr.length() > 0) {

        cigarOp.length = 1;
        char currentOp = cigarStr[0];

        for(size_t i = 1; i < cigarStr.size(); i++) {

            if(cigarStr[i] == currentOp)
                cigarOp.length++;
            else {

                cigarOp.op = GetNibbleForCigarOp(currentOp);
                cigarOps.push_back(cigarOp);

                currentOp = cigarStr[i];
                cigarOp.length = 1;
            }
        }

        cigarOp.op = GetNibbleForCigarOp(currentOp);
        cigarOps.push_back(cigarOp);
    }

    return cigarOps;
}

BAM::Cigar::CigarOps ForMatch(size_t length)
{
    CigarOps cigar;

    CigarOp op={ GetNibbleForCigarOp('M'), length };
    cigar.push_back(op);

    return cigar;
}

}
}
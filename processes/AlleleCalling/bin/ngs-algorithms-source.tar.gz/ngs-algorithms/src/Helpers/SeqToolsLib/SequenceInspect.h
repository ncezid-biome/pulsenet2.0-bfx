#pragma once
/**
    Unit tests in SequenceInspectTests.cpp
*/

#include "Sequence.h"


namespace seq
{

bool AreAllBasesACGTacgt(const Sequence& sequence);
bool SequenceContains   (const Sequence& input, const Sequence& query);
bool AreAllBasesN       (const Sequence& sequence);

} // namespace seq


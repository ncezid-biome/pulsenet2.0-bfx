#include "stdafx.h"

#include "SequenceFileName.h"

#include "boost/algorithm/string/predicate.hpp"

#include "CompressionType.h"
#include "filereader.h"


SequenceFileName::SequenceFileName(const Str::Path::Val& filename)
    : filename_( filename )
{
}

SequenceFileName::SequenceFileName()
    : filename_()
{
}

void SequenceFileName::ReplaceExtension(Str::Text::Val newExtension /*= PM("") */)
{
    // Remove e.g. .gz
    if ( CompressionType::FileHasCompressionExtension(filename_) )
        filename_ = filename_.replace_extension();

    // Remove e.g. .fasta
    SeqFileReaderPtr reader = SeqFileReader::FromFactory( filename_.extension().string(), false );
    if ( reader )
        filename_ = filename_.replace_extension();

    // Append new extension, if required
    if ( ! newExtension.empty() ){
        if ( ! boost::starts_with(newExtension, PM(".")) )
            newExtension = PM(".") + newExtension;

        filename_ = filename_.string() + newExtension;
    }
}

Str::Text::Val SequenceFileName::ToString() const
{
    return filename_.string();
}

void SequenceFileName::operator=(const Str::Path::Val& filename)
{
    filename_ = filename;
}

SequenceFileName::operator const Str::Path::Val&() const
{
    return filename_;
}

bool SequenceFileName::Exists() const
{
    return boost::filesystem::exists(filename_)
        && boost::filesystem::is_regular_file(filename_);
}

std::ostream & operator<<(std::ostream &stream, const SequenceFileName& file)
{
    stream << file.ToString();
    return stream;
}

#pragma once

#include "PathDef.h"

#include "kmer.h"
#include "AlleleInfo.h"
#include "filereader.h"

#include "FileRotator.h"



/**
    \sa AlleleKMerTableIO
*/
class AlleleKMerTable
{
public:
    typedef boost::shared_ptr<AlleleKMerTable> Ptr;
public:
	struct ShortAlleleInfo{
		Str::Text::Val   name_;
		size_t			 length_; //> length in base pairs
		ShortAlleleInfo(Str::Text::Arg   name, size_t	length);
	};
	typedef std::vector<ShortAlleleInfo>	 AllelesInfo;	 
public:
    AlleleKMerTable();
    AlleleKMerTable( size_t k );

    void Fill       ( const SeqFileReader&  reader
                    , AllelesInfo&       allelesInfo
                    , const communication::CalcCommunication& comm);
    void ReportStats( const communication::CalcCommunication& comm );

    KMerTable<AlleleInfo>& GetTable();

private:
    KMerTable<AlleleInfo> table_;
};

/**
    Provides i/o access to an allele kmer table file

    \sa AlleleKMerTable
*/
class AlleleKMerTableIO
{
public:
    AlleleKMerTableIO( AlleleKMerTable*      table,
                       const Str::Path::Val& baseName,
                       const communication::CalcCommunication& comm);

    void Read();
    void Store( const communication::CalcCommunication& comm );

          AlleleKMerTable& GetTable();
    const AlleleKMerTable& GetTable() const;

private:
    AlleleKMerTable*  kmerTable_;
    SingleFileRotator fileRotator_;
};

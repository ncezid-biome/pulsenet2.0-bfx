#include <stdafx.h>
#include "BAMConcatenation.h"
#include <SAMToolsLib.h>
#include "SAMToBAMConverter.h"
#include "BAMFileType.h"

void BAM::Concatenation::AddPart(const Str::Path::Val& inputFile)
{
    Str::Path::Val bamFile = inputFile;

    if(GetFileType(inputFile) == FileType::SAM){

        SAMToBAMConverter converter;

        bamFile += ".bam";
        converter.ConvertFile(inputFile, bamFile);
    }

    //store strings, because we need the c_str's later
    bamFiles_.push_back(bamFile.string());
}

void BAM::Concatenation::Concat(const Str::Path::Val& outputFile)
{
    std::vector<Str::Text::Ref> refs(bamFiles_.size());

    std::transform(bamFiles_.cbegin(), bamFiles_.cend(), refs.begin(), [](const Str::Text::Val & q) {
        return q.c_str();
    });

    Str::Text::Val outputFilePath = outputFile.string();
    bam_cat(refs.size(), const_cast<char* const*>(refs.data()), nullptr, outputFilePath.c_str());
}

#include "stdafx.h"

#include "SequenceManip.h"

#include <algorithm>

#include "CapitalTable.h"
#include "SequenceRangeManip.h"


namespace seq
{
    
/**
    bases actg are upper-cased, other bases are replaced by 'N'.
*/
void ActgToUpperCase(Str::Text::Val& sequence)
{
    ActgToUpperCase( sequence.begin(), sequence.end() );
}

/**
    Might want to remove this, make sure that readers always return upper case...
*/
void ActgToUpperCase(Sequence& sequence)
{
    ActgToUpperCase( sequence.begin(), sequence.end() );
}

/**
    Reverse the sequence
*/
void Reverse(Sequence& sequence)
{
    Reverse(sequence.begin(), sequence.end());
}

/**
    Take the reverse complement of the sequence:

    - ACGT -> TGCA
    - reverse the sequence
*/
void ReverseComplement(Sequence& sequence)
{
    ReverseComplement( sequence.begin(), sequence.end() );
}

/**
    Take the complement of \a sequence
*/
void Complement(Sequence& sequence)
{
    Complement( sequence.begin(), sequence.end() );
}

Sequence ReverseComplementCopy(const Sequence& sequence)
{
    Sequence copy;
    copy.Resize(sequence.GetLength());

    ReverseComplementCopy(begin(sequence), end(sequence), begin(copy), end(copy));

    return copy;
}

void addtoconsensus(char nucl, int &Tcnt, int &Ccnt, int &Acnt, int &Gcnt, int &gapcnt)
{
	switch (nucl)
	{
		case 'A': Acnt+=12; break;
		case 'C': Ccnt+=12; break;
		case 'G': Gcnt+=12; break;
		case 'T': Tcnt+=12; break;
		case 'R': Acnt+=6;Gcnt+=6; break;
		case 'Y': Ccnt+=6;Tcnt+=6; break;
		case 'M': Acnt+=6;Ccnt+=6; break;
		case 'K': Gcnt+=6;Tcnt+=6; break;
		case 'S': Ccnt+=6;Gcnt+=6; break;
		case 'W': Acnt+=6;Tcnt+=6; break;
		case 'H': Acnt+=4;Ccnt+=4;Tcnt+=4; break;
		case 'B': Ccnt+=4;Gcnt+=4;Tcnt+=4; break;
		case 'V': Acnt+=4;Ccnt+=4;Gcnt+=4; break;
		case 'D': Acnt+=4;Gcnt+=4;Tcnt+=4; break;
		case 'N': Acnt+=3;Ccnt+=3;Gcnt+=3;Tcnt+=3; break;
		case '-': gapcnt+=1; break;
		case ' ': gapcnt+=1; break;
		case 'a': Acnt+=12; break;
		case 'c': Ccnt+=12; break;
		case 'g': Gcnt+=12; break;
		case 't': Tcnt+=12; break;
		case 'r': Acnt+=6;Gcnt+=6; break;
		case 'y': Ccnt+=6;Tcnt+=6; break;
		case 'm': Acnt+=6;Ccnt+=6; break;
		case 'k': Gcnt+=6;Tcnt+=6; break;
		case 's': Ccnt+=6;Gcnt+=6; break;
		case 'w': Acnt+=6;Tcnt+=6; break;
		case 'h': Acnt+=4;Ccnt+=4;Tcnt+=4; break;
		case 'b': Ccnt+=4;Gcnt+=4;Tcnt+=4; break;
		case 'v': Acnt+=4;Ccnt+=4;Gcnt+=4; break;
		case 'd': Acnt+=4;Gcnt+=4;Tcnt+=4; break;
		case 'n': Acnt+=3;Ccnt+=3;Gcnt+=3;Tcnt+=3; break;
	}
}
char translate(char ch1, char ch2, char ch3)
{
	char AA[65] = "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG";

	int i,j,k,k1,k2,k3,p,cnt;
	int cnts1[5],cnts2[5],cnts3[5];
	char az;
	
	k1=-100;k2=-100;k3=-100;
	if (ch1=='t') k1=0;else
	if (ch1=='c') k1=1;else
	if (ch1=='a') k1=2;else
	if (ch1=='g') k1=3;

	if (ch2=='t') k2=0;else
	if (ch2=='c') k2=1;else
	if (ch2=='a') k2=2;else
	if (ch2=='g') k2=3;

	if (ch3=='t') k3=0;else
	if (ch3=='c') k3=1;else
	if (ch3=='a') k3=2;else
	if (ch3=='g') k3=3;
	i=k1*16+k2*4+k3;
	if ((i>-1)&&(i<64))	return AA[i];

//doe nog een poging als het iupac code is.
	for (i=0;i<5;i++) {cnts1[i]=0;cnts2[i]=0;cnts3[i]=0;}
	addtoconsensus(ch1,cnts1[0],cnts1[1],cnts1[2],cnts1[3],cnts1[4]);
	addtoconsensus(ch2,cnts2[0],cnts2[1],cnts2[2],cnts2[3],cnts2[4]);
	addtoconsensus(ch3,cnts3[0],cnts3[1],cnts3[2],cnts3[3],cnts3[4]);
	cnt=0;az='X';
	for (i=0;i<4;i++)
	{
		k1=-100;
		if (cnts1[i]>0) k1=i;
		for (j=0;j<4;j++)
		{
			k2=-100;
			if (cnts2[j]>0) k2=j;
			for (k=0;k<4;k++)
			{
				k3=-100;
				if (cnts3[k]>0) k3=k;
				p=k1*16+k2*4+k3;
				if ((p>-1)&&(p<64))	
				{
					if (az!=AA[p]) cnt++;
					az=AA[p];
				}
			}
		}
	}
	if (cnt==1) return az;
//als cnt>1 betekent dit dat er niet ��nduidig ��n aminozuur gevonden is
	return 'X';
}



Sequence Translate( const Sequence& sequence )
{
	Sequence translated;
	translated.Resize(sequence.GetLength()/3);

	auto it_in = begin(sequence), it_in_end = end(sequence);
	auto it_out = begin(translated);

	while (it_in!=it_in_end) {
		*it_out = translate(*it_in, *(it_in+1), *(it_in+2));
		it_in+=3; it_out+=1;
	}
	return translated;
}


} // namespace seq

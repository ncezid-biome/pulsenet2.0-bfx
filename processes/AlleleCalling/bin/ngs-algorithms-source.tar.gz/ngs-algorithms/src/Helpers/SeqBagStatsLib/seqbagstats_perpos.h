#pragma once
#include <vector>

class Scores {
public:
	typedef int ScoreType;
private:
	std::vector<int> counts_;
	std::vector<std::vector<ScoreType>> scores_;
private:
	mutable std::vector<int> min_, max_;
	mutable std::vector<double> mean_, stdev_;
	mutable std::vector<std::vector<double>> quantiles_;
public:
	void calcMin() const;
	void calcMax() const;
	void calcMean() const;
	void calcStDev() const;
	void calcQuantiles() const;
	void cleanup();
public:
	Scores() {}
	~Scores() {}

	inline size_t maxLen() const { return scores_.size(); }
	inline size_t maxQual(size_t i) const { return scores_[i].size(); }
	inline ScoreType operator()(size_t i, size_t j) const {
		return scores_[i][j];
	}
	inline void resize(size_t i) {
		if (scores_.size()<i) scores_.resize(i);		
		if (counts_.size()<i) counts_.resize(i, 0);
	}
	inline void add(size_t i, size_t j) {
		if (scores_.size()<=i) scores_.resize(i+1);
		if (scores_[i].size()<=j) scores_[i].resize(j+1, 0);
		if (counts_.size()<=i) counts_.resize(i+1, 0);
		counts_[i]+=1;
		scores_[i][j]+=1;
	}
	inline void addLine(const char* line, size_t  size, size_t qualOffset) {		
		for(size_t i=0; i<size; ++i) add(i, line[i]-qualOffset);
	}
	
	inline double getCount(size_t i) {
		return counts_[i];
	}
	inline double getMean(size_t i) {
		if (mean_.size()==0) calcMean();
		return mean_[i];
	}
	inline double getStDev(size_t i) {
		if (stdev_.size()==0) calcStDev();
		return stdev_[i];
	}
	inline double getQuant95(size_t i) {
		if (quantiles_.size()==0) calcQuantiles();	
		return quantiles_[i][4];
	}
	inline double getQuant75(size_t i) {
		if (quantiles_.size()==0) calcQuantiles();	
		return quantiles_[i][3];
	}
	inline double getQuant50(size_t i) {
		if (quantiles_.size()==0) calcQuantiles();	
		return quantiles_[i][2];
	}
	inline double getQuant25(size_t i) {
		if (quantiles_.size()==0) calcQuantiles();	
		return quantiles_[i][1];
	}
	inline double getQuant5(size_t i) {
		if (quantiles_.size()==0) calcQuantiles();	
		return quantiles_[i][0];
	}
	inline const std::vector<double>& getAvg() const {
		if (mean_.size()==0) calcMean();
		return mean_;
	}
	inline const std::vector<double>& getStDev() const {
		if (stdev_.size()==0) calcStDev();
		return stdev_;
	}
	inline const std::vector<int>& getMin() const {
		if (min_.size()==0) calcMin();
		return min_;
	}
	inline const std::vector<int>& getMax() const {
		if (max_.size()==0) calcMax();
		return max_;
	}

	inline const std::vector<std::vector<double>>& getQuantiles() const {
		if (quantiles_.size()==0) calcQuantiles();
		return quantiles_;
	}

	void merge(const Scores& other);
};

class AllScores {
public:
	std::vector<int> counts_, counts1_, counts2_;
	std::vector<int> countsA_, countsA1_, countsA2_;
	std::vector<int> countsC_, countsC1_, countsC2_;
	std::vector<int> countsG_, countsG1_, countsG2_;
	std::vector<int> countsT_, countsT1_, countsT2_;
	Scores scores_, scores1_, scores2_;
	bool hasQual_;
public:
	AllScores();
	~AllScores() {}

	bool hasQual() const;
	void add(const char* seq1, const char* qual1, size_t seqlen1, const char* seq2, const char* qual2, size_t seqlen2, size_t qualOffset);
	void add(const AllScores& other);

	//void merge(const AllScores& other);
	void mergeScores();

	void calc() const;
};
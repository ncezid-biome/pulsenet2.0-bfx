#include "stdafx.h"

#include "Codons.h"


namespace seq
{


Codons getStartCodons()
{
    Codons codons;
    codons.push_back( PM("ATG") );
    codons.push_back( PM("GTG") );
    codons.push_back( PM("TTG") );
    return codons;
}

Codons getStopCodons()
{
    Codons codons;
    codons.push_back( PM("TAG") );
    codons.push_back( PM("TAA") );
    codons.push_back( PM("TGA") );
    return codons;
}


} // namespace seq

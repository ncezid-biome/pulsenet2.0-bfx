#include "am.h"
#include "pthread.h"
#include <stdlib.h>
#include <stdarg.h>
#include "bam.h"

#ifndef AMGNU
#include <errhandlingapi.h>
#else
#define ASSERT  assert
#include "exception.h"
#endif

pthread_mutex_t addMutex;

#ifndef AMGNU
int __sync_fetch_and_add(volatile int *mem, int val)
{
    int r;
    pthread_mutex_lock (&addMutex);
    r=(*mem+=val);
    pthread_mutex_unlock (&addMutex);
    return r;
}

int am_vsnprintf(char *dst, size_t size, const char *fmt, va_list ap)
{
    int l;

#if _MSC_VER < 1900
	//force only two digit exponent (as on linux)
	// This function is deprecated from 1900 (Visual Studio 2015)
	_set_output_format(_TWO_DIGIT_EXPONENT);
#endif

    l=vsnprintf(dst, size, fmt, ap);

    //microsofts retarded vsnprintf returns -1 if the buffer is too small
    if(l<0) {

        //get the length that is required
        return _vscprintf(fmt, ap);
    }
    return l;
}
#endif

/**
 * The hack below, in cooperation with the define in am.h, redirects messages written to stderr
 * to the callback registered with set_message_callback. If there is no such callback, then 
 * the message is written to stderr anyway.
 */

void* message_cb_data=NULL;
message_callback message_cb=NULL;

void fprintf_capture(FILE *stream, const char *format, ...) {

    va_list args;
    va_start(args, format);

    if(stream==stderr && message_cb) {

        char buffer[1024];

        vsnprintf(buffer, 1023, format, args);
        message_cb(buffer, message_cb_data);
    }
    else
        vfprintf(stream, format, args);
}

void set_message_callback(message_callback callback, void* data) {

    message_cb=callback;
    message_cb_data=data;
}

#ifndef AMGNU
/**
 * Since pthreads is imported as a .lib (and not a dll), we have to invoke pthread_win32_process_attach_np manually.
 * Calling it repeatedly does not immediately apparent harm, but we should avoid that anyway. This aux function takes
 * care of that.
 * Remark: this function is not thread-safe.
 */
void ensure_pthreads() {

    static uint8_t pthread_setup=0;

    if(!pthread_setup) {

        pthread_setup=1;
        pthread_win32_process_attach_np();
    }
}
#endif

/**
 * Since bam_destroy1 is a define, we can't use it from the main program if samtools is imported as a DLL: allocated
 * memory must be deallocated from the same local heap. For symmetry, we also provide an stl_bam_init1.
 */
bam1_t* stl_bam_init1()
{
    return bam_init1();
}

void stl_bam_destroy1(bam1_t* b)
{
    bam_destroy1(b);
}

void exception_exit(int code) {

#ifndef AMGNU
    //don't actually exit, just raise an exception with a specific code
    RaiseException(EXIT_EXCEPTION, 0, 0, 0);
#else
    throw KError("%1") << code;
#endif
}

#ifdef __cplusplus
extern "C" {
#endif

bam_index_t *bam_index_load_core(FILE *fp);

#ifdef __cplusplus
}
#endif

/**
 * Open a BAM index file directly (as opposed to through the name of its BAM file)
 */
bam_index_t* bam_index_load_directly(const char* indexFile) {

    FILE* fp=fopen(indexFile, "rb");

    if(fp) {

        bam_index_t* index=bam_index_load_core(fp);
        fclose(fp);

        return index;
    }
    return NULL;
}
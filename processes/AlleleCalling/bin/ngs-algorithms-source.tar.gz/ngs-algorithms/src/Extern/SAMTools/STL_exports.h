#pragma once

#include "bam.h"

typedef void(*message_callback)(const char* message, void* data);

#ifdef __cplusplus
extern "C" {
#endif

//am.cpp
SLW32_DLLPORT bam1_t* stl_bam_init1();
SLW32_DLLPORT void stl_bam_destroy1(bam1_t* b);
SLW32_DLLPORT void set_message_callback(message_callback callback, void* data);
SLW32_DLLPORT void exception_exit(int code);
SLW32_DLLPORT bam_index_t* bam_index_load_directly(const char* indexFile);

//bam_index.c
SLW32_DLLPORT int bam_index_build2(const char *fn, const char *_fnidx);

//bam_sort.c
SLW32_DLLPORT void bam_sort_core(int is_by_qname, const char *fn, const char *prefix, size_t max_mem);
SLW32_DLLPORT void bam_sort_core_ext(int is_by_qname, const char *fn, const char *prefix, size_t _max_mem, int is_stdout, int n_threads, int level, int full_path);

//bam_cat.c
SLW32_DLLPORT int bam_cat(int nfn, char* const* fn, const bam_header_t* h, const char* outbam);


#ifdef __cplusplus
} //extern "C"
#endif
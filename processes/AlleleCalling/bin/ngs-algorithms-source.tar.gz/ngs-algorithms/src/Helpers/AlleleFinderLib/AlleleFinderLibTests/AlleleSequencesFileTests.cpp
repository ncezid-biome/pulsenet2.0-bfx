#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "ConsoleLogger.h"
#include "AlleleSequencesFile.h"

#include "MockAlleleFiles.h"

using namespace test;


BOOST_AUTO_TEST_SUITE( AlleleSequencesFileTests );

BOOST_AUTO_TEST_CASE( CreateFile_gz_Ok )
{
    MockAlleleSequencesFile allelefile = MockAlleleFiles::GetAlleleSequencesFile_gz();

    ConsoleLogger logger( ConsoleLogger::LogMode::Text );
    communication::CalcCommunication comm( &logger );

    AlleleSequencesFile file(allelefile.filename, comm);
}

BOOST_AUTO_TEST_CASE( CreateFile_uncompressed_Ok )
{
    MockAlleleSequencesFile allelefile = MockAlleleFiles::GetAlleleSequencesFile_uncompressed();

    ConsoleLogger logger( ConsoleLogger::LogMode::Text );
    communication::CalcCommunication comm( &logger );

    AlleleSequencesFile file(allelefile.filename, comm);
}

BOOST_AUTO_TEST_CASE( CreateFile_uncompr_nonExistent_Ok )
{
    MockAlleleSequencesFile allelefile = MockAlleleFiles::GetAlleleSequencesFile_uncompressed_nonexistent();

    ConsoleLogger logger( ConsoleLogger::LogMode::Text );
    communication::CalcCommunication comm( &logger );

    AlleleSequencesFile file(allelefile.filename, comm);
}

BOOST_AUTO_TEST_SUITE_END();

#pragma once

#include "StringDef.h"
#include <boost/algorithm/string/predicate.hpp>
#include "PathDef.h"

namespace BAM
{

enum class FileType {
    SAM,
    BAM
};

Str::Text::Ref GetTypeReadMode(FileType t);

Str::Text::Ref GetTypeWriteMode(FileType t);

Str::Text::Ref ToString(FileType t);

FileType GetFileType(const Str::Path::Val& path);

}
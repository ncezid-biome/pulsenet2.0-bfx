/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

//#include <string>
//#include <vector>
#include "StringDef.h"
#include "PathDef.h"

#ifndef STRDEF_H
#define STRDEF_H
//
//#define ToArg(X) (X).c_str()
//#define ToRef(X) (X).c_str()
//
//struct Str {
//	typedef const char* Arg;
//	typedef const char* Ref;
//	typedef std::string Val;
//	typedef std::vector<Val> Vec;
//};
//
//struct Id {
//	typedef const char* Arg;
//	typedef const char* Ref;
//	typedef std::string Val;
//	typedef std::vector<Val> Vec;
//};
//
//struct Buffer {
//	typedef const char* Arg;
//	typedef const char* Ref;
//	typedef std::string Val;
//	typedef std::vector<Val> Vec;
//};
//
//
//struct Path {
//	typedef const char* Arg;
//	typedef const char* Ref;
//	typedef std::string Val;
//	typedef std::vector<Val> Vec;
//};
//
//inline bool CaseInsensitiveLess(const std::string& str1, const std::string& str2) 
//{
//	return _stricmp(str1, str2)<0;
//}
//
//template<class T>
//Str::Text::Val ToStr(const T& val) {
//	std::ostringstream os; os << val; return os.str();
//}

#endif
#include "stdafx.h"

#ifdef AMGNU
#include "UnixProcess.h"

#include <unistd.h>
#include <signal.h>
#include <sys/prctl.h>
#include <sys/wait.h>
#include <ext/stdio_filebuf.h>

#include "exception.h"
#include "CommandLine.h"
#include "RunExceptions.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "runextern_UnixDefines.h"

namespace runextern
{


UnixProcess::UnixProcess()
    : commandLine_  ()
    , info_         ()
    , status_       ()
    , childExited_  ( false )
    , childExitCode_( 0 )
    , parentToChildPipe(boost::make_shared<UnixPipe>())
    , childToParentPipe(boost::make_shared<UnixPipe>())
{
}

UnixProcess::~UnixProcess()
{
}

void UnixProcess::setCmdLine(const ProcessCmdLine& cmd)
{
    commandLine_ = cmd;
}

void UnixProcess::setInfo(const ProcessInfo& info)
{
    info_ = info;
}

const ProcessStatus& UnixProcess::getStatus()
{
    return status_;
}

UnixProcess::Memory UnixProcess::getMemoryUsage() const
{
    return 0;
}

namespace {

//Redirect output sent throught \a fd to \a file.
void dupToFile(const Str::Path::Val& file, int fd) {

    int fileFd=open(file.c_str(), O_CREAT | O_WRONLY, 0644);

    if(fileFd<0)
        throw KError(TXT("Unable to open output file %1: %2")) << file << strerror(errno);

    if(dup2(fileFd, fd)<0)
        throw KError(TXT("Unable to redirect output to %1: %2")) << file << strerror(errno);
}

}

/**
    See also:

    http://stackoverflow.com/questions/1584956/how-to-handle-execvp-errors-after-fork
*/
bool UnixProcess::run()
{
    // Note: parent: this process, child: the new process that will be executed

    // Create pipes for parent->child and child->parent communication
    if ( ! parentToChildPipe->create() ){
        status_.setFailedToCreatePipes( errno, PM("Failed to create parent to child pipes") );
        return false;
    }

    if ( ! childToParentPipe->create() ){
        status_.setFailedToCreatePipes( errno, PM("Failed to create child to parent pipes") );
        return false;
    }

    // Create a temporary pipe that will be used for notifying the parent process of errors in the
    // child process (if any)
    UnixPipe::Ptr controlPipe=boost::make_shared<UnixPipe>();
    if ( ! controlPipe->create() ){
        status_.setFailedToCreatePipes( errno, PM("Failed to create error control pipe") );
        return false;
    }

    // Close the control pipe if the child exec succeeds
    controlPipe->setCloseWriteOnExit();

    // Do the actual fork: splits the current process into two!
    myPid_ = fork();

    switch( myPid_ ){
    case -1:
        status_.setFailedToStart( errno, PM("Failed to fork") );
        return false;

    case 0:
        {
        try {
            // Child process
            parentToChildPipe->closeForWriting();
            childToParentPipe->closeForReading();
            controlPipe->closeForReading();

            // Let the child write to the pipe instead of to stdout/stderr
            parentToChildPipe->captureStdIn();

            //redirect stdout to file instead if one has been set
			if(commandLine_.GetOutputFile().empty())
			{
				childToParentPipe->captureStdOut();
				childToParentPipe->captureStdErr();
			}
			else
			{
                dupToFile(commandLine_.GetOutputFile(), STDOUT_FILENO);

				//redirect stderr to file instead if one has been set
				if (commandLine_.GetRedirectStderr())
					dupToFile(commandLine_.GetOutputFile(), STDERR_FILENO);
				else
					childToParentPipe->captureStdErr();
			}

            // Ask to be notified of parent death, then kill myself (i.e. parent dies -> child dies)
            prctl(PR_SET_PDEATHSIG, SIGHUP);

            ProcessCmdLine::ArgvPtr argv=commandLine_.GetArgv();

            if(info_.hasWorkingDir()) {

                if(chdir(info_.getWorkingDir()))
                    throw KError("Could not chdir to working directory \"%1\": %2") << info_.getWorkingDir() << strerror(errno);
            }

            // Execute the command (returns -1 on failure, but if it ever returns that indicates failure anyway)
            execvp( commandLine_.GetCommand(), argv.get() );

            // Got here -> error in execvp -> signal error
            throw KError("execvp() failed: %1") << strerror(errno);
        }
        catch ( std::exception& e ) {
            status_.setFailedToStart(errno, RawMessage(PM("Exception while to execute command '%1', message: %2"), commandLine_.GetCommand(), e.what()).c_str());
        }
        catch ( ... ) {
            status_.setFailedToStart(errno, PM("Unknown exception when executing child"));
        }

        //transfer error + errno to parent through control socket
        UnixPipeListener::sendMessage( controlPipe, status_.getErrorCode() );
        UnixPipeListener::sendMessage( controlPipe, status_.getErrorText() );

        // Shut down the child
        _exit(0);
    }

    default:
        // Parent process (this process)

        // Close some pipe parts: parent to child: want to do writing, parent from child: reading
        parentToChildPipe->closeForReading();
        childToParentPipe->closeForWriting();
        controlPipe->closeForWriting();

        // Check if the child exited with an error. Note that the controlPipe is shut down automatically if the
        // exec call succeeded -> read will fail
        {
            __gnu_cxx::stdio_filebuf<char> controlBuf(controlPipe->getReadDescriptor(), std::ios::in);
            std::istream controlStream(&controlBuf);

            int errcode;
            std::string message;

            //try to read errno and, if that actually worked, the error message
            if(controlStream.read((char*) &errcode, sizeof(int))) {

                try {
                    std::getline(controlStream, message);
                }
                catch (...) {
                    message = "Unknown error: could not read control pipe";
                }

                status_.setFailedToStart(errcode, message);
                return false;
            }
        }

        // Set up the listener
        listener_ = UnixPipeListener( childToParentPipe, parentToChildPipe );
    }

    return true;
}

void UnixProcess::terminate(ErrorCode errorCode)
{
	auto code = errorCode;
	if (code == ERROR_PROCESS_ABORTED)
	{
		code = SIGTERM;
	}

	kill(myPid_, code);
}

bool UnixProcess::checkForMessage(MessageBuffer& buffer, int &bytesRead)
{
    // Check for a line because that's what the caller expects
    bool listenOk = listener_.checkForLine( buffer, bytesRead );

    if(!listenOk) {

        int status;
        if(waitpid(myPid_, &status, 0)>0) {

            if (WIFEXITED(status)) {                    /* did child exit normally? */
                int child_val = WEXITSTATUS(status);    /* get child's exit status */
                if ( child_val != 0 ) {
                    throw ChildProcessExitWithErrorException(child_val);
                }
            }
            else if(WIFSIGNALED(status)) {
                throw KError( PM("Child process was terminated by signal %1; core dumped: %2\n") )
                        << WTERMSIG(status) << WCOREDUMP(status);
            }
            else {
                throw KError( PM("Child process did something unexpected: waitpid() status: %1\n") )
                        << status;
            }
        }
        else {
            throw KError( PM("Waiting for child process failed: %1") )
                    <<  strerror(errno);
        }

    }

    return listenOk;
}

void UnixProcess::sendMessage(Str::Text::Arg message)
{
    listener_.sendMessage( message );
}

int UnixProcess::GetExitCode()
{
	int status = 0;
	auto ret = ::waitpid(myPid_, &status, WNOHANG);

	if (ret == 0) // still running
	{
		throw KError("Process is still running");
	}
	else if ((ret == -1) && (errno != ECHILD))
	{
		throw KError((RawMessage("Error, child process: %1") << std::strerror(ECHILD)).str());
	}

	return status; // valid as exit code iff not running
}

ErrorCode UnixProcess::GetErrorCode()
{
	// retrieve registered system error
	ErrorCode ec = errno;

	int status = 0;
	auto ret = ::waitpid(myPid_, &status, WNOHANG);

	if (ret == 0) // still running
	{
		return ec;
	}

	// ignore a bad file descriptor on process finish on Ubuntu 20
	// TODO extend documentation on the need for this
	auto const ERRNO_BAD_FILE_DESCRIPTOR = 9;
	auto const DISTRO_UBUNTU_20 = "ubuntu-20";
	auto const os = std::string(OS_DISTRO);
	if ((ec == ERRNO_BAD_FILE_DESCRIPTOR) && (os == DISTRO_UBUNTU_20))
	{
		return 0;
	}

	// for legacy, ignore broken pipe errors on process finish
	if (ec == ERROR_BROKEN_PIPE)
	{
		return 0;
	}

	return ec;
}

} // namespace runextern


#endif

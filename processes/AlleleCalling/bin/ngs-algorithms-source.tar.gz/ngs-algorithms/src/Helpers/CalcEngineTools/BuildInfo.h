#pragma once

#include <string>

std::string GetBuildNumber();

const char* GetBuildDate();

const char* GetBuildBranch();

std::string GetCEVersion();

#include "stdafx.h"
#include "AlignmentPair.h"

SeqBAM::Bowtie2Filter::AlignmentPair::AlignmentPair() : first(nullptr), second(nullptr), score(std::numeric_limits<double>::min()), pos(-1)
{

}

SeqBAM::Bowtie2Filter::AlignmentPair::AlignmentPair(const AlignmentWithScore* one, const AlignmentWithScore* two) : first(one), second(two)
{
    ASSERT(one);
    ASSERT(two);

    double totalSize = first->length + second->length;

    if(totalSize > 0)
        score = (first->score * first->length + second->score * second->length) / totalSize;
    else
        score = 0.0;

    pos = first->read->core.pos + 1699 * second->read->core.pos;
}

SeqBAM::Bowtie2Filter::AlignmentPair::MatchPosition SeqBAM::Bowtie2Filter::AlignmentPair::matchPosition() const
{
    return pos;
}

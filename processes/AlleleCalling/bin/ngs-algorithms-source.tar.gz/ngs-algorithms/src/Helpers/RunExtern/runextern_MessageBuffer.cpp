#include "stdafx.h"

#include "boost/algorithm/string.hpp"

#include "runextern_MessageBuffer.h"


namespace runextern
{
    

void MessageBuffer::reset()
{
    size_t numChars = sizeof(buffer_) / sizeof(char);
    memset( &buffer_, 0, numChars );
}

/**
    \return The buffer, split into separate lines
*/
Str::Text::Vec MessageBuffer::getBufferLines() const
{
    Str::Text::Vec lines;
    boost::split( lines, getBuffer(), boost::is_any_of(PM("\r\n")) );
    // Remove empty elements
    lines.resize( std::remove_if( lines.begin(), lines.end(), []( const Str::Text::Val& val ){ return val.empty(); } ) - lines.begin() );
    return lines;
}

/**
    Truncates the content of the buffer to `len` characters at most.
*/
void MessageBuffer::truncate(int len)
{
    if(len>=0 && len<sizeof(buffer_) / sizeof(char)) {
        buffer_[len]='\0';
    }
}


} // namespace runextern
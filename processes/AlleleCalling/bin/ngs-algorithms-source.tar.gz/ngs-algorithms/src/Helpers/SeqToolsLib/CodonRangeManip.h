#pragma once
/**
    \sa CodonManip.h
*/


#include "boost/algorithm/string/predicate.hpp"

#include "Codons.h"
#include "FrameRange.h"
#include "FrameDirection.h"


namespace seq
{


template<typename T_It>
bool StartsWithStartCodon( T_It begin, T_It end, const Codons& startCodons )
{
    if ( begin == end )
        return false;

    for ( auto&& codon: startCodons )
        if ( boost::algorithm::starts_with(std::make_pair(begin, end), codon) )
            return true;

    return false;
}

template<typename T_It>
bool EndsWithStopCodon( T_It begin, T_It end, const Codons& stopCodons  )
{
    if ( begin == end )
        return false;

    for ( auto&& codon: stopCodons )
        if ( boost::algorithm::ends_with(std::make_pair(begin, end), codon) )
            return true;

    return false;
}

template<typename T_It>
bool ContainsCodonAt( T_It begin, const Codons& codons )
{
    for ( auto&& codon: codons ){
        if (   codon[0] == *begin
            && codon[1] == *(begin+1)
            && codon[2] == *(begin+2) )
        {
            return true;
        }
    }

    return false;
}

template<typename T_It >
bool QueryFrameForwardRange( 
                      T_It begin,
                      T_It end,
                      FrameRange     range,
                      std::function<bool (T_It,T_It)> f )
{
    ASSERT(begin <= end );

    switch( range ){
    default:
    case FrameRange::All:
        return f(begin, end);

    case FrameRange::StartExcluded:
        if ( end - begin < 3 )
            return false;

        return f(begin+3, end);

    case FrameRange::EndExcluded:
        if ( end - begin < 3 )
            return false;

        return f(begin, end-3);

    case FrameRange::Internal:
        if ( end - begin < 6 )
            return false;
        return f(begin+3, end-3);
    }
}

template<typename T_It >
bool QueryFrameReverseRange( 
                    T_It begin,
                    T_It end,
                    FrameRange     range,
                    std::function<bool (T_It,T_It)> f )
{
    ASSERT(begin <= end );

    switch( range ){
    default:
    case FrameRange::All:
        return f(begin, end);

    case FrameRange::StartExcluded:
        if ( end - begin < 3 )
            return false;

        return f(begin, end-3);

    case FrameRange::EndExcluded:
        if ( end - begin < 3 )
            return false;

        return f(begin+3,end);

    case FrameRange::Internal:
        if ( end - begin < 6 )
            return false;
        return f(begin+3, end-3);
    }
}

template<typename T_It>
bool ContainsCodonInForwardFrame( T_It begin, T_It end, const Codons& codons, FrameRange range )
{
    return QueryFrameForwardRange<T_It>(begin, end, range, [&codons](T_It begin, T_It end){
        // - 3 : needed to avoid going over the end
        for( ; begin <= end - 3; begin += 3 ) {
            if ( ContainsCodonAt(begin, codons) )
                return true;        
        }

        return false;
    });
}

/**
    begin and end should not be reversed i.e. begin < end.

    \param range Applied to the reverse range! i.e. excluding the last
                 codon in the search excludes the codon at the start of the forward sequence.
    \param end   In the typical iterator sense i.e. one past the last element!
*/
template<typename T_It>
bool ContainsCodonInReverseFrame( T_It begin, T_It end, const Codons& codons, FrameRange range )
{
    ASSERT(begin <= end );

    return QueryFrameReverseRange<T_It>(begin, end, range, [&codons](T_It begin, T_It end){
        // Reverse search: terminates faster if stop codon present towards the end
        for( ; begin <= end - 3; end -= 3 ) {
            if ( ContainsCodonAt(end-3, codons) )
                return true;    
        }

        return false;
    });
}

template<typename T_It>
bool ContainsInternalStopCodon( T_It begin, T_It end, const Codons& codons, FrameDirection frame )
{
    if ( frame == FrameDirection::Forward )
        return ContainsCodonInForwardFrame(begin, end, codons, FrameRange::EndExcluded);
    else
        return ContainsCodonInReverseFrame(begin, end, codons, FrameRange::EndExcluded);
}

} // namespace seq

#include "stdafx.h"

#ifdef AMGNU

#include "UnixPipe.h"

#include <unistd.h>
#include <fcntl.h>

#include "exception.h"


namespace runextern
{


UnixPipe::UnixPipe()
    : pipes_()
{
    pipes_[0] = -1;
    pipes_[1] = -1;
}

 UnixPipe::UnixPipe(int pipes[2])
     : pipes_()
 {
     pipes_[0] = pipes[0];
     pipes_[1] = pipes[1];
 }

 int UnixPipe::getReadDescriptor()
 {
     return pipes_[0];
 }

 int UnixPipe::getWriteDescriptor()
 {
     return pipes_[1];
 }

 void UnixPipe::closeForReading()
 {
     close( pipes_[0] );
 }

 void UnixPipe::closeForWriting()
 {
     close( pipes_[1] );
 }

 /**
    \return true if creating the pipes succeeded, false otherwise
 */
 bool UnixPipe::create()
 {
     // pipe: returns 0 on success
     return pipe( pipes_ ) == 0;
 }

 void UnixPipe::setCloseWriteOnExit()
 {
     if ( fcntl(getWriteDescriptor(), F_SETFD, fcntl(getWriteDescriptor(), F_GETFD) | FD_CLOEXEC) )
         throw KError( PM("Unable to set the write endpoint of the pipe to close on exit") );
 }

 Str::Text::Val UnixPipe::getErrorText( int errorCode )
 {
     Str::Text::Val reason;
     switch( errorCode ){
     case E2BIG:
         reason = PM("The number of bytes in the new process's argument list is larger than the system-imposed systemimposed imposed limit");
         break;
     case EACCES:
         reason = PM("(EACCES) Search permission is denied for a component of the path prefix/The new process file is not an ordinary file/The new process file mode denies execute permission/The new process file is on a filesystem mounted with execution disabled.");
         break;
     case EFAULT:
         reason = PM("The new process file is not as long as indicated by the size values in its header|Path, argv, or envp point to an illegal address.");
         break;
     case EIO:
         reason = PM("An I/O error occurred while reading from the file system.");
         break;
     case ELOOP:
         reason = PM("Too many symbolic links were encountered in translating the pathname.  This is taken to be indicative of a looping symbolic link.");
         break;
     case ENAMETOOLONG:
         reason = PM("A component of a pathname exceeded {NAME_MAX} characters, or an entire path name exceeded {PATH_MAX} characters.");
         break;
     case ENOENT:
         reason = PM("The new process file does not exist.");
         break;
     case ENOEXEC:
         reason = PM("The new process file has the appropriate access permission, but has an unrecognized format (e.g., an invalid magic number in its header).");
         break;
	 case EBADF:
		 reason = PM("Bad file descriptor.");
         break;
     case ENOMEM:
         reason = PM("The new process requires more virtual memory than is allowed by the imposed maximum");
         break;
     case ENOTDIR:
         reason = PM("A component of the path prefix is not a directory.");
         break;
     case ETXTBSY:
         reason = PM("The new process file is a pure procedure (shared text) file that is currently open for writing or reading by some process.");
         break;
     default:
         reason = RawMessage( PM("Unknown (%1)"), errorCode ).c_str();
         break;
     }
     return reason;
 }

/**
     Redirect stdout to the write end of this pipe
*/
 void UnixPipe::captureStdOut()
 {
     if ( dup2(getWriteDescriptor(), STDOUT_FILENO) == -1 )
         throw KError( PM("Failed to capture stdout") );
 }

 /**
    Redirect stderr to the write end of this pipe
 */
 void UnixPipe::captureStdErr()
 {
     if ( dup2(getWriteDescriptor(), STDERR_FILENO) == -1 )
         throw KError( PM("Failed to capture stderr") );
 }

 /**
    Replace stdin by the read part of this pipe i.e. reading from stdin
    actually reads from this pipe instead
 */
 void UnixPipe::captureStdIn()
 {
     if ( dup2(getReadDescriptor(), STDIN_FILENO) == -1 )
         throw KError( PM("Failed to capture stdin") );
 }

 UnixPipe::~UnixPipe()
 {
     //closing a file descriptor that was already closed is fine
     if(pipes_[0] >= 0)
         close(pipes_[0]);
     if(pipes_[1] >= 0)
         close(pipes_[1]);
 }

} // namespace runextern


#endif // #ifdef AMGNU

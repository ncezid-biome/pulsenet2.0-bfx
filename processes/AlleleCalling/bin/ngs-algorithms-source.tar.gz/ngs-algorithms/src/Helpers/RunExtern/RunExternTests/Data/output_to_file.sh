#!/bin/bash

#we do some extra effort to emit carriage returns to mimick windows
echo -e I feel the heat wave and I like it'\r'
echo -e $@'\r'

sleep 1

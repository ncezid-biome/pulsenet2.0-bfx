#pragma once
#include <StringDef.h>
#include <vector>
#include "BAMAlignment.h"
#include "SAMWrapper.h"

namespace BAM
{

/**
 * This class can be used to write a few Alignments from the same template to a BAM file
 * en groupe. Although this can also be done manually, this class takes care setting the
 * common name and linking the reads.
 */
class STW_DLLPORT AlignmentTemplate
{

public:

    /**
     * Aligments in the same template have the same name. With this method, one can
     * set that name. The name should be set before the first segment is added.
     */
    void SetName(Str::Text::Val name)
    {
        name_ = name;
    }

    void AddSegment(Alignment::Ptr segment);

    void WriteToBAMFile(bamFile file);


private:

    Str::Text::Val name_;
    std::vector<Alignment::Ptr> segments_;
};

}


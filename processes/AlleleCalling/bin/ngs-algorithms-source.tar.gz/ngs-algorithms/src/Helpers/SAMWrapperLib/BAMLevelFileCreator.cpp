#include "stdafx.h"
#include "BAMLevelFileCreator.h"

namespace BAM
{

void LevelFileCreator::CreateLevelFile(FileResolver::Ptr files)
{
    currentBlock_=UINT64_MAX;

    output_.open(files->GetBAMLevelFile().string(), std::ios::binary);

    strncpy(header.signature, "BLF0", 4);
    header.blockHeadersOffset=0;
    header.numberOfBlockHeaders=0;

    output_.write((char*)&header, sizeof(Header));

    //invoke pileup routines
    OpenFile(files);
    CreateLeveledPileup();

    Complete();
}

void LevelFileCreator::Complete()
{

    BlockHeader blockHeader;

    //add end block to blockHeaders
    blockHeader.blockAddress=0xFFFFFF;
    blockHeader.fileOffset=output_.tellp();
    blockHeaders.push_back(blockHeader);

    //update header
    header.blockHeadersOffset=output_.tellp();
    //do not include end block
    header.numberOfBlockHeaders=blockHeaders.size()-1;

    for(const auto& bHeader: blockHeaders) {
        output_.write((char*)&bHeader, sizeof(BlockHeader));
    }

    output_.seekp(0);
    output_.write((char*)&header, sizeof(Header));
    output_.close();
}

void LevelFileCreator::AddRead(BamTold bamTold, ReadLevel level)
{

    //std::cout << "adding " << std::hex << bamTold << std::dec << " level: "  << level << std::endl;

    if(currentBlock_!=GetBlockAddress(bamTold)) {

        BlockHeader blockHeader;

        //std::cout << "New block address: " << std::hex << GetBlockAddress(bamTold) << std::dec << std::endl;

        blockHeader.blockAddress=currentBlock_=GetBlockAddress(bamTold);
        blockHeader.fileOffset=output_.tellp();

        blockHeaders.push_back(blockHeader);
    }

    ReadInfo readInfo;

    readInfo.blockOffset=GetBlockOffset(bamTold);
    readInfo.readLevel=level;

    output_.write((char*)&readInfo, sizeof(ReadInfo));
}

int LevelFileCreator::FetchCallback(bam1_t& b)
{
    //this is a new read
    b.extra=(void*)0;
    return 0;
}

int LevelFileCreator::PileupCallback(uint32_t tid, uint32_t pos, int n, const bam_pileup1_t pl[])
{

    for(int m=0; m<n; m++) {

        if(pl[m].b->extra==0) {

            //std::cout << "Adding " << pl[m].b->data << ": tid=" << pl[m].b->core.tid << ", pos=" << pl[m].b->core.pos << "," << pl[m].qpos << ", told: " << std::hex << pl[m].b->told << std::dec << ", calc level: " << pl[m].level << std::endl;

            //levels from samtools are one-based, apply correction
            AddRead(pl[m].b->told, pl[m].level-1);

            //mark as processed read
            pl[m].b->extra=(void*)1;
        }
    }
    return 0;
}

bool LevelFileCreator::HasLevelFile(FileResolver::Ptr files)
{
    using namespace boost::filesystem;

    //TODO: sanity check on header or something

    if(exists(files->GetBAMLevelFile())) {

        std::time_t lastWrite=last_write_time(files->GetBAMLevelFile());

        if(lastWrite >= last_write_time(files->GetSortedBAMFile())
           && lastWrite >= last_write_time(files->GetBAMIndexFile()))
            return true;
    }

    return false;
}

}
/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#ifndef RANDOM_H
#define RANDOM_H


bool GetRandomBool(double p);
char GetRandomBase();
double GetRandomNumber(double low, double high);

#endif
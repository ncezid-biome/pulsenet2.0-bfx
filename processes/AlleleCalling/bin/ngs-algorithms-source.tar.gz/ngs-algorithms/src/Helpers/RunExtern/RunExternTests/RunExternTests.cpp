#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "boost/algorithm/string.hpp"
#include "boost/chrono/system_clocks.hpp"
#ifdef AMGNU
#include "boost/chrono/detail/inlined/posix/chrono.hpp"
#include <sys/stat.h>
#endif

#include "translate.h"
#include "debugstr.h"
#include "userbreak.h"

#include "runextern_tests.h"
#include "runextern_appListener.h"
#include "CalcCommunicationReporter.h"

using namespace runextern;

#ifdef AMGNU
#include "UnixProcess.h"
#define Sleep   sleep
#else
#include "WindowsProcessPool.h"
#endif
#include "textfile.h"

struct RunExternTestsFixture {

#ifdef AMGNU

    RunExternTestsFixture()
    {
        //on linux, set test scripts as executable
        SetExecutable(getDataFilePath(GetScriptName(PM("sleep_1"))));
        SetExecutable(getDataFilePath(GetScriptName(PM("echo_oi"))));
        SetExecutable(getDataFilePath(GetScriptName(PM("output_to_file"))));
    }

    void SetExecutable(const Str::Text::Val& script)
    {
        if(chmod(script.c_str(), 0755))
            //only show a warning, we may not have permission to change permissions, and if they are executable already, thats cool
            std::cerr << "Could not set permission of test script " << script << ": " << strerror(errno) << std::endl;
    }

    Process::Ptr CreateProcess()
    {
        return boost::make_shared<UnixProcess>();
    }

    inline Str::Text::Val GetScriptName(const Str::Text::Val& base)
    {
        return base + ".sh";
    }
#else
    Process::Ptr CreateProcess()
    {
        WindowsProcess::Ptr process( pool_.CreateProcess() );
        return process;
    }

    inline Str::Text::Val GetScriptName(const Str::Text::Val& base)
    {
        return base + ".bat";
    }
#endif

    Process::Ptr RunScript( const Str::Text::Val& script )
    {
        Process::Ptr process = CreateProcess();

        process->setCmdLine( ProcessCmdLine(getDataFilePath(script)) );

        if (! process->run() )
            BOOST_FAIL( process->getStatus().getErrorText() );

        return process;
    }

    void TestScript( const Str::Text::Val& script, const Str::Text::Val& output )
    {
        Process::Ptr process = RunScript( script );

        // Give the command the time to execute
        Sleep(100);

        int           bytesread = 0;
        MessageBuffer message;
        message.reset();
        if ( ! process->checkForMessage( message, bytesread ) )
            BOOST_FAIL( process->getStatus().getErrorText() );

        Str::Text::Vec lines = message.getBufferLines();

        BOOST_REQUIRE( lines.size() > 0 );

        // Give the last line, first line might contain the command
        BOOST_REQUIRE_EQUAL( output, lines.back() );
    }

public:
#ifndef AMGNU
    WindowsProcessPool pool_;
#endif
};

BOOST_FIXTURE_TEST_SUITE( runExternTests, RunExternTestsFixture );

BOOST_AUTO_TEST_CASE(RunSetProcess)
{
    Process::Ptr process = CreateProcess();

    process->setCmdLine( ProcessCmdLine(PM("echo test")) );

    process->run();

    int           bytesread = 0;
    MessageBuffer message;
    BOOST_REQUIRE(process->checkForMessage( message, bytesread ));

    debug_str << message.getBuffer() << std::endl;
}

BOOST_AUTO_TEST_CASE(RunEchoOi_CheckOutput)
{
    TestScript( GetScriptName(PM("echo_oi")), PM("oi") );
}

BOOST_AUTO_TEST_CASE(RunSleep_listen)
{
    boost::chrono::steady_clock::time_point start = boost::chrono::steady_clock::now();

    ProcessInfo info;
    Process::Ptr process = RunScript( GetScriptName(PM("sleep_1")) );

    process->setInfo(info);

    communication::CalcCommunication dummy;
    CalcCommunicationReporter reporter(dummy);
    ExternAppListener listener( process, info );

    // don't run threaded
    listener.listen(reporter);

    boost::chrono::duration<double> elapsed = boost::chrono::steady_clock::now() - start;

    BOOST_REQUIRE( elapsed.count() > 1.0 );
}

BOOST_AUTO_TEST_CASE(RunOutputToFile)
{
    ProcessInfo info;
    Process::Ptr process = CreateProcess();

    Str::ID::Val id(ToStr(boost::chrono::steady_clock::now().time_since_epoch().count()));
    Str::Path::Val outputFile(id + ".txt");

    Str::Text::Val expected = "I feel the heat wave and I like it\r\nSeeeee how they rollll " + id + "\r\n";

    ProcessCmdLine output_to_file(getDataFilePath(GetScriptName("output_to_file")));
    output_to_file << "Seeeee how they rollll" << id;
    output_to_file.SetOutputFile(outputFile);

    process->setCmdLine(output_to_file);
    process->setInfo(info);

    if (! process->run() )
        BOOST_FAIL( process->getStatus().getErrorText() );

    communication::CalcCommunication dummy;
    CalcCommunicationReporter reporter(dummy);
    ExternAppListener listener( process, info );

    //wait for termination
    listener.listen(reporter);

#ifndef AMGNU
    //on windows, the file is sometimes not immediately accessible
    Sleep(1000);
#endif

    BOOST_REQUIRE(boost::filesystem::exists(outputFile));

    {
        Str::Text::Val result;
        TextFile resultFile(outputFile.string(), TextFile::read);
        resultFile.ReadFile(result);

        BOOST_CHECK_EQUAL(expected, result);
    }

    BOOST_REQUIRE(boost::filesystem::remove(outputFile));
}

BOOST_AUTO_TEST_SUITE_END();


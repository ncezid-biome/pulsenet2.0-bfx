#include "stdafx.h"

#include "allelefinder.h"

#include "boost/math/distributions.hpp"

#include "IBuffImpl.h"

#include "filewriter.h"

#include "filetools.h"
#include "logging.h"
#include "helper.h"
#include "XmlReportBuilder.h"
#include "HashMap.h"
#include "LocusOutput.h"
#include "kmer.h"

#include "CE_LogAction.h"
#include "CE_Communication.h"
#include "CE_ExecuteEnvironment.h"

#include "AlleleInfo.h"
#include "AlleleKMerTable.h"
#include "allelefindersettings.h"

#include "StatsCalculator.h"
#include "SRSStatsCalculatorSettings.h"
#include "NamedSequence.h"
#include "SequenceManip.h"
#include "SequenceInspect.h"
#include "AlleleName.h"

//#include "referencemapper.h"
//#include "referencemappersettings.h"
//#include "BowtieMapper.h"

#include "SequenceRangeInspect.h"
#include "CodonRangeManip.h"

using namespace seq;


void fillFinderFactory()
{
    RegisterFactoryTrait<KMerAlleleFinder>::RegisterItem();
}

AlleleFinderAlgorithm::AlleleFinderAlgorithm()
{
}
AlleleFinderAlgorithm::~AlleleFinderAlgorithm()
{
}
int AlleleFinderAlgorithm::ExecuteImpl(int argc, char* argv[], const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm)
{
    AlleleFinderSettings settings;
    if (settings.ParseAndSetup(argc, argv, env, comm)) {
		settings.LogSettings(comm);
        {
            StatsCalculator            stats;
            SRSStatsCalculatorSettings statsSettings(SRSStatsCalculatorSettings::Standalone::No);

            // Give the poor baby some files and some default values
            statsSettings.AddFiles( settings.readFiles, settings.readFileTypes );

            // Possibly get some extra stuff from the cmd line
            statsSettings.ParseAndSetup( argc, argv, env, comm );

            stats.Calculate( statsSettings, env, comm );
		}

        // Run the algorithm
        AlleleFinder::Apply(settings, env, comm);
        return 0;
    } else {
		settings.showHelp(std::cout);
        return 1;
	}
}



AlleleFinder::AlleleFinder()
{
}
AlleleFinder::~AlleleFinder()
{
}
void AlleleFinder::parseFiles(const AlleleFinderSettings& settings, SequenceFiles& downloadedfiles, const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm) const
{
    auto fileLocators = settings.readFiles;

    InputFileParser fileParser;

    for ( const auto& file : settings.readFiles )
        fileParser.AddFile( file );

    downloadedfiles.merge( fileParser.GetFiles() );
}
void AlleleFinder::apply(const AlleleFinderSettings& settings, const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm) const
{
    checkPre(settings, comm);

    SequenceFiles inputFiles;
    parseFiles(settings, inputFiles, env, comm);

    if ( inputFiles.isEmpty() )
        throw KError( PM("Unable to find alleles: no files present") );

    inputFiles.Log( PM("Files"), comm );

    applyImpl(settings, inputFiles, env, comm);
}
void AlleleFinder::Apply(const AlleleFinderSettings& settings, const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm)
{
    AlleleFinderPtr finder = AlleleFinder::Factory::GetMap(settings.algorithmType);
    if (finder==0)
        throw KError("Could not find algorithm '%1'.") << settings.algorithmType;

    finder->apply(settings, env, comm);
}


KMerAlleleFinder::KMerAlleleFinder()
{
}
KMerAlleleFinder::~KMerAlleleFinder()
{
}
KMerAlleleFinder::FactoryIDType::Ref KMerAlleleFinder::GetTypeName()
{
    return "KMerAlleleFinder";
}
KMerAlleleFinder::FactoryIDType::Ref KMerAlleleFinder::GetFactoryType() const
{
    return GetTypeName();
}
AlleleFinderPtr KMerAlleleFinder::Clone() const
{
    return AlleleFinderPtr(new KMerAlleleFinder);
}
void KMerAlleleFinder::checkPre(const AlleleFinderSettings& settings, const communication::CalcCommunication& comm) const
{
    if ( ! settings.HasAlleleFile() )
        throw KError("No allele file specified.");

    for (size_t i=0; i<settings.readFiles.size(); ++i) {
        SeqFileReaderPtr reader = SeqFileReader::AutoDetect(settings.readFiles[i], settings.readFileTypes[i])->Clone();
        if (reader==0)
            throw KError("Unknown file format '%1'.") << settings.readFileTypes[i];
    }
}


class AlleleRelations
{
private:
    typedef std::hash_map<size_t, std::vector<size_t>> RelationsMap;
    RelationsMap parents_;
public:
    inline void AddParent(size_t childid, size_t parentid)
    {
        parents_[childid].push_back(parentid);
    }
    inline bool HasParent(size_t childid, std::vector<size_t>& parents)
    {
        auto it = parents_.find(childid);
        if (it==parents_.end()) return false;

        parents = it->second;
        return !parents.empty();
    }
    inline void toStream(std::ostream& os)
    {
        for(auto it = parents_.begin(); it!=parents_.end(); ++it) {
            os << it->first << "\t:\t";
            for(size_t i=0; i<it->second.size(); ++i) os << it->second[i] << '\t';
            os << '\n';
        }
    }
};




class LocusCoverage;
class AlleleCoverage
{
    friend class LocusCoverage;
private:
    size_t nKeywords_;
    size_t nKeywordsMissing_;
    size_t totCov_, minCov_, maxCov_;
public:
    AlleleCoverage() : nKeywords_(0), nKeywordsMissing_(0), totCov_(0), maxCov_(0), minCov_(std::numeric_limits<size_t>::max()) {}

    inline void add(size_t cov, bool present)
    {
        ++nKeywords_;
        if (present) {
            totCov_+=cov;
            minCov_ = std::min(minCov_, cov);
            maxCov_ = std::max(maxCov_, cov);
        }
        else {
            ++nKeywordsMissing_;
        }
    }
    inline double getKeywordCoverage() const
    {
        return (1.0* nKeywords_ - 1.0* nKeywordsMissing_) / (1.0* nKeywords_);
    }
    inline void toStream(std::ostream& os)
    {
        os	<< nKeywords_ << '\t'
            << nKeywordsMissing_ << '\t'
            << ( nKeywords_ ? ((1.0*totCov_) / (1.0*nKeywords_)) : 0.0 ) << '\t'
            << minCov_ << '\t'
            << maxCov_ << '\t';
    }
};

class LocusCoverage
{
private:
    size_t nAlleles_;
    struct Allele {
        size_t idx_;
        size_t coverage_;
        double identify_;
        Allele(size_t idx, size_t coverage, double identify)
            : idx_(idx)
            , coverage_(coverage)
            , identify_(identify)
        {}
    };
    std::vector<Allele> alleles_;
	Allele unknownAllele_;
    size_t runnerUpAllele_;
    size_t nKeywords_;
    size_t nKeywordsMissing_;
    size_t totCov_, minCov_, maxCov_;
    double nCopies_ ;
    double maxKeywordCoverage_, runnerUpKeywordCoverage_;
public:
    LocusCoverage()
        : maxKeywordCoverage_(0)
        , runnerUpKeywordCoverage_(0)
        , nAlleles_(0)
        , nKeywords_(0)
        , nKeywordsMissing_(0)
        , totCov_(0)
        , maxCov_(0)
        , minCov_(std::numeric_limits<size_t>::max())
        , nCopies_(0)
		, unknownAllele_(0,0,0)
   {}

    inline void add(size_t alleleid, const AlleleCoverage& cov, double keywordCoverageThreshold)
    {
        if (cov.getKeywordCoverage()>=keywordCoverageThreshold) {
            alleles_.push_back(Allele(alleleid, cov.totCov_, cov.getKeywordCoverage()));
        }
		else if(cov.getKeywordCoverage()>unknownAllele_.identify_)
			unknownAllele_ = Allele(alleleid, cov.totCov_, cov.getKeywordCoverage());

        if (maxKeywordCoverage_>cov.getKeywordCoverage()) {
            if (runnerUpKeywordCoverage_<cov.getKeywordCoverage()) {
                runnerUpKeywordCoverage_=cov.getKeywordCoverage();
                runnerUpAllele_=alleleid;
            }
        }
        else{
            maxKeywordCoverage_ = cov.getKeywordCoverage();
		}
        ++nAlleles_;
        nKeywords_+=cov.nKeywords_;
        nKeywordsMissing_+=cov.nKeywordsMissing_;
        totCov_+=cov.totCov_;
        minCov_=std::min(minCov_, cov.minCov_);
        maxCov_=std::max(maxCov_, cov.maxCov_);
    }
    inline void cleanup(AlleleRelations& relations, const communication::CalcCommunication& comm)
    {
        using namespace std;
        hash_set<size_t> covered;
        for(size_t i=0; i<alleles_.size(); ++i) covered.insert(alleles_[i].idx_);

        bool done=false;
        std::vector<size_t> parents, toremove;
        for(size_t i=0; i<alleles_.size(); ++i) {
            if (relations.HasParent(alleles_[i].idx_, parents)) {
                done = false;
                for(size_t j=0; j<parents.size() && !done; ++j) {
                    if (covered.find(parents[j])!=covered.end()) {
                        toremove.push_back(i);
                        done=true;
                    }
                }
            }
        }

        for(size_t i=toremove.size(); i>0; --i) {
            alleles_.erase(alleles_.begin()+toremove[i-1]);
        }

        //if (!toremove.empty())
        //	comm.Send( communication::CalcMessage( Message("\tRemoved %1 overlapping alleles!", toremove.size()).str()) );
    }
    inline void setNCopies(double nCopies)
    {
        nCopies_=nCopies;
    }
    inline double getKeywordCoverage() const
    {
        return (1.0* nKeywords_ - 1.0* nKeywordsMissing_) / (1.0* nKeywords_);
    }
    inline double getMaxKeywordCoverage() const
    {
        return maxKeywordCoverage_;
    }
    inline double getAvgCoverage() const
    {
        return ( nKeywords_ ? ((1.0*totCov_) / (1.0*nKeywords_)) : 0.0 );
    }
    inline size_t nAlleles() const
    {
        return alleles_.size();
    }
    inline void allelesToStream(std::ostream& os, const Str::Text::Vec& alleleNames, double thresholdForPresence)
    {
        if (!alleles_.empty()) {
            os << AlleleName::ExtractAlleleNumber(alleleNames[alleles_[0].idx_]);
            for(size_t i=1; i<alleles_.size(); ++i)
                os<<',' << AlleleName::ExtractAlleleNumber(alleleNames[alleles_[i].idx_]);
        }
        else if (maxKeywordCoverage_>=thresholdForPresence) {
            os << "?";
        }
    }
    inline void allelesToOutput(std::vector<LocusOutput::Allele>& alleles
                                , const AlleleKMerTable::AllelesInfo& allelesInfo
                                , double thresholdForPresence
                                , size_t k)
    {
        if (!alleles_.empty()) {
            for(size_t i=0; i<alleles_.size(); ++i) {
                LocusOutput::Allele a;
                {
                    const AlleleKMerTable::ShortAlleleInfo& info = allelesInfo[alleles_[i].idx_];
                    a.id = AlleleName::ExtractAlleleNumber(info.name_);
                    a.kwCoverage = alleles_[i].coverage_ * 1.0 / (info.length_ - k +1); //coverage which should match de novo coverage theoretically
                    a.sequenceIdentity = alleles_[i].identify_*100;
                }
                alleles.push_back(a);
            }
        }
        else if (maxKeywordCoverage_>=thresholdForPresence) {
            LocusOutput::Allele a;
            {
                a.id = -2;
                const AlleleKMerTable::ShortAlleleInfo& info = allelesInfo[unknownAllele_.idx_];
                a.kwCoverage = unknownAllele_.coverage_ * 1.0 / (info.length_ - k +1); //coverage which should match de novo coverage theoretically
                a.sequenceIdentity = unknownAllele_.identify_*100;
            }
            alleles.push_back(a);
        }
    }
    inline void statsToStream(std::ostream& os)
    {
        os	<< nCopies_ << '\t'
            << maxKeywordCoverage_ << '\t'
            << runnerUpKeywordCoverage_ << '\t'
            << nKeywords_ << '\t'
            << nKeywordsMissing_ << '\t'
            << ( nKeywords_ ? ((1.0*totCov_) / (1.0*nKeywords_)) : 0.0 ) << '\t'
            << ( (nKeywordsMissing_==nKeywords_) ? 0 : minCov_) << '\t'
            << maxCov_;
    }
};


class AlleleCoverageResult
{
};


class AlleleCoverageData
{
private:
    KMerTable<AlleleInfo>& table_;
    std::vector<AlleleCoverage>& alleleCoverage_;
    size_t threshold_, thresholdFwd_, thresholdRev_;
public:
    AlleleCoverageData(std::vector<AlleleCoverage>& alleleCoverage, KMerTable<AlleleInfo>& table, size_t threshold, size_t thresholdFwd, size_t thresholdRev)
        : alleleCoverage_(alleleCoverage), table_(table), threshold_(threshold), thresholdFwd_(thresholdFwd), thresholdRev_(thresholdRev)  {}

    inline KMerTable<AlleleInfo>& getTable()
    {
        return table_;
    }
    inline std::vector<AlleleCoverage>& getCoverage()
    {
        return alleleCoverage_;
    }
    inline size_t getThreshold() const
    {
        return threshold_;
    }
    inline size_t getThresholdFwd() const
    {
        return thresholdFwd_;
    }
    inline size_t getThresholdRev() const
    {
        return thresholdRev_;
    }


};

class AlleleCoverageHandler
{
private:
    AlleleCoverageData* data_;
public:
    AlleleCoverageHandler() : data_(0) {}

    inline void init(AlleleCoverageData& data)
    {
        data_ = &data;
    }
    inline void handle(const Str::Text::Val& name, const Str::Text::Val& seq, const Str::Text::Val& qual, size_t index)
    {
        size_t k = data_->getTable().getK();
        if (seq.size()<k) return;
        KMerTable<AlleleInfo>::Key key;
        bool fwd;
        for(size_t i=0; i<=seq.size() - k; ++i) {
            data_->getTable().getKey(seq.c_str()+i, key, fwd);
            const AlleleInfo& info = data_->getTable().getInfo(key);
            data_->getCoverage()[index].add(info.getCnt(), info.getCnt()>=data_->getThreshold() && info.getCntFwd()>=data_->getThresholdFwd() && info.getCntRev()>=data_->getThresholdRev());
        }
    }
    inline void intermediate()
    {
    }
    inline void finish(AlleleCoverageResult& result)
    {
    }
};


void KMerAlleleFinder::applyImpl(const AlleleFinderSettings& settings, const SequenceFiles& downloadedfiles, const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm) const
{
    size_t nCoresForScreening = env.GetMaxNumThreads();
    size_t nCoresForCoverage  = env.GetMaxNumThreads();


    /*	--- PART ONE ------------------------------------------------------------------------------
    	Build up the search structure. Two possibilities depending on the parameter
    		settings.createKMerTable
    	If this parameter is true, then
    		- the search structure is built up from the allele file in settings.alleleFile
    		- if the parameter settings.kmerTableFile is set to something non-empty, the
    			table is stored in this file
    	If this parameter is false, then the file settings.kmerTableFile is read.

    	We als read the allele names here (some overhead, because we actually read the allele file!).
    	Note that we do not need the actual allele names until we perform output, we just need to know
    	how many there are.
    	------------------------------------------------------------------------------------------- */

    AlleleFinderData::Ptr finderData;
    {
        engine::LogBlock action( PM("Building up search structure"), comm );
        finderData.reset( new AlleleFinderData(settings, comm) );
        action.LogSuccess();
    }

    if (settings.readFiles.empty())
        return;

    // --- END OF PART ONE ------------------------------------------------------------------------

    /*	--- PART TWO ------------------------------------------------------------------------------
    	Screen the reads against the search structure.
    	------------------------------------------------------------------------------------------- */

    comm.Send( communication::CalcMessage("Screening the reads...") );

    for (size_t i=0; i<downloadedfiles.files.size(); ++i) {
        for (size_t j=0; j<downloadedfiles.files[i].files.size(); ++j) {

            comm.Send( communication::CalcMessage(Message(TXT("Screening file '%1' ... "),  downloadedfiles.files[i].files[j].string())) );
            SeqFileReaderPtr reader = SeqFileReader::AutoDetect(ToRef(downloadedfiles.files[i].files[j].string()), downloadedfiles.files[i].filetype)->Clone();
			comm.Send( communication::CalcMessage( Message("Opening file of type: '%1'...") << reader->GetFactoryType() ) );
            reader->init(ToRef(downloadedfiles.files[i].files[j].string()), 5000000);

            ScreenKMerTable(reader, finderData->GetKMerTable()->GetTable(), nCoresForScreening, 10000);
        }
    }

    comm.Send( communication::CalcMessage("Done screening the reads!") );

    // --- END OF PART TWO ------------------------------------------------------------------------




    /*	--- PART THREE ----------------------------------------------------------------------------
    	Find out the kmer coverage of each allele. To save memory, we do not record for every kmer
    	where it came from. instead, we just run through the alleles again and determine coverage.
    	Then transfer the allele coverage information to locus coverage information. For each locus,
    	determine the number of copies to be expected in the locus.
    	------------------------------------------------------------------------------------------- */

    comm.Send( communication::CalcMessage("Determining allele relations...") );

    std::hash_map<Str::Text::Val, AlleleRelations> relations;
    {
        SeqFileReaderPtr reader = SeqFileReader::AutoDetect(finderData->GetAlleleFile()->GetFilename(), settings.alleleFileType)->Clone();
		comm.Send( communication::CalcMessage( Message("Opening file of type: '%1'...") << reader->GetFactoryType() ) );
        reader->init(finderData->GetAlleleFile()->GetFilename(), 5000000);

        std::hash_map<Str::Text::Val, std::vector<std::pair<size_t, seq::Sequence>>> allelesPerLocus;
        size_t allelenr = 0;
        while (reader->hasMore()) {
            seq::NamedSequence seq;
            reader->getNextSeq(seq);
            Str::Text::Val locus = AlleleName::ExtractLocusName(seq.GetName());

            //do we really need this, or is IUPACToUpperCase (built-in into NamedSequence) sufficient?
            seq::ActgToUpperCase(seq.GetData());

            allelesPerLocus[locus].push_back(std::make_pair(allelenr, std::move(seq.GetData())));
            allelenr+=1;
        }

        auto cmp = [](const std::pair<size_t, seq::Sequence>& allele1, const std::pair<size_t, seq::Sequence>& allele2) -> bool {
            return allele1.second.GetLength() < allele2.second.GetLength();
        };

        for ( auto& itlocus : allelesPerLocus ) {
            std::sort(itlocus.second.begin(), itlocus.second.end(), cmp);

            for(size_t i = 0; i < itlocus.second.size(); ++i) {
                const seq::Sequence& refAllele = itlocus.second[i].second;
                const seq::Sequence refAlleleRevCompl = seq::ReverseComplementCopy(refAllele);

                for(size_t j = 0; j < i; ++j) {
                    const seq::Sequence& queryAllele = itlocus.second[j].second;

                    if (   seq::SequenceContains(refAllele, queryAllele)
                        || seq::SequenceContains(refAlleleRevCompl, queryAllele))
                    {
                        relations[itlocus.first].AddParent(itlocus.second[j].first, itlocus.second[i].first);
                    }
                }
            }
        }
    }

    /*
    std::ostringstream os;
    for(auto it=relations.begin(); it!=relations.end(); ++it) {
    	os << it->first << '\n';
    	it->second.toStream(os);
    	os << '\n';
    }
    comm.Send(communication::CalcCreateResultFile("relations.txt", os.str()));
    */

    comm.Send( communication::CalcMessage("Done determining allele relations!") );


    comm.Send( communication::CalcMessage("Determining allele coverages...") );

    std::vector<AlleleCoverage> alleleCoverages (finderData->GetAlleleCount());
    std::hash_map<Str::Text::Val, LocusCoverage> loci;
    {
		SeqFileReaderPtr reader = SeqFileReader::AutoDetect(finderData->GetAlleleFile()->GetFilename(), settings.alleleFileType)->Clone();
		comm.Send( communication::CalcMessage( Message("Opening file of type: '%1'...") << reader->GetFactoryType() ) );
        reader->init(finderData->GetAlleleFile()->GetFilename(), 5000000);

        AlleleCoverageData data(alleleCoverages, finderData->GetKMerTable()->GetTable(), settings.minCoverage, settings.minCoverageFwd, settings.minCoverageRev);
        AlleleCoverageResult result;

        PerReadThreading<AlleleCoverageHandler, AlleleCoverageData, AlleleCoverageResult>  threading(nCoresForCoverage, data);
        threading.handle(reader, result, 1000);
    }

    comm.Send( communication::CalcMessage("Done determining allele coverages!") );




    size_t nPresent = 0, nAbsent=0, nMissing=0, nDouble=0, nMultiple=0;
    comm.Send( communication::CalcMessage("Determining locus coverages...") );
    {
        Str::Text::Val locus;
        double keywordCoverageThreshold = settings.thresholdForKeywordCoverage;
        for (size_t i=0; i<finderData->GetAlleleCount(); ++i) {
            locus = AlleleName::ExtractLocusName(finderData->GetAllelesInfo()[i].name_);
            loci[locus].add(i, alleleCoverages[i], keywordCoverageThreshold);
        }

        size_t nrOfBins = 10;
        double minPerc = settings.thresholdForLocusPresence;
        std::vector<size_t>  locusMaxKeyCov(nrOfBins,0);
        double avgFoundLoci = 0;
        //determine average coverage, and standard deviation of the coverage
        double avgCov = 0;
        //double stDev = 0;
        {
            double totCov = 0, v, ssq = 0;
            for(auto it = loci.begin(); it!=loci.end(); ++it) {
                it->second.cleanup(relations[it->first], comm);
                totCov+=it->second.getAvgCoverage();
                double mxCov = it->second.getMaxKeywordCoverage();
                if (mxCov==1) {
                    nPresent+=1;
                    avgFoundLoci += it->second.getAvgCoverage();
                }
                else if (mxCov < minPerc)
                    nAbsent+=1;
                else {
                    nMissing+=1;
                    size_t idx = clip_value<size_t>(nrOfBins*floor((mxCov-minPerc)/(1-minPerc)), 0 , locusMaxKeyCov.size()-1);
                    locusMaxKeyCov[idx]++;
                }

                if (it->second.nAlleles()==2)
                    nDouble+=1;
                else if (it->second.nAlleles()>2)
                    nMultiple+=1;
            }
            if (!loci.empty())
                avgCov = totCov / (1.0* loci.size());
            if(nPresent!=0)
                avgFoundLoci /= nPresent;
            for(auto it = loci.begin(); it!=loci.end(); ++it) {
                v=it->second.getAvgCoverage()-avgCov;
                ssq+=v *v;
            }

            //if (loci.size()>1)
            //    stDev = sqrt(ssq / (1.0*loci.size() - 1));
        }

        comm.Send( communication::CalcMessage(Message("\tAverage locus coverage: %1", avgCov).c_str())							);
        comm.Send( communication::CalcMessage(Message("\tOf the %1 loci, there are ", loci.size() ).c_str())					);
        comm.Send( communication::CalcMessage(Message("\t\t%1 loci present", nPresent).c_str())									);
        comm.Send( communication::CalcMessage(Message("\tAverage present locus coverage: %1", avgFoundLoci).c_str())							);
        comm.Send( communication::CalcMessage(Message("\t\t%1 loci presumed present, but not found", nMissing).c_str())			);
        for(size_t i=0; i< nrOfBins; ++i) {
            comm.Send( communication::CalcMessage(Message("\t\t\t- In bin [%2, %3] => %1 loci presumed present",
                                                  locusMaxKeyCov[i],
                                                  minPerc + i*(1-minPerc)/nrOfBins,
                                                  minPerc + (i+1)*(1-minPerc)/nrOfBins).c_str())			);
        }
        comm.Send( communication::CalcMessage(Message("\t\t%1 loci absent", nAbsent).c_str())									);
        comm.Send( communication::CalcMessage(Message("\tOf the loci that are present,").c_str())								);
        comm.Send( communication::CalcMessage(Message("\t\t%1 have a unique allele",  nPresent - nDouble - nMultiple).c_str())	);
        comm.Send( communication::CalcMessage(Message("\t\t%1 have two alleles", nDouble).c_str())								);
        comm.Send( communication::CalcMessage(Message("\t\t%1 have more than two alleles", nMultiple).c_str())					);

        //find the copy number for this locus
        for(std::hash_map<Str::Text::Val, LocusCoverage>::iterator it = loci.begin(); it!=loci.end(); ++it) {
            it->second.setNCopies(it->second.getAvgCoverage() / avgCov);
        }
    }
    comm.Send( communication::CalcMessage("Done determining locus coverages!") );
    // --- END OF PART THREE ----------------------------------------------------------------------

    /*	--- PART FOUR ------------------------------------------------------------------------------
    	Perform the output.
    	(1) Output the detailed allele coverage information for all the alleles with 100% coverage
    			filename: alleles.100.txt
    	(1)	For each locus,
    			- output the average coverage of the locus
    			- output the alleles that are 100% covered (comma-separated list). If there are no
    				exact matches but we think that the locus is present, output a ?
    			filename: loci.txt
    	------------------------------------------------------------------------------------------- */

    comm.Send( communication::CalcMessage("Performing output...") );
	
	LocusOutput output;
    //print out the alleles that are 100% covered
    /*{
    	std::ostringstream os;
    	for (size_t i=0; i<nAlleles; ++i) {
    		if (alleleCoverages[i].getKeywordCoverage()>=1) {
    			os << alleleNames[i] << '\t'; alleleCoverages[i].toStream(os); os << "\n";
    		}
    	}

    	comm.Send ( communication::CalcCreateResultFile("alleles.100.txt", os.str()) );
    }*/

    //for each locus, print out which alles have been found with a 100% match, plus some statistics
    {
        // double keywordCoverageThreshold = settings.thresholdForKeywordCoverage;
        double thresholdForPresence = settings.thresholdForLocusPresence;
        /*std::hash_map<Str::Text::Val, LocusCoverage> loci;
        Str::Text::Val locus;
        for (size_t i=0; i<nAlleles; ++i) {
        	locus = GetLocusFromAllele(alleleNames[i]);
        	loci[locus].add(i, alleleCoverages[i], keywordCoverageThreshold);
        }*/
        {
            //LocusOutput output;
            for (auto it=loci.begin(); it!=loci.end(); ++it) {
                LocusOutput::Locus o;
                o.locus = it->first;
                it->second.allelesToOutput(o.alleles, finderData->GetAllelesInfo(), thresholdForPresence, settings.k);
                output.addLocus(o);
            }
            Str::Text::Val xml;
            output.toString(xml);
            comm.Send( communication::CalcCreateResultFile("loci.xml", xml));
        }
        /*{
        	std::ostringstream os;
        	for (auto it=loci.begin(); it!=loci.end(); ++it) {
        		os << it->first;
        		os << '\t';
        		it->second.allelesToStream(os, alleleNames, thresholdForPresence);
        		os << '\n';
        	}
        	comm.Send ( communication::CalcCreateResultFile("loci.txt", os.str()) );
        }
        {
        	std::ostringstream os;
        	for (auto it=loci.begin(); it!=loci.end(); ++it) {
        		os << it->first << '\t';
        		it->second.statsToStream(os);
        		os << '\n';
        	}
        	comm.Send ( communication::CalcCreateResultFile("stats.txt", os.str()) );
        }*/
    }
    comm.Send( communication::CalcMessage("Output done!") );
    // --- END OF PART FIVE -----------------------------------------------------------------------

    /* --------------------------------------------------------------------------------------------
    	PERFORM THE REPORTING
    	We plan to report on:
    		(1) overall startistics on the identification:
    				number of uniquely determined loci,
    				number of loci that have multiple hits
    		(2) for the loci with a runner-up, the score of teh best hit and the score of the runner-up
       -------------------------------------------------------------------------------------------- */
    size_t nLoci = loci.size(), nAssignedLoci = nPresent, nUniqueLoci = nLoci - nDouble - nMultiple, nMultipleLoci = nDouble + nMultiple, nNewAlleles =nMissing;
    {
        using namespace xmlrprt::builder;
        XmlReportBuilder builder;
        {
            XmlReport report(builder, "Allele finder identification report");
            {
                Section s(report, "Parameters");
                {
                    Table t(s, 5, 2, "", Table::DisplayHints::KeyValuePairs);
                    {
                        t(0, 0) = "algorithm";
                        t(0, 1) = "KMerAlleleFinder";
                        t(1, 0) = "k";
                        t(1, 1) = ToStr(settings.k);
                    }
                }
            }
            {
                Section s(report, "Statistics");
                {
                    Table t(s, 5, 2, "", Table::DisplayHints::KeyValuePairs);
                    {
                        t(0, 0) = "Number of loci";
                        t(0, 1) = ToStr(nLoci);
                        t(1, 0) = "Number of assigned loci";
                        t(1, 1) = ToStr(nAssignedLoci);
                        t(2, 0) = "Number of uniquely assigned loci";
                        t(2, 1) = ToStr(nUniqueLoci);
                        t(3, 0) = "Number of multiply assigned loci";
                        t(3, 1) = ToStr(nMultipleLoci);
                        t(4, 0) = "Number of new alleles";
                        t(4, 1) = ToStr(nNewAlleles);
                    }
                }
                {
                }
            }
        }
        comm.Send( communication::CalcCreateResultFile("blast_report.xml", builder.toString()));
    }

	//if (!settings.findNewAlleles_) return;

	////--- fetch the allele info -------------------------------------------------------------------
 //   LocusList locusList;
	//AlleleDescriptors alleleInfo;
	//LoadAlleleDescriptors(data.GetAlleleInfoFileName(), locusList, alleleInfo, comm);


	////now use the output to create a pseudosequence and map all reads against that
	////for mapping, use a local mapping algorithm
	//
	//
	////write fasta file on local dir with the locus sequences
	//Str::Path::Val refFlName = env.localDir / "locusReferences.fasta";
	//FastaFileWriter flWriter = FastaFileWriter(refFlName);
	//for(LocusOutput::const_iterator it = output.begin(); it!=output.end(); ++it) {
	//	const LocusOutput::Locus& locus = it->second;
	//	if (locus.alleles.size()>0)
	//		flWriter.writeSeq(locus.locus+"|"+locus.locus+"_"+ToStr(locus.alleles[0].id), locus.alleles[0].sequence);
	//}

	////map all reads against this very fragmented reference
	//ReferenceMapperSettings mappingSettings;
	//{ 
	//	mappingSettings.referenceFiles.push_back(refFlName);
	//	mappingSettings.referenceFileType = "fasta";
	//	for(size_t i=0; i<settings.readFiles.size(); ++i) mappingSettings.readFiles.push_back(Str::Path::Val(settings.readFiles[i]));
	//	mappingSettings.trimmingsettings.doTrimming = false;
	//	mappingSettings.mappingsettings.tryLocal = true;
	//	mappingSettings.mappingsettings.allowGapsRead = false;
	//	mappingSettings.mappingsettings.allowGapsReference = true;
	//	mappingSettings.mappingsettings.nCores = env.GetMaxNumThreads();
	//	mappingSettings.algorithmType = BowtieMapper::GetTypeName();
	//}

	//MappingFiles mappingFiles;
	//MappingResults mappingResults;
	//ReferenceMapper::Apply(mappingSettings, mappingFiles, mappingResults, env, comm);

	//LocusOutput output2;
	////read in the consensus file, process the newly constructed sequences
	//SeqFileReaderPtr flReader = SeqFileReader::AutoDetect(mappingFiles.consensusFile);
	//flReader->init(mappingFiles.consensusFile, 10000000);
	//NamedSequence seq;
	//while (flReader->hasMore()) {
	//	flReader->getNextSeq(seq);
	//	Str::Text::Val locusId, alleleId;
	//	{
	//		Strings parts;
	//		splitstring(seq.GetName(), parts, "|");
	//		locusId = parts[0];
	//		alleleId = parts[1];
	//	}
	//	LocusOutput::Locus locus;
	//	locus.locus = locusId;
	//	{
	//		LocusOutput::Allele a;
	//		a.sequence = seq.GetData().ToString();
	//		a.sequenceIdentity = 100.0;
	//		a.nonACGT = seq::CountNonACGT(a.sequence.begin(), a.sequence.end());
 //           a.requiresStartStop = alleleInfo[alleleId].hasstartstop;
	//		a.startsWithStart = seq::StartsWithStartCodon(a.sequence.begin(), a.sequence.begin()+3, settings.startCodons);
	//		a.stopsWithStop  = seq::EndsWithStopCodon(a.sequence.end()-3, a.sequence.end(), settings.stopCodons);
	//		a.hasInternalStop = seq::ContainsInternalStopCodon(a.sequence.begin(), a.sequence.end(), settings.stopCodons, FrameDirection::Forward);
	//		locus.alleles.push_back(a);
	//	}
	//	output2.addLocus(locus);
	//}

	//Str::Text::Val xml;
 //   output.toString(xml);
 //   comm.Send( communication::CalcCreateResultFile("loci2.xml", xml));
}


#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "filereader.h"

#include "TestSequenceFiles.h"
#include "NamedSequence.h"

using namespace seq;

#ifdef AMGNU

struct BZ2TestFicture
{
};

BOOST_FIXTURE_TEST_SUITE( bz2Tests, BZ2TestFicture );

#ifdef AMGNU
BOOST_AUTO_TEST_CASE(bz2_fastq_ReadEmpty_GetSeqReturnsEmpty)
{
    const test::SequenceFile seqfile = test::SequenceFiles::GetEmptySequenceFile_Fastq(Compression::bz2);

    {
        FastQFileReader reader( seqfile.filename.string() );
        NamedSequence sequence;

        BOOST_CHECK      ( ! reader.hasMore() );
        reader.getNextSeq( sequence );

        BOOST_CHECK_EQUAL( sequence.GetName(), Str::Text::Val() );
        BOOST_CHECK_EQUAL( sequence.GetData(), Sequence("") );
        BOOST_CHECK      ( ! reader.hasMore() );
    }
}

BOOST_AUTO_TEST_CASE(bz2_fastq_ReadSingleSeq_Ok)
{
    const test::SequenceFile seqfile = test::SequenceFiles::GetSingleLineSequenceFile_Fastq(Compression::bz2);

    {
        FastQFileReader reader( seqfile.filename.string() );
        NamedSequence sequence;
        reader.getNextSeq( sequence );

        BOOST_CHECK_EQUAL( seqfile.sequences[0].name, sequence.GetName() );
        BOOST_CHECK_EQUAL( Sequence(seqfile.sequences[0].sequence), sequence.GetData() );
        BOOST_CHECK      ( ! reader.hasMore() );
    }
}

BOOST_AUTO_TEST_CASE(bz2_fasta_ReadFiveSeqs_Ok)
{
    const test::SequenceFile seqfile = test::SequenceFiles::GetFiveSeqsFile_Fasta(Compression::bz2);

    {
        FastaFileReader reader( seqfile.filename.string() );
        NamedSequence rsequence;

        for ( auto& sequence : seqfile.sequences ){
            reader.getNextSeq( rsequence );

            BOOST_CHECK_EQUAL( sequence.name, rsequence.GetName() );
            BOOST_CHECK_EQUAL( Sequence(sequence.sequence), rsequence.GetData() );
        }

        BOOST_CHECK( ! reader.hasMore() );
    }
}
#endif

BOOST_AUTO_TEST_SUITE_END();

#endif

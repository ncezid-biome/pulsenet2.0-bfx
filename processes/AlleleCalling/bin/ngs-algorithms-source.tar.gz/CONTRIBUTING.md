# Process Versioning

When updating the version of processes, you **MUST** check the minimum_version parameter of each processes.
- If the new version of the process include changes you want to have in all future pipeline run : you must change the minimum_version to the new one.
- If the new version of the process include only additional features, not mandatory for pipeline processing, then you can keep the current minimum_version.

# Docker image

## Build

To build the runner Docker image, you must be logon with AWS

Then, you can run the following commands : 
```bash
scripts/docker.sh build
```

By default, the script will load the .env file. If you want to use a specific .env file, just add the `-e` parameter with the specific file.
```bash
scripts/docker.sh -e "prod.env" build
```

If you want to build a specific tag, just add the `-t` parameter with the wanted tag.
```bash
scripts/docker.sh -t "v1.0.0" build
```

## Push


Then, you can run the following commands : 
```bash
scripts/docker.sh push
```

By default, the script will load the .env file. If you want to use a specific .env file, just add the `-e` parameter with the specific file.
```bash
scripts/docker.sh -e "prod.env" push
```

If you want to build a specific tag, just add the `-t` parameter with the wanted tag.
```bash
scripts/docker.sh -t "v1.0.0" push
```

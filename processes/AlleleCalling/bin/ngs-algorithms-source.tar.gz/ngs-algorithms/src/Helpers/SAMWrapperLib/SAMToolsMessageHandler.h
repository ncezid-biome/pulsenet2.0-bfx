#pragma once
#include "SAMToolsLib.h"

class SAMToolsMessageHandler
{

private:

    typedef void(*Callback)(const char* message, const communication::CalcCommunication* calc);

public:
    SAMToolsMessageHandler(Callback cb, const communication::CalcCommunication& calc)
    {
        set_message_callback((message_callback)cb, (void*)&calc);
    }

    ~SAMToolsMessageHandler()
    {
        set_message_callback(nullptr, nullptr);
    }

private:

    SAMToolsMessageHandler(const SAMToolsMessageHandler&);
    SAMToolsMessageHandler& operator=(const SAMToolsMessageHandler&);

};
#include "stdafx.h"

#include "CE_FileSystem.h"

#include <fstream>

#include "boost/algorithm/string/trim.hpp"
#include "boost/algorithm/string/predicate.hpp"

#include "exception.h"
#include "helper.h"
#include "CalcCommunicationImpl.h"

#include "CE_LogAction.h"


namespace engine
{

//Str::Path::Val makeNative( const Str::Path::Val& inputPath )
//{
//    Str::Text::Val resultPath = inputPath.string();
//
//#ifndef AMGNU
//    ReplaceString( resultPath, PM("/"), PM("\\"));
//#else
//    ReplaceString( resultPath, PM("\\"), PM("/"));
//#endif
//
//    return resultPath;
//}

/**
    Throws a KError if the path \a path does not exist. \a dirname is used for reporting.
*/
void checkDirectoryexists(const Str::Path::Val& path, const Str::Text::Val& dirName)
{
    if (   ! boost::filesystem::exists(path)
           || ! boost::filesystem::is_directory(path) ) {
        if ( ! dirName.empty() )
            throw KError( PM("%1 directory '%2' does not exist") )
                    << dirName
                    << path.string();
        else
            throw KError( PM("directory '%1' does not exist") )
                    << path.string();
    }
}

/**
    For e.g. C:\Documents\myFile.fasta.gz, returns fasta.gz
*/
Str::Text::Val getFullExtension(Str::Path::Val path)
{
    Str::Text::Val extension;
    while ( path.has_extension() ) {
        if ( ! extension.empty() )
            extension = PM(".") + extension;

        extension = path.extension().string() + extension;
        path = path.stem();
    }
    return extension;
}

void copyFile(const Str::Path::Val& inpath,
			  const Str::Path::Val& outPath,
			  FileExistsMode	    onFileExists,
			  const communication::CalcCommunication& comm )
{
	// Remove the old file first, if it exists (needed or copyFile fails if the destination file existed)
	if ( boost::filesystem::exists(outPath) ){
		if ( ! boost::filesystem::is_regular_file(outPath) )
			throw KError( PM("Copying file: destination (%1) exists but is not a regular file") )
				<< outPath.string();

		switch( onFileExists ){
		case FileExistsMode::KeepExisting:
			comm.Send( communication::CalcMessage(RawMessage(PM("Not copying file %1 to %2: destination file exists"), inpath.string(), outPath.string()).c_str()) );
			return;
            break;
		case FileExistsMode::OverwriteExisting:
			{
				engine::LogBlock action( RawMessage(PM("Removing old file: '%1'"), outPath.string()).c_str(), comm );
				boost::filesystem::remove( outPath );
				action.LogSuccess();
			}
            break;
		case FileExistsMode::ThrowIfExisting:
			throw KError( PM("Unable to copy file %1: destination file %2 already exists") )
				<< inpath.string() << outPath.string();
            break;
		}
	}

	{
		engine::LogBlock action( RawMessage(PM("Copying file %1 to %2"), inpath.string(), outPath.string()).c_str(), comm );
		boost::filesystem::copy_file( inpath, outPath );
		action.LogSuccess();
	}
}

//use functions in BasicMFC's pathdef.h
//void sanitizePath   ( Str::Text::Val& pathString ) { ::sanitizePath(pathString); }
//void sanitizePath   ( Str::Path::Val& path ) { ::sanitizePath(path); }
//void sanitizeUNCPath( Str::Text::Val& pathString ) { ::sanitizeUNCPath(pathString); }
//void sanitizeUNCPath( Str::Path::Val& path ) { ::sanitizeUNCPath(path); }


namespace
{

bool isPathDelimiter( const char delim )
{
    return delim == '\''
           || delim == '"';
}

} // namespace

Str::Text::Val escapePath(Str::Text::Val pathString)
{
    if ( pathString.empty() )
        return PM("\"\"");

    // Remove any delimiters
    sanitizePath(pathString);

    // Add delimiters
    return PM('"') + pathString + PM('"');
}

Str::Text::Val escapePath(Str::Path::Val pathString)
{
    return escapePath(pathString.string());
}

/**
    Fast method for getting the content of a file. Throws on error.
*/
Str::Text::Val getFileContent(const Str::Path::Val& path)
{
    std::ifstream in(ToRef(path), std::ios::in | std::ios::binary);
    if (in) {
        std::string contents;
        in.seekg(0, std::ios::end);
        contents.resize(in.tellg());
        in.seekg(0, std::ios::beg);
        in.read(&contents[0], contents.size());
        in.close();
        return(contents);
    }
    throw(errno);
}

/**
    Recursively copies a directory. Throws in case of error.

    Files and/or directories already existing is not an error!
*/
void copyDirectory( const Str::Path::Val& old, const Str::Path::Val& dest )
{
    if ( old == dest )
        return;

    namespace fs = boost::filesystem;

    if ( ! fs::exists(dest) ){
        // Don't throw if the dir already exists
        fs::create_directory(dest);
    }

    for ( fs::directory_iterator itcurrent(old); itcurrent != fs::directory_iterator(); ++itcurrent ) {
        fs::path currentPath( itcurrent->path() );

        if ( boost::filesystem::is_directory(currentPath) ) {
            Str::Path::Val destDir = dest / currentPath.filename();
            copyDirectory( currentPath, destDir );
        }
        else if ( boost::filesystem::is_regular_file(currentPath) ) {

            Str::Path::Val destination = dest / currentPath.filename();

            boost::system::error_code ec;

            //if file already exists, explicitly overwrite by removing it first
            //if it is a symlink, it may not point to an existing file; remove anyhow
            if ( fs::exists(destination) || fs::is_symlink(destination)) {

                //remove() removes the symlink itself, which is what we want
                fs::remove(destination, ec);

                if ( ec.value() != boost::system::errc::success )
                    throw KError( RawMessage(PM("(%1) Failed to remove file '%2'"),
                    ec.value(),
                    destination.string()).c_str() );

            }

            fs::copy_file( currentPath,
                destination,
                ec);

            if ( ec.value() != boost::system::errc::success )
                throw KError( RawMessage(PM("(%1) Failed to copy file '%2' to '%3'"),
                ec.value(),
                currentPath.string(),
                (dest / currentPath.filename()).string() ).c_str() );
        }


    }
}

/**
    On windows: 8000. On Linux: 100000 (should be good for most systems, is quite conservative).
*/
int getMaxCommandlineLength()
{
#ifndef AMGNU
    return 8000;
#else
    return 100000;
    //return ARG_MAX;
#endif
}

} // namespace engine

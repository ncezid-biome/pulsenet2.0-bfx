#ifndef KMER_H
#define KMER_H

/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele
*/

#include <string>
#include <unordered_map>
#include "threading.h"
#include "boost/functional/hash.hpp"
#include "HashMap.h"
#include "boost/shared_ptr.hpp"

/* 
classes for creating keys out of a sequence
*/

class BasicKMerCreator {
public:
	typedef unsigned __int64 Key;
protected:
	size_t k_;
	size_t minQual_, qualOffset_, maxNViolations_;	
	char code_[256];
	char revcomplcode_[256];
public:
	BasicKMerCreator() : k_(21), minQual_(20), qualOffset_(33), maxNViolations_(0) {
		for(size_t i=0; i<256; ++i) code_[i]=-1;
		code_['A']=0;
		code_['C']=1;
		code_['G']=2;
		code_['T']=3;
		code_['a']=0;
		code_['c']=1;
		code_['g']=2;
		code_['t']=3;

		for(size_t i=0; i<256; ++i) revcomplcode_[i]=-1;
		revcomplcode_['T']=0;
		revcomplcode_['G']=1;
		revcomplcode_['C']=2;
		revcomplcode_['A']=3;	
		revcomplcode_['t']=0;
		revcomplcode_['g']=1;
		revcomplcode_['c']=2;
		revcomplcode_['a']=3;
	}
	~BasicKMerCreator() {}

	inline void setParams(size_t k, size_t minQual, size_t maxNViolations, size_t qualOffset) {
		k_=k;		
		minQual_= minQual;
		maxNViolations_ = maxNViolations;
		qualOffset_ =qualOffset;
	}
	inline size_t getK() const { return k_; }	
	inline size_t getMinQual() const { return minQual_; }	
	inline size_t getMaxNViolations() const { return maxNViolations_; }	
	inline size_t getQualOffset() const { return qualOffset_; }	

	inline bool getKey(Str::Text::Arg sequence, Key& key, bool& fwd) {

		std::vector<unsigned __int64> fwdencoding_(k_/32 + (k_%32==0 ? 0 : 1), 0), revencoding_(k_/32 + (k_%32==0 ? 0 : 1), 0);

		size_t idx=0;
		for(size_t i=0; i<k_; ++i) {
			if (code_[sequence[i]]<0) return false;
			fwdencoding_[idx] = (fwdencoding_[idx] << 2) + code_[sequence[i]];  
			revencoding_[idx] = (revencoding_[idx] << 2) + revcomplcode_[sequence[k_- i - 1]];  			
			if ((i+1)%32==0) ++idx;
		}

		Key fwdKey = boost::hash_range(fwdencoding_.begin(), fwdencoding_.end());
		Key revKey = boost::hash_range(revencoding_.begin(), revencoding_.end());

		fwd = fwdKey < revKey;
		key = (fwd ? fwdKey : revKey);
		
		return true;
	}

	inline bool getKey(Str::Text::Arg sequence, Str::Text::Arg qualities, Key& key, bool& fwd) {

		std::vector<unsigned __int64> fwdencoding_(k_/32 + (k_%32==0 ? 0 : 1), 0), revencoding_(k_/32 + (k_%32==0 ? 0 : 1), 0);

		size_t idx=0; size_t nViolations = 0;
		for(size_t i=0; i<k_; ++i) {
			if (code_[sequence[i]]<0) return false;
			fwdencoding_[idx] = (fwdencoding_[idx] << 2) + code_[sequence[i]];  
			revencoding_[idx] = (revencoding_[idx] << 2) + revcomplcode_[sequence[k_- i - 1]];  
			nViolations += (qualities[i]-qualOffset_)<minQual_;
			if ((i+1)%32==0) ++idx;
		}

		Key fwdKey = boost::hash_range(fwdencoding_.begin(), fwdencoding_.end());
		Key revKey = boost::hash_range(revencoding_.begin(), revencoding_.end());

		fwd = fwdKey < revKey;
		key = (fwd ? fwdKey : revKey);
		
		return nViolations<=maxNViolations_;
	}
};

class GappedKMerCreator {
public:
	typedef unsigned __int64 Key;
protected:
	size_t k_;
	size_t minQual_, qualOffset_, maxNViolations_;	
	char code_[256];
	char revcomplcode_[256];
public:
	GappedKMerCreator() : k_(21), minQual_(20), qualOffset_(33), maxNViolations_(0) {
		for(size_t i=0; i<256; ++i) code_[i]=-1;
		code_['A']=0;
		code_['C']=1;
		code_['G']=2;
		code_['T']=3;
		code_['a']=0;
		code_['c']=1;
		code_['g']=2;
		code_['t']=3;

		for(size_t i=0; i<256; ++i) revcomplcode_[i]=-1;
		revcomplcode_['T']=0;
		revcomplcode_['G']=1;
		revcomplcode_['C']=2;
		revcomplcode_['A']=3;	
		revcomplcode_['t']=0;
		revcomplcode_['g']=1;
		revcomplcode_['c']=2;
		revcomplcode_['a']=3;
	}
	~GappedKMerCreator() {}

	inline void setParams(size_t k, size_t minQual, size_t maxNViolations, size_t qualOffset) {
		k_=k;		
		minQual_= minQual;
		maxNViolations_ = maxNViolations;
		qualOffset_ =qualOffset;
	}

	inline size_t getK() const { return k_; }	
	inline size_t getMinQual() const { return minQual_; }	
	inline size_t getMaxNViolations() const { return maxNViolations_; }	
	inline size_t getQualOffset() const { return qualOffset_; }	

	inline bool getKey(Str::Text::Arg sequence, Key& key, bool& fwd) {

		std::vector<unsigned __int64> fwdencoding_(k_/32 + (k_%32==0 ? 0 : 1), 0), revencoding_(k_/32 + (k_%32==0 ? 0 : 1), 0);

		size_t idx=0;
		for(size_t i=0; i<k_/2; ++i) {
			if (code_[sequence[i]]<0) return false;
			fwdencoding_[idx] = (fwdencoding_[idx] << 2) + code_[sequence[i]];  
			revencoding_[idx] = (revencoding_[idx] << 2) + revcomplcode_[sequence[k_- i - 1]];  			
			if ((i+1)%32==0) ++idx;
		}

		for(size_t i=k_/2+1; i<k_; ++i) {
			if (code_[sequence[i]]<0) return false;
			fwdencoding_[idx] = (fwdencoding_[idx] << 2) + code_[sequence[i]];  
			revencoding_[idx] = (revencoding_[idx] << 2) + revcomplcode_[sequence[k_- i - 1]];  			
			if ((i+1)%32==0) ++idx;
		}

		Key fwdKey = boost::hash_range(fwdencoding_.begin(), fwdencoding_.end());
		Key revKey = boost::hash_range(revencoding_.begin(), revencoding_.end());

		fwd = fwdKey < revKey;
		key = (fwd ? fwdKey : revKey);
		
		return true;
	}

	inline bool getKey(Str::Text::Arg sequence, Str::Text::Arg qualities, Key& key, bool& fwd) {

		std::vector<unsigned __int64> fwdencoding_(k_/32 + (k_%32==0 ? 0 : 1), 0), revencoding_(k_/32 + (k_%32==0 ? 0 : 1), 0);

		size_t idx=0; size_t nViolations = 0;
		for(size_t i=0; i<k_/2; ++i) {
			if (code_[sequence[i]]<0) return false;
			fwdencoding_[idx] = (fwdencoding_[idx] << 2) + code_[sequence[i]];  
			revencoding_[idx] = (revencoding_[idx] << 2) + revcomplcode_[sequence[k_- i - 1]];  
			nViolations += (qualities[i]-qualOffset_)<minQual_;
			if ((i+1)%32==0) ++idx;
		}

		for(size_t i=k_/2+1; i<k_; ++i) {
			if (code_[sequence[i]]<0) return false;
			fwdencoding_[idx] = (fwdencoding_[idx] << 2) + code_[sequence[i]];  
			revencoding_[idx] = (revencoding_[idx] << 2) + revcomplcode_[sequence[k_- i - 1]];  
			nViolations += (qualities[i]-qualOffset_)<minQual_;
			if ((i+1)%32==0) ++idx;
		}

		Key fwdKey = boost::hash_range(fwdencoding_.begin(), fwdencoding_.end());
		Key revKey = boost::hash_range(revencoding_.begin(), revencoding_.end());

		fwd = fwdKey < revKey;
		key = (fwd ? fwdKey : revKey);
		
		return nViolations<=maxNViolations_;
	}
};

/* 
keep track of a list of kmers
*/

template<class Info, class KMerCreator = BasicKMerCreator>
class KMerList {
public:
	typedef typename KMerCreator::Key Key;
private:
	typedef std::vector<Key> KeyList;
	typedef std::vector<Info> InfoList;
	typedef std::vector<size_t> PosList;
	typedef std::vector<char> FwdList;
	size_t size_;
	InfoList info_;	
	KeyList keys_;
	FwdList fwds_;
	PosList positions_;	
	KMerCreator creator_;
private:
	mutable Key fwd_, revcompl_;
public:
	KMerList() { }
	KMerList(size_t k) { reset(k); }

	inline void reset(size_t k, size_t minQual, size_t maxNViolations, size_t qualOffset) {
		creator_.setParams(k, minQual, maxNViolations, qualOffset);
		size_=0;		
	}	
	inline bool getKey(Str::Text::Arg sequence, Key& key, bool& fwd) {
		return creator_.getKey(sequence, key, fwd);
	}
	inline bool getKey(Str::Text::Arg sequence, Str::Text::Arg qualities, Key& key, bool& fwd) {
		return creator_.getKey(sequence, qualities, key, fwd);
	}
	inline size_t getK() const { return creator_.getK(); }	
	inline size_t getMinQual() const { return creator_.getMinQual(); }	
	inline size_t getMaxNViolations() const { return creator_.getMaxNViolations(); }	
	inline size_t getQualOffset() const { return creator_.getQualOffset(); }	
	void add(Str::Text::Arg sequence, Str::Text::Arg qualities, size_t size, bool hasQual, const Info& data) {	
		if 	(size<getK()) return; //sequence too small

		if (info_.size()<=size_ + size-getK() + 1) {			
			info_.resize(info_.size() + std::max<size_t>(size - getK() + 1, 10000));
			positions_.resize(positions_.size() + std::max<size_t>(size - getK() + 1, 10000));
			keys_.resize(keys_.size() + std::max<size_t>(size - getK() + 1, 10000));	
			fwds_.resize(keys_.size() + std::max<size_t>(size - getK() + 1, 10000));	
		}

		Key key; bool fwd;
		Info myData(data);
		if (hasQual) {
			for(size_t i=0; i<=size-getK(); ++i) {
				if (getKey(sequence+i, qualities+i, key, fwd)) {
					myData.loadSeq(sequence+i, getK());
					keys_[size_] = key;
					info_[size_] = myData;
					positions_[size_]=i;
					fwds_[size_]=fwd;
					size_+=1;
				}
			}
		}
		else {
			for(size_t i=0; i<=size-getK(); ++i) {						
				if (getKey(sequence+i, key, fwd)) {
					myData.loadSeq(sequence+i, getK());
					keys_[size_] = key;
					info_[size_] = myData;
					positions_[size_]=i;
					fwds_[size_]=fwd;
					size_+=1;
				}
			}
		}
	}	

	inline size_t size() const { return size_; }
	inline Key fetchKey(size_t i) const { return keys_[i]; /*keys_.substr(getK()*i, getK());*/ }
	inline const Info& fetchInfo(size_t i) const { return info_[i]; }
	inline size_t fetchPos(size_t i) const { return positions_[i]; }
	inline bool fetchFwd(size_t i) const { return fwds_[i]!=0; }
};


/* 
proper kmer hash table

For each kmer, an object of type Info is created. When adding a sequence, one can pass on an instance of the Info class 
containing the info about the sequence. This Info class is then merged with the Info class in the hash table by the function
	void add(const Info& info, size_t pos) 
The variable pos is the position in the sequence.
When screening an existing kmer table against a set of sequences, the data that is passed on for every sequence, is the 
ScreenData object. This is then added to the Info object by
	void screen(const ScreenData& data, size_t pos);
The variable pos is the position in the sequence.

The 
	Info 
class should have the following interface:

class Info {
public:
	class ScreenData {
	public:
		ScreenData() ;
		ScreenData(Str::Text::Arg name, size_t index);
	};
public:
	Info();	
	Info(Str::Text::Arg name, size_t index);

	void loadSeq(Str::Text::Arg seq, size_t size);
	void add(const Info& data, size_t pos, bool fwd);
	void screen(const ScreenData& data, size_t pos, bool fwd);	
};
*/

template<class Info, class KMerCreator = BasicKMerCreator>
class KMerTable {
public:
	typedef typename KMerCreator::Key Key;
private:
	typedef std::unordered_map<Key, Info> HashMap;
	HashMap map_;	
	Info dummy_;
	KMerCreator creator_;
public:
	KMerTable() {} 
	KMerTable(size_t k, size_t minQual, size_t maxNViolations, size_t qualOffset)  { reset(k, minQual, maxNViolations, qualOffset); }
	
	inline void reset(size_t k, size_t minQual, size_t maxNViolations, size_t qualOffset) {
		creator_.setParams(k, minQual, maxNViolations, qualOffset);
		map_.clear();		
	}
	inline bool getKey(Str::Text::Arg sequence, Key& key, bool& fwd) {
		return creator_.getKey(sequence, key, fwd);
	}
	inline bool getKey(Str::Text::Arg sequence, Str::Text::Arg qualities, Key& key, bool& fwd) {
		return creator_.getKey(sequence, qualities, key, fwd);
	}
	inline size_t getK() const { return creator_.getK(); }	
	inline size_t getMinQual() const { return creator_.getMinQual(); }	
	inline size_t getMaxNViolations() const { return creator_.getMaxNViolations(); }	
	inline size_t getQualOffset() const { return creator_.getQualOffset(); }	
	void add(Str::Text::Arg sequence, Str::Text::Arg qualities, size_t size, bool hasQual, const Info& data) {
		if 	(size<getK()) return; //sequence too small

		Info myData(data);

		typename HashMap::iterator it;
		Key key; bool fwd;
		if (hasQual) {
			for(size_t i=0; i<=size-getK(); ++i) {
				if (getKey(sequence+i, qualities+i, key, fwd)) {	
					myData.loadSeq(sequence+i, getK());
					it = map_.find(key);
					if (it==map_.end()) map_[key].add(myData, i, fwd);
					else it->second.add(myData, i, fwd);
				}
			}
		}
		else {
			for(size_t i=0; i<=size-getK(); ++i) {
				if (getKey(sequence+i, key, fwd)) {	
					myData.loadSeq(sequence+i, getK());
					it = map_.find(key);
					if (it==map_.end()) map_[key].add(myData, i, fwd);
					else it->second.add(myData, i, fwd);
				}
			}
		}
	}
	void add(const KMerList<Info, KMerCreator>& other) {
		typename HashMap::iterator it;
		Key key;
		for(size_t i=0; i<other.size(); ++i) {
			key = other.fetchKey(i);
			it = map_.find(key);
			if (it==map_.end()) map_[key].add(other.fetchInfo(i), other.fetchPos(i), other.fetchFwd(i));
			else it->second.add(other.fetchInfo(i), other.fetchPos(i), other.fetchFwd(i));				
		}
	}
	void merge(const KMerTable& other) {
		typename HashMap::iterator it;

        size_t i = 0;
		for(typename HashMap::const_iterator iit = other.map_.begin(); iit!=other.map_.end(); ++iit, ++i) {
			it = map_.find(iit->first);
			if (it==map_.end())
                map_[iit->first].add(iit->second, i);
			else
                it->second.add(iit->second, i);
		}
	}
	//void screen(Str::Text::Arg sequence, Str::Text::Arg qualities, size_t size, bool hasQual, const typename Info::ScreenData& data) {
	//	typename HashMap::iterator it;
	//	Key key; bool fwd;
	//	typename Info::ScreenData myData(data);
	//	if (hasQual) {
	//		for(size_t i=0; i<=size-k_; ++i) {
	//			if (getKey(sequence+i, qualities+i, key, fwd)) {
	//				myData.loadSeq(sequence+i, getK());
	//				it = map_.find(key);
	//				if (it!=map_.end()) 
	//					it->second.screen(data, i, fwd);
	//			}
	//		}
	//	}
	//	else {
	//			for(size_t i=0; i<=size-k_; ++i) {
	//			if (getKey(sequence+i, key, fwd)) {
	//				myData.loadSeq(sequence+i, getK());
	//				it = map_.find(key);
	//				if (it!=map_.end()) 
	//					it->second.screen(data, i, fwd);
	//			}
	//		}
	//	}
	//}
	size_t size() const { 
		return map_.size(); 
	}
	void update(const KMerTable<Info, KMerCreator>& other) {
		typename HashMap::iterator it2;
		for(auto it = other.begin(); it!=other.end(); ++it) {
			it2 = map_.find(it->first);
			if (it!=map_.end())
				it2->second.update(it->second);
		}
	}
	void screen(const KMerList<typename Info::ScreenData, KMerCreator>& other) {
		typename HashMap::iterator it;
		for(size_t i=0; i<other.size(); ++i) {
			it = map_.find(other.fetchKey(i));
			if (it!=map_.end())
				it->second.screen(other.fetchInfo(i), other.fetchPos(i), other.fetchFwd(i));
		}
	}
	typedef std::function<bool (const Info&)> AcceptFunctor;
	void filter(AcceptFunctor acceptFunctor) {
		std::vector<Key> toremove;
		for(auto it = map_.begin(); it!=map_.end(); ++it) {
			if (!acceptFunctor(it->second)) toremove.push_back(it->first);			
		}
		for(size_t i=0; i<toremove.size(); ++i) 
			map_.erase(map_.find(toremove[i]));		
	}


	const Info& getInfo(Key key) const { 
		typename HashMap::const_iterator it = map_.find(key);
		if (it!=map_.end()) return it->second;
		else return dummy_;
	}
	bool hasInfo(Key key, const Info*& info) const { 
		typename HashMap::const_iterator it = map_.find(key);
		if (it!=map_.end()) info = &it->second; else info=0;
		return info!=0;
	}

	void toStream(std::ostream& os) const {		
		unsigned __int32 k = ncast<unsigned __int32>(getK()); os.write((const char*)(&k), 4);
		unsigned __int32 minQual = ncast<unsigned __int32>(getMinQual()); os.write((const char*)(&minQual), 4);		
		unsigned __int32 maxNViolations = ncast<unsigned __int32>(getMaxNViolations()); os.write((const char*)(&maxNViolations), 4);
		unsigned __int32 qualOffset = ncast<unsigned __int32>(getQualOffset()); os.write((const char*)(&qualOffset), 4);
		unsigned __int32 sz = ncast<unsigned __int32>(map_.size()); os.write((const char*)(&sz), 4);		
		for(auto it=begin(); it!=end(); ++it) {
			os.write((const char*)(&it->first), sizeof(Key));
			it->second.toStream(os);
		}
	}
	void fromStream(std::istream& is) {
		map_.clear();
		unsigned __int32 k; is.read((char*)(&k), 4); 
		unsigned __int32 minQual; is.read((char*)(&minQual), 4);		
		unsigned __int32 maxNViolations; is.read((char*)(&maxNViolations), 4);
		unsigned __int32 qualOffset; is.read((char*)(&qualOffset), 4);
		reset(k, minQual, maxNViolations, qualOffset);

		unsigned __int32 sz; is.read((char*)(&sz), 4);		
		Key key; Info info;
		for(size_t i=0; i<sz; ++i) {
			is.read((char*)(&key), sizeof(Key));
			info.fromStream(is);
			map_[key]=info;
		}
	}

	typedef typename HashMap::const_iterator const_iterator;
	const_iterator begin() const { return map_.begin(); }
	const_iterator end() const { return map_.end(); }

	typedef typename HashMap::iterator iterator;
	iterator begin() { return map_.begin(); }
	iterator end() { return map_.end(); }

	inline const_iterator find(Key key) const { return map_.find(key); }
	inline iterator find(Key key)  { return map_.find(key); }
};

/* 
default implementation for multithreaded kmer table creation
*/

template<class Info, class KMerCreator>
class KMerTableCreationResult {
};

template<class Info, class KMerCreator>
class KMerTableCreationData  {
private:
	KMerTable<Info, KMerCreator>& table_;
private:
	boost::mutex mutex_;
public:
	KMerTableCreationData(KMerTable<Info, KMerCreator>& table) : table_(table) {}

	inline size_t getK() const { return table_.getK(); }
	inline size_t getMinQual() const { return table_.getMinQual(); }	
	inline size_t getMaxNViolations() const { return table_.getMaxNViolations(); }	
	inline size_t getQualOffset() const { return table_.getQualOffset(); }	

	void add(const KMerList<Info, KMerCreator>& other) {
		boost::mutex::scoped_lock lock(mutex_);
		table_.add(other);
	}
	
};

template<class Info, class KMerCreator>
class KMerTableCreationHandler {
private:
	KMerList<Info, KMerCreator> myList_;	
	KMerTableCreationData<Info, KMerCreator>* data_;
public:
	KMerTableCreationHandler() : data_(0) {}

	inline void init(KMerTableCreationData<Info, KMerCreator>& data) {
		data_ = &data;		
		myList_.reset(data_->getK(), data_->getMinQual(), data_->getMaxNViolations(), data_->getQualOffset());
	}
	inline void handle(const Str::Text::Val& name, const Str::Text::Val& seq, const Str::Text::Val& qual, size_t index) {
		myList_.add(seq, qual, seq.size(), !qual.empty(), Info(name, index));
	}
	inline void intermediate() {
		data_->add(myList_);
		myList_.reset(data_->getK(), data_->getMinQual(), data_->getMaxNViolations(), data_->getQualOffset());
	}
	inline void finish(KMerTableCreationResult<Info, KMerCreator>& result) {			
	}
};

template<class Info, class KMerCreator>
void CreateKMerTable(SeqFileReader::Ptr reader, KMerTable<Info, KMerCreator>& table, size_t nThreads, size_t chunkSize=10000) 
{
	KMerTableCreationData<Info, KMerCreator> data(table);
	KMerTableCreationResult<Info, KMerCreator> result;

	PerReadThreading<KMerTableCreationHandler<Info, KMerCreator>, KMerTableCreationData<Info, KMerCreator>, KMerTableCreationResult<Info, KMerCreator>>  threading(nThreads, data);
	threading.handle(reader, result, chunkSize);	
}




/* 
default implementation for multithreaded kmer table screening
*/

template<class Info, class KMerCreator>
class KMerTableScreeningResult {
};

template<class Info, class KMerCreator>
class KMerTableScreeningData  {
private:
	KMerTable<Info, KMerCreator>& table_;
private:
	boost::mutex mutex_;
public:
	KMerTableScreeningData(KMerTable<Info, KMerCreator>& table) : table_(table) {}

	inline size_t getK() const { return table_.getK(); }
	inline size_t getMinQual() const { return table_.getMinQual(); }	
	inline size_t getMaxNViolations() const { return table_.getMaxNViolations(); }	
	inline size_t getQualOffset() const { return table_.getQualOffset(); }	

	void screen(const KMerList<typename Info::ScreenData, KMerCreator>& other) {
		boost::mutex::scoped_lock lock(mutex_);
		table_.screen(other);
	}
	
};

template<class Info, class KMerCreator>
class KMerTableScreeningHandler {
private:
	KMerList<typename Info::ScreenData, KMerCreator> myList_;
	size_t k_;
	KMerTableScreeningData<Info, KMerCreator>* data_;
public:
	KMerTableScreeningHandler() : data_(0) {}

	inline void init(KMerTableScreeningData<Info, KMerCreator>& data) {
		data_ = &data;		
		myList_.reset(data_->getK(), data_->getMinQual(), data_->getMaxNViolations(), data_->getQualOffset());
	}
	inline void handle(const Str::Text::Val& name, const Str::Text::Val& seq, const Str::Text::Val& qual, size_t index) {
		myList_.add(seq, qual, seq.size(), !qual.empty(), typename Info::ScreenData(name, index));
	}
	inline void intermediate() {
		data_->screen(myList_);
		myList_.reset(data_->getK(), data_->getMinQual(), data_->getMaxNViolations(), data_->getQualOffset());
	}
	inline void finish(KMerTableScreeningResult<Info, KMerCreator>& result) {			
	}
};


template<class Info, class KMerCreator>
void ScreenKMerTable(SeqFileReader::Ptr reader, KMerTable<Info, KMerCreator>& table, size_t nThreads, size_t chunkSize=10000) 
{
	KMerTableScreeningData<Info, KMerCreator> data(table);
	KMerTableScreeningResult<Info, KMerCreator> result;

	PerReadThreading<KMerTableScreeningHandler<Info, KMerCreator>, KMerTableScreeningData<Info, KMerCreator>, KMerTableScreeningResult<Info, KMerCreator>> threading(nThreads, data);
	threading.handle(reader, result, chunkSize);	
}


#endif	
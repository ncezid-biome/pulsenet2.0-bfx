#pragma once


namespace seq
{


typedef char Base;

Base Complement(Base base);


} // namespace seq
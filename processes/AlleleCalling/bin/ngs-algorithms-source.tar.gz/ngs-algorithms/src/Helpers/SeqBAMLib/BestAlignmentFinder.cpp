#include "stdafx.h"
#include "BestAlignmentFinder.h"

SeqBAM::Bowtie2Filter::BestAlignmentFinder::BestAlignmentFinder(double minScore_) : minScore(minScore_)
{

}

bool SeqBAM::Bowtie2Filter::BestAlignmentFinder::accept(const AlignmentWithScore& t) const
{
    return ((t.read->core.flag & BAM_FUNMAP) == 0) && t.score >= minScore;
}

double SeqBAM::Bowtie2Filter::BestAlignmentFinder::score(const AlignmentWithScore& t) const
{
    return t.score;
}

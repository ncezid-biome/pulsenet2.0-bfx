/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#include "strdef.h"
#include "boost/filesystem.hpp"

#ifndef FILETOOLS_H
#define FILETOOLS_H

size_t FileSize(Str::Path::Arg filename);
size_t SizeLeft(std::ifstream& ifile);
void OpenBinary(std::ifstream& is, const Str::Path::Val& filename);
void OpenBinary(std::ofstream& os, const Str::Path::Val& filename);
void OpenText  (std::ifstream& is, const Str::Path::Val& filename);
void OpenText  (std::ofstream& os, const Str::Path::Val& filename);

void OpenBinary(std::ifstream& is, Str::Path::Arg dir, const Str::Path::Val& filename);
void OpenBinary(std::ofstream& os, Str::Path::Arg dir, const Str::Path::Val& filename);
void OpenText(std::ifstream& is, Str::Path::Arg dir, const Str::Path::Val& filename);
void OpenText(std::ofstream& os, Str::Path::Arg dir, const Str::Path::Val& filename);

Str::Path::Val CreatePath(Str::Path::Arg part1, Str::Path::Arg part2);

bool ExistsFile(Str::Path::Arg filename);
void RemoveFile(Str::Path::Arg filename);

Str::Path::Val GetFileName(Str::Path::Arg path);

template<class T> 
void Serialize(const T& obj, const Str::Path::Val& filename)
{
	std::ofstream os; OpenBinary(os, filename);
	obj.serialize(os);
}
template<class T> 
void Deserialize(T& obj, const Str::Path::Val& filename)
{
	std::ifstream is; OpenBinary(is, filename);
	obj.deserialize(is);
}

#endif

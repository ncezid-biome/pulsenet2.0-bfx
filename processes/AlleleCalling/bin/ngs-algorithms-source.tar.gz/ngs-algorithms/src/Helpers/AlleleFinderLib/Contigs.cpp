#include "stdafx.h"
#include "Contigs.h"
#include "exception.h"
#include "filereader.h"
#include "NamedSequence.h"
#include "SequenceManip.h"


AllContigs::AllContigs()
{
}
AllContigs::~AllContigs()
{
}
void AllContigs::load(const Str::Path::Val& seqFile)
{
	SeqFileReader::Ptr reader = SeqFileReader::AutoDetect(seqFile);
	if (reader==nullptr) 
		throw KError("Unknown file type for file '%1'.") << seqFile.string();

	reader->init(seqFile, 5000000);
    while(reader->hasMore()) {
        seq::NamedSequence sequence;
        reader->getNextSeq(sequence);

        //do we really need this, or is IUPACToUpperCase (built-in into NamedSequence) sufficient?
        seq::ActgToUpperCase(sequence.GetData());

        revContigs_[sequence.GetName()] = seq::ReverseComplementCopy(sequence.GetData());
        fwdContigs_[sequence.GetName()] = std::move(sequence.GetData());
    }
}
const seq::Sequence& AllContigs::get(const Str::ID::Val& contigId, bool fwd) const
{
	if (fwd) {
		auto it = fwdContigs_.find(contigId);
		if (it!=fwdContigs_.end()) return it->second;
	}
	else {
		auto it = revContigs_.find(contigId);
		if (it!=revContigs_.end()) return it->second;
	}

	throw KError("Could not find contig with id '%1'.") << contigId;
}


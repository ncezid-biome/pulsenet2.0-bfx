#pragma once


namespace compression{


class IntCurveReaderItf{
public:
	virtual ~IntCurveReaderItf(){}
	virtual size_t		GetCount() const=0;
	virtual int			GetValue(size_t i) const=0;
};


class IntCurveWriterItf{
public:
	virtual ~IntCurveWriterItf(){}
	virtual void	SetCount(size_t cnt) =0;
	virtual void	SetValue(size_t i, int val) =0;
};

template<int N, typename Iterator>
void SaveIntCurve(Iterator& it, const IntCurveReaderItf& curve){
	int currentOffset = 0;
	SaveNumber<8,Iterator, size_t, false>(it, curve.GetCount(), currentOffset, false);
	size_t cnt=curve.GetCount();
	int nr =0 ;
	for(size_t i=0; i<cnt ;++i){
		if(i==0)
			nr= curve.GetValue(0);
		else
			nr = curve.GetValue(i) - curve.GetValue(i-1);
		bool neg = nr<0; 
		if(neg){
			nr  = - nr; //remove sign
		}
		SaveNumber<N,Iterator, CoverageReaderItf::CountType, true>(it, nr, currentOffset, neg);
	}
}


template<int N, typename Iterator>
void LoadIntCurve(Iterator& it,  IntCurveWriterItf& curve){
	int currentOffset = 0;
	bool neg=false;
	size_t cnt = LoadNumber<8,Iterator, size_t, false>(it, currentOffset, neg);
	curve.SetCount(cnt);
	size_t thisCnt = 0;
	int prevValue = 0;
	while(thisCnt < cnt){
		bool neg=false;
		int nr = LoadNumber<N,Iterator, CoverageWriterItf::CountType, true>(it, currentOffset, neg);
		curve.SetValue(thisCnt, nr + prevValue);
		prevValue += nr;
		++thisCnt;
	}
	if(currentOffset!=0)
		++it;
}

}//namespace compression{

#pragma  once
#include <vector>

namespace compression{

/**
N-bit compression works as follows
Each buffer position can hold GetBitSize() bits (6 or 8 typically). N can be smaller than GetBitSize() (3 or 4)
bit N: is there a next bit (if true then there the number doesn't fit in 2^(N-2)
bit N-1: sign bit
bit N-2 .. 1: number (positive) 
After this there will be an offset within the buffer position. And the next N-bit is written starting from this offset.
*/


#pragma region OutputNr

/**
Stores a number in a 'buffer', with a certain bit-offset. The number can be store in different bytes
-it: output iterator. Must support ++ and * and the dereferenced value must support |=
-currentOffset: offset within byte
-val: positive value, must fit within GetBitSize of the buffer
*/
template<int N, typename Iterator>
void  CompressNumber(Iterator& it, int& currentOffset, typename Iterator::value_type val){
    const int bits = Iterator::GetBitSize() ;//8* sizeof(typename Iterator::value_type);
    ASSERT(currentOffset<bits);
    ASSERT(val< (1<<bits));
    if(currentOffset==0)
        ++it;
    //first part in first byte
    *it |= (~(~0<<(bits-currentOffset))<<currentOffset) & (val<<currentOffset);
    //is there more?
    if(currentOffset+N-bits > 0){
        //store the rest in n next byte
        ++it;
        *it |= (val>>(bits - currentOffset));
    }
    //offset for next
    currentOffset = (currentOffset + N) % bits;
}


/**
Stores a preprocessed number in a 'buffer', with a  certain bit-offset. A preprocessed number means that it has been
chopped in pieces that fit in Iterator::GetBitSize()
-it: output iterator
-currentOffset: offset within byte
-tmpBuffer: a vector of positive value, must each fit within GetBitSize of the buffer
*/
template<int N, typename Iterator>
void  CompressNumber(Iterator& it, int& currentOffset, const std::vector<typename Iterator::value_type>& tmpBuffer){
    //store in reverse order
    const int bits = Iterator::GetBitSize() ;
    const size_t len = tmpBuffer.size();
    for(size_t i=0 ; i<len;++i){
        if(currentOffset==0)
            ++it;
        *it |= (~(~0<<(bits-currentOffset))<<currentOffset) & (tmpBuffer[len-1 - i]<<currentOffset);
        if(currentOffset+N-bits > 0){
            ++it;
            *it |= (tmpBuffer[len-1-i]>>(bits - currentOffset));
        }
        currentOffset = (currentOffset + N) % bits;
    }
}

/**
Store a number in buffer iterator it, with an offset currentOffset within the current buffer space.
Optionally store with a sign bit.
\param Iterator:must support * and ++ operator, the reuslt of * must support |=
\param nr: positive number
\param currentoffset: offset within the current buffer char
\param neg: is the number negative?

\param sign: turn sign bit on/off compile-time
*/
template<int N, typename Iterator, typename VecType, bool sign>
void  SaveNumber(Iterator& it, VecType nr, int& currentOffset, bool neg){
    typedef typename Iterator::value_type BuffType;
    ASSERT(nr>=0);
    int signShift = sign ? 2 : 1;
    BuffType allOnes = ~(~0 << (N-signShift));

    std::vector<typename Iterator::value_type>  tmpBuffer;
    tmpBuffer.reserve(sizeof(VecType)/sizeof(BuffType)+1);
    BuffType thisNr = (sign & neg ? (1<<(N-signShift)) : 0);//sign bit
    thisNr |= nr & allOnes; //take the rest 
    nr >>= N-signShift;
    //thisNr |= (1 << N);//next link bit
    tmpBuffer.push_back(thisNr);

    allOnes = ~(~0 << (N-1));
    while(nr >  0){
        BuffType thisNr = nr & allOnes; 
        nr >>= N-1;
        thisNr |= (1 << (N-1));
        tmpBuffer.push_back(thisNr);
    }
    CompressNumber<N, Iterator>(it, currentOffset, tmpBuffer);
}



#pragma endregion 




#pragma region Input of numbers

/**
Gets the next N-bit. Either increases the offset or the buffer.
*/
template<int N, typename Iterator>
typename Iterator::value_type DecompressNumber(Iterator&  bufferIt, int& currentOffset){
    const int bits = Iterator::GetBitSize() ;//8 * sizeof(typename Iterator::value_type);
    typename Iterator::value_type nxt=0;
    // currentOffset == 0 : leave 4 lowest bits alive
    // currentOffset == 4 : put 4 highest bits in 4 lowest bits, zero the others
    nxt = ~(~0 << N) & (*bufferIt >>(currentOffset));
    if(currentOffset+N-bits >= 0){
        ++bufferIt;
    }
    if(currentOffset+N-bits > 0){
        nxt |= (~(~0<<(currentOffset+N-bits)) & *bufferIt) << (bits - currentOffset);
    }
    currentOffset = (currentOffset + N) % bits;
    return nxt;
}

/**
Load a number from a buffer, with an offset within a buffer. 
*/
template<int N, typename Iterator, typename VecType, bool sign>
VecType  LoadNumber(Iterator&  bufferIt, int& currentOffset, bool& neg){
    typename Iterator::value_type nxt = DecompressNumber<N, Iterator>(bufferIt, currentOffset);
    VecType nr = 0;
    // nxt & 1000 : check if the "next bit" is on
    while(nxt & (1<<(N-1))){
        // For N==4 : keep the lowest 3 bits of nxt (& with 0111)
        typename Iterator::value_type thisNr = nxt & ~(~0 << (N-1)); 
        // Shift existing part of the number N-1 bits to the left
        nr <<= (N-1);
        // Add newly read number in the lowest N-1 bits
        nr |= thisNr;
        nxt = DecompressNumber<N, Iterator>(bufferIt, currentOffset);
    }
    int signShift = sign? 2 : 1;
    neg  = sign && (nxt & (1 << (N-2)))!=0;
    nr <<= (N-signShift);
    nr |= nxt & ~(~0 << (N-signShift));
    return nr * (neg ? -1 : 1);
}

#pragma endregion 

}//namespace compression{


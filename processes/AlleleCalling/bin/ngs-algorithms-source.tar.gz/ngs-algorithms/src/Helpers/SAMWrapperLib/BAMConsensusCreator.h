#pragma once

#include <cstdint>
#include "SAMWrapper.h"
#include "BAMPileup.h"
#include "BAMPileFileTypes.h"
#include "BAMConsensusCaller.h"
#include <boost/shared_ptr.hpp>
#include "BAMCoverage.h"
#include "CalcCommunication.h"

namespace BAM
{

class STW_DLLPORT ConsensusCreator: public Pileup
{

public:

    typedef boost::shared_ptr<ConsensusCreator> Ptr;

public:

    ConsensusCreator(ConsensusCaller::Settings settings): Pileup(true), settings_(settings), consensusCaller_(settings)
    {

    }

    void CreateConsensus(const communication::CalcCommunication& calc, FileResolver::Ptr files);

    void CreateConsensus(const communication::CalcCommunication& calc, FileResolver::Ptr files, const ReferenceID refID, const ReferencePosition start, const ReferencePosition end);

    Str::Text::Ref GetConsensus() const
    {
        return ToRef(consensus_);
    }

    const compression::CoverageReaderItf& GetForwardCoverage() const
    {
        return forwardCoverage_;
    }

    const compression::CoverageReaderItf& GetReverseCoverage() const
    {
        return reverseCoverage_;
    }

    ConsensusCaller::Settings GetSettings() const
    {
        return settings_;
    }

private:

    void AddCoverages(int n, const bam_pileup1_t pl[], int offset);

    void AddPosition(char c, int n = 0, const bam_pileup1_t pl[] = nullptr, int offset = 0);

    virtual int PileupCallback(ReferenceID tid, ReferencePosition pos, int n, const bam_pileup1_t pl[]);

    virtual void ReferenceChanged(ReferenceID refID);

private:

    //whether or not to insert a pipe before adding the next position
    bool insertPipe_;

    Str::Text::Val consensus_;
    ConsensusCaller consensusCaller_;
    const ConsensusCaller::Settings settings_;

    Coverage forwardCoverage_;
    Coverage reverseCoverage_;

    const communication::CalcCommunication* calc_;
};

}

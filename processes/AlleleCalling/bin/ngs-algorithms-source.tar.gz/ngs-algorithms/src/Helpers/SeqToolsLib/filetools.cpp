/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#include "stdafx.h"

#include "filetools.h"

#include <fstream>

#include "exception.h"


size_t FileSize(Str::Path::Arg filename)
{
	std::ifstream ifile(filename, std::ios::binary);
	
	if (!ifile.is_open())
		throw KError("Could not open file %1.") << filename;
	
	return SizeLeft(ifile);
}


size_t SizeLeft(std::ifstream& ifile)
{
	if (!ifile.is_open())
		throw KError("Stream was not opened for reading");
	
	std::streampos start = ifile.tellg();
	ifile.seekg(0, std::ifstream::end);
	std::streampos end = ifile.tellg();
	ifile.seekg(start, std::ifstream::beg);
	return end-start;
}


bool ExistsFile(Str::Path::Arg filename) 
{
	std::ifstream ifile(filename);
	return ifile.is_open();
}

void RemoveFile(Str::Path::Arg filename)
{
	if (ExistsFile(filename))
		boost::filesystem::remove(Str::Path::Val(filename.c_str()));
}

Str::Path::Val CreatePath(Str::Path::Arg part1, Str::Path::Arg part2)
{
	boost::filesystem::path p(part1.c_str());
	p/=boost::filesystem::path(part2.c_str());
	return Str::Path::Val(p.string());
}

Str::Path::Val GetFileName(Str::Path::Arg path)
{
	Str::Path::Val mypath = path.c_str();

	Str::Text::Val filename = mypath.filename().string();

	size_t pos = filename.find_last_of('.');
	if (pos==std::string::npos) return filename;

	return filename.substr(0, pos);
	
}


void OpenBinary(std::ifstream& is, const Str::Path::Val& filename)
{
	is.open(filename.c_str(), std::ios::binary);
	if (!is.is_open()) 
		throw KError( "Could not open input file %1." ) << filename;
}
void OpenBinary(std::ofstream& os, const Str::Path::Val& filename)
{
	os.open(filename.c_str(), std::ios::binary);
	if (!os.is_open()) 
		throw KError( "Could not open output file %1." ) << filename;
}



void OpenText(std::ifstream& is, const Str::Path::Val& filename)
{
	is.open(filename.c_str(), std::ios::in);
	if (!is.is_open()) 
		throw KError( "Could not open input file %1." ) << filename;
}
void OpenText(std::ofstream& os, const Str::Path::Val& filename)
{
	os.open(filename.c_str(), std::ios::out);
	if (!os.is_open()) 
		throw KError( "Could not open output file %1." ) << filename;
}




void OpenBinary(std::ifstream& is, Str::Path::Arg dir, Str::Path::Arg filename)
{
	Str::Path::Val myFileName = CreatePath(dir, filename);
	is.open(ToRef(myFileName), std::ios::binary);
	if (!is.is_open()) 
		throw KError( "Could not open input file %1."  ) << myFileName;
}
void OpenBinary(std::ofstream& os, Str::Path::Arg dir, Str::Path::Arg filename)
{
	Str::Path::Val myFileName = CreatePath(dir, filename);
	os.open(ToRef(myFileName), std::ios::binary);
	if (!os.is_open()) 
		throw KError( "Could not open output file %1." ) << myFileName;
}



void OpenText(std::ifstream& is, Str::Path::Arg dir, Str::Path::Arg filename)
{
	Str::Path::Val myFileName = CreatePath(dir, filename);
	is.open(ToRef(myFileName), std::ios::in);
	if (!is.is_open()) 
		throw KError( "Could not open input file %1." ) << myFileName;
}
void OpenText(std::ofstream& os, Str::Path::Arg dir, Str::Path::Arg filename)
{
	Str::Path::Val myFileName = CreatePath(dir, filename);
	os.open(ToRef(myFileName), std::ios::out);
	if (!os.is_open()) 
		throw KError( "Could not open output file %1." ) << myFileName;
}

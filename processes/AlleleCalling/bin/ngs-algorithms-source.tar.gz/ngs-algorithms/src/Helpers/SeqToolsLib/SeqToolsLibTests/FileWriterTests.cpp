#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "filewriter.h"
#include "WritableDirectory.h"
#include "TestSequenceFiles.h"
#include "textfile.h"

using namespace test;

/**
    Note: fixture is created for every test (-> dir is cleaned before every test)
*/
struct FileWriterFixture
{
    FileWriterFixture()
        : outdir(PM("SeqFileWriter"))
    {
    }

    WritableDirectory outdir;
};


BOOST_FIXTURE_TEST_SUITE( FileWriterTests, FileWriterFixture );

BOOST_AUTO_TEST_CASE(UncompressedFastQFileWriter_SingleSeq_NoQual_Throws)
{
    Str::Path::Val outname = outdir.GenerateUniqueName(PM("SingleSeqNoQual"), PM(".fastq"));

    SequenceFile seqfile = SequenceFiles::GetSingle_NoQuality_Fastq( Compression::None );

    {
        UncompressedFastQFileWriter writer( outname );
        BOOST_CHECK_THROW(
            writer.writeSeq( seqfile.sequences.front().name, seqfile.sequences.front().sequence ),
            KError);
    }
}

BOOST_AUTO_TEST_CASE(UncompressedFastQFileWriter_SingleSeq_EmptyQual_Throws)
{
    Str::Path::Val outname = outdir.GenerateUniqueName(PM("SingleSeqEmptyQual"), PM(".fastq"));

    SequenceFile seqfile = SequenceFiles::GetSingle_NoQuality_Fastq( Compression::None );

    {
        UncompressedFastQFileWriter writer( outname );
        BOOST_CHECK_THROW(
            writer.writeSeq( seqfile.sequences.front().name, seqfile.sequences.front().sequence, PM("") ),
            KError);
    }
}

BOOST_AUTO_TEST_SUITE_END();

#pragma once
#include <PathDef.h>
#include <translate.h>
#include <exception.h>
#include "SAMToolsLib.h"
#include "BAMTypes.h"
#include "SAMWrapper.h"
#include "BAMFileResolver.h"

namespace BAM
{

class STW_DLLPORT Iterator: public BAMTypes
{

public:
    typedef boost::shared_ptr<Iterator> Ptr;

public:
    Iterator(): bamFile_(nullptr), hasIter_(false)
    {
        bamRead_=stl_bam_init1();
    }

    void Open(FileResolver::Ptr files)
    {
        files_=files;

        bamFile_=samopen(ToRef(files->GetSortedBAMFile()), PM("rb"), 0);
        if(bamFile_==nullptr) {
            throw KError("Could not open BAM-file %1") << files->GetSortedBAMFile();
        }
    }

    void Open(const Str::Path::Val file);

    void Close()
    {
        if(bamFile_!=nullptr) {

            samclose(bamFile_);
            bamFile_=nullptr;
        }
        files_.reset();
    }

    ~Iterator()
    {
        stl_bam_destroy1(bamRead_);
        CleanupIter();
        Close();
    }

    void SetRegion(ReferenceID refID, ReferencePosition beginPosition, ReferencePosition endPosition)
    {
        if(!files_)
            throw KError("Cannot use SetRegion on a [SB]AM file alone");

        //remove old iterator, if necessary
        CleanupIter();

        index_=bam_index_load_directly(ToRef(files_->GetBAMIndexFile())); // load BAM index
        if(index_==nullptr)
            throw KError("Could not open index for BAM-file %1") << files_->GetSortedBAMFile();

        iter=bam_iter_query(index_, refID, beginPosition, endPosition);

        hasIter_=true;
    }

    bam1_t* GetNextRead();

    bool GetNextReadInto(bam1_t* read);

private:

    void CleanupIter()
    {
        if(hasIter_) {
            bam_iter_destroy(iter);
            bam_index_destroy(index_);
        }
    }

private:

    Iterator(const Iterator&);
    Iterator& operator=(const Iterator&);

    bool hasIter_;
    bam_iter_t iter;
    bam_index_t* index_;

public:

    bam1_t* bamRead_;
    samfile_t* bamFile_;

    FileResolver::Ptr files_;

};
}
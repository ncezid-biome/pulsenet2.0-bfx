#pragma once

#include "CE_ProgramOptions.h"

#include "StringDef.h"
#include "PathDef.h"

class SequenceFiles;

class SRSStatsCalculatorSettings: public engine::ProgramOptions
{
public:	
	Str::ID::Val    algorithmType;
	Str::Text::Vec  readFiles;
	Str::ID::Vec    readFileTypes;
	size_t          qualOffset;

	Str::Text::Val outputFileNameInfo, outputFileNameStats;

    enum class Standalone
    {
        Yes,
        No
    };

	bool doSanitizePath;

public:
	SRSStatsCalculatorSettings( Standalone standalone );
	~SRSStatsCalculatorSettings();

	bool ParseAndSetup(int argc, char* argv[], const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm) override;
	
    void AddFile ( const Str::Text::Val& file, const Str::Text::Val& filetype );
    void AddFiles( const Str::Text::Vec& files, const Str::Text::Vec& filetypes );
    void AddFiles( const SequenceFiles& files);

private:
    void SanitizeFile( size_t index );
};

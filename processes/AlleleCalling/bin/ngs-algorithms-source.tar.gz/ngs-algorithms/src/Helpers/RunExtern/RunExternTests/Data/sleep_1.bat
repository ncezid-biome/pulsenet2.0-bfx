REM Do a ping of 2 to get 1 seconds
@ping -n 2 127.0.0.1 >nul
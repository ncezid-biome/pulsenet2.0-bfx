#pragma once

#include "StringDef.h"


namespace runextern
{

Str::Text::Val getDataFilePath( const Str::Text::Val& filename );

} // namespace runextern
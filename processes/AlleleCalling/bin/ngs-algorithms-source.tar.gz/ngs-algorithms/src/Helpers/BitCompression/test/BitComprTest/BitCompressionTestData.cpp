#include "stdafx.h"

#include "BitCompressionTestData.h"

#include "TestConfiguration.hpp"


Str::Path::Val BitCompressionTestData::GetLargeFlexstorageFile1()
{
    return GetBitCompressionFiledir() / PM("flexstore110");
}

Str::Path::Val BitCompressionTestData::GetBitCompressionFiledir()
{
    return test::TestConfiguration::GetInputFileRoot() / PM("BitCompression");
}

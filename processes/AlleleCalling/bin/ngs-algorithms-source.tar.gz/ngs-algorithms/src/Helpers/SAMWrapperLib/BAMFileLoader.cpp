#include "stdafx.h"
#include "BAMFileLoader.h"
#include "BAMFileSorter.h"
#include "BAMFileIndexer.h"
#include "BAMPileFileCreator.h"
#include "BAMLevelFileCreator.h"
#include "CalcCommunicationImpl.h"
#include "SAMToolsMessageHandler.h"
#include "SAMToBAMConverter.h"
#include "debugstr.h"
#include <boost/make_shared.hpp>
#include "LocalFileResolver.h"
#include "TempFileResolver.h"
#include "BAMFileType.h"

namespace BAM
{

FileResolver::Ptr FileLoader::LoadBAMFile(const communication::CalcCommunication& calc, const Str::Path::Val& inputFile, const Str::Path::Val& tempDir)
{
    FileLoader loader;
    return loader.Load(calc, inputFile, tempDir);
}

FileResolver::Ptr FileLoader::LoadBAMFile(const communication::CalcCommunication& calc, const Str::Path::Val& inputFile)
{
    FileLoader loader;
    BasicFileResolver::Ptr files=boost::make_shared<LocalFileResolver>(inputFile);

    return loader.Load(calc, inputFile, files);
}

FileResolver::Ptr FileLoader::Load(const communication::CalcCommunication& calc, const Str::Path::Val& inputFile, BasicFileResolver::Ptr files)
{
    SAMToolsMessageHandler messageHandler(FileLoader::ErrorCallback, calc);

    if(GetFileType(inputFile) == FileType::SAM){

        calc.Send(communication::CalcMessage("Converting to BAM-format..."));

        SAMToBAMConverter converter;
        converter.ConvertFile(inputFile, files->GetBAMFile());

        calc.Send(communication::CalcMessage( (Message("File %1 has been converted to BAM-format") << inputFile.string() ).c_str() ));
    }
    else {
        //input file is not a SAM file...
        //override BAM file in file resolver
        files->SetBamFile(inputFile);
    }

    calc.ContinueOrAbort();

    FileSorter sorter;
    sorter.SetMaxThreads(communication::GetMaxThread());

#ifndef AMGNU
    {
        MEMORYSTATUSEX memStats;
        memStats.dwLength=sizeof(memStats);
        GlobalMemoryStatusEx(&memStats);

        sorter.SetMaxMem(memStats.ullTotalPhys*75/100);
    }
#endif

    if(!sorter.IsSorted(files->GetBAMFile())) {

        calc.Send(communication::CalcMessage("Sorting BAM file..."));

        sorter.SortFile(files->GetBAMFile(), files->GetSortedBAMFile());

        calc.Send(communication::CalcMessage( (Message("Input has been sorted into %1") << files->GetSortedBAMFile() ).c_str() ));
    }
    else {
        //input file was already sorted
        //override sorted BAM file in file resolver
        files->SetSortedBamFile(files->GetBAMFile());
    }

    calc.ContinueOrAbort();

    FileIndexer indexer;
    if(!indexer.HasIndex(files)) {

        calc.Send(communication::CalcMessage("Indexing file..."));

        indexer.CreateIndexFile(files);

        calc.Send(communication::CalcMessage( (Message("Index has been written into %1") << files->GetBAMIndexFile().string() ).c_str() ));
    }

    calc.ContinueOrAbort();

    if(createPileFile_) {

        PileFileCreator pileFileCreator;
        if(!pileFileCreator.HasPileFile(files)) {

            calc.Send(communication::CalcMessage("Creating pile file..."));
            pileFileCreator.CreatePileFile(files);
        }

        calc.ContinueOrAbort();
    }

    if(createLevelFile_) {

        LevelFileCreator levelFileCreator;
        if(!levelFileCreator.HasLevelFile(files)) {

            calc.Send(communication::CalcMessage("Creating level file..."));
            levelFileCreator.CreateLevelFile(files);
        }

        calc.ContinueOrAbort();
    }

    return files;
}

FileResolver::Ptr FileLoader::Load(const communication::CalcCommunication& calc, const Str::Path::Val& inputFile, const Str::Path::Val& tempDir)
{
    BasicFileResolver::Ptr files=boost::make_shared<TempFileResolver>(tempDir);

    return Load(calc, inputFile, files);
}

void FileLoader::ErrorCallback(const char* message, const communication::CalcCommunication* calc)
{
    debug_str << message << std::endl;
}

}
#include "stdafx.h"
#include "BAMAlignment.h"
#include <string>
#include <stdlib.h>
#include <boost/smart_ptr/make_shared_array.hpp>

/**
 * Set the CIGAR through a vector of CigarOp objects.
 * By default, the CIGAR is set to "{length-of-sequence}M".
 */
void BAM::Alignment::SetCigar(const Cigar::CigarOps& cigarOps)
{
    //roll a new one
    size_t parts=cigarOps.size();
    Cigar::Cigar cigar=boost::make_shared<Cigar::CigarOp[]>(parts);

    for(size_t m=0; m<parts; m++) {

        cigar[m]=cigarOps[m];

        //check if CigarOp struct works correctly
        ASSERT(cigar[m].length==bam_cigar_oplen(cigar[m].raw));
    }

    cigarLen_=parts;
    cigar_.swap(cigar);
}

/**
 * Set the CIGAR in string form, e.g. "12M2D1M2I85M". The string is parsed until the
 * end or the first error, i.e. length=0 or operator missing.
 * By default, the CIGAR is set to "{length-of-sequence}M".
 */
void BAM::Alignment::SetCigar(Str::Text::Arg cigar)
{
    SetCigar(Cigar::FromRLEString(cigar));
}

void BAM::Alignment::SetSequence(Str::Text::Arg sequence)
{
    const Str::Text::Val sequenceString(sequence);
    sequenceLen_=sequenceString.length();

    //we store two bases per byte, so we divide length by 2 (>>1), rounding up (+1)
    size_t length=getTwoBasesLength();
    Sequence newSequence=boost::make_shared<TwoBases[]>(length);

    for(size_t m=0; m<length; m++) {

        newSequence[m].b1=bam_nt16_table[sequenceString[2*m] & 0xFF];
        newSequence[m].b2=bam_nt16_table[sequenceString[2*m+1] & 0xFF];

        //check if TwoBases struct works correctly
        ASSERT(newSequence[m].b2==bam1_seqi((char*)&newSequence[m], 1));
    }

    sequence_.swap(newSequence);
}

void BAM::Alignment::SetQuality(Str::Text::Arg quality)
{
    Str::Text::Val qualityString(quality);

    qualityLen_=qualityString.length();
    Quality newQuality=boost::make_shared<uint8_t[]>(qualityLen_);

    for(size_t m=0; m<qualityLen_; m++) {

        newQuality[m]=qualityString[m]-33;
    }

    quality_.swap(newQuality);
}

void BAM::Alignment::WriteToBAMFile(bamFile file) const
{
    size_t nameLen=name_.length();
    size_t bufferLength=nameLen+1+cigarLen_*4+getTwoBasesLength()+sequenceLen_ + aux_.size();
    char* buffer=new char[bufferLength];

    bam1_t* b=stl_bam_init1();

    b->core.tid=refID_;
    b->core.pos=position_;
    b->core.flag=flags_;
    b->core.isize=templateLength_;

    if(mate_) {
        b->core.mtid=mate_->refID_;
        b->core.mpos=mate_->position_;
    }
    else {
        b->core.mtid=NOREFERENCE;
        b->core.mpos=NOPOSITION;
    }


    b->data=reinterpret_cast<uint8_t*>(buffer);
    b->data_len=bufferLength;

    strncpy(bam1_qname(b), name_.c_str(), nameLen);
    b->core.l_qname=nameLen+1;

    if(cigar_) {

        memcpy(bam1_cigar(b), cigar_.get(), cigarLen_*sizeof(Cigar::CigarOp));
        b->core.n_cigar=cigarLen_;
    }
    else if((flags_ & BAM_FUNMAP)==0) {

        //read is mapped, write default cigar
        Cigar::CigarOp defaultCigar= { Cigar::GetNibbleForCigarOp('M'), sequenceLen_ };
        memcpy(bam1_cigar(b), &defaultCigar, sizeof(Cigar::CigarOp));
        b->core.n_cigar=1;
    }
    else {
        b->core.n_cigar = 0;
        //we've allocated space for the default cigar length of 1, but we were just kidding, bruh
        b->data_len -= 4;
    }

    memcpy(bam1_seq(b), sequence_.get(), getTwoBasesLength());
    b->core.l_qseq=sequenceLen_;

    if(quality_ && sequenceLen_==qualityLen_) {
        memcpy(bam1_qual(b), quality_.get(), qualityLen_);
    }
    else {
        memset(bam1_qual(b), 0xFF, sequenceLen_);
    }

    memcpy(bam1_aux(b), &aux_[0], aux_.size());

    bam_write1(file, b);

    b->data=nullptr;
    delete[] buffer;

    stl_bam_destroy1(b);
}

void BAM::Alignment::AddAuxString(Str::ID::Arg tag, Str::Text::Arg value)
{
    aux_.append(AuxEntry::Create(tag, value));
}

/**
 * Indicate that the given Alignment comes after the current Alignment. This
 * method manipulates the flags of both objects.
 */
void BAM::Alignment::SetMate(Alignment::Ptr mate)
{
    mate_=mate;

    //set mreverse flag if mate is a reverse read
    if(mate_->flags_ & BAM_FREVERSE) {
        flags_|=BAM_FMREVERSE;
    }
}

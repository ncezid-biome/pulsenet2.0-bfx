#pragma once
#include "runextern_cmdline.h"

namespace runextern {

	class BatchFile {
	private:
		std::vector<ProcessCmdLine> lines_;
	public:
		BatchFile();
		BatchFile(const ProcessCmdLine& line);
		BatchFile(Str::Text::Arg lines);
		BatchFile(const BatchFile& other);
		~BatchFile();

		BatchFile& operator =(const BatchFile& other);

		void addLine(const ProcessCmdLine& line);

		typedef std::vector<ProcessCmdLine>::const_iterator cmdline_iterator;
		cmdline_iterator begin();
		cmdline_iterator end();
	};

	class ExternalApp {
	public:
		ExternalApp();
		virtual ~ExternalApp();

		virtual void createBatchFile(BatchFile& file) const =0;
	};




	class BatchFileApp : public ExternalApp {
	private:
		Str::Text::Val filename_;
	public:
		BatchFileApp();
		BatchFileApp(Str::Text::Arg filename);
		~BatchFileApp();

		void setFilename(Str::Text::Arg filename);
		void createBatchFile(BatchFile& file) const;
	};

	class MemoryBatchFileApp : public ExternalApp {
	private:
		BatchFile file_;
	public:
		MemoryBatchFileApp();
		MemoryBatchFileApp(const BatchFile& file);
		MemoryBatchFileApp(const ProcessCmdLine& cmdline);		
		~MemoryBatchFileApp();

		void setBatchFile(const BatchFile& file);
		void createBatchFile(BatchFile& file) const;
	};
}
#include "stdafx.h"

#include "CE_ProgramOptions.h"
#include "CE_FilesCommunication.h"

#include <fstream>
#include "boost/program_options.hpp"
#include "boost/program_options/options_description.hpp"

#define OPTION_HELP "help"
#define OPTION_SETTINGSFILE "settingsFile"
#define OPTION_ORGANISMSETTINGSFILE "organismSettings"
#define OPTION_ORGANISM "organism"


namespace engine{

ProgramOptions::ProgramOptions(const Str::Text::Val& name, bool asSub): options_(name), name_(name) 
{
	if (!asSub) {
		options_.add_options()
			(OPTION_HELP, "produce help message")
			(OPTION_SETTINGSFILE, boost::program_options::value<Str::Path::Val>(), "settings file")
			;
	}
}

Str::Text::Val ProgramOptions::GetName() const 
{
	return name_;
}
void ProgramOptions::showHelp(std::ostream& os) const
{
    os << options_;
}

/**
 * \brief Parses the command parameters, loads an optional settings file and determines if the help should be shown or not.
 * 
 * \return A boolean that indicates if normal operations should take place or if the help should be shown.
 *
 * \retval TRUE   The help should be shown by the calling function.
 * \retval FALSE  Normal operation should be performed by the calling function, do not show the help.
*/
bool ProgramOptions::ParseCmdLine(int argc, char* argv[], const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm)
{
	//parse the command line
    boost::program_options::variables_map vm;
	boost::program_options::parsed_options parsed_options = boost::program_options::command_line_parser(argc, argv).options(options_).allow_unregistered().run();
    boost::program_options::store(parsed_options, vm);
		
	// react to the --help flag
	if (vm.count(OPTION_HELP) != 0)
		return true;

	//list options that are passed in that we don't react to
	// Prepare the communication
	auto unrecognized = collect_unrecognized(parsed_options.options,	 boost::program_options::exclude_positional);
	for (const auto& value : unrecognized) {
		comm.Send(communication::CalcWarning(RawMessage(PM("Unknown command line parameter: %1"), value).c_str()));
	}
	
	//the things above need to be done before the notify. 
	//That way --help can be passed in without getting errors about missing required parameters.
    boost::program_options::notify(vm);

	//read the settings file (if any)
    if (!vm.count(OPTION_SETTINGSFILE)==0) {
        Str::Path::Val settingsFile = vm[OPTION_SETTINGSFILE].as<Str::Path::Val>();
        std::ifstream is (ToRef(settingsFile));
        if (!is.is_open())
            throw KError("Could not open settings file '%1'.") << settingsFile;

        boost::program_options::store(boost::program_options::parse_config_file(is, options_, true), vm);
        boost::program_options::notify(vm);
    }
	for (auto flag: flags_)
		flag.value = !(vm.count(flag.id)==0);

	//no help needs to be shown -> return false
	return false;
}
ProgramOptions& ProgramOptions::AddFlag(Str::Text::Arg id, Str::Text::Arg descr, bool& value)
{
	options_.add_options() 
		(id, descr);

	flags_.push_back(Flag(id, value));
	reportables_.push_back(Reportable::Ptr(new ConcreteReportable<bool>(id, descr, value)));

	return *this;
}
ProgramOptions& ProgramOptions::AddProgramOptions(ProgramOptions& subOptions)
{
	options_.add(subOptions.options_);
	reportables_.push_back(Reportable::Ptr(new ProgramOptionsReportable(subOptions)));
	return *this;
}
void ProgramOptions::TransferReportablesTo(ProgramOptions& other) const
{
	for (Reportable::Ptr reportablePtr: reportables_){
		int nFound = 0;
		for (Reportable::Ptr otherReportablePtr: other.reportables_) {
			if (reportablePtr->IsSameOptionAs(*otherReportablePtr)) {
				reportablePtr->CopyValueTo(*otherReportablePtr);
				nFound +=1;
			}
		}
	}
}

void ProgramOptions::SuppressReporting(ProgramOptions const & subOptions)
{
	auto FindCorrespondingReportable = [&subOptions](boost::shared_ptr<Reportable> const & i)
		{
			if (i->GetTypeId() == ProgramOptionsReportable::GetProgramOptionsTypeId())
			{
				return static_cast<ProgramOptionsReportable*>(i.get())->GetId() == subOptions.GetName();
			}
			return false;
		};
	auto it = std::find_if(reportables_.begin(), reportables_.end(), FindCorrespondingReportable);
	if (it != reportables_.end())
	{
		reportables_.erase(it);
	}
}

void ProgramOptions::SuppressReporting(std::string idToRemove) {

	auto FindCorrespondingReportable = [idToRemove](boost::shared_ptr<Reportable> const & i)
	{
		return static_cast<ProgramOptionsReportable*>(i.get())->GetId() == idToRemove;
	};

	auto it = std::find_if(reportables_.begin(), reportables_.end(), FindCorrespondingReportable);
	if (it != reportables_.end())
	{
		reportables_.erase(it);
	}

}

void ProgramOptions::SuppressReporting(std::vector<std::string> idsToRemove){

	for (auto it = std::begin(idsToRemove); it != std::end(idsToRemove); ++it) {		
		auto reportable_it = std::find_if(reportables_.begin(), reportables_.end(), [it](boost::shared_ptr<Reportable> & i){ 			
			return static_cast<ProgramOptionsReportable*>(i.get())->GetId() == static_cast<std::string>(it->data());
		});
		if (reportable_it != reportables_.end())
		{
			reportables_.erase(reportable_it);
		}		
	}

}

void ProgramOptions::LogSettings(const communication::CalcCommunication& comm, int level) const
{	
	if (level==0)
		comm.Send( communication::CalcMessage(PM("=== PROGRAM OPTIONS ===")) );
	
	comm.Send( communication::CalcMessage( IndentedMessage(GetName(), level).str() ) );		
	for (size_t i=0; i<reportables_.size(); ++i) 
		reportables_[i]->LogSetting(comm, level+1);

	if (level==0)
		comm.Send( communication::CalcMessage(PM("=== END PROGRAM OPTIONS ===")) );
	
}

bool ProgramOptions::ParseAndSetup(int argc, char* argv[], const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm)
{
	return false;
}



} //end namespace engine
#pragma once

#include "StringDef.h"

Str::Text::Val GetVersionInfo();
void           PrintVersionInfo();

void PrintVersionInfo( const Str::Text::Val& shortName, const Str::Text::Val& longName );

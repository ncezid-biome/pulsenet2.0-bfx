#pragma once


namespace seq
{

class Sequence;

} // namespace seq
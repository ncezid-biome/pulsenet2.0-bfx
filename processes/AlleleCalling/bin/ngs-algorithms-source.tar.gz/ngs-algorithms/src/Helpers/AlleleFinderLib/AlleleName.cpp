#include "stdafx.h"

#include "AlleleName.h"


Str::Text::Val AlleleName::ExtractLocusName(const Str::Text::Val& allelename)
{
    Str::Text::Val myAllele(allelename);
    size_t pos = myAllele.find_last_of('_');
    if (pos!=Str::Text::Val::npos) 
        return myAllele.substr(0, pos);
    else 
        return myAllele;
}

size_t AlleleName::ExtractAlleleNumber(const Str::Text::Val& allelename)
{
    Str::Text::Val myAllele(allelename);
    size_t pos = myAllele.find_last_of('_');
    if (pos!=Str::Text::Val::npos) 
        return atoi(myAllele.substr(pos+1, std::string::npos).c_str());
    else 
        return -1;
}

#include "stdafx.h"

#include "BaseManip.h"

#include "RevComplTable.h"


namespace seq
{

Base Complement(Base base)
{
    return RevComplTable::Get()[base];
}


} // namespace seq

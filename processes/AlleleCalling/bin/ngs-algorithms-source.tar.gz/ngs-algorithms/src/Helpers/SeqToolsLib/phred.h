#pragma once

extern double errorprobs[64];
void initErrorProbs();


#define PHREDC 0.23025850929940456840179914546844

char toPhredQual(double err);
double toErrorProb(char phredQual);



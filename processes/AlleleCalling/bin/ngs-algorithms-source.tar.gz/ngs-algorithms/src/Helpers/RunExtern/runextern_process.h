#pragma once

#include "StringDef.h"

#include "boost/smart_ptr.hpp"

#include "runextern_cmdline.h"
#include "runextern_processInfo.h"
#include "runextern_errorcode.h"
#include "runextern_MessageBuffer.h"



namespace runextern
{

    
class ProcessStatus
{
public:
    ProcessStatus();

    void setFailedToCreatePipes   (ErrorCode errcode, const Str::Text::Val& message);
    void setFailedToStart         (ErrorCode errcode, const Str::Text::Val& message);
    void setFailedToSetPriority   (ErrorCode errcode, const Str::Text::Val& message);
    void setFailedToSetMemoryLimit(ErrorCode errcode, const Str::Text::Val& message);

    ErrorCode getErrorCode() const;

    bool failed() const;
    bool failedToCreatePipes() const;
    bool failedToStart() const;
    bool failedToSetPriority() const;
    bool failedToSetMemoryLimit() const;

    void           setErrorText( const Str::Text::Val& text ){ errorText_ = text; }
    Str::Text::Val getErrorText() const { return errorText_; }

private:		
    bool failed_pipecreation_;
    bool failed_creation_;
    bool failed_priorityclass_;
    bool failed_jobobject_;

    ErrorCode      errcode_;
    Str::Text::Val errorText_;
};

/**
    Create processes using a \a ProcessPool
*/
class Process
{
public:
    typedef boost::shared_ptr<Process> Ptr;

    typedef unsigned __int64 Memory;

public:
    virtual ~Process(){}

    virtual void setCmdLine(const ProcessCmdLine& cmd) = 0;
    virtual void setInfo(const ProcessInfo& info) = 0;

    virtual const  ProcessStatus& getStatus() = 0;
    virtual Memory getMemoryUsage() const = 0;

    virtual bool run() = 0;
            void killProcess();
    virtual void terminate( ErrorCode errorCode ) =0;
    virtual bool checkForMessage(MessageBuffer& buffer, int &bytesRead) =0;
    virtual void sendMessage( Str::Text::Arg message ) =0;
	virtual int GetExitCode() = 0;
	virtual ErrorCode GetErrorCode() = 0;
};


}

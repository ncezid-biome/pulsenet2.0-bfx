#pragma once

#ifdef AMGNU

#include "runextern_process.h"

#include "UnixPipe.h"
#include "UnixPipeListener.h"


namespace runextern
{
    


class UnixProcess : public Process
{
public:
    UnixProcess();
    ~UnixProcess();

    virtual void   setCmdLine(const ProcessCmdLine& cmd) override;
    virtual void   setInfo(const ProcessInfo& info) override;
    virtual const  ProcessStatus& getStatus() override;
    virtual Memory getMemoryUsage() const override;
    virtual bool   run() override;
    virtual void   terminate(ErrorCode errorCode) override;
    virtual bool   checkForMessage(MessageBuffer& buffer, int &bytesRead) override;
    virtual void   sendMessage(Str::Text::Arg message) override;
	virtual int    GetExitCode() override;
	virtual ErrorCode GetErrorCode() override;

private:
    UnixProcess( const UnixProcess& rhs );
    UnixProcess& operator=( const UnixProcess& rhs );

private:
    ProcessCmdLine   commandLine_;
    ProcessInfo      info_;
    ProcessStatus    status_;
    UnixPipeListener listener_;
    pid_t            myPid_;

    volatile bool    childExited_;
    volatile int     childExitCode_;

    UnixPipe::Ptr    parentToChildPipe;
    UnixPipe::Ptr    childToParentPipe;
};


} // namespace runextern


#endif

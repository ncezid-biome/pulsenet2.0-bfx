#include "stdafx.h"

#include "FileRotator.h"

#include "boost/regex.hpp"
#include "boost/algorithm/string/trim.hpp"
#include "boost/algorithm/string/predicate.hpp"

#include "translate.h"
#include "helper.h"
#include "textfile.h"
#include "CalcCommunicationImpl.h"

#include "CE_LogAction.h"


Str::Text::Val FileRotator::linkSuffix_ = PM("_link");

using namespace communication;

/**
    Must call SetBasename after construction! Provide this constructor to allow postponed
    error checking.

    \sa SetBasename
*/
FileRotator::FileRotator( int numRotations )
    : linkBaseName_()
    , numRotations_( numRotations )
{
}

/**
    \param baseName cannot be a directory! Must be a filename with a full path, the path must exist!
*/
FileRotator::FileRotator( const Str::Path::Val& linkBaseName,
                          int                   numRotations,
                          const CalcCommunication& comm )
    : linkBaseName_( linkBaseName )
    , numRotations_( numRotations )
{
    if ( numRotations_ <= 1 )
        throw KError( PM("The number of rotations must exceed 1 (requested: %1)") )
            << numRotations_;

    CheckBasename( linkBaseName_, comm );
}

/**
    \return True if \a filename was a rotated name, false otherwise
*/
bool FileRotator::GetUnrotatedName( const Str::Path::Val& filename, Str::Path::Val& unrotated )
{
    unrotated = filename;

    boost::regex re( PM(".+_\\d+") );
    if ( boost::regex_match(filename.string(), re) ){
        Str::Text::Val newBasename = filename.string();
        newBasename.erase( newBasename.find_last_of( PM("_") ), newBasename.size() );

        if (   boost::filesystem::exists(GetLinkfilePath(newBasename))
            && boost::filesystem::is_regular_file(GetLinkfilePath(newBasename)) )
        {
            unrotated = newBasename;
            return true;
        }
    }

    return false;
}

void FileRotator::SetBasename( const Str::Path::Val& linkBaseName, const CalcCommunication& comm )
{
    CheckBasename( linkBaseName, comm );
    linkBaseName_ = linkBaseName;
}

void FileRotator::CheckBasename( const Str::Path::Val& linkBaseName, const CalcCommunication& comm )
{
    if ( linkBaseName.empty() )
        throw InternalError( PM("An empty name for a rotated file is invalid") );

    bool isValid = true;
    try {
        // If the name is a directory it is invalid!
        isValid = ! (    boost::filesystem::exists(linkBaseName)
                      && boost::filesystem::is_directory(linkBaseName) );
    } catch ( std::exception& e ){
        comm.Send( CalcWarning(
            RawMessage( "Ignoring error: Unable to check directory '%1' existence: %2\n",
                        linkBaseName,
                        e.what()).c_str()) );
    }
    
    if ( ! isValid )
        throw KError( PM("Invalid basename for rotated file (%1): a directory with that name exists") )
            << linkBaseName;
}

Str::Path::Val FileRotator::GetNextFile( const Str::Path::Val& fileBaseName ) const
{
    return GetFilename( fileBaseName, GetNextRotation() );
}

/**
    Get the next rotation, restarting at 0 if the maximum is reached. Returns 0 if the
    link file does not exist yet (-> first creation of the rotated file and the link 
    file).
*/
int FileRotator::GetNextRotation() const
{
    int rotation = 0;
    if ( boost::filesystem::exists(GetLinkfilePath()) ){
        rotation = GetCurrentRotation();

        ++rotation;
        if ( rotation >= numRotations_ )
            rotation = 0;
    }

    return rotation;
}

Str::Path::Val FileRotator::GetLinkfilePath( const Str::Path::Val& basename )
{
    return basename.string() + linkSuffix_;
}

Str::Path::Val FileRotator::GetLinkfilePath() const
{
    return GetLinkfilePath( GetLinkBaseName() );
}

/**
    Get the current rotation index i.e. the suffix of the file the current rotation points to. 
    Returns 0 if no link file exists yet.
*/
int FileRotator::GetCurrentRotation() const
{
    if ( ! boost::filesystem::exists(GetLinkfilePath()) )
        return 0;

    std::ifstream ifile(GetLinkfilePath().c_str());
    if ( ! ifile.is_open() )
        throw KError( PM("Unable to open link file %1") )
            << GetLinkfilePath();

    int rotation = 0;
    try {
        ifile >> rotation;
    } catch ( ... ){
        throw KError( PM("Malformed rotation index in link file '12'") )
            << GetLinkfilePath().string();
    }

    return rotation;
}

/**
    Make the link file point to the next rotation. Do this after you have written this next
    rotation! Throws if the new rotated file does not exist.
*/
void FileRotator::RotateLinkfile( const CalcCommunication& comm )
{
    // Get the rotation before opening the file for writing!
    int rotation = GetNextRotation();

    engine::LogAction( comm, RawMessage(PM("Rotating link file '%1' (%2 -> %3)"),
        GetLinkfilePath(),
        GetCurrentRotation(),
        GetNextRotation() ).c_str() );

    {
        TextFile linkFile( ToRef(GetLinkfilePath()), TextFile::write );
        linkFile.WriteString( ToStr(rotation) );
    }
}

Str::Path::Val FileRotator::GetFilename( const Str::Path::Val& fileBaseName, int rotation ) const
{
    return fileBaseName.string() + PM("_") + ToStr(rotation);
}

Str::Path::Val FileRotator::GetLinkBaseName() const
{
    return linkBaseName_;
}

Str::Path::Val FileRotator::GetCurrentFile(const Str::Path::Val& fileBaseName) const
{
    return GetFilename( fileBaseName, GetCurrentRotation() );
}


SingleFileRotator::SingleFileRotator(const Str::Path::Val& filename, int numRotations, const communication::CalcCommunication& comm)
    : rotator_( filename, numRotations, comm )
{
}

/**
    Get the current file the link file points to i.e. this is the file that should be
    currently opened for reading
*/
Str::Path::Val SingleFileRotator::GetCurrentFile() const
{
    return rotator_.GetCurrentFile( rotator_.GetLinkBaseName() );
}

/**
    Get the next file the link file should point to i.e. updated file contents should be
    written to this file, after that the file link in the link file must be pointed to this
    new file.
*/
Str::Path::Val SingleFileRotator::GetNextFile() const
{
    return rotator_.GetNextFile( rotator_.GetLinkBaseName() );
}

/**
    Single file -> check if the new file exists before rotating
*/
void SingleFileRotator::RotateLinkfile( const CalcCommunication& comm )
{
    Str::Path::Val nextFile = GetNextFile();

    if (   ! boost::filesystem::exists(nextFile)
        || ! boost::filesystem::is_regular_file(nextFile) )
        throw KError( PM("The next file rotation (%1) does not exist, unable to rotate link file (%2)") )
            << nextFile.string()
            << rotator_.GetLinkfilePath().string();

    rotator_.RotateLinkfile( comm );
}

FileRotatorExtentions::FileRotatorExtentions( int numRotations )
    : rotator_( numRotations )
{
}

FileRotatorExtentions::FileRotatorExtentions( const Str::Path::Val& baseName,
                                              int                   numRotations,
                                              const CalcCommunication& comm )
    : rotator_( baseName, numRotations, comm )
{
}

Str::Path::Val FileRotatorExtentions::GetCurrentFile(const Str::Text::Val& extension) const
{
    return GetCurrentFileBase().replace_extension( GetCurrentFileBase().extension().string() + GetParsedExtension(extension) );
}

Str::Path::Val FileRotatorExtentions::GetNextFile(const Str::Text::Val& extension) const
{
    return GetNextFileBase().replace_extension( GetNextFileBase().extension().string() + GetParsedExtension(extension) );
}

void FileRotatorExtentions::RotateLinkfile( const CalcCommunication& comm )
{
    rotator_.RotateLinkfile( comm );
}

/**
    Ensure leading '.' if \a extension is not empty
*/
Str::Text::Val FileRotatorExtentions::GetParsedExtension(const Str::Text::Val extension)
{
    Str::Text::Val parsed = extension;
    if (    ! extension.empty()
         && ! boost::starts_with(parsed, PM(".")) )
        parsed = PM(".") + parsed;

    return parsed;
}

/**
    Get the current file base: the base part of the name with the rotator link appended (but
    without any extension!)
*/
Str::Path::Val FileRotatorExtentions::GetCurrentFileBase() const
{
    return rotator_.GetCurrentFile( rotator_.GetLinkBaseName() );
}

Str::Path::Val FileRotatorExtentions::GetNextFileBase() const
{
    return rotator_.GetNextFile( rotator_.GetLinkBaseName() );
}

void FileRotatorExtentions::SetBasename(const Str::Path::Val& baseName, const communication::CalcCommunication& comm)
{
    rotator_.SetBasename( baseName, comm );
}

FileNoRotator::FileNoRotator(const Str::Path::Val& filename)
    : filename_( filename )
{
}

Str::Path::Val FileNoRotator::GetCurrentFile() const 
{
    return filename_;
}

Str::Path::Val FileNoRotator::GetNextFile() const 
{
    return GetCurrentFile();
}

void FileNoRotator::RotateLinkfile(const CalcCommunication& comm)
{
    comm.Send( CalcMessage(
        RawMessage(PM("Not rotating link file for '%1': using as single file"), GetCurrentFile()).c_str() ) );
}

FileRotatorExtention::FileRotatorExtention( const Str::Path::Val& baseName,
                                            int                   numRotations,
                                            const Str::Text::Val& extension,
                                            const CalcCommunication& comm )
    : rotator_  ( baseName, numRotations, comm )
    , extension_( extension )
{
}

Str::Path::Val FileRotatorExtention::GetCurrentFileBase() const
{
    return rotator_.GetCurrentFileBase();
}

Str::Path::Val FileRotatorExtention::GetNextFileBase() const
{
    return rotator_.GetNextFileBase();
}

Str::Path::Val FileRotatorExtention::GetCurrentFile() const 
{
    return rotator_.GetCurrentFile( extension_ );
}

Str::Path::Val FileRotatorExtention::GetNextFile() const 
{
    return rotator_.GetNextFile( extension_ );
}

void FileRotatorExtention::RotateLinkfile(const CalcCommunication& comm)
{
    return rotator_.RotateLinkfile( comm );
}

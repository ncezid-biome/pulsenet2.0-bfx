/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/


#ifndef LOGGING_H
#define LOGGING_H

#include "strdef.h"


class Logger {
public:
	Logger();
	virtual ~Logger();

	virtual void addLog(Str::Text::Arg line) =0;
};

/**
    Usage note: do not use this in Calculation Engine algorithms, use the provided 
    calccommunication instead!
*/
class Logging {
private:
	static std::vector<Logger*> loggers_;
	static int prevprogress_;
public:
	static void AddError(Str::Text::Arg error);
	static void AddWarning(Str::Text::Arg error);
	static void AddLog(Str::Text::Arg part1);
	static void AddProgress(float progress, float total);

	static void Start(Logger* logger); 
	static void Start(Logger* logger1, Logger* logger2);
	static void Stop();
};

class LoggedCalc {
public:
	LoggedCalc(Str::Text::Arg message);
	~LoggedCalc();
};

#endif
#pragma once
/**
    ******************************************************
    ADD READERS HERE -> ALSO ADD THEM TO fillReaderFactory
    ******************************************************
*/

#include <fstream>

#include "boost/thread/mutex.hpp"

#include "factorycounter.h"
#include "compression.h"
#include "CalcCommunication.h"
#include "OwnedFactory.h"

#include "NamedSequence.h"
#include "SequenceReadSettings.h"



/**
    To use a reader multiple times: use the #rewind function to put the reader back in
    the initial state.
*/
class FileReader
{
private:
	std::ifstream ifile_;
	boost::shared_ptr<CompressedReader> compressedreader_;
    Str::Path::Val filepath_;
	size_t buffersize_, sizeleft_, totsize_;
	char *buffer_, *bufferend_, *pos_;
private:
	void readSome();
public:
	FileReader();
	FileReader(const Str::Path::Val& path, size_t  buffsize=5000000);
	~FileReader();

	void init(const Str::Path::Val& path, size_t  buffsize);

	size_t sizeLeft() const;
	size_t totSize() const;

    void rewind();
	bool hasMore() const;
	char peek();
	void skipNextLine();
	void getNextLine(Str::Buffer::Val& line, bool append);
	void read(char* buff, size_t len);

private:
    FileReader( const FileReader& rhs );
    FileReader& operator=( const FileReader& rhs );

    void prepareForReading();
    void ResetCompressedReader();
};

void getline(FileReader& reader, Str::Buffer::Val& line);

class SeqFileReader;
typedef boost::shared_ptr<SeqFileReader> SeqFileReaderPtr;

/**
    \sa getReaderFactory, fillReaderFactory
*/
class SeqFileReader : public FactoryPrototypeBase<SeqFileReader, SeqFileReaderPtr>, public Cloneable<SeqFileReader>
{
public:
	typedef SeqFileReaderPtr Ptr;
    typedef FactoryIDType::Val Id;
    typedef FactoryIDType::Ref IdRef;
protected:
	mutable FileReader reader_;
public:
	SeqFileReader();
	SeqFileReader(const Str::Path::Val& path, size_t  buffsize=5000000);
	virtual ~SeqFileReader();	

	virtual bool hasQualities() const =0;

	size_t sizeLeft() const;
	size_t totSize() const;
    void init(const Str::Path::Val& path, size_t  buffsize);

    /**
        The reader must be rewinded when this function returns i.e. further read operations
        must be able to occur without needing to rewind the reader first.
    */
	virtual bool isRightFileType(FileReader& reader) const =0;
    
	bool hasMore() const;
	virtual void getNextSeq(seq::NamedSequence& sequence) const =0;
	virtual void getNextSeq(Str::Text::Val& name, Str::Text::Val& seq, Str::Text::Val& qual) const =0;

	static void Read( const Str::Path::Val& filename, 
                      Id                    filetype,
                      std::vector<seq::NamedSequence>& sequences,
                      const seq::SequenceReadSettings& settings,
                      const communication::CalcCommunication& comm );

    static SeqFileReaderPtr FromFactory(Str::Text::Val filetype, bool dothrow = true);
	static SeqFileReaderPtr AutoDetect(const Str::Path::Val& path, Str::Text::Val filetype = PM(""), bool dothrow = true);
};

void fillReaderFactory();
OwnedFactory<SeqFileReader>::Ptr getReaderFactory();

class FastaFileReader : public SeqFileReader                      
{
public:
	FastaFileReader();
	FastaFileReader(const Str::Path::Val& path, size_t buffsize=5000000);

    Ptr Clone() const override;

	virtual bool hasQualities() const { return false; }
	virtual void getNextSeq(seq::NamedSequence& sequence) const;
	virtual void getNextSeq(Str::Text::Val& name, Str::Text::Val& seq, Str::Text::Val& qual) const;

    virtual bool isRightFileType(FileReader& reader) const override;

    virtual Str::ID::Ref GetFactoryType() const override { return GetTypeName(); }
    static Str::ID::Ref GetTypeName() { return GetExtension(); }
    static Str::ID::Ref GetExtension() { return PM("fasta"); }
};

class FastQFileReader : public SeqFileReader
{
public:
	FastQFileReader();
	FastQFileReader(const Str::Path::Val& path, size_t  buffsize=5000000);

    Ptr Clone() const override;

	virtual bool hasQualities() const override { return true; }
	virtual void getNextSeq(seq::NamedSequence& sequence) const override;
	virtual void getNextSeq(Str::Text::Val& name, Str::Text::Val& seq, Str::Text::Val& qual) const override;

    virtual bool isRightFileType(FileReader& reader) const override;

    virtual Str::ID::Ref GetFactoryType() const override { return GetTypeName(); }
    static Str::ID::Ref GetTypeName() { return GetExtension(); }

    static Str::ID::Ref   GetExtension()        { return PM("fastq"); }
    static Str::Text::Val GetGZippedExtension();

private:
    void readName(Str::Text::Val& name) const;
};

class ThreadSafeFileReader;
typedef boost::shared_ptr<ThreadSafeFileReader> ThreadSafeFileReaderPtr;

class ThreadSafeFileReader {
public:
	class Chunk {
	private:
		std::vector<size_t> indices_;
		std::vector<std::string> names_, sequences_, qualities_;
		size_t size_, chunkSize_;
	public:
		Chunk () : chunkSize_(0) {}
		
		inline void init(size_t chunkSize) { 
			if (chunkSize_!=chunkSize) {
				chunkSize_=chunkSize;
				names_.resize(chunkSize);			
				sequences_.resize(chunkSize);	
				qualities_.resize(chunkSize);
				indices_.resize(chunkSize);	
			}
		}
		inline void reset() {
			size_ = 0;
		}
		inline void addOne() {
			size_+=1;
		}
		inline Str::Text::Val& getCurrentName() {
			return names_[size_-1];
		}
		inline Str::Text::Val& getCurrentSeq() {
			return sequences_[size_-1];
		}	
		inline Str::Text::Val& getCurrentQual() {
			return qualities_[size_-1];
		}
		inline size_t& getCurrentIdx() {
			return indices_[size_-1];
		}	
		inline size_t size() const { 
			return size_; 
		}
		inline const Str::Text::Val& getName(size_t i) const {
			return names_[i];
		}
		inline const Str::Text::Val& getSeq(size_t i) const {
			return sequences_[i];
		}
		inline const Str::Text::Val& getQual(size_t i) const {
			return qualities_[i];
		}
		inline size_t getIndex(size_t i) const {
			return indices_[i];
		}
	};
private:
	SeqFileReader::Ptr reader1_;	
	SeqFileReader::Ptr reader2_;	
	size_t chunkSize_;	
private:
	mutable size_t index_;
	mutable boost::mutex mutex_;
public:
	ThreadSafeFileReader();
	//ThreadSafeFileReader(SeqFileReader::Id type, const Str::Path::Val& path, size_t  buffsize=5000000, size_t chunkSize = 10000);
	ThreadSafeFileReader(SeqFileReader::Ptr reader, size_t chunkSize = 10000);
	ThreadSafeFileReader(SeqFileReader::Ptr reader1, SeqFileReader::Ptr reader2, size_t chunkSize = 10000);
	
	void getNextChunk(Chunk& chunk, const communication::CalcCommunication& comm=communication::CalcCommunication()) const;
	void getNextChunk(Chunk& chunk1, Chunk& chunk2, const communication::CalcCommunication& comm=communication::CalcCommunication()) const;
};

#include "stdafx.h"
#include "BAMFileResolver.h"

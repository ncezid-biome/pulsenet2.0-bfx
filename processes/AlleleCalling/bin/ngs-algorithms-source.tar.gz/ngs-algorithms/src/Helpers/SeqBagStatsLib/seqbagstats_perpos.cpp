#include "stdafx.h"

#include "seqbagstats_perpos.h"

#include <limits>
#include <cmath>
#include <algorithm>


void Scores::calcMin() const
{
	size_t maxlen=maxLen();
	min_.clear(); min_.resize(maxlen, std::numeric_limits<int>::max());
	for(size_t i=0; i<maxlen; ++i) {
		for(size_t j=0; j<scores_[i].size(); ++j) {		
			if (scores_[i][j]!=0) min_[i]=std::min<int>(min_[i], j);			
		}
	}
	
}
void Scores::calcMax() const
{
	size_t maxlen=maxLen();
	max_.clear(); max_.resize(maxlen, -std::numeric_limits<int>::max());
	for(size_t i=0; i<maxlen; ++i) {
		for(size_t j=0; j<scores_[i].size(); ++j) {			
			if (scores_[i][j]!=0) max_[i]=std::max<int>(max_[i], j);
		}
	}
}
void Scores::calcMean() const
{
	size_t maxlen=maxLen();
	mean_.clear(); mean_.resize(maxlen, 0);
	
	for(size_t i=0; i<maxlen; ++i) {
		for(size_t j=0; j<scores_[i].size(); ++j) {
			mean_[i]+=scores_[i][j]*j*1.0/counts_[i];
		}
	}
}
void Scores::calcStDev()  const
{
	//calc accoording to Numerical Recipes p. 613
	if (mean_.empty()) calcMean();

	size_t maxlen=maxLen();		
	stdev_.resize(maxlen, 0);

	double a, s1=0, s2=0, NN, sqrtN;
	for(size_t i=0; i<maxlen; ++i) {
		NN=(counts_[i]-1.0);
		sqrtN=sqrt(1.0*counts_[i]);
		for(size_t j=0; j<scores_[i].size(); ++j) {
			a=(1.0*j-mean_[i]);
			s1=scores_[i][j]*a*a/NN;
			s2=scores_[i][j]*a/sqrtN;
		}
		stdev_[i]= s1- s2*s2/NN;
	}
}
void Scores::calcQuantiles()  const
{
	size_t maxlen=maxLen();		

	quantiles_.resize(5);
	for(size_t i=0; i<5; ++i) quantiles_[i].resize(maxlen, -1.0);

	double bounds[5]={0.05, 0.25, 0.50, 0.75, 0.95};
	for(size_t i=0; i<maxlen; ++i) {			
		size_t cnt=0;
		for(size_t j=0; j<scores_[i].size(); ++j) {
			cnt+=scores_[i][j];
			for(size_t k=0; k<5; ++k) {
				if (quantiles_[k][i]==-1 && (1.0*cnt)/(1.0*counts_[i])>=bounds[k]) {
					quantiles_[k][i]=j;
				}
			}
		}
	}
}
void Scores::cleanup() 
{
	scores_.clear();
}
void Scores::merge (const Scores& other) 
{	
	if (counts_.size()<other.counts_.size()) counts_.resize(other.counts_.size(), 0);
	if (scores_.size()<other.scores_.size()) scores_.resize(other.scores_.size());		
	for(size_t i=0; i<other.scores_.size(); ++i) {
		if (scores_[i].size()<=other.scores_[i].size()) scores_[i].resize(other.scores_[i].size(), 0);
	}

	for(size_t i=0; i<other.scores_.size(); ++i) {
		counts_[i]+=other.counts_[i];
		for(size_t j=0; j<other.scores_[i].size(); ++j) {
			scores_[i][j]+=other.scores_[i][j];
		}
	}
}


AllScores::AllScores()
: hasQual_(false)
{
}
bool AllScores::hasQual() const
{
	return hasQual_;
}
void AllScores::add(const char* seq1, const char* qual1, size_t seqlen1, const char* seq2, const char* qual2, size_t seqlen2, size_t qualOffset)
{
	size_t maxseqsize=std::max(seqlen1, seqlen2);
	if (counts_.size()<maxseqsize) counts_.resize(maxseqsize, 0);
	if (counts1_.size()<maxseqsize) counts1_.resize(maxseqsize, 0);
	if (counts2_.size()<maxseqsize) counts2_.resize(maxseqsize, 0);
	if (countsA_.size()<maxseqsize) countsA_.resize(maxseqsize, 0);
	if (countsC_.size()<maxseqsize) countsC_.resize(maxseqsize, 0);
	if (countsG_.size()<maxseqsize) countsG_.resize(maxseqsize, 0);
	if (countsT_.size()<maxseqsize) countsT_.resize(maxseqsize, 0);
	if (countsA1_.size()<maxseqsize) countsA1_.resize(maxseqsize, 0);
	if (countsC1_.size()<maxseqsize) countsC1_.resize(maxseqsize, 0);
	if (countsG1_.size()<maxseqsize) countsG1_.resize(maxseqsize, 0);
	if (countsT1_.size()<maxseqsize) countsT1_.resize(maxseqsize, 0);
	if (countsA2_.size()<maxseqsize) countsA2_.resize(maxseqsize, 0);
	if (countsC2_.size()<maxseqsize) countsC2_.resize(maxseqsize, 0);
	if (countsG2_.size()<maxseqsize) countsG2_.resize(maxseqsize, 0);
	if (countsT2_.size()<maxseqsize) countsT2_.resize(maxseqsize, 0);

	hasQual_= qual1!=0 || qual2!=0;
	
	if (seqlen1){
		for(size_t i=0; i<seqlen1; ++i) {
			countsA_[i]+=(seq1[i]=='a' || seq1[i]=='A');
			countsC_[i]+=(seq1[i]=='c' || seq1[i]=='C');
			countsG_[i]+=(seq1[i]=='g' || seq1[i]=='G');
			countsT_[i]+=(seq1[i]=='t' || seq1[i]=='T');
			countsA1_[i]+=(seq1[i]=='a' || seq1[i]=='A');
			countsC1_[i]+=(seq1[i]=='c' || seq1[i]=='C');
			countsG1_[i]+=(seq1[i]=='g' || seq1[i]=='G');
			countsT1_[i]+=(seq1[i]=='t' || seq1[i]=='T');
			++counts_[i];
			++counts1_[i];
		}
		if (qual1) {
			scores_.addLine(qual1, seqlen1, qualOffset);
			scores1_.addLine(qual1, seqlen1, qualOffset);
		}		
	}
	if (seqlen2){
		for(size_t i=0; i<seqlen2; ++i) {
			countsA_[i]+=(seq2[i]=='a' || seq2[i]=='A');
			countsC_[i]+=(seq2[i]=='c' || seq2[i]=='C');
			countsG_[i]+=(seq2[i]=='g' || seq2[i]=='G');
			countsT_[i]+=(seq2[i]=='t' || seq2[i]=='T');
			countsA2_[i]+=(seq2[i]=='a' || seq2[i]=='A');
			countsC2_[i]+=(seq2[i]=='c' || seq2[i]=='C');
			countsG2_[i]+=(seq2[i]=='g' || seq2[i]=='G');
			countsT2_[i]+=(seq2[i]=='t' || seq2[i]=='T');
			++counts_[i];
			++counts2_[i];
		}
		if (qual2) {
			scores_.addLine(qual2, seqlen2, qualOffset);
			scores2_.addLine(qual2, seqlen2, qualOffset);
		}
	}
}
void AllScores::add(const AllScores& other)
{
	size_t maxseqsize=other.counts_.size();
	if (counts_.size()<maxseqsize) counts_.resize(maxseqsize, 0);
	if (counts1_.size()<maxseqsize) counts1_.resize(maxseqsize, 0);
	if (counts2_.size()<maxseqsize) counts2_.resize(maxseqsize, 0);
	if (countsA_.size()<maxseqsize) countsA_.resize(maxseqsize, 0);
	if (countsC_.size()<maxseqsize) countsC_.resize(maxseqsize, 0);
	if (countsG_.size()<maxseqsize) countsG_.resize(maxseqsize, 0);
	if (countsT_.size()<maxseqsize) countsT_.resize(maxseqsize, 0);
	if (countsA1_.size()<maxseqsize) countsA1_.resize(maxseqsize, 0);
	if (countsC1_.size()<maxseqsize) countsC1_.resize(maxseqsize, 0);
	if (countsG1_.size()<maxseqsize) countsG1_.resize(maxseqsize, 0);
	if (countsT1_.size()<maxseqsize) countsT1_.resize(maxseqsize, 0);
	if (countsA2_.size()<maxseqsize) countsA2_.resize(maxseqsize, 0);
	if (countsC2_.size()<maxseqsize) countsC2_.resize(maxseqsize, 0);
	if (countsG2_.size()<maxseqsize) countsG2_.resize(maxseqsize, 0);
	if (countsT2_.size()<maxseqsize) countsT2_.resize(maxseqsize, 0);

	for(size_t i=0; i<other.counts_.size(); ++i) {
		counts_[i]+=other.counts_[i];
		counts1_[i]+=other.counts1_[i];
		counts2_[i]+=other.counts2_[i];
		countsA_[i]+=other.countsA_[i];
		countsC_[i]+=other.countsC_[i];
		countsG_[i]+=other.countsG_[i];
		countsT_[i]+=other.countsT_[i];
		countsA1_[i]+=other.countsA1_[i];
		countsC1_[i]+=other.countsC1_[i];
		countsG1_[i]+=other.countsG1_[i];
		countsT1_[i]+=other.countsT1_[i];
		countsA2_[i]+=other.countsA2_[i];
		countsC2_[i]+=other.countsC2_[i];
		countsG2_[i]+=other.countsG2_[i];
		countsT2_[i]+=other.countsT2_[i];
	}

	hasQual_= hasQual_ || other.hasQual_;

	scores_.merge(other.scores_);
	scores1_.merge(other.scores1_);
	scores2_.merge(other.scores2_);
}
void AllScores::calc() const
{
	scores_.calcMin();
	scores_.calcMax();
	scores_.calcMean();
	scores_.calcStDev();
	scores_.calcQuantiles();

	scores1_.calcMin();
	scores1_.calcMax();
	scores1_.calcMean();
	scores1_.calcStDev();
	scores1_.calcQuantiles();

	scores2_.calcMin();
	scores2_.calcMax();
	scores2_.calcMean();
	scores2_.calcStDev();
	scores2_.calcQuantiles();
}


void AllScores::mergeScores(){
	scores_ = Scores();
	scores_.merge(scores1_);
	scores_.merge(scores2_);
}

//
//void AllScores::merge(const AllScores& other)
//{
//	size_t maxseqsize=other.counts_.size();
//	if (counts_.size()<maxseqsize) counts_.resize(maxseqsize, 0);
//	if (counts1_.size()<maxseqsize) counts1_.resize(maxseqsize, 0);
//	if (counts2_.size()<maxseqsize) counts2_.resize(maxseqsize, 0);
//	if (countsA_.size()<maxseqsize) countsA_.resize(maxseqsize, 0);
//	if (countsC_.size()<maxseqsize) countsC_.resize(maxseqsize, 0);
//	if (countsG_.size()<maxseqsize) countsG_.resize(maxseqsize, 0);
//	if (countsT_.size()<maxseqsize) countsT_.resize(maxseqsize, 0);
//	if (countsA1_.size()<maxseqsize) countsA1_.resize(maxseqsize, 0);
//	if (countsC1_.size()<maxseqsize) countsC1_.resize(maxseqsize, 0);
//	if (countsG1_.size()<maxseqsize) countsG1_.resize(maxseqsize, 0);
//	if (countsT1_.size()<maxseqsize) countsT1_.resize(maxseqsize, 0);
//	if (countsA2_.size()<maxseqsize) countsA2_.resize(maxseqsize, 0);
//	if (countsC2_.size()<maxseqsize) countsC2_.resize(maxseqsize, 0);
//	if (countsG2_.size()<maxseqsize) countsG2_.resize(maxseqsize, 0);
//	if (countsT2_.size()<maxseqsize) countsT2_.resize(maxseqsize, 0);
//
//	for(size_t i=0; i<other.counts_.size(); ++i) {
//		counts_[i]+=other.counts_[i];
//		counts1_[i]+=other.counts1_[i];
//		counts2_[i]+=other.counts2_[i];
//		countsA_[i]+=other.countsA_[i];
//		countsC_[i]+=other.countsC_[i];
//		countsG_[i]+=other.countsG_[i];
//		countsT_[i]+=other.countsT_[i];
//		countsA1_[i]+=other.countsA1_[i];
//		countsC1_[i]+=other.countsC1_[i];
//		countsG1_[i]+=other.countsG1_[i];
//		countsT1_[i]+=other.countsT1_[i];
//		countsA2_[i]+=other.countsA2_[i];
//		countsC2_[i]+=other.countsC2_[i];
//		countsG2_[i]+=other.countsG2_[i];
//		countsT2_[i]+=other.countsT2_[i];
//	}
//
//	hasQual_= hasQual_ || other.hasQual_;
//
//	//scores_.merge(other.scores_);
//	scores1_.merge(other.scores1_);
//	scores2_.merge(other.scores2_);
//}
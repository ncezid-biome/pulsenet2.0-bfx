#pragma once

#include "Sequence.h"

namespace seq
{

/**
    The mother class: encapsulates a named sequence
*/
class NamedSequence
{
public:
    NamedSequence();
    NamedSequence( NamedSequence&& rhs ) throw();
    explicit NamedSequence( const Str::Text::Val& name, const Str::Text::Val& sequence );
    ~NamedSequence() throw();

    NamedSequence& operator=( NamedSequence&& rhs );

    const Str::Text::Val& GetName() const;
          Sequence&       GetData();
    const Sequence&       GetData() const;

    bool IsEmpty() const;

private:
    /** See the Sequence class for more info */
    NamedSequence( const NamedSequence& rhs );
    NamedSequence& operator=( const NamedSequence& rhs );

private:
    struct OpaquePointer;
    std::unique_ptr<OpaquePointer> d_;
};

} // namespace seq

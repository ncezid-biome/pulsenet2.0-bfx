#pragma  once


namespace compression{

#pragma region CoverageItf

/**
Class to draw coverage
*/
class CoverageDrawerItf{
public:
	typedef int CountType;
public:
	virtual ~CoverageDrawerItf();
	/**
	the total number of positions
	*/
	virtual  size_t GetCount() const=0;
	/**
	The total coverage at a certain base position
	*/
	virtual  CountType  GetTot(size_t basePos) const=0;  
	/**
	the total count for base baseNr (0 to 3) and at basePos.
	So GetBaseCount(basePos, 0) + GetBaseCount(basePos, 1) +GetBaseCount(basePos,2)+GetBaseCount(basePos, 3) <= GetTot(basePos) 
	*/
	virtual  CountType  GetBaseCount(size_t basePos, size_t baseNr) const=0;  
};


/**
Class to consult coverage info. Used to WRITE the stuff with bitcompression
*/
class CoverageReaderItf
    : public CoverageDrawerItf
{
public:
	virtual ~CoverageReaderItf();
	/**
	The difference between total coverage at pos basePos and position basePos-1 if basePos!=0
	if basePos==0 the GetTotDiff(0)==GetTot(0)
	You need this function when you want do Save it via
	*/
	virtual  CountType  GetTotDiff(size_t basePos) const;  
	/**
	Should return 0,1,2 or 3. The resulting number should be the maximum of  so
	 GetBaseCount(GetMaxBaseNr(basePos)) >= max(GetBaseCount(basePos, 0), GetBaseCount(basePos, 1),GetBaseCount(basePos,2),GetBaseCount(basePos, 3))
	*/
	virtual  size_t			GetMaxBaseNr(size_t basePos) const;  
};


/**
class to store coverage info. This class is used when you READ a bit compression file. Be ware it will used several of the reader
functions too so it should be implemented nicely
*/
class CoverageWriterItf 
	: public CoverageReaderItf{
public:
	virtual ~CoverageWriterItf(){}

	virtual  void  SetCount(size_t cnt) =0;
    /** Set count for total coverage only */
    virtual  void  SetCountTotal(size_t cnt) =0;
	virtual  void  SetTot(size_t i, CountType cnt) =0;  
	virtual  void  SetBaseCount(size_t i, size_t base, CountType cnt) =0;  
	virtual  void  SetMaxBaseNr(size_t i, size_t maxBase) =0;  
};
#pragma endregion 


}//namespace compression{
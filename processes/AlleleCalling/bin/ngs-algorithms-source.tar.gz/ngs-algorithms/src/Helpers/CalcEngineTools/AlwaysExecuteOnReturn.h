#pragma once

#include <functional>

/**
    RAII helper class: the input function is executed on desctruction. Use this to always execute
    a function (e.g. a lambda) when a method returns.
*/
class AlwaysExecuteOnReturn
{
public:
    typedef std::function<void (void)> ExecFunction;

public:
    AlwaysExecuteOnReturn( ExecFunction function )
        : function_( function )
    {
    }

    ~AlwaysExecuteOnReturn()
    {
        function_();
    }

private:
    AlwaysExecuteOnReturn( const AlwaysExecuteOnReturn& rhs );
    AlwaysExecuteOnReturn& operator=( const AlwaysExecuteOnReturn& rhs );

private:
    ExecFunction function_;
};

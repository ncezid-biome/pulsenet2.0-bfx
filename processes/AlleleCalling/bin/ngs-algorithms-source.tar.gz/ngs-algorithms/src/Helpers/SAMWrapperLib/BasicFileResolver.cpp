#include "stdafx.h"
#include "BasicFileResolver.h"

Str::Path::Val BAM::BasicFileResolver::GetBAMFile() const
{
    if(!bamFile_.empty())
        return bamFile_;

    return Str::Path::Val(basePath_)+=".bam";
}

Str::Path::Val BAM::BasicFileResolver::GetSortedBAMFile() const
{
    if(!sortedBamFile_.empty())
        return sortedBamFile_;

    return sortedBasePath_;
}

Str::Path::Val BAM::BasicFileResolver::GetBAMIndexFile() const
{
	// NOTE NOT TO BE COMMITTED!!!
	if (!sortedBamFile_.empty())
		return Str::Path::Val(sortedBamFile_) += ".bai";
	
	return Str::Path::Val(sortedBasePath_)+=".bai";
}

Str::Path::Val BAM::BasicFileResolver::GetBAMPileFile() const
{
    return Str::Path::Val(sortedBasePath_)+=".bpf";
}

Str::Path::Val BAM::BasicFileResolver::GetBAMLevelFile() const
{
    return Str::Path::Val(sortedBasePath_)+=".blf";
}

Str::Path::Val BAM::BasicFileResolver::GetReferenceFile() const
{
    throw std::logic_error("The method or operation is not implemented.");
}

void BAM::BasicFileResolver::SetBamFile(Str::Path::Val bamFile)
{
    bamFile_=bamFile;
}

void BAM::BasicFileResolver::SetSortedBamFile(Str::Path::Val sortedBamFile)
{
    sortedBamFile_=sortedBamFile;
}

void BAM::BasicFileResolver::SetBasePath(Str::Path::Val basePath)
{
    basePath_=basePath;
    SetSortedBasePath(Str::Path::Val(basePath)+=".sorted.bam");
}

void BAM::BasicFileResolver::SetSortedBasePath(Str::Path::Val sortedBasePath)
{
    sortedBasePath_=sortedBasePath;
}

#include "stdafx.h"

#include "StringCounter.h"



StringCounter::StringCounter()
    : strings_()
{
}

StringCounter::StringCounter( const Str::Text::Vec& strings )
    : strings_()
{
    for ( auto&& string : strings ){
        AddString( string );
    }
}

StringCounter::StringCounter(const std::vector<KError>& errors)
    : strings_()
{
    for ( auto&& err : errors ){
        AddString( err.what() );
    }
}

void StringCounter::AddString(const Str::Text::Val& string)
{
    if ( strings_.find(string) != strings_.cend() )
        strings_[string]++;
    else
        strings_[string] = 1;
}

void StringCounter::Print(std::ostream& os) const
{
    for ( auto&& pair : strings_ ){
        os << pair.first;
        if ( pair.second > 1 ){
            os << RawMessage(PM(" (x %1)"), pair.second).c_str();
        }
        os << "\n";
    }
}

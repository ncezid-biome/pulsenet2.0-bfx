#include "stdafx.h"

#include "runextern_tests.h"

#include "PathDef.h"
#include "translate.h"


namespace runextern
{

Str::Text::Val getDataFilePath(const Str::Text::Val& filename)
{
    //this needs compiler flag /FC to get the full path
    Str::Path::Val thisFile(__FILE__);

    return (thisFile.parent_path() / "Data" / filename).string();
}


} // namespace runextern

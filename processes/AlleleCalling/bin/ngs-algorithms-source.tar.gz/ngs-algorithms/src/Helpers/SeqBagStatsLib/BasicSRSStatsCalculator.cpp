#include "stdafx.h"

#include "BasicSRSStatsCalculator.h"

#include "seqbagstats_general.h"
#include "seqbagstats_perpos.h"
#include "seqbagstats_info.h"
#include "seqbagstats_stats.h"
#include "threading.h"

#include "SRSStatsCalculatorSettings.h"
#include "CE_Communication.h"


BasicSRSStatsCalculator::BasicSRSStatsCalculator()
{
}

BasicSRSStatsCalculator* BasicSRSStatsCalculator::Clone() const
{
    return new BasicSRSStatsCalculator();
}

Str::ID::Val BasicSRSStatsCalculator::GetTypeName()
{
    return PM("BasicStatsCalculator");
}

Str::ID::Val BasicSRSStatsCalculator::GetFactoryType() const
{
    return GetTypeName();
}

void BasicSRSStatsCalculator::CheckPre (
    const SRSStatsCalculatorSettings&       settings,
    const engine::ExecuteEnvironment&       env,
    const communication::CalcCommunication& comm) const
{
}

namespace 
{

class BasicStatsData
{
public:
    size_t qualOffset;
};

class BasicStatsResult
{
public:
    SeqBagGeneralStats general;
    AllScores scores;
};

class BasicStatsHandler
{
private:
    BasicStatsData* data_;
    BasicStatsResult myResult_;
public:
    BasicStatsHandler() : data_(0) {}

    inline void init(BasicStatsData& data)
    {
        data_ = &data;
    }
    void handle(const Str::Text::Val& name, const Str::Text::Val& seq, const Str::Text::Val& qual, size_t index)
    {
        myResult_.general.add(seq.c_str(), qual.size()==seq.size()?qual.c_str():0, seq.size(), 0, 0, 0, data_->qualOffset);
        myResult_.scores.add(seq.c_str(), qual.size()==seq.size()?qual.c_str():0, seq.size(), 0, 0, 0, data_->qualOffset);
    }
    void handle(const Str::Text::Val& name1, const Str::Text::Val& seq1, const Str::Text::Val& qual1, const Str::Text::Val& name2, const Str::Text::Val& seq2, const Str::Text::Val& qual2,size_t index)
    {
        myResult_.general.add(seq1.c_str(), qual1.size()==seq1.size()?qual1.c_str():0, seq1.size(), seq2.c_str(), qual2.size()==seq2.size()?qual2.c_str():0, seq2.size(), data_->qualOffset);
        myResult_.scores.add(seq1.c_str(), qual1.size()==seq1.size()?qual1.c_str():0, seq1.size(), seq2.c_str(), qual2.size()==seq2.size()?qual2.c_str():0, seq2.size(), data_->qualOffset);
    }
    inline void intermediate()
    {
    }
    inline void finish(BasicStatsResult& result)
    {
        result.general.add(myResult_.general);
        result.scores.add(myResult_.scores);
    }
};

} // namespace 

void BasicSRSStatsCalculator::ApplyImpl(const SRSStatsCalculatorSettings& settings, const SplitSequenceFiles& downloadedfiles, SeqBagInfo& returnInfo, std::string& info, std::string& stats, const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm) const
{
    comm.Send( communication::CalcMessage( Message("Performing statistics calculations...")));

    downloadedfiles.Log( comm );

    size_t nCores = comm.GetNrOfProcessorsLeft();

    BasicStatsData data;
    data.qualOffset=settings.qualOffset;

    BasicStatsResult result;

    PerReadThreading<BasicStatsHandler,BasicStatsData, BasicStatsResult> threading(nCores, data);

    //run over the single-end files
    for(size_t i=0; i<downloadedfiles.singleFiles.files.size(); ++i) {
        for(size_t j=0; j<downloadedfiles.singleFiles.files[i].files.size(); ++j) {
            comm.Send( communication::CalcMessage( Message("Analyzing file %1...") << downloadedfiles.singleFiles.files[i].files[j].filename() ) );
            SeqFileReaderPtr reader = SeqFileReader::AutoDetect(downloadedfiles.singleFiles.files[i].files[j], downloadedfiles.singleFiles.files[i].filetype);
            comm.Send( communication::CalcMessage( Message("Opening file of type: '%1'...") << reader->GetFactoryType() ) );
            reader->init(downloadedfiles.singleFiles.files[i].files[j], 5000000);

            threading.handle(reader, result, 50000, comm);
        }
    }

    //run over the paired-end files
    for(size_t i=0; i<downloadedfiles.pairedFiles.files.size(); i+=1) {
        for(size_t j=0; j<downloadedfiles.pairedFiles.files[i].files.size(); j+=2) {

            comm.Send( communication::CalcMessage(
                Message("Analyzing files %1 and %2...") << downloadedfiles.pairedFiles.files[i].files[j].filename() << downloadedfiles.pairedFiles.files[i].files[j+1].filename()) );

            SeqFileReaderPtr reader1 = SeqFileReader::AutoDetect(downloadedfiles.pairedFiles.files[i].files[j], downloadedfiles.pairedFiles.files[i].filetype);
            comm.Send( communication::CalcMessage( Message("Opening file of type: '%1'...") << reader1->GetFactoryType() ) );
            reader1->init(downloadedfiles.pairedFiles.files[i].files[j], 5000000);

            SeqFileReaderPtr reader2 = SeqFileReader::AutoDetect(downloadedfiles.pairedFiles.files[i].files[j+1],downloadedfiles.pairedFiles.files[i].filetype);
            comm.Send( communication::CalcMessage( Message("Opening file of type: '%1'...") << reader2->GetFactoryType() ) );
            reader2->init(downloadedfiles.pairedFiles.files[i].files[j+1], 5000000);

            threading.handle(reader1, reader2, result, 50000, comm);
        }
    }

    //store the general results
    {
        SeqBagInfo myinfo;
        myinfo.fromCounts(result.general);

        Str::Xml::Val xml;
        myinfo.Save(xml);

		info = xml;
        //comm.Send( communication::CalcCreateResultFile("info.xml", xml) );
    }

	//get the return info 
	returnInfo.fromCounts(result.general);

    //store the per-positon results
    {
        SeqBagStats mystats;
        mystats.fromScores(result.scores);

        Str::Xml::Val xml;
        mystats.Save(xml);

		stats = xml;
		//comm.Send( communication::CalcCreateResultFile("stats.xml", xml) );
    }

    comm.Send( communication::CalcMessage( Message("Statistics calculations done")));
    
}

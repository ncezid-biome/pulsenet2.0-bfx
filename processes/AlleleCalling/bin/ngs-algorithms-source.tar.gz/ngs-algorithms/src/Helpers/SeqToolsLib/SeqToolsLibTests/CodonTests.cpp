#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "Sequence.h"
#include "CodonManip.h"

using namespace seq;


struct CodonTestsFixture
{
    CodonTestsFixture()
        : allasequence("AAAAAAAAAA12")
    {

    }

    static Str::Text::Val GetStopCodon()
    {
        return getStopCodons()[0];
    }

    /**
        Sequence consisting of 12xA. 12 because that way appending to the sequence happens in-frame.
    */
    Sequence allasequence;
};

BOOST_FIXTURE_TEST_SUITE( CodonTests, CodonTestsFixture );

//______________________________________________________________________________
// Start codon tests

BOOST_AUTO_TEST_CASE( StartsWithStartCodon_NoStartCodon_False )
{
    BOOST_REQUIRE_EQUAL(false, StartsWithStartCodon(allasequence, getStartCodons()));
}

BOOST_AUTO_TEST_CASE( StartsWithStartCodon_StartCodon_True )
{
    allasequence.Insert(0, getStartCodons()[0]);
    BOOST_REQUIRE_EQUAL(true, StartsWithStartCodon(allasequence, getStartCodons()));
}

BOOST_AUTO_TEST_CASE( StartsWithStartCodon_StartCodonNotFirst_False )
{
    allasequence.Insert(1, getStartCodons()[0]);
    BOOST_REQUIRE_EQUAL(false, StartsWithStartCodon(allasequence, getStartCodons()));
}

BOOST_AUTO_TEST_CASE( StartsWithStartCodon_StartCodonLast_False )
{
    allasequence.AppendSequence(getStartCodons()[0]);
    BOOST_REQUIRE_EQUAL(false, StartsWithStartCodon(allasequence, getStartCodons()));
}

BOOST_AUTO_TEST_CASE( StartsWithStartCodon_StartCodon_StopCodons_False )
{
    allasequence.Insert(0, getStartCodons()[0]);
    BOOST_REQUIRE_EQUAL(false, StartsWithStartCodon(allasequence, getStopCodons()));
}

//______________________________________________________________________________
// Stop codon tests

BOOST_AUTO_TEST_CASE( EndsWithStopCodon_NoStopCodon_False )
{
    BOOST_REQUIRE_EQUAL(false, EndsWithStopCodon(allasequence, getStopCodons()));
}

BOOST_AUTO_TEST_CASE( StopsWithStopCodon_StopCodon_True )
{
    allasequence.AppendSequence(GetStopCodon());
    BOOST_REQUIRE_EQUAL(true, EndsWithStopCodon(allasequence, getStopCodons()));
}

BOOST_AUTO_TEST_CASE( StopsWithStopCodon_StopCodonNotLast_False )
{
    allasequence.Insert(11, GetStopCodon());
    BOOST_REQUIRE_EQUAL(false, EndsWithStopCodon(allasequence, getStopCodons()));
}

BOOST_AUTO_TEST_CASE( StopsWithStopCodon_StopCodonFirst_False )
{
    allasequence.Insert(0, GetStopCodon());
    BOOST_REQUIRE_EQUAL(false, EndsWithStopCodon(allasequence, getStopCodons()));
}

//______________________________________________________________________________
// Combined codon tests

BOOST_AUTO_TEST_CASE( StartsAndEndsWithCodons_StartEnd_True )
{
    allasequence.Insert(0, getStartCodons()[0]).AppendSequence(GetStopCodon());
    BOOST_REQUIRE_EQUAL(true, StartsAndEndsWithCodons(allasequence, getStartCodons(), getStopCodons()));
}

BOOST_AUTO_TEST_CASE( StopsWithStopCodon_StopCodon_False )
{
    allasequence.AppendSequence(GetStopCodon());
    BOOST_REQUIRE_EQUAL(false, StartsAndEndsWithCodons(allasequence, getStartCodons(), getStopCodons()));
}

BOOST_AUTO_TEST_CASE( StopsWithStopCodon_StartCodon_False )
{
    allasequence.Insert(0, getStartCodons()[0]);
    BOOST_REQUIRE_EQUAL(false, StartsAndEndsWithCodons(allasequence, getStartCodons(), getStopCodons()));
}

BOOST_AUTO_TEST_CASE( StopsWithStopCodon_NoCodon_False )
{
    BOOST_REQUIRE_EQUAL(false, StartsAndEndsWithCodons(allasequence, getStartCodons(), getStopCodons()));
}

BOOST_AUTO_TEST_CASE( StopsWithStopCodon_MiddleStartNormalStop_False )
{
    allasequence.Insert(1, getStartCodons()[0]).AppendSequence(GetStopCodon());
    BOOST_REQUIRE_EQUAL(false, StartsAndEndsWithCodons(allasequence, getStartCodons(), getStopCodons()));
}

//______________________________________________________________________________
// Internal stop codon tests

BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_NoStopCodon_False )
{
    BOOST_REQUIRE_EQUAL(false, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Forward));
    BOOST_REQUIRE_EQUAL(false, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Reverse));
}

//______________________________________________________________________________
// Forward tests

// Forward direction: Test out-of frame codons at the end
BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_StopCodonAtEnd_False )
{
    allasequence.AppendSequence(GetStopCodon());
    BOOST_REQUIRE_EQUAL(false, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Forward));
}

BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_StopCodonAtEndMin1_False )
{
    allasequence.Insert(11, GetStopCodon());
    BOOST_REQUIRE_EQUAL(false, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Forward));
}

BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_StopCodonAtEndMin2_False )
{
    allasequence.Insert(10, GetStopCodon());
    BOOST_REQUIRE_EQUAL(false, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Forward));
}

BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_StopCodonAtEndMin3_True )
{
    allasequence.Insert(9, GetStopCodon());
    BOOST_REQUIRE_EQUAL(true, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Forward));
}

BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_StopCodonAtStart_True )
{
    allasequence.Insert(0, GetStopCodon());
    BOOST_REQUIRE_EQUAL(true, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Forward));
}

BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_InternalStop_True )
{
    allasequence.Insert(3, GetStopCodon());
    BOOST_REQUIRE_EQUAL(true, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Forward));
}

BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_InternalStopNoFrame_False )
{
    allasequence.Insert(4, GetStopCodon());
    BOOST_REQUIRE_EQUAL(false, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Forward));
}

//______________________________________________________________________________
// Reverse tests

BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_Rev_StopCodonAtEnd_False )
{
    allasequence.Insert(0, GetStopCodon());
    BOOST_REQUIRE_EQUAL(false, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Reverse));
}

BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_Rev_StopCodonAtStartPlus1_False )
{
    allasequence.Insert(1, GetStopCodon());
    BOOST_REQUIRE_EQUAL(false, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Reverse));
}

BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_Rev_StopCodonAtStartPlus2_False )
{
    allasequence.Insert(2, GetStopCodon());
    BOOST_REQUIRE_EQUAL(false, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Reverse));
}

BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_Rev_StopCodonAtStartPlus3_True )
{
    allasequence.Insert(3, GetStopCodon());
    BOOST_REQUIRE_EQUAL(true, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Reverse));
}

BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_Rev_StopCodonAtEnd_True )
{
    allasequence.AppendSequence(GetStopCodon());
    BOOST_REQUIRE_EQUAL(true, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Reverse));
}

BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_Rev_InternalStop_True )
{
    allasequence.Insert(3, GetStopCodon());
    BOOST_REQUIRE_EQUAL(true, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Reverse));
}

BOOST_AUTO_TEST_CASE( ContainsInternalStopCodon_Rev_InternalStopNoFrame_False )
{
    allasequence.Insert(4, GetStopCodon());
    BOOST_REQUIRE_EQUAL(false, ContainsInternalStopCodon(allasequence, getStopCodons(), FrameDirection::Reverse));
}

//______________________________________________________________________________
// Codon at tests

BOOST_AUTO_TEST_CASE( ContainsCodonAt_NoCodon_False )
{
    for ( size_t i = 0; i < allasequence.GetLength(); ++i )
        BOOST_REQUIRE_EQUAL(false, ContainsCodonAt(allasequence, i, getStopCodons()));
}

BOOST_AUTO_TEST_CASE( ContainsCodonAt_SingleCodon_True )
{
    allasequence.Insert(4, GetStopCodon());
    BOOST_REQUIRE_EQUAL(true, ContainsCodonAt(allasequence, 4, getStopCodons()));
}

BOOST_AUTO_TEST_SUITE_END();

#include "stdafx.h"
#include "BAMAux.h"
#include <stddef.h>

namespace BAM
{

static_assert(offsetof(AuxEntry, I) == 2 + 1, "offsetof(AuxEntry, i) should be 2 + 1 for correct operation");

#define AUXCREATE(T, M, C) \
    template<> Str::Text::Val AuxEntry::Create(Str::ID::Arg t, T value) \
    {                                                                   \
        return Create<T, &AuxEntry::M, C>(t, value);                    \
    }

AUXCREATE(char, A, 'A');

AUXCREATE(int8_t, c, 'c');
AUXCREATE(uint8_t, C, 'C');
AUXCREATE(int16_t, s, 's');
AUXCREATE(uint16_t, S, 'S');
AUXCREATE(int32_t, i, 'i');
AUXCREATE(uint32_t, I, 'I');

AUXCREATE(float, f, 'f');

template<> Str::Text::Val AuxEntry::Create(Str::ID::Arg t, Str::Text::Arg content)
{
    AuxEntry ae;
    size_t len = strlen(content);

    strncpy(ae.tag, t, 2);
    ae.type = 'Z';
    strncpy(ae.Z, content, sizeof(ae.Z) - 1);
    ae.Z[sizeof(ae.Z) - 1] = '\0';

    //yes, include the null terminator
    return Str::Text::Val((char*)&ae, 2 + 1 + std::min(sizeof(ae.Z), len + 1));
}

}

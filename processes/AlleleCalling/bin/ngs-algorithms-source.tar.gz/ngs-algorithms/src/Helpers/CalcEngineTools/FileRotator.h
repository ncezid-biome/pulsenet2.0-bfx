#pragma once

#include "PathDef.h"

#include "CalcCommunication.h"


class FileRotatorItf
{
public:
    typedef boost::shared_ptr<FileRotatorItf> Ptr;

public:
    virtual ~FileRotatorItf(){}

    virtual Str::Path::Val GetCurrentFile() const = 0;
    virtual Str::Path::Val GetNextFile   () const = 0;
    virtual void           RotateLinkfile( const communication::CalcCommunication& comm ) = 0;
};

class FileNoRotator : public FileRotatorItf
{
public:
    FileNoRotator( const Str::Path::Val& filename );

    virtual Str::Path::Val GetCurrentFile() const override;
    virtual Str::Path::Val GetNextFile   () const override;
    virtual void           RotateLinkfile( const communication::CalcCommunication& comm ) override;

private:
    Str::Path::Val filename_;
};

/**
    Rotate multiple files. For more info: see SingleFileRotator. Use that class for rotating
    single files.

    The linkBaseName argument of the constructor specifies the name of the link file. The name
    of the corresponding actual files is left open, the base part of the name is asked
    as arguments in the various getters (see e.g. GetCurrentFile). See e.g. SingleFileRotator
    for a class where the name of the link file is also the name of the actual file.

    \sa SingleFileRotator, FileRotatorExtentions
*/
class FileRotator
{
public:
    FileRotator( int numRotations );
    FileRotator( const Str::Path::Val& linkBaseName, int numRotations, const communication::CalcCommunication& comm );

    void SetBasename( const Str::Path::Val& linkBaseName, const communication::CalcCommunication& comm );

    Str::Path::Val GetCurrentFile( const Str::Path::Val& fileBaseName ) const;
    Str::Path::Val GetNextFile   ( const Str::Path::Val& fileBaseName ) const;
    void           RotateLinkfile( const communication::CalcCommunication& comm );

    Str::Path::Val GetLinkBaseName() const;
    Str::Path::Val GetLinkfilePath() const;

    static bool    GetUnrotatedName( const Str::Path::Val& filename, Str::Path::Val& unrotated );

private:
    int            GetCurrentRotation() const;
    int            GetNextRotation() const;
    void           CheckBasename( const Str::Path::Val& linkBaseName, const communication::CalcCommunication& comm );
    static Str::Path::Val GetLinkfilePath( const Str::Path::Val& basename );

    Str::Path::Val GetFilename( const Str::Path::Val& fileBaseName, int rotation ) const;  

    static Str::Text::Val linkSuffix_;

private:
    Str::Path::Val linkBaseName_;
    int            numRotations_;
};

/**
    Utility class for wrap-around access to a file: allows writing a new version of the file 
    (potentially slow), after which a link file is updated to point to this new file (very fast). This
    to prevent other programs from having this file overwritten during a read.
    
    If the base filename is e.g. 'gloriousFile', with 5 rotations then after some usage you 
    will have:
    
    gloriousFile_0
    gloriousFile_1
    gloriousFile_2
    gloriousFile_3
    gloriousFile_4
    gloriousFile_link
    
    Where gloriousFile_rotation contains the index of the current rotation. When writing the next
    version of the rotated file you use GetNextFile() to get the name, then write it, then update
    the link file using RotateLinkfile().    

    \sa FileRotator, FileRotatorExtentions
*/
class SingleFileRotator : public FileRotatorItf
{
public:
    SingleFileRotator( const Str::Path::Val& filename, int numRotations, const communication::CalcCommunication& comm );

    virtual Str::Path::Val GetCurrentFile() const override;
    virtual Str::Path::Val GetNextFile() const override;
    virtual void           RotateLinkfile( const communication::CalcCommunication& comm ) override;

private:
    FileRotator rotator_;
};

/**
    Rotating files that end in an extension, where the rotating index should come before
    the extension. Useful for rotating e.g. the blast libraries, where we do not have control
    over the individual output files, only over the base name of the output (i.e. the part 
    before the extension).

    \sa SingleFileRotator
*/
class FileRotatorExtentions
{
public:
    FileRotatorExtentions( int numRotations );
    FileRotatorExtentions( const Str::Path::Val& baseName,
                           int                   numRotations,
                           const communication::CalcCommunication& comm );

    void SetBasename( const Str::Path::Val& baseName, const communication::CalcCommunication& comm );

    Str::Path::Val GetCurrentFileBase() const;
    Str::Path::Val GetNextFileBase() const;
    Str::Path::Val GetCurrentFile( const Str::Text::Val& extension ) const;
    Str::Path::Val GetNextFile   ( const Str::Text::Val& extension ) const;

    void RotateLinkfile( const communication::CalcCommunication& comm );

private:
    static Str::Text::Val GetParsedExtension( const Str::Text::Val extension );

private:
    FileRotator rotator_;
};

class FileRotatorExtention : public FileRotatorItf
{
public:
    FileRotatorExtention( const Str::Path::Val& baseName,
                          int                   numRotations,
                          const Str::Text::Val& extension,
                          const communication::CalcCommunication& comm );

    Str::Path::Val GetCurrentFileBase() const;
    Str::Path::Val GetNextFileBase() const;
    virtual Str::Path::Val GetCurrentFile() const override;
    virtual Str::Path::Val GetNextFile   () const override;

    virtual void RotateLinkfile( const communication::CalcCommunication& comm ) override;

private:
    FileRotatorExtentions rotator_;
    Str::Text::Val        extension_;
};

#pragma once
#include <vector>
#include "StringDef.h"

class AllScores;
class SeqBagStats {
public:
	struct Stat {
		int count[2], countA[2], countC[2], countG[2], countT[2];
		int min[2], max[2];
		double avg[3], stdev[3];
		double quantiles[3][5];

		Stat() {
			count[0]=0; count[1]=0; countA[0]=0; countA[1]=0; countC[0]=0; countC[1]=0; countG[0]=0; countG[1]=0; countT[0]=0; countT[1]=0;
			min[0]=0; min[1]=0; max[0]=0; max[1]=0;
			avg[0]=0; avg[1]=0; avg[2]=0; stdev[0]=0; stdev[1]=0; stdev[2]=0;
			for (size_t i=0; i<3; ++i) for (size_t j=0; j<5; ++j) quantiles[i][j]=0;
		}
	};
private:
	std::vector<Stat> stats_;
public:
	SeqBagStats();
	~SeqBagStats();

	void Reset();

	void fromScores(const AllScores& scores);

	void Load(const Str::Xml::Val& string);
	void Save(Str::Xml::Val& string) const;

	inline size_t  Size() const { return stats_.size(); }

	inline int GetCounts(size_t i) const { return stats_[i].count[0]+stats_[i].count[1]; }
	inline int GetCounts(size_t part, size_t i) const { return stats_[i].count[part]; }
	inline int GetCountsA(size_t i) const { return stats_[i].countA[0] + stats_[i].countA[1]; }
	inline int GetCountsA(size_t part, size_t i) const { return stats_[i].countA[part]; }
	inline int GetCountsC(size_t i) const { return stats_[i].countC[0] + stats_[i].countC[1]; }
	inline int GetCountsC(size_t part, size_t i) const { return stats_[i].countC[part]; }
	inline int GetCountsG(size_t i) const { return stats_[i].countG[0] + stats_[i].countG[1]; }
	inline int GetCountsG(size_t part, size_t i) const { return stats_[i].countG[part]; }
	inline int GetCountsT(size_t i) const { return stats_[i].countT[0] + stats_[i].countT[1]; }
	inline int GetCountsT(size_t part, size_t i) const { return stats_[i].countT[part]; }	

	inline double GetAvg(size_t i) const { if (stats_.size()<=i) return 0; else return stats_[i].avg[0]; }
	inline double GetAvg(size_t part, size_t i) const { if (stats_.size()<=i) return 0; else return stats_[i].avg[part+1]; }
	inline double GetStDev(size_t i) const { if (stats_.size()<=i) return 0; else return stats_[i].stdev[0]; }
	inline double GetStDev(size_t part, size_t i) const { if (stats_.size()<=i) return 0; else return stats_[i].stdev[part+1]; }
	inline int GetMin(size_t i) const { if (stats_.size()<=i) return 0; else return stats_[i].min[0]<stats_[i].min[1]?stats_[i].min[0]:stats_[i].min[1]; }
	inline int GetMin(size_t part, size_t i) const { if (stats_.size()<=i) return 0; else return stats_[i].min[part]; }
	inline int GetMax(size_t i) const { if (stats_.size()<=i) return 0; else return stats_[i].max[0]<stats_[i].max[1]?stats_[i].max[1]:stats_[i].max[0]; }
	inline int GetMax(size_t part, size_t i) const  { if (stats_.size()<=i) return 0; else return stats_[i].max[part]; }
	inline double GetQuant(size_t quant, size_t i) const { if (stats_.size()<=i) return 0; else return stats_[i].quantiles[0][quant]; }
	inline double GetQuant(size_t quant, size_t part, size_t i) const { if (stats_.size()<=i) return 0; else return stats_[i].quantiles[part+1][quant]; }
};
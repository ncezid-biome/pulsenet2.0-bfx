#ifndef __SAM_HEADER_H__
#define __SAM_HEADER_H__

#include "am_h.h"

#ifdef __cplusplus
extern "C" {
#endif

	SLW32_DLLPORT void *sam_header_parse2(const char *headerText);
	SLW32_DLLPORT void *sam_header_merge(int n, const void **dicts);
	SLW32_DLLPORT void sam_header_free(void *header);
	SLW32_DLLPORT char *sam_header_write(const void *headerDict);   // returns a newly allocated string

    /*
        // Usage example 
        const char *key, *val; 
        void *iter = sam_header_parse2(bam->header->text);
        while ( iter = sam_header_key_val(iter, "RG","ID","SM" &key,&val) ) printf("%s\t%s\n", key,val);
    */
    SLW32_DLLPORT void *sam_header2key_val(void *iter, const char type[2], const char key_tag[2], const char value_tag[2], const char **key, const char **value);
	SLW32_DLLPORT char **sam_header2list(const void *_dict, char type[2], char key_tag[2], int *_n);

    /*
        // Usage example
        int i, j, n;
        const char *tags[] = {"SN","LN","UR","M5",NULL}; 
        void *dict = sam_header_parse2(bam->header->text);
        char **tbl = sam_header2tbl_n(h->dict, "SQ", tags, &n);
        for (i=0; i<n; i++)
        {
            for (j=0; j<4; j++) 
                if ( tbl[4*i+j] ) printf("\t%s", tbl[4*i+j]); 
                else printf("-");
            printf("\n");
        }
        if (tbl) free(tbl);
     */
    SLW32_DLLPORT char **sam_header2tbl_n(const void *dict, const char type[2], const char *tags[], int *n);

	SLW32_DLLPORT void *sam_header2tbl(const void *dict, char type[2], char key_tag[2], char value_tag[2]);
	SLW32_DLLPORT const char *sam_tbl_get(void *h, const char *key);
	SLW32_DLLPORT int sam_tbl_size(void *h);
	SLW32_DLLPORT void sam_tbl_destroy(void *h);

#ifdef __cplusplus
}
#endif

#endif

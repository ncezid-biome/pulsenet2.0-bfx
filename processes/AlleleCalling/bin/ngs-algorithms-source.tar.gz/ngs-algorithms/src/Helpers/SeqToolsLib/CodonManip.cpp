#include "stdafx.h"

#include "CodonManip.h"

#include "CodonRangeManip.h"

namespace seq
{


bool StartsWithStartCodon(const Sequence& sequence, const Codons& startCodons)
{
    return StartsWithStartCodon( sequence.begin(), sequence.end(), startCodons );
}

bool EndsWithStopCodon(const Sequence& sequence, const Codons& stopCodons)
{
    return EndsWithStopCodon( sequence.begin(), sequence.end(), stopCodons );
}

bool StartsAndEndsWithCodons(const Sequence& sequence, const Codons& startCodons, const Codons& stopCodons)
{
    return    StartsWithStartCodon(sequence, startCodons)
           && EndsWithStopCodon(sequence, stopCodons);
}

/**
    Low-level method, if you think you need it you probably need to write a nice wrapper for
    it, test that wrapper and give it a sensible name so people know what you're trying to do.
*/
bool ContainsCodonAt(const Sequence& sequence, size_t position, const Codons& codons)
{
    return ContainsCodonAt( sequence.begin() + position, codons );
}

bool ContainsCodonInForwardFrame(const Sequence& sequence, const Codons& codons, FrameRange range)
{
    return ContainsCodonInForwardFrame(sequence.begin(), sequence.end(), codons, range);
}

bool ContainsCodonInReverseFrame(const Sequence& sequence, const Codons& codons, FrameRange range)
{
    return ContainsCodonInReverseFrame(sequence.begin(), sequence.end(), codons, range);
}

/**
    In-frame search of an internal stop codon i.e. excluding the last amino-acid.

    If the frame is reversed, it is the last amino-acid on the reversed sequence that is excluded
    i.e. the first amino-acid on the forward sequence.
*/
bool ContainsInternalStopCodon(const Sequence& sequence, const Codons& stopcodons, FrameDirection frame)
{
    return ContainsInternalStopCodon(sequence.begin(), sequence.end(), stopcodons, frame);
}

} // namespace seq

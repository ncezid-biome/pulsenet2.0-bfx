#include "stdafx.h"

#include "BAMPileFileReader.h"
#include <boost/interprocess/file_mapping.hpp>
#include <exception.h>
#include <translate.h>
#include <cstdint>

namespace BAM
{

void PileFileReader::Open(const Str::Path::Val& file)
{

    using namespace boost::interprocess;

    file_mapping fileMapping(ToRef(file), read_only);
    mapped_region mappedRegion(fileMapping, read_only);

    Header* header=static_cast<Header*>(mappedRegion.get_address());

    referenceCount_=header->referenceCount;

    //basic sanity check
    const size_t expectedSize=sizeof(Header)+ referenceCount_*sizeof(ReferenceCoverageInfo);

    if(strncmp(PM("BPF0"), header->signature, 4) || expectedSize > mappedRegion.get_size()) {

        throw KError("Invalid BPF file: wrong signature or size");
    }

    mappedRegion_.swap(mappedRegion);

    const char* data=static_cast<const char*>(mappedRegion_.get_address());
    references_=reinterpret_cast<const ReferenceCoverageInfo*>(data + sizeof(Header));
    positions_=reinterpret_cast<const PositionInfo*>(data + sizeof(Header) + referenceCount_*sizeof(ReferenceCoverageInfo));
}

void PileFileReader::Close()
{
    referenceCount_=0;
    references_=nullptr;
    positions_=nullptr;

    //close memory map by stealing it from mappedRegion_ and going out of scope
    boost::interprocess::mapped_region dummyMap(std::move(mappedRegion_));
}

PileFileTypes::FullPileHeight PileFileReader::GetFwdCoverageAt(ReferenceID refID, DrawPosition pos) const
{
    if(IsInRange(refID, pos)) {

        return UnscaleIfScaled<MAXHEIGHT>(positions_[references_[refID].offset+pos].fwdCoverage, references_[refID].maxFwdCoverage);
    }
    return 0;
}

PileFileTypes::FullPileHeight PileFileReader::GetRevCoverageAt(ReferenceID refID, DrawPosition pos) const
{
    if(IsInRange(refID, pos)) {

        return UnscaleIfScaled<MAXHEIGHT>(positions_[references_[refID].offset+pos].revCoverage, references_[refID].maxRevCoverage);
    }
    return 0;
}


PileFileTypes::FullMateDistance PileFileReader::GetMateDistanceAt(ReferenceID refID, DrawPosition pos) const
{
    if(IsInRange(refID, pos)) {

        return UnscaleIfScaled<MAXDISTANCE>(positions_[references_[refID].offset+pos].mateDistance, references_[refID].mateDistanceInfo.rangeMax);
    }
    return 0;
}


/**
 * Converts a DrawPosition (drawing coordinates) into ReferencePosition (offset wrt to reference sequence). If the
 * given DrawPosition is out of range, then UINT32_MAX is returned. If clip is true otoh, then the largest valid
 * ReferencePosition is returned.
 */
BAMTypes::ReferencePosition PileFileReader::DrawPositionToReferencePosition(ReferenceID refID, DrawPosition drawPos, bool clip) const
{
    if(IsInRange(refID, 0)) {

        //we should only look within the PositionInfo data of this reference
        const PositionInfo* positions=&positions_[references_[refID].offset];

        if(drawPos<references_[refID].length)
            return positions[drawPos].refPosition;

        return clip? positions[references_[refID].length-1].refPosition: UINT32_MAX;
    }

    return 0;
}

/**
 * Converts a ReferencePosition (offset wrt to reference sequence) into a DrawPosition (drawing coordinates).
 * This method uses an iteration over the pile file, so use it wisely!
 */
PileFileTypes::DrawPosition PileFileReader::ReferencePositionToDrawPosition(ReferenceID refID, ReferencePosition refPos, bool extendBeyondReference) const
{

    //This method uses the fact that a reference position is always smaller than or equal to its corresponding
    //drawing position (drawing=reference+inserts). By using the reference as an (under)estimate for the drawing
    //position, we get a first approximation. The difference between the refPos we are looking for and the refpos
    //we arrived at, gives an (under)estimate of how much we are off.

    ASSERT(refPos<2000000000UL);

    if(IsInRange(refID, 0)) {

        DrawPosition d=refPos;

        const DrawPosition refLength=references_[refID].length;
        //we should only search within the PositionInfo data of this reference
        const PositionInfo* positions=&positions_[references_[refID].offset];

        ASSERT(positions[0].refPosition==0);

        while( d<refLength && refPos>positions[d].refPosition) {

            d+=(refPos-positions[d].refPosition);
        }

        if(d<refLength && positions[d].refPosition==refPos) {

            //we have found the PositionInfo that corresponds to the given refPos
            //return its index
            return d;
        }
        else if(d>=refLength) {

            //it appears that we have run out of reference...

            if(extendBeyondReference) {

                //let's pretend that after the interval, DrawPositions and ReferencePosition increase at the same rate

                //return the DrawPosition for the last valid ReferencePosition
                //and add the distance by which we are overshooting the reference
                return refLength-1+refPos-positions[refLength-1].refPosition;
            }
            else {
                //simply return the largest draw position
                return refLength-1;
            }
        }
    }
    return UINT32_MAX;
}

/**
 * Returns the length, in terms of DrawPositions, of the segment identified by \p refID.
 */
PileFileTypes::DrawPosition PileFileReader::GetLength(ReferenceID refID) const
{
    if(refID<referenceCount_)
        return references_[refID].length;

    return 0;
}

PileFileTypes::FullPileHeight PileFileReader::GetMaxHeight(ReferenceID refID) const
{
    if(refID<referenceCount_)
        return references_[refID].maxFwdCoverage+references_[refID].maxRevCoverage;

    return 0;
}

PileFileTypes::FullPileHeight PileFileReader::GetMaxFwdCoverage(ReferenceID refID) const
{
    if(refID<referenceCount_)
        return references_[refID].maxFwdCoverage;

    return 0;
}

PileFileTypes::FullPileHeight PileFileReader::GetMaxRevCoverage(ReferenceID refID) const
{
    if(refID<referenceCount_)
        return references_[refID].maxRevCoverage;

    return 0;
}

PileFileTypes::MateDistanceInfo PileFileReader::GetMateDistanceInfo(ReferenceID refID) const
{
    if(refID<referenceCount_)
        return references_[refID].mateDistanceInfo;

    return MateDistanceInfo();
}

}
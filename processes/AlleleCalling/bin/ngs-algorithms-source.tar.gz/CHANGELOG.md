# CHANGELOG



## v1.3.0 (2026-05-28)

### Feature

* feat: add license

Merged in DGB-1421-cdc-add-license-to-ngs-pipeline (pull request #26)

* feat: add license

* fix: update poetry v2


Approved-by: Joao Andre CARRIÇO ([`015b82d`](https://github.com/rdsi/ngs-pipeline-cdc/commit/015b82d81f8fba96b8a112dbfbca7debafe22f63))


## v1.2.0 (2024-11-06)

### Chore

* chore(release): 1.2.0 ([`9c3f159`](https://github.com/rdsi/ngs-pipeline-cdc/commit/9c3f1593173f9aac9a66d3edc2e84648ce3e7a4f))

### Feature

* feat: update ngs-pipeline-process-correct-assembly and cleaning-KB to allow setting a max_gc_content threshold

* feat: update cleaning KB to v1.1.0 (adding max_gc_content)

* feat: update CorrectAssembly and ReferenceMapConsensus to use max_gc_content


Approved-by: Dolf MICHIELSEN ([`5ac868d`](https://github.com/rdsi/ngs-pipeline-cdc/commit/5ac868dcd9ec2810a98d3a9cab03344de4324598))

### Unknown

* Merged in DGB-702-ngs-pipeline-update-cdc-pipeline-with-latest-v-3-updates (pull request #24)

DGB-702 ngs pipeline update cdc pipeline with latest v 3 updates

* fix: fixes the name of the knowledge base

* feat: updates process and knowledge base versions

* feat: adds the referenceMapConsensus process to the pipeline

* feat: adds referenceMapConsensus to the assembly subworkflow

* fix: when handling multiple KBs, allows to have one of them use the given genus and another use DEFAULT when lacking the specified genus

* fix: KB order for ReferenceMapConsensus was wrong

* test: adds a new scenario for testing the ReferenceMapConsensus, with a MTBC sample

* fix: ensures empty list of KBs is returned in case any of the KBs are missing

* feat: increases the CPUs/threads for ReferenceMapConsensus

* fix: follows pipeline standards and removes unnecessary extra results

* feat: uses getKnowledgeBase from SAAS rather


Approved-by: Michael SAUVAGNAT ([`5d9a589`](https://github.com/rdsi/ngs-pipeline-cdc/commit/5d9a5895203b5767e464d1a292352792468c176d))

* Merged in DGB-855-make-fail-thresholds-less-strict (pull request #23)

feat: makes the FAIL thresholds for Mycobacterium tuberculosis less strict, so that the CDC can analyze them case by case

* feat: makes the FAIL thresholds for Mycobacterium tuberculosis less strict, so that the CDC can analyze them case by case

* feat: update DB version from 1.0.6 to 1.0.7


Approved-by: Dolf MICHIELSEN ([`6d4d012`](https://github.com/rdsi/ngs-pipeline-cdc/commit/6d4d012b0807598df6ceaa69c9332db43241c512))

* Merged in DGB-853-add-wg-snp-and-kraken-k-bs (pull request #22)

DGB-853 add wg snp and kraken k bs

* feat: adds JSON files for the kraken kb

* doc: adds path to the kraken2_db in S3 to our README.md

* feat: adds wgSNP kb


Approved-by: Dolf MICHIELSEN
Approved-by: Vincent ROHOU ([`5a7bb20`](https://github.com/rdsi/ngs-pipeline-cdc/commit/5a7bb206b084585095f9730c1cc60e84c0958aaf))


## v1.1.0 (2024-09-12)

### Chore

* chore(release): 1.1.0 ([`90d92f9`](https://github.com/rdsi/ngs-pipeline-cdc/commit/90d92f99330d9b9363c54765ad44dbe00916ec55))

* chore: use conda-forge

Merged in ADX-6969-ngs-process-replace-anaconda-by-conda-forge (pull request #21)

fix: replace defaults by conda-forge

* fix: replace defaults by conda-forge

* style: isort/black/flake8

Approved-by: Dolf MICHIELSEN
Approved-by: Michael SAUVAGNAT ([`7e2fa54`](https://github.com/rdsi/ngs-pipeline-cdc/commit/7e2fa5491f988f3c6e5bb14240b9cfba55fdec88))

* chore: add source of BN CE C++ algorithms used in processes

Merged in DGB-833-add-c-algorithms-to-ngs-pipeline (pull request #18)

👽️chore(algorithms): add BN CE C++ algorithms used in processes.

*  👽️chore(algorithms): add BN CE C++ algorithms used in processes.


Approved-by: Vincent ROHOU ([`fbd43f8`](https://github.com/rdsi/ngs-pipeline-cdc/commit/fbd43f81745bf6ffb6ab92ccc9b7dc0d7951a513))

### Feature

* feat: Add more KBs for Mycobacterium

Merged in DGB-847-add-supporting-files-for-mtbc-allele-calling-filtering-databases (pull request #20)

DGB-847 Add supporting files for mtbc allele calling filtering databases

* feat: adds info.json and enable_loci.tsv for MYCOBACTERIUM

* feat: adds reference-mapping kb

* docs: adds links to our S3 databases (reference genome and blast_db)

* feat: MINIMUM_COVERAGE=5 instead of 3

Approved-by: Dolf MICHIELSEN ([`894e0ab`](https://github.com/rdsi/ngs-pipeline-cdc/commit/894e0abc2ed54609b11dd32cbfcf71c7dc6f74a3))

* feat: Add KBs for Mycobacterium

Merged in DGB-834-add-knowledge-bases-to-ngs-pipeline-cdc (pull request #19)

DGB-834 add knowledge bases to ngs pipeline cdc

* feat: adds Mycobacterium tuberculosis genome size (and sorts the JSON)

* feat: adds minimum/maximum GC content for Mycobacterium tuberculosis

* feat: adds qc_references for Mycobacterium tuberculosis

* feat: adds MLST schemes for Mycobacterium

Approved-by: Miguel Paulo MACHADO ([`a64973d`](https://github.com/rdsi/ngs-pipeline-cdc/commit/a64973d38ebf3dda02d31c6d5a0712a0f4030908))


## v1.0.0 (2024-05-27)

### Breaking

* feat: generate outputs.json

BREAKING CHANGE: result.json, report.json &amp; qc.json are not generated anymore

These files are now aggregated into one outputs.json file.

* all of them

* Merged in ADX-4290-create-a-unique-json-containing (pull request #1)

copy changes from saas&#39; repo

Approved-by: Vincent ROHOU

Approved-by: Vincent ROHOU ([`8268cb3`](https://github.com/rdsi/ngs-pipeline-cdc/commit/8268cb3c370f151f8fb5074258b51c62f494f409))

### Chore

* chore(release): 1.0.0 ([`77b1008`](https://github.com/rdsi/ngs-pipeline-cdc/commit/77b1008f64e805abb613d675fc3151cc47c28da7))

* chore: bitbucket pipeline no push to ECR or val/prod envs ([`2a42be0`](https://github.com/rdsi/ngs-pipeline-cdc/commit/2a42be00ec3c03d0f0908614b7cc46187ec01c3c))

### Feature

* feat: NGS pipeline for CDC, including re-run capability

Merged in feature/DGB-768-cdc-ngs-pipeline-update-for-mtb (pull request #17)

Merged in DGB-769-add-classify-reads-process-krake (pull request #16)

* Merged in DGB-769-add-classify-reads-process-krake (pull request #16)

feat: re-run pipeline with process bypass

* feat: re-run pipeline with process bypass

* docs: add knowledge_bases_folder argument

* feat: add MYCOBACTERIUM kbs to allele-calling/-filtering

* chore: remove Pseudomonas references

Approved-by: Guilherme COPPINI

* chore: set initial version to 0.0.0


Approved-by: Vincent ROHOU ([`2d3e894`](https://github.com/rdsi/ngs-pipeline-cdc/commit/2d3e894fda3e552915f020497529a9b3cab0f65f))

* feat: support for similarities in a config file

Approved-by: Vincent ROHOU ([`94fd47f`](https://github.com/rdsi/ngs-pipeline-cdc/commit/94fd47fc10bce7d1bc9fb7376830cb4d2d21f6b5))

* feat: ADX-4340-ngs-pipeline-results-and-logs-o (pull request #9) ([`274ba34`](https://github.com/rdsi/ngs-pipeline-cdc/commit/274ba34ea12878edf05365a6398ced4c210846f2))

* feat: ADX-4307-ngs-pipeline-run-wgmlst-process (pull request #8)

Merged in ADX-4354-generate-nextflow-report-and-pu (pull request #7)

* Merged in ADX-4354-generate-nextflow-report-and-pu (pull request #7)

Report from saas

* Report from saas


Approved-by: Michael SAUVAGNAT ([`adcf00f`](https://github.com/rdsi/ngs-pipeline-cdc/commit/adcf00f5ff9768432d67b96adfb9d1bf3daa052b))

* feat: add the allele-naming process to the pipeline ([`f5ccdec`](https://github.com/rdsi/ngs-pipeline-cdc/commit/f5ccdeced8d16661cee6ac2e3f45e3b3b3e1c875))

### Fix

* fix: update nextflow.contig processes to latest patch versions ([`e63b6dc`](https://github.com/rdsi/ngs-pipeline-cdc/commit/e63b6dcef3a880d8d64d80f474abf1474b14c922))

* fix: use run_directory in serotyping publishDir ([`20dc4ba`](https://github.com/rdsi/ngs-pipeline-cdc/commit/20dc4ba7bc1a9395350a4409e121950b46db7b82))

### Unknown

* Merged in feature/ADX-5382-cdc-pipeline-adjust-to-latest-v (pull request #14)

* Merged in ADX-5384-update-ngs-pipeline-cdc (pull request #13)

🚚copying what&#39;s on saas

* 🐛 fix the failed fix t_t

* 🎨 remove some leftover snake_case

* ✏️ fix the s3 paths

* ⬆️ upgrade processes

* 🍱 add kb for filtering

* 📝 rework the README

* ⬆️ update version for prepare reads and allele calling

* ✏️ fixing typos

* 📝 update README regarding Azure

* 📝 fix section about KB

Approved-by: Dolf MICHIELSEN ([`f85ae49`](https://github.com/rdsi/ngs-pipeline-cdc/commit/f85ae497c404b0560a83b715d32870f1e3e832c9))

* Merged in bugfix/ADX-4827-ngs-pipeline-update-cdc-pipelin (pull request #12)

* ✨ bring the features from saas

* 🐛 fix allele naming to handle outputs.json as an input

* 🔧 set process tags

Approved-by: Vincent ROHOU
Approved-by: Johan GORIS ([`959dcd3`](https://github.com/rdsi/ngs-pipeline-cdc/commit/959dcd3c5e08249b195823305eafdc75fb8d4fb5))

* Merged in bugfix/ADX-4606-cdc-pipeline-inconsistent-profi (pull request #11)

bugfix/ADX-4606-cdc-pipeline-inconsistent-profi

* :bug: fix(allele-naming) consistent profile outputs with allele-calling


Approved-by: Michael SAUVAGNAT ([`5753751`](https://github.com/rdsi/ngs-pipeline-cdc/commit/575375103cd333373be85bf6d801400e7e9c23b4))

* doc: ADX-4401 Subworkflows details ([`85a7548`](https://github.com/rdsi/ngs-pipeline-cdc/commit/85a7548a1e4cb831857fb25a4c9903ee3da778b8))

* init ([`b64c12f`](https://github.com/rdsi/ngs-pipeline-cdc/commit/b64c12f82b1bdbff3ad6b03cf6d6eac18d02e8c8))

* internal: add CI pipeline ([`84877bc`](https://github.com/rdsi/ngs-pipeline-cdc/commit/84877bcbf4f7ed05e83b0ff1a4543f9877d6b226))

#include "stdafx.h"

#ifdef AMGNU

#include "UnixProcessPool.h"



namespace runextern
{


runextern::UnixProcessPool::UnixProcessPool()
{

}

UnixProcess* runextern::UnixProcessPool::CreateProcess()
{
    return new UnixProcess();
}


} // namespace runextern


#endif // #ifdef AMGNU

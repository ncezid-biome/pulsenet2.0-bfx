#pragma once
#include <PathDef.h>
#include "SAMWrapper.h"

namespace BAM
{

class STW_DLLPORT FileSorter
{
public:

    //defaults: 200Mib mem per thread (and per chunk), 1 thread, compression level 2 [0-9]
    FileSorter(): maxMem_(200<<20), threads_(1), compression_(2)
    {
    }

    bool IsSorted(const Str::Path::Val& input);

    void SortFile(const Str::Path::Val& input, const Str::Path::Val& output);

    void SetMaxMem(uint64_t val)
    {
        //inside samtools, the memory limit is also a size_t
        maxMem_=val>SIZE_MAX? SIZE_MAX: val;
    }

    void SetMaxThreads(size_t val)
    {
        threads_ = val>1? val: 1;
    }

    void SetCompressionLevel(size_t val)
    {
        compression_ = val;
    }

private:
    size_t maxMem_;
    size_t threads_;
    size_t compression_;
};

}
/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#include "stdafx.h"
#include "logging_calccommunication.h"

LoggerFromCalcCommunication::LoggerFromCalcCommunication()
    : mustContinue_( true )
{
}
LoggerFromCalcCommunication::~LoggerFromCalcCommunication()
{
}
void LoggerFromCalcCommunication::TransferInfo(Str::Text::Arg message) 
{
	size_t pos = message.str().find("Name=\"CalcIncrMaxProgress\" Max=\"");
	if (pos!=std::string::npos) {
		nTicks_ = atoi(message.str().substr(pos+strlen("Name=\"CalcIncrMaxProgress\" Max=\"")).c_str());
		currTick_=0;
		return;
	}
	pos = message.str().find("Name=\"CalcIncrProgress\"");
	if (pos!=std::string::npos) {
		++currTick_;
		Logging::AddProgress(currTick_, nTicks_);
		return;
	}
	Logging::AddLog(message);
}
const volatile bool& LoggerFromCalcCommunication::MustContinue() const 
{ 
	return mustContinue_; 
}	
bool LoggerFromCalcCommunication::CanUseInThread() const 
{
	return true;
}
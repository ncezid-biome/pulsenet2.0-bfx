#pragma once

#include "boost/shared_ptr.hpp"

#include "StringDef.h"

#include "CE_OptionalExtraArguments.h"

namespace engine
{

class  Logger;

namespace tools
{


class CommandLine
{
public:
    CommandLine();
    void Init( int      argc,
               char*    argv[],
               Logger&  logger );

    int            GetArgCount         () const;
    Str::Text::Val GetArg              ( int index ) const;
    Str::Text::Vec GetArgVector        () const;
    char**         GetOldstyleArgVector() const;

    Str::Text::Val GetResultsDir       () const;
    Str::Text::Val GetSharedDir        () const;
    Str::Text::Val GetSharedTempDir    () const;
    
    bool           HasLocalDir         () const;
    Str::Text::Val GetLocalDir         () const;

          OptionalExtraArguments& GetExtraArguments();
    const OptionalExtraArguments& GetExtraArguments() const;

private:
    void ParseArguments( Logger& logger );
    void ParseOptionalExtraArgs(int argc, char* argv[]);

    CommandLine( const CommandLine& rhs );
    CommandLine& operator=( const CommandLine& rhs );

private:
    Str::Text::Vec argv_;
    boost::shared_ptr<char*[]> oldstyleArgv_;
    Str::Text::Val resultsdir_;
    Str::Text::Val shareddir_;
    Str::Text::Val sharedtempdir_;
    OptionalExtraArguments extraArguments_;
};


} // namespace tools

} // namespace engine

#pragma once
#include "SAMWrapper.h"
#include "BAMTypes.h"
#include <PathDef.h>
#include <sam.h>
#include <bam2bcf.h>
#include "BAMFileResolver.h"

namespace BAM
{

class STW_DLLPORT Pileup: protected BAMTypes
{

public:
    Pileup(bool padCallback);
    virtual ~Pileup();

    void OpenFile(FileResolver::Ptr files);
    void CloseFile();

    void CreatePileup(bool countMultipleAlignments=false);
    void CreatePileup(ReferenceID refId, ReferencePosition regionBegin, ReferencePosition regionEnd, bool countMultipleAlignments=false);

    void CreateLeveledPileup();
    void CreateLeveledPileup(ReferenceID refId, ReferencePosition regionBegin, ReferencePosition regionEnd);

    // Get the base corresponding to the pileup element. In case of insertions, an offset can be given.
    inline char GetPileElementBase(const bam_pileup1_t& p, int o)
    {

        return bam_nt16_rev_table[bam1_seqi(bam1_seq(p.b), p.qpos + o)];
    }

    Str::ID::Vec GetReferenceNames() const;
    std::vector<BAMTypes::ReferenceInfo> GetReferencesInfo() const;

protected:
    virtual int FetchCallback(bam1_t& b);
    virtual int LeveledFetchCallback(bam1_t& b);

    const bam_header_t* GetFileHeader() const {

        return samFile_->header;
    }

private:
    //SAMTools callbacks
    static int fetch_func(bam1_t* b, void* data);
    static int lfetch_func(bam1_t* b, void* data);

    static int pileup_func(ReferenceID tid, ReferencePosition pos, int n, const bam_pileup1_t* pl, void* data);

    virtual int PileupCallback(ReferenceID tid, ReferencePosition pos, int n, const bam_pileup1_t pl[]) = 0;

    virtual void PileupFinished() {};
    virtual void ReferenceChanged(ReferenceID refID) {};

    void PerformPadCallback(ReferenceID tid, ReferencePosition pos);

    inline void PerformReferenceChanged(ReferenceID tid);

    Pileup(const Pileup&);
    Pileup& operator=(const Pileup&);

private:
    samfile_t* samFile_;
    bam_index_t* bamIndex_;

    //pileup buffers, both without and with level
    bam_plbuf_t* buf_;
    bam_lplbuf_t* lbuf_;

    //pileup_func was last called for this position
    ReferencePosition lastPos_;
    //whether or not pileup_func should be called for empty piles
    bool padCallback_;

    //the reference we are currently pileup'ing for
    ReferenceID currentTid_;
    std::vector<BAMTypes::ReferenceInfo> refInfos_;
};

}
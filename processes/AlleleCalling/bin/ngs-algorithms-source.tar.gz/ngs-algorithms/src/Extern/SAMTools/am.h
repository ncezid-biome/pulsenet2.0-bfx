#pragma once

#include <getopt.h>

#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <stdint.h>
#include "am_h.h"

////////// redirect fprintf(stderror,...) to a callback, cf. fprintf_capture and set_message_callback in am.cpp
#define fprintf fprintf_capture

//use these macro's to do arithmetic with void pointers
#define INCRVOIDPTR(p, n)   *((char**)&p)+=n
#define ADD2VOIDPTR(p, n)   ((void*)(((char*)p)+n))

#ifndef AMGNU

#include <io.h>

// This file contains all the things that are required to make sense of the entire SAMTools source code.
// This file should not bleed through to other projects by including a SAMTools header.

#define _USE_MATH_DEFINES // for C
#include <math.h>
#include <float.h>

#define __func__ __FUNCTION__

////////// some windows-specific aliases

#define atoll _atoi64

#include <wchar.h>

#define setmode _setmode
#define O_BINARY    _O_BINARY
#define O_CREAT     _O_CREAT
#define O_TRUNC     _O_TRUNC
#define O_WRONLY    _O_WRONLY
#define O_RDONLY    _O_RDONLY

#define access  _access
#define R_OK     04

#define alloca _alloca
#define vfprintf vfprintf_s

int __sync_fetch_and_add(volatile int *mem, int val);

//call this function to ensure that pthreads are available
void ensure_pthreads();

//samtools contains an implementation of lgamma, names kf_lgamma
//TODO: verify that it indeed calculates lgamma
BCFW32_DLLPORT double kf_lgamma(double z);
#define lgamma kf_lgamma

#define srand48(x) srand(x)

#define _CRT_TERMINATE_DEFINED

#endif //ifndef AMGNU

//functions that are exported publicly 
#include "STL_exports.h"

#ifdef __cplusplus
extern "C" {
#endif

//am.cpp
SLW32_DLLPORT void fprintf_capture(FILE *stream, const char *format, ...);

#ifndef AMGNU
//bam_aux.c
SLW32_DLLPORT double drand48();
#endif

//bam_cat.c
SLW32_DLLPORT int main_cat(int argc, char *argv[]);

//bam_index.c
SLW32_DLLPORT int bam_index(int argc, char *argv[]);
SLW32_DLLPORT int bam_idxstats(int argc, char *argv[]);

//bam_md.c
SLW32_DLLPORT int bam_fillmd(int argc, char *argv[]);

//bam_reheader.c
SLW32_DLLPORT int main_reheader(int argc, char *argv[]);

//bam_sort.c
SLW32_DLLPORT int bam_sort(int argc, char *argv[]);
SLW32_DLLPORT int bam_merge(int argc, char *argv[]);

//bedidx.c
SLW32_DLLPORT int bed_overlap(const void *_h, const char *chr, int beg, int end);
SLW32_DLLPORT void *bed_read(const char *fn);
SLW32_DLLPORT void bed_destroy(void *_h);

//faidx.c
SLW32_DLLPORT int faidx_main(int argc, char *argv[]);

#define _CURSES_LIB 1

#ifdef AMGNU
#define am_vsnprintf    vsnprintf
#else
SLW32_DLLPORT int am_vsnprintf(char *dst, size_t size, const char *fmt, ...);
#endif

#ifdef __cplusplus
} //extern "C"
#endif
#include "stdafx.h"

#include "WindowsProcess.h"

#include "Psapi.h"

#include "mathHelp.h"
#include "debugstr.h"
#include "extensionbrowser.h"
#include "GetLastErrorText.h"


namespace runextern
{


ParentListener::ParentListener()
    : readHandle_ ( INVALID_HANDLE_VALUE )
    , writeHandle_( INVALID_HANDLE_VALUE )
{
}

ParentListener::ParentListener(HANDLE readHandle, HANDLE writeHandle)
    : readHandle_  ( readHandle  )
    , writeHandle_ ( writeHandle )
{
}

bool ParentListener::checkForMessage(MessageBuffer& buffer, int &bytesRead)
{
    DWORD myBytesRead=0;
    BOOL ok=::ReadFile(readHandle_, buffer.getBuffer(), (DWORD) buffer.getBufferSize(), &myBytesRead, NULL);
    if (ok) 
        bytesRead=myBytesRead;
    return 
        ok==TRUE;
}
void ParentListener::sendMessage(Str::Text::Arg m)
{	
    DWORD dw;
    std::string mess=m; mess+="\n";
    ::WriteFile(writeHandle_, mess.c_str(), (DWORD) mess.size(), &dw, NULL);
}

WindowsProcess::WindowsProcess()
    : hreadParentFromChild_(INVALID_HANDLE_VALUE), hwriteParentToChild_(INVALID_HANDLE_VALUE),
      handle_process_(INVALID_HANDLE_VALUE), handle_thread_(INVALID_HANDLE_VALUE)
{
}
WindowsProcess::WindowsProcess(const ProcessCmdLine& cmd)
    : cmdline_(cmd),
      hreadParentFromChild_(INVALID_HANDLE_VALUE), hwriteParentToChild_(INVALID_HANDLE_VALUE),
      handle_process_(INVALID_HANDLE_VALUE), handle_thread_(INVALID_HANDLE_VALUE)
{
}
WindowsProcess::WindowsProcess(const ProcessCmdLine& cmd, const ProcessInfo& info)
    : cmdline_(cmd), info_(info),
      hreadParentFromChild_(INVALID_HANDLE_VALUE), hwriteParentToChild_(INVALID_HANDLE_VALUE),
      handle_process_(INVALID_HANDLE_VALUE), handle_thread_(INVALID_HANDLE_VALUE)
{
}
WindowsProcess::~WindowsProcess()
{
	CloseHandle(handle_process_);
    CloseHandle(handle_thread_);
	CloseHandle(hreadParentFromChild_);
	CloseHandle(hwriteParentToChild_);
}
void WindowsProcess::setCmdLine(const ProcessCmdLine& cmd)
{
	cmdline_=cmd;
}
void WindowsProcess::setInfo(const ProcessInfo& info)
{
	info_=info;
}     
const ProcessStatus& WindowsProcess::getStatus()
{
	return status_;
}
HANDLE WindowsProcess::getReadHandle() 
{ 
	return hreadParentFromChild_; 
}
HANDLE WindowsProcess::getWriteHandle() 
{ 
	return hwriteParentToChild_;
}
HANDLE WindowsProcess::getProcessHandle()
{
	return handle_process_;
}
DWORD WindowsProcess::getMainThreadId()
{
	return id_main_thread_;
}
bool WindowsProcess::run()
{	
	BOOL ok;

	//--- CREATE A PIPE FROM THE CHILD TO THE PARENT ----------------------------------------------
	hreadParentFromChild_ = NULL; 
	HANDLE hwriteChildToParent = NULL;  // stdout
	HANDLE hwriteChildToParent2 = NULL; // stderr
    HANDLE hwriteChildToFile = NULL;    // stdout and optionally stderr
	
	//--- create the security attributes object ---------------------------------------------------
	SECURITY_ATTRIBUTES sa = {sizeof(SECURITY_ATTRIBUTES), NULL, TRUE }; // inheritable handle

	//--- create the pipe -------------------------------------------------------------------------
	ok = ::CreatePipe(&hreadParentFromChild_, &hwriteChildToParent, &sa, 0);
	if (!ok)	{ /* pipe failed */		
		status_.setFailedToCreatePipes(GetLastError(), getLastErrorText());
		return false;
	}

	// optional stderr redirection
	if (cmdline_.GetOutputFile().empty() || // no file provided for output
		(!cmdline_.GetOutputFile().empty() && !cmdline_.GetRedirectStderr())  // a file provided for output but no request for stderr redirection
		)
	{
		//--- duplicate the write handle --------------------------------------------------------------
		ok = ::DuplicateHandle(GetCurrentProcess(),		// duplicate from this WindowsProcess
			hwriteChildToParent,	    // this handle 
			GetCurrentProcess(),		// into this WindowsProcess
			&hwriteChildToParent2,      // as this handle
			0,							// no access flags (subsumed by DUPLICATE_SAME_ACCESS)
			TRUE,						// create inheritable
			DUPLICATE_SAME_ACCESS);		// create duplicate access
		if (!ok) { /* duplication failed */

			status_.setFailedToCreatePipes(GetLastError(), getLastErrorText());

			//cleanup the handles
			::CloseHandle(hreadParentFromChild_);
			::CloseHandle(hwriteChildToParent);

			return false;
		}
	}
	//--- DONE CREATING A PIPE FROM THE CHILD TO THE PARENT ---------------------------------------


	//--- CREATE A PIPE FROM THE PARENT TO THE CHILD ----------------------------------------------
	HANDLE hreadChildFromParent = NULL;
	hwriteParentToChild_ = NULL;     

	ok = ::CreatePipe(&hreadChildFromParent, &hwriteParentToChild_, &sa, 0);
	if(!ok) { /* pipe failed */
		status_.setFailedToCreatePipes(GetLastError(), getLastErrorText());
		return false;
	}
	//--- DONE CREATING A PIPE FROM THE CHILD TO THE PARENT ---------------------------------------

	//--- START UP THE WindowsProcess --------------------------------------------------------------------

	//--- create the startup information and initialize it -----------------------------------------
	STARTUPINFO startup; ::ZeroMemory(&startup, sizeof(STARTUPINFO));
	startup.cb = sizeof(startup);
	startup.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
	startup.wShowWindow = SW_HIDE; // hidden console window
	startup.hStdInput = hreadChildFromParent; // not used
	startup.hStdOutput = hwriteChildToParent;
	if (hwriteChildToParent2 != NULL)
	{
		startup.hStdError = hwriteChildToParent2;
	}

    if(!cmdline_.GetOutputFile().empty())
    {
        SECURITY_ATTRIBUTES sa;
        sa.nLength = sizeof(sa);
        sa.lpSecurityDescriptor = NULL;
        sa.bInheritHandle = TRUE;

        std::string fileName = cmdline_.GetOutputFile().string();

        hwriteChildToFile = CreateFile(fileName.c_str(),
                              GENERIC_WRITE,
                              FILE_SHARE_WRITE,
                              &sa,
                              OPEN_ALWAYS,
                              FILE_ATTRIBUTE_NORMAL,
                              NULL);

        startup.hStdOutput = hwriteChildToFile;
		if (cmdline_.GetRedirectStderr())
		{
			// stderr redirected to the same output file
			startup.hStdError = hwriteChildToFile;
		}
    }
	
	//--- create the WindowsProcess information and initialize it ----------------------------------------
	PROCESS_INFORMATION procinfo; ::ZeroMemory(&procinfo, sizeof(PROCESS_INFORMATION));
	
	// We want a non-inherited write handle. DuplicateHandle with a
	// NULL target fixes the read side to be non-inheritable
	::DuplicateHandle(	::GetCurrentProcess(),    // in this WindowsProcess
						hreadParentFromChild_,    // parent read handle
						::GetCurrentProcess(),    // to this WindowsProcess
						NULL,                     // modify existing handle
						0,                        // flags
						FALSE,                    // not inheritable
						DUPLICATE_SAME_ACCESS);   // same handle access

	// We want a non-inherited read handle. DuplicateHandle with a
	// NULL target fixes the read side to be non-inheritable
	::DuplicateHandle(	::GetCurrentProcess(),    // in this WindowsProcess
						hwriteParentToChild_,     // child read handle
						::GetCurrentProcess(),    // to this WindowsProcess
						NULL,                     // modify existing handle
						0,                        // flags
						FALSE,                    // not inheritable
						DUPLICATE_SAME_ACCESS);   // same handle access

	// We need a writeable buffer for the command (silly Windows restriction)
	CString command=cmdline_.getCmdLine();
	LPTSTR cmd = command.GetBuffer(command.GetLength() + 1);

	//get the working directory
	LPCTSTR currentDir = NULL;
	
	if (info_.hasWorkingDir())
        currentDir=info_.getWorkingDir();

    if ( currentDir && IsOnNetworkDrive(currentDir) )
        throw KError( PM("Process working directory cannot be on a network drive: '%1' (cmd: %2)") )
            << currentDir
            << cmd;

    DWORD processflags = CREATE_SUSPENDED;

    if ( CanCreateJobObject() ){
        // Needed for giving the spawned process its own job if we want to restrict its memory limit
        processflags |= CREATE_BREAKAWAY_FROM_JOB;
    }

	//start the WindowsProcess
	ok = ::CreateProcess(	NULL,										// command is part of input string
							cmd,										// (writeable) command string
							NULL,       								// WindowsProcess security
							NULL,       								// thread security
							TRUE,       								// inherit handles flag
							processflags,                               // flags, make sure there is no other job watching this process
							NULL,        								// inherit environment
							currentDir,        							// inherit directory
							&startup,    								// STARTUPINFO
							&procinfo);  								// WindowsProcess_INFORMATION
	
	//release the buffer in the CString
	command.ReleaseBuffer();

	if (!ok) { /* failed to start */
		
		status_.setFailedToStart( GetLastError(), getLastErrorText() );

		//close the handles
		::CloseHandle(hreadChildFromParent);
		::CloseHandle(hwriteChildToParent);
		::CloseHandle(hwriteChildToParent2);
        ::CloseHandle(hwriteChildToFile);
		
		return false;
	}

	//remember the handle to the WindowsProcess and the id of the main thread
	handle_process_=procinfo.hProcess;
    handle_thread_=procinfo.hThread;
	id_main_thread_=procinfo.dwThreadId;

	//--- SET THE PRIORITY CLASS ------------------------------------------------------------------
	ok=::SetPriorityClass(procinfo.hProcess, info_.getPriority());
	if (!ok) {
		status_.setFailedToSetPriority(GetLastError(), getLastErrorText());
		return false;
	}

	//--- SET THE MAXIMUM AMOUNT OF MEMORY --------------------------------------------------------
    // If we cannot create job objects we silently continue here, needed to run external 
    // processes on citrix (cannot break away from jobs there).
    if (info_.hasMemoryLimit() && CanCreateJobObject()) {
        if (! SetMaxMemory( procinfo.hProcess, info_.getMemoryLimit(), status_ ) )
            return false;
	}


	//--- RESUME THE WindowsProcess ----------------------------------------------------------------------
	//remember! we've started the WindowsProcess in a suspended state
	::ResumeThread(procinfo.hThread);
    
	//--- CLEANUP ---------------------------------------------------------------------------------
	//close the output pipes so we get true EOF/broken pipe
	::CloseHandle(hreadChildFromParent);
	::CloseHandle(hwriteChildToParent);
	::CloseHandle(hwriteChildToParent2);
    ::CloseHandle(hwriteChildToFile);

    //--- Set up the listener ---------------------------------------------------------------------
    listener_ = ParentListener( getReadHandle(), getWriteHandle() );

	//--- AND WE ARE DONE -------------------------------------------------------------------------
	return true;
} 
bool WindowsProcess::isRunning() const
{
	DWORD exitCode;
	BOOL ok = GetExitCodeProcess(handle_process_, &exitCode);
	return ok && exitCode==STILL_ACTIVE;
}

/**
    Note: This is not possible if this process is not allowed to create new job objects that
          are then attached to the new process, whereupon the child breaks away from the
          parent.
*/
bool WindowsProcess::SetMaxMemory( HANDLE hWindowsProcess, int maxMemory, ProcessStatus& status )
{
    if ( ! CanCreateJobObject() )
        return false;

    //figure out how many bytes to use
    SIZE_T maxmemory; 
    {
        unsigned __int64 maxmemory64=maxMemory; maxmemory64*=1024*1024;
        unsigned __int64 maxint=std::numeric_limits<SIZE_T>::max();
        if(maxmemory64>maxint) maxmemory=ncast<SIZE_T>(maxint-1);
        else maxmemory=ncast<SIZE_T>(maxmemory64);

        if (maxmemory<0.8*std::numeric_limits<unsigned __int64>::max()) {
            maxmemory+=ncast<SIZE_T>(0.1*maxmemory);
        }
    }	

    //create the job object
    HANDLE jobhandle = CreateJobObject(0, "WindowsProcessJobObject");
    //HANDLE jobhandle = CreateJobObject(0, NULL);
    if ( jobhandle == INVALID_HANDLE_VALUE) {
        status.setFailedToSetMemoryLimit(GetLastError(), getLastErrorText());
        return false;
    }

    if ( GetLastError() == ERROR_ALREADY_EXISTS )
        debug_str << "I already existed" << std::endl;

    //create the information object
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limitinfo;
    ::ZeroMemory(&limitinfo, sizeof(limitinfo));
    limitinfo.BasicLimitInformation.LimitFlags=JOB_OBJECT_LIMIT_JOB_MEMORY|JOB_OBJECT_LIMIT_PROCESS_MEMORY;
    limitinfo.ProcessMemoryLimit=maxmemory;
    limitinfo.JobMemoryLimit=maxmemory;

    //load the information into the job
    BOOL ok = SetInformationJobObject(jobhandle, JobObjectExtendedLimitInformation, &limitinfo, sizeof(JOBOBJECT_EXTENDED_LIMIT_INFORMATION));
    if (!ok) {
        status.setFailedToSetMemoryLimit(GetLastError(), getLastErrorText());
        return false;
    }

    //associate the WindowsProcess with the job
    ok = AssignProcessToJobObject(jobhandle, hWindowsProcess);
    if (!ok) {
        status.setFailedToSetMemoryLimit(GetLastError(), getLastErrorText());
        return false;
    }

    return true;
}

/**
    Is this process associated with a job object?
*/
bool WindowsProcess::IsInJob()
{
    BOOL result = 0;
    ::IsProcessInJob( GetCurrentHandle(), nullptr, &result );
    return result != 0;
}

/**
    Get the handle of the current process i.e. not the fired-up process.
*/
HANDLE WindowsProcess::GetCurrentHandle()
{
    return ::GetCurrentProcess();
}

bool WindowsProcess::CanCreateJobObject()
{
    if ( ! IsInJob() )
        return true;

    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limitinfo;
    ::ZeroMemory(&limitinfo, sizeof(limitinfo));

    ::QueryInformationJobObject(
        nullptr,                            // _In_opt_   HANDLE hJob (nullptr -> job of current job, which we verified above exists)
        JobObjectExtendedLimitInformation,  // _In_       JOBOBJECTINFOCLASS JobObjectInfoClass,
        &limitinfo,                         // _Out_      LPVOID lpJobObjectInfo,
        sizeof(JOBOBJECT_EXTENDED_LIMIT_INFORMATION), // _In_       DWORD cbJobObjectInfoLength,
        nullptr                             // _Out_opt_  LPDWORD lpReturnLength
        );

    // silent breakaway: process spawned with CreateProcess always get a new job object i.e. 
    // CREATE_BREAKAWAY_FROM_JOB is implicit
    return    limitinfo.BasicLimitInformation.LimitFlags & JOB_OBJECT_LIMIT_BREAKAWAY_OK
           || limitinfo.BasicLimitInformation.LimitFlags & JOB_OBJECT_LIMIT_SILENT_BREAKAWAY_OK;
}

WindowsProcess::Memory WindowsProcess::getMemoryUsage() const 
{
    PROCESS_MEMORY_COUNTERS memcounter;
    ::ZeroMemory(&memcounter, sizeof(PROCESS_MEMORY_COUNTERS));

    BOOL ok = GetProcessMemoryInfo(handle_process_, &memcounter, sizeof(PROCESS_MEMORY_COUNTERS));
    if (ok)
        return memcounter.WorkingSetSize;
    else
        return 0;
}

void WindowsProcess::terminate(ErrorCode errorCode)
{
    ::TerminateProcess(handle_process_, errorCode);
}

bool WindowsProcess::checkForMessage(MessageBuffer& buffer, int &bytesRead)
{
    return listener_.checkForMessage( buffer, bytesRead );
}

void WindowsProcess::sendMessage(Str::Text::Arg message)
{
    listener_.sendMessage(message);
}

int WindowsProcess::GetExitCode()
{
	DWORD exitCode = 0;
	if (::GetExitCodeProcess(handle_process_, &exitCode) == FALSE)
	{
		throw KError("Could not retrieve process exit code");
	}
	return int(exitCode);
}

ErrorCode WindowsProcess::GetErrorCode()
{
	ErrorCode ec = ::GetLastError();

	if (isRunning())
	{
		return ec;
	}
		
	// NOTE in earlier code, the error code is used as control mechanism
	// with a broken pipe error indicating process finish
	// this logic is maintained for legacy
	if (ec == ERROR_BROKEN_PIPE)
	{
		return 0;
	}

	return ec;
}

Str::Text::Val WindowsProcess::getErrorText(ErrorCode errorCode)
{
    return GetErrorText(errorCode);
}

Str::Text::Val WindowsProcess::getLastErrorText()
{
    return GetLastErrorText();
}

} // namespace runextern

#pragma once

#include "StatsCalculatorImpl.h"


class BasicSRSStatsCalculator : public StatsCalculatorImpl
{
public:
    BasicSRSStatsCalculator();

    virtual BasicSRSStatsCalculator* Clone() const override;

    static Str::ID::Val             GetTypeName();
    virtual Str::ID::Val            GetFactoryType() const override;

private:
    virtual void CheckPre           ( const SRSStatsCalculatorSettings& settings,
                                      const engine::ExecuteEnvironment& env,
                                      const communication::CalcCommunication& comm) const override;
    virtual void ApplyImpl          ( const SRSStatsCalculatorSettings& settings,
                                      const SplitSequenceFiles&         downloadedfiles,
									  SeqBagInfo& returnInfo,
									  std::string& info, std::string& stats,
                                      const engine::ExecuteEnvironment& env,
                                      const communication::CalcCommunication& comm) const override;
};

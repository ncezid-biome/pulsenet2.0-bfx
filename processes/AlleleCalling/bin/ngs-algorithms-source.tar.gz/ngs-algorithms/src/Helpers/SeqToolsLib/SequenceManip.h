#pragma once
/**
    \file SequenceManip.h

    \sa SequenceRangeManip.h
*/

#include "Sequence.h"


namespace seq
{


void ActgToUpperCase( Str::Text::Val& sequence );

void ActgToUpperCase  ( Sequence& sequence );
void Reverse          ( Sequence& sequence );
void Complement       ( Sequence& sequence );
void ReverseComplement( Sequence& sequence );

Sequence ReverseComplementCopy( const Sequence& sequence );

Sequence Translate( const Sequence& sequence );

} // namespace seq

#pragma once

#include <cstdint>
#include "SAMWrapper.h"
#include "BAMPileup.h"
#include "BAMPileFileTypes.h"
#include "BAMConsensusCaller.h"
#include <boost/shared_ptr.hpp>
#include "BAMCoverage.h"
#include "CalcCommunication.h"
#include "srsmapping_coverage.h"

namespace SeqBAM
{

class CoverageProvider: public BAM::Pileup
{

public:

    CoverageProvider(): Pileup(false), minContigLength_(0)
    {
        //Pileup(false), since we don't need a callback for positions without coverage
    }

    CoverageProvider(size_t minContigLength): Pileup(false), minContigLength_(minContigLength)
    {
    }

    CoverageProvider(const Str::Path::Val& reference): Pileup(false), minContigLength_(0), reference_(reference)
    {
    }

	void init(const Str::Path::Val& reference) 
	{ 
		reference_ = reference;
	}
    void Fill(BAM::FileResolver::Ptr files, bool countMultipleAlignments=false);

private:

    void FilterShortContigs();

    void MatchAgainstReference(const std::vector<BAMTypes::ReferenceInfo>& refInfos);

    virtual void ReferenceChanged(ReferenceID refID) {}

protected:
    virtual int PileupCallback(ReferenceID tid, ReferencePosition pos, int n, const bam_pileup1_t pl[]);

private:
    size_t minContigLength_;
    Str::Path::Val reference_;

public:

    std::vector<Str::ID::Val> contigNames_;
    std::vector<SRSMappingCoverage> coverages_;

};

class CoverageStatistics {
public:
	std::vector<double> avgCoveragesFwd, avgCoveragesRev; //average coverage per contig in fwd and rev
	double avgCoverageFwd, avgCoverageRev; //total average coverage
};

}

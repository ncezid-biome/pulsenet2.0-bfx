#pragma once

#include <map>

#include "exception.h"


class StringCounter
{
public:
    typedef std::map<Str::Text::Val, int> Map;

public:
    StringCounter();
    StringCounter( const Str::Text::Vec& strings );
    StringCounter( const std::vector<KError>& errors );
    
    void AddString( const Str::Text::Val& string );
    void Print    ( std::ostream& os ) const;
    
private:
    Map strings_;
};

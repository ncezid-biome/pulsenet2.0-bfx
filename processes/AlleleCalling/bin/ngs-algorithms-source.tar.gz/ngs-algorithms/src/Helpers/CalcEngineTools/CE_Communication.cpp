#include "stdafx.h"

#include "CE_Communication.h"

#include "translate.h"
#include "pugixml.hpp"

#include "CompressionType.h"
#include "NoCompressionType.h"

namespace communication
{


/**
    \param messageType An optional type for the message, is also written in the log file.
*/
CalcCreateResultFile::CalcCreateResultFile( const Str::Text::Val& filename,
											const Str::Text::Val& content, 
											CompressionTypePtr compressionTypePtr)
    : filename_   ( filename    )
    , content_    ( content     )
{
	compressionTypeId_ = (compressionTypePtr == nullptr) ? NoCompressionType::GetTypeName() : compressionTypePtr->GetID();
}

Str::Text::Val CalcCreateResultFile::GetName() const
{
    return PM("Result");
}

void CalcCreateResultFile::ToXml(pugi::xml_node& nd) const
{
    nd.append_child( PM("filename") )
		.append_child( pugi::node_pcdata )
		.set_value( ToRef(filename_) );

	nd.append_child( PM("content") )
    .append_child( pugi::node_pcdata )
    .set_value( ToRef(content_) );

	nd.append_child( PM("compressionType") )
    .append_child( pugi::node_pcdata )
	.set_value( ToRef(compressionTypeId_) );
}
    

/*  ------------------------------------------------------------------------*/

CalcAppendLogFile::CalcAppendLogFile( const Str::Text::Val& filename,
                                      const Str::Text::Val& content,
                                      const engine::LogMessageType&    messageType  )
    : filename_( filename )
    , content_ ( content  )
    , messageType_( messageType )
{
}

Str::Text::Val CalcAppendLogFile::GetName() const
{
    return PM("AppendLog");
}

void CalcAppendLogFile::ToXml(pugi::xml_node& nd) const
{
    nd.append_child( PM("filename") )
    .append_child( pugi::node_pcdata )
    .set_value( ToRef(filename_) );

    nd.append_child( PM("content") )
    .append_child( pugi::node_pcdata )
    .set_value( ToRef(content_) );

    nd.append_child( PM("type") )
    .append_child( pugi::node_pcdata )
    .set_value( ToRef(messageType_.ToString()) );
}

/*  ------------------------------------------------------------------------*/

CalcLogMessage::CalcLogMessage( Str::Text::Arg content,
                                const engine::LogMessageType& messageType  )
    : content_ ( content  )
    , messageType_( messageType )
{
}

Str::Text::Val CalcLogMessage::GetName() const
{
    return PM("LogMessage");
}

void CalcLogMessage::ToXml(pugi::xml_node& nd) const
{
    nd.append_child( PM("content") )
    .append_child( pugi::node_pcdata )
    .set_value( ToRef(content_) );

    nd.append_child( PM("type") )
    .append_child( pugi::node_pcdata )
    .set_value( ToRef(messageType_.ToString()) );
}


} // namespace communication

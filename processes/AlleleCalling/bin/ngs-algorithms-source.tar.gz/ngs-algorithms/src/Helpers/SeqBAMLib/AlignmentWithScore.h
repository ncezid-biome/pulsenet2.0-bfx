#pragma once
#include "align.h"
#include "BAMRead.h"

namespace SeqBAM
{

namespace Bowtie2Filter
{

class AlignmentWithScore: public BAM::Read
{
public:

    AlignmentWithScore();

    AlignmentWithScore(AlignmentWithScore&& other);

    AlignmentWithScore& operator= (AlignmentWithScore&& other);

    int matchPosition() const;

    void Evaluate();

public:
    double score;
    size_t length;

};

}

}
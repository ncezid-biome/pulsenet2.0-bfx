/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#include "strdef.h"

#ifndef SETTINGS_H
#define SETTINGS_H


/*
	A setting basically is a pair of 
		a setting identifier: plain string, should not contain anything but alphanumerical characters or underscores
		a value: a string, an int, a double or a bool (0=false, any other int=true)
*/


class Settings {
public:
	typedef Str::ID::Val Id;
	typedef Str::Buffer::Val Val;
	typedef std::vector<bool> BoolVec;
public:
	virtual Val getSetting(const Id& id) const =0;
public:
	Settings();
	virtual ~Settings();

	virtual bool hasSetting(const Id& id) const =0;
	
	Str::Text::Val getStringSetting(const Id& id) const;
	Str::Path::Val getPathSetting(const Id& id) const;
	bool getBoolSetting(const Id& id) const;
	int getIntSetting(const Id& id) const;
	double getDoubleSetting(const Id& id) const;
	Str::Text::Vec getStringVecSetting(const Id& id) const;
	BoolVec getBoolVecSetting(const Id& id) const;
	Str::Path::Vec getPathVecSetting(const Id& id) const;
};


class SubSettings : public Settings {
private:
	Id prefix_;
	const Settings& parent_;
public:
	virtual Val getSetting(const Id& id) const;
	virtual bool hasSetting(const Id& id) const;
public:
	SubSettings(const Settings& parent, const Id& prefix);
};

namespace SettingIds {
	extern Settings::Id WorkingDir;
	extern Settings::Id LogFile;
	extern Settings::Id OutputDir;
};

#endif
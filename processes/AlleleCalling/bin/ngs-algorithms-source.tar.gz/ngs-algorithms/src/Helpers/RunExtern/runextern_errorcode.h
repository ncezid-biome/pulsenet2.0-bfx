#pragma once



namespace runextern
{

typedef unsigned long ErrorCode;

} // namespace runextern
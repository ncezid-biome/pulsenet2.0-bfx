#include "stdafx.h"

#include "SequenceFileManip.h"

#include "Message.h"
#include "CalcCommunicationImpl.h"

#include "filereader.h"
#include "SequenceInspect.h"

using namespace communication;


void seq::UnzipSequenceFile(const Str::Path::Val& inputfile, const Str::Path::Val& ouputfile )
{
    ProcessSequenceFile(inputfile, ouputfile, [](size_t i, const seq::NamedSequence& c){ return true; });
}

/**
    Unzips for BLAST: all reads that contain only 'N' are removed. Do this because blastn does
    not process a file if this happens. We can remove the contigs because results are based on the
    name of the contigs, not their number.
*/
void seq::UnzipSequenceFileForBLAST(const Str::Path::Val& inputfile, const Str::Path::Val& ouputfile, const communication::CalcCommunication& comm)
{
    ProcessSequenceFile(inputfile, ouputfile, [&comm](size_t iread, const seq::NamedSequence& sequence) {

        if ( AreAllBasesN(sequence.GetData()) ) {
            comm.Send( CalcMessage(
                           pm("Removing all-N read %1 (%2) to comply with blastn complexity requirements.")
                           .arg(iread+1)
                           .arg(sequence.GetName())
                       ) );

            return false;
        }

        return true;
    });
}

void seq::MergeSequenceFiles(const Str::Path::Vec& inputfiles, const Str::Path::Val& outputfile)
{
    std::ofstream os(outputfile.string());

    for(auto& inputFile : inputfiles) {

        EnumerateSequenceFile(inputFile, [&os](size_t i, seq::NamedSequence & sequence) {

            os << '>' << sequence.GetName() << '\n';
            os << sequence.GetData() << '\n';
        });
    }
}


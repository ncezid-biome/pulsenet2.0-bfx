#pragma once

#include "Optionlist.h"

#include "SNPFilter.h"



namespace snp
{


class AmbiguousBaseFilterSettings : public options::VertOptionGroup
{
public:
    AmbiguousBaseFilterSettings();
    ~AmbiguousBaseFilterSettings(){ Reset(); }

    options::IntOption maxfreq;
	options::BooleanOption useRealBasesAnalysis;
};

/**
    Filter to remove SNP positions that have too many ambiguous bases.

    An ambiguous base is a base that's non-ACGT and not a gap.
    So gaps are not considered ambiguous.
*/
class AmbiguousBaseFilter : public SNPFilter
{
public:
    AmbiguousBaseFilter();

    SequencesSnpsActivePtr FilterSNPs(const SNPAnalysisCache& cache, const SnpFilterDataList& filters, const communication::CalcCommunication& comm) const override;

    Str::Text::Val GetDisplayName() const override;
    Str::Text::Val GetShortInfo() const override;
    Str::Text::Val GetDescription() const override;
    
    Str::Text::Val GetSnpDisplayInfo(const SnpCache& snp, int sequenceIndex, const SNPAnalysisCache& cache, const SnpFilterData& filterData) const override;
    Str::Text::Val GetPositionDisplayInfo(SnpPosition position, const SNPAnalysisCache& cache, const SnpFilterData& filterData) const override;
    double GetSnpSortValue(const SnpCache& snp, int sequenceIndex, const SNPAnalysisCache& cache, const SnpFilterData& filterData) const override;
    double GetPositionSortValue(SnpPosition position, const SNPAnalysisCache& cache, const SnpFilterData& filterData) const override;

    Str::Text::Val GetTypeID() const override;
    AmbiguousBaseFilterSettings* GetOptions() override;
    SNPFilter* Clone() const override;
    FilterCategory GetCategory() const override;

    Str::Text::Val GetGroup() const override { return TXT("Base quality"); }

    static Str::Text::Val GetTypeName();

private:
    AmbiguousBaseFilterSettings settings_;
};


} // namespace snp
#include "stdafx.h"

#include "CE_LogMessageType.h"


namespace engine
{

LogMessageType::LogMessageType(Type type)
    : type_( type )
{
}

LogMessageType LogMessageType::Message()
{
    return LogMessageType( Type::Message );
}

LogMessageType LogMessageType::Warning()
{
    return LogMessageType( Type::Warning );
}

LogMessageType LogMessageType::Error()
{
    return LogMessageType( Type::Error );
}

LogMessageType LogMessageType::Progress()
{
    return LogMessageType( Type::Progress );
}

Str::Text::Val LogMessageType::ToString() const
{
    switch( type_ ) {
    case Type::Progress:
        return PM("");
    case Type::Warning:
        return PM("Warning");
    case Type::Error:
        return PM("Error");
    default:
    case Type::Message:
        return PM("Msg");
    }
}

void LogMessageType::FromString(const Str::Text::Val& string)
{
    if ( string == PM("") )
        type_ = Type::Progress;
    else if ( string == PM("Warning") )
        type_ = Type::Warning;
    else if ( string == PM("Error") )
        type_ = Type::Error;
    else
        type_ = Type::Message;
}


} // namespace engine

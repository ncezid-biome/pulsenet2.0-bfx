#pragma once

#include "StringDef.h"


namespace engine
{


class LogMessageType
{
public:
    static LogMessageType Message();
    static LogMessageType Warning();
    static LogMessageType Error();
    static LogMessageType Progress();

    void           FromString( const Str::Text::Val& string );
    Str::Text::Val ToString() const;

private:
    enum class Type
    {
        Message,
        Warning,
        Error,
        Progress
    };

    LogMessageType( Type type );

private:
    Type type_;
};

} // namespace communication

#include "stdafx.h"
#include "BAMIterator.h"
#include "BAMFileType.h"

void BAM::Iterator::Open(const Str::Path::Val file)
{
    FileType type=GetFileType(file);
    bamFile_ = samopen(ToRef(file), GetTypeReadMode(type), 0);
    if(bamFile_ == nullptr) {
        throw KError("Could not open %2-file %1") << file << ToString(type);
    }
}

bool BAM::Iterator::GetNextReadInto(bam1_t* read)
{
    if(hasIter_)
        return bam_iter_read(bamFile_->x.bam, iter, read) >= 0;

    return samread(bamFile_, read) >= 0;
}

bam1_t* BAM::Iterator::GetNextRead()
{
    if(GetNextReadInto(bamRead_))
        return bamRead_;

    return nullptr;
}

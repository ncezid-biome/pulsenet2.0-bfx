#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "Sequence.h"


struct SequenceTestsFixture
{

};

BOOST_FIXTURE_TEST_SUITE( SequenceTests, SequenceTestsFixture );

BOOST_AUTO_TEST_CASE(Swap)
{
	seq::Sequence a(PM("aaaa"));
	seq::Sequence c(PM("cccc"));

	a.Swap(c);
	BOOST_REQUIRE_EQUAL(a, seq::Sequence(PM("cccc")));
	BOOST_REQUIRE_EQUAL(c, seq::Sequence(PM("aaaa")));

	swap(a, c);
	BOOST_REQUIRE_EQUAL(a, seq::Sequence(PM("aaaa")));
	BOOST_REQUIRE_EQUAL(c, seq::Sequence(PM("cccc")));
}

BOOST_AUTO_TEST_CASE(TrimAmbiguous)
{
	std::string const original(PM("nNnAAanNGnnN"));
	std::string const trimmed(PM("aaANng"));

	seq::Sequence amb(original);
	BOOST_REQUIRE_EQUAL(amb.GetLength(), original.size());
	amb.TrimAmbiguous();
	BOOST_REQUIRE_EQUAL(amb, seq::Sequence(trimmed));
	BOOST_REQUIRE_EQUAL(amb.GetLength(), trimmed.size());
}

BOOST_AUTO_TEST_SUITE_END();

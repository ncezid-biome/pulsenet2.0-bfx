#include "stdafx.h"
#include "filewriter.h"

#include <algorithm>

#include "logging.h"
#include "intdef.h"
#include "filetools.h"
#include "Message.h"

#include "CompressionType.h"
#include "GzipCompressionType.h"
#include "NoCompressionType.h"



namespace 
{

CompressionTypePtr getCompressionType( bool gzipped )
{
    if ( gzipped )
        return boost::make_shared<GzipCompressionType>();
    else
        return boost::make_shared<NoCompressionType>();
}

} // namespace 

void fillWriterFactory()
{
    RegisterFactoryTrait<FastaFileWriter>::RegisterItem();
    RegisterFactoryTrait<UncompressedFastQFileWriter>::RegisterItem();
    RegisterFactoryTrait<GZippedFastQFileWriter>::RegisterItem();
}

SeqFileWriter::SeqFileWriter()
{
}
SeqFileWriter::SeqFileWriter(const Str::Path::Val& path, bool gzipped, size_t  buffsize)	
{
	init(path, gzipped, buffsize);
}
SeqFileWriter::~SeqFileWriter()
{
}
void SeqFileWriter::init(const Str::Path::Val& path, bool gzipped, size_t  buffsize)
{
    OpenBinary(os_, path);
	writer_.Reset(os_, getCompressionType(gzipped));
}

/**
    \sa WriteLineAlways
*/
void SeqFileWriter::writeLine(Str::Text::Arg line, size_t size)
{
	writer_.WriteBuffer(line.c_str(), size);
	if (size>0 && line[size-1]!='\n') 
		WriteNewline();
}

void SeqFileWriter::WriteNewline()
{
    writer_.WriteBuffer(PM("\n"), 1);
}

/**
    Writes just a newline if \a line is empty

    \sa writeLine
*/
void SeqFileWriter::WriteLineAlways(Str::Text::Arg line, size_t size)
{
    writer_.WriteBuffer(line.c_str(), size);
    if (size == 0 || line[size-1] != '\n') 
        WriteNewline();
}




FastaFileWriter::FastaFileWriter()
{
}
FastaFileWriter::FastaFileWriter(const Str::Path::Val& path, bool gzipped, size_t  buffsize)
	: SeqFileWriter(path, gzipped, buffsize)
{
}
FastaFileWriter::~FastaFileWriter()
{
}
FastaFileWriter::IdRef FastaFileWriter::GetTypeName()
{
	return "fasta";
}
FastaFileWriter::IdRef FastaFileWriter::GetFactoryType() const
{
	return GetTypeName();
}
SeqFileWriter::Ptr FastaFileWriter::Clone() const
{
	return Ptr(new FastaFileWriter);
}
void FastaFileWriter::writeSeq(const Str::Text::Val& name, const Str::Text::Val& seq)
{
	writeLine(RawMessage(">%1", name).str(), name.size()+1);
	size_t sz = seq.size(), pos=0;
	while (pos<sz) {		
		writeLine(seq.c_str()+pos, pos+60<sz ? 60 : sz-pos);
		pos+=60;
	}
	
}
void FastaFileWriter::writeSeq(const Str::Text::Val& name, const Str::Text::Val& seq, const Str::Text::Val& qual)
{	
	writeSeq(name, seq);
}

FastQFileWriter::FastQFileWriter()
{
}
FastQFileWriter::FastQFileWriter(const Str::Path::Val& path, bool gzipped, size_t  buffsize)
	: SeqFileWriter(path, gzipped, buffsize)
{
}
FastQFileWriter::~FastQFileWriter()
{
}
void FastQFileWriter::writeSeq(const Str::Text::Val& name, const Str::Text::Val& seq)
{
    writeSeq(name, seq, PM(""));
}
void FastQFileWriter::writeSeq(const Str::Text::Val& name, const Str::Text::Val& seq, const Str::Text::Val& qual)
{
    if ( seq.size() != qual.size() )
        throw KError( PM("Malformed fastq file write: sequence length (%1) different from quality length (%2)") )
            << seq.size() << qual.size();

    writeLine      ('@' + name, name.size()+1);
    WriteLineAlways(seq, seq.size());
    writeLine      ('+' + name, name.size()+1);
    // Always write a line for the quality, even if empty, otherwise malformed fastq
    WriteLineAlways(qual, qual.size());
}





UncompressedFastQFileWriter::UncompressedFastQFileWriter()
{
}
UncompressedFastQFileWriter::UncompressedFastQFileWriter(const Str::Path::Val& path, size_t  buffsize)
	: FastQFileWriter(path, false, buffsize)
{
}
UncompressedFastQFileWriter::~UncompressedFastQFileWriter()
{
}
UncompressedFastQFileWriter::IdRef UncompressedFastQFileWriter::GetTypeName()
{
	return "fastq";
}
UncompressedFastQFileWriter::IdRef UncompressedFastQFileWriter::GetFactoryType() const
{
	return GetTypeName();
}
SeqFileWriter::Ptr UncompressedFastQFileWriter::Clone() const
{
	return Ptr(new UncompressedFastQFileWriter);
}




GZippedFastQFileWriter::GZippedFastQFileWriter()
{
}
GZippedFastQFileWriter::GZippedFastQFileWriter(const Str::Path::Val& path, size_t  buffsize)
	: FastQFileWriter(path, true, buffsize)
{
}
GZippedFastQFileWriter::~GZippedFastQFileWriter()
{
}
GZippedFastQFileWriter::IdRef GZippedFastQFileWriter::GetTypeName()
{
	return "fastq.gz";
}
GZippedFastQFileWriter::IdRef GZippedFastQFileWriter::GetFactoryType() const
{
	return GetTypeName();
}
SeqFileWriter::Ptr GZippedFastQFileWriter::Clone() const
{
	return Ptr(new GZippedFastQFileWriter);
}




ThreadSafeFileWriters::ThreadSafeFileWriters()
{
}
ThreadSafeFileWriters::ThreadSafeFileWriters(SeqFileWriter::Id type, const Str::Path::Vec& path, bool gzipped, size_t  buffsize)
{
	for(size_t i=0; i<path.size(); ++i) {
		writers_.push_back(SeqFileWriter::Factory::GetMap(type)->Clone());
		writers_.back()->init(path[i], gzipped, buffsize);	
	}
}
ThreadSafeFileWriters::ThreadSafeFileWriters(std::vector<SeqFileWriter::Ptr> writers)
	: writers_(writers)
{
}
void ThreadSafeFileWriters::clear()
{
	writers_.clear();
}
size_t ThreadSafeFileWriters::size() const
{
	return writers_.size(); 
}
void ThreadSafeFileWriters::push_back(SeqFileWriter::Ptr writer)
{
	writers_.push_back(writer);
}
void ThreadSafeFileWriters::writeChunks(const std::vector<Chunk>& chunks)
{	
	ASSERT(chunks.size()==writers_.size());
	boost::mutex::scoped_lock lock(mutex_);
	for (size_t j=0; j<chunks.size() ; ++j)
		for(size_t i=0; i<chunks[j].size(); ++i) {
		writers_[j]->writeSeq(chunks[j].getName(i), chunks[j].getSeq(i), chunks[j].getQual(i));
	}		
}
/*
const SeqFileWriter* ThreadSafeFileWriters::getWriter() const
{
    return writer_.get();
}
*/
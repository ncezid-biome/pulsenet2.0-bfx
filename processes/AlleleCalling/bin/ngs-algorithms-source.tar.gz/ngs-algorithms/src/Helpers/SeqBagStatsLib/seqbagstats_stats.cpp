#include "stdafx.h"
#include "seqbagstats_stats.h"
#include "seqbagstats_perpos.h"
#include "xmlwrapper.h"

SeqBagStats::SeqBagStats()
{
}

SeqBagStats::~SeqBagStats()
{
}
void SeqBagStats::Reset()
{
	stats_.clear();
}
void SeqBagStats::fromScores(const AllScores& scores)
{
	//a hack for being able to read in entire genomes
	if (scores.counts_.size()>1000000) { stats_.clear(); return; }

	stats_.resize(scores.counts_.size());

	size_t lenPart1 = scores.scores1_.maxLen();
	bool hasPart1 = lenPart1>0;
	size_t lenPart2 = scores.scores2_.maxLen();
	bool hasPart2 = lenPart2>0;

	for(size_t i=0; i<stats_.size(); ++i) {
		
		ASSERT(scores.counts_[i]==scores.counts1_[i] + scores.counts2_[i]);
		stats_[i].count[0]=	scores.counts1_[i];
		stats_[i].count[1]=	scores.counts2_[i];	
		
		ASSERT(scores.countsA_[i]==scores.countsA1_[i] + scores.countsA2_[i]);
		stats_[i].countA[0]=	scores.countsA1_[i];
		stats_[i].countA[1]=	scores.countsA2_[i];	

		ASSERT(scores.countsC_[i]==scores.countsC1_[i] + scores.countsC2_[i]);
		stats_[i].countC[0]=	scores.countsC1_[i];
		stats_[i].countC[1]=	scores.countsC2_[i];	

		ASSERT(scores.countsG_[i]==scores.countsG1_[i] + scores.countsG2_[i]);
		stats_[i].countG[0]=	scores.countsG1_[i];
		stats_[i].countG[1]=	scores.countsG2_[i];	

		ASSERT(scores.countsT_[i]==scores.countsT1_[i] + scores.countsT2_[i]);
		stats_[i].countT[0]=	scores.countsT1_[i];
		stats_[i].countT[1]=	scores.countsT2_[i];	
				
		if (scores.hasQual()) {
			stats_[i].avg[0]= scores.scores_.getAvg()[i];
			if (i<lenPart1)stats_[i].avg[1]= scores.scores1_.getAvg()[i];
			if (i<lenPart2) stats_[i].avg[2]= scores.scores2_.getAvg()[i];

			stats_[i].stdev[0]= scores.scores_.getStDev()[i];
			if (i<lenPart1) stats_[i].stdev[1]= scores.scores1_.getStDev()[i];
			if (i<lenPart2) stats_[i].stdev[2]= scores.scores2_.getStDev()[i];

			if (i<lenPart1) stats_[i].min[0]= scores.scores1_.getMin()[i];
			if (i<lenPart2) stats_[i].min[1]= scores.scores2_.getMin()[i];

			if (i<lenPart1) stats_[i].max[0]= scores.scores1_.getMax()[i];
			if (i<lenPart2) stats_[i].max[1]= scores.scores2_.getMax()[i];

			for(size_t j=0; j<5; ++j) {
				stats_[i].quantiles[0][j]=scores.scores_.getQuantiles()[j][i];
				if (i<lenPart1) stats_[i].quantiles[1][j]=scores.scores1_.getQuantiles()[j][i];
				if (i<lenPart2) stats_[i].quantiles[2][j]=scores.scores2_.getQuantiles()[j][i];
			}
		}
	}
}

void SeqBagStats::Load(const Str::Xml::Val& string)
{
	if (string.size()==0) {	
		stats_.resize(0);
		return;

	}

	XmlBlock b(PM("seqbag_stats"));	
	b.FromStr(string);

	std::string version;
	b.FromXmlAttr(PM("version"), version);
	
	if (version!=PM("1")) {	
		ASSERT(0);
		throw KError(TXT("Cannot load sequence read sets statistics, unknown version '%1'.")) << version;
	}
	{
		size_t size = 0;
		b.FromXml(PM("size"), size);			
		
		stats_.resize(size);
        if (size > 0)
            b.FromXmlEncoded(PM("stats"), (char*)(&stats_[0]), size*sizeof(Stat));
	}	

}

void SeqBagStats::Save(Str::Xml::Val& string) const
{
	XmlBlock b(PM("seqbag_stats"));
	{
		b.ToXmlAttr(PM("version"), std::string(PM("1")));
		b.ToXml(PM("size"), stats_.size());
		if(!stats_.empty())
			b.ToXmlEncoded(PM("stats"), (const char*)(&stats_[0]), stats_.size()*sizeof(Stat));
	}

	Str::Xml::Val str;
	b.ToStr(str);
	string=ToRef(str);
}
#pragma once
#include <boost/shared_ptr.hpp>
#include "BasicFileResolver.h"
#include "PathDef.h"

namespace BAM
{

class LocalFileResolver: public BasicFileResolver
{

public:

    LocalFileResolver(const Str::Path::Val& inputFile): BasicFileResolver(inputFile)
    {
    }

    virtual void SetBamFile(Str::Path::Val bamFile);

    virtual void SetSortedBamFile(Str::Path::Val sortedBamFile);
};

}
#pragma once

#include "CE_LogMessageType.h"

#include "CalcCommunication.h"


namespace engine
{

class Logger;

/**
    Log an action, need to manually call LogSuccess to report success. Is somewhat better than the
    auto logging in LogAction becaus that also logs success if an error has been thrown.
*/
class LogBlock
{
public:
    LogBlock( const Str::Text::Val& message, const communication::CalcCommunication& comm );
    LogBlock( LogMessageType type, const Str::Text::Val& message, const communication::CalcCommunication& comm );

    void LogSuccess();

private:
    void Init();

    LogBlock( const LogBlock& rhs );
    LogBlock& operator=( const LogBlock& rhs );

private:
    communication::CalcCommunication communication_;
    LogMessageType    type_;
    Str::Text::Val message_;
};

/**
    See engine::LoggedAction, analogous implementation
*/
class LogAction
{
public:
    LogAction( const communication::CalcCommunication& comm, const Str::Text::Val& message);
    LogAction( const communication::CalcCommunication& comm, LogMessageType type, const Str::Text::Val& message);
    ~LogAction();

private:
    LogBlock logBlock_;
};


} // namespace engine

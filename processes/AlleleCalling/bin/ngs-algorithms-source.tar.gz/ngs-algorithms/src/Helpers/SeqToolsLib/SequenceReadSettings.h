#pragma once


namespace seq
{


enum class DoAppend
{
    Yes,
    No
};

enum class DoReverse
{
    Yes,
    No
};

enum class DoComplement
{
    Yes,
    No
};

/**
    All settings default to No
*/
struct SequenceReadSettings
{
    SequenceReadSettings()
        : append    ( DoAppend::No )
        , reverse   ( DoReverse::No )
        , complement( DoComplement::No )
    {
    }

    DoAppend     append;
    DoReverse    reverse;
    DoComplement complement;
};


} // namespace seq

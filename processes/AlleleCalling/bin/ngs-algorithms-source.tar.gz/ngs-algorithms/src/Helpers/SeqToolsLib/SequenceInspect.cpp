#include "stdafx.h"

#include "SequenceInspect.h"
#include "SequenceRangeInspect.h"


namespace seq
{


bool AreAllBasesACGTacgt(const Sequence& sequence)
{
    return AreAllBasesACGTacgt(sequence.begin(), sequence.end());
}

/**

*/
bool SequenceContains(const Sequence& input, const Sequence& query)
{
    return input.Contains(query);
}

bool AreAllBasesN(const Sequence& sequence)
{
    return AreAllBasesN(sequence.begin(), sequence.end());
}


} // namespace seq

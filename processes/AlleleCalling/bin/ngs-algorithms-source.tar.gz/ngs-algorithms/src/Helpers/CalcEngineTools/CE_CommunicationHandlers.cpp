#include "stdafx.h"

#include "CE_CommunicationHandlers.h"

#include "translate.h"
#include "exception.h"


namespace communication
{


namespace
{

Str::Text::Val getRequiredChildString(pugi::xml_node& parent, const Str::Text::Val& childName)
{
    pugi::xml_node child = parent.child( ToRef(childName) );
    if ( child.type() == pugi::node_null )
        throw KError( RawMessage(PM("Required tag '%1' not found"), childName).c_str() );

    return child.child_value();
}

} // namespace

CalcCreateResultFileHandler::CalcCreateResultFileHandler(Functor f)
    : f_       ( f )
    , filename_()
    , content_ ()
	, compressionTypeId_()
{
}

CalcCreateResultFileHandler::Ptr CalcCreateResultFileHandler::Clone() const
{
    return Ptr( new CalcCreateResultFileHandler(f_) );
}

Str::Text::Val CalcCreateResultFileHandler::GetName() const
{
    return PM("Result");
}

void CalcCreateResultFileHandler::Handle()
{
    f_( filename_, content_, compressionTypeId_);
}

void CalcCreateResultFileHandler::FromXml(pugi::xml_node& nd)
{
    filename_			= getRequiredChildString( nd, PM("filename") );
    content_			= getRequiredChildString( nd, PM("content") );
	compressionTypeId_	= getRequiredChildString( nd, PM("compressionType") );
}

/*  ------------------------------------------------------------------------*/

CalcAppendLogfileHandler::CalcAppendLogfileHandler(Functor f)
    : f_          ( f )
    , filename_   ()
    , content_    ()
    , messageType_( engine::LogMessageType::Message() )
{
}

CalcAppendLogfileHandler::Ptr CalcAppendLogfileHandler::Clone() const
{
    return Ptr( new CalcAppendLogfileHandler(f_) );
}

Str::Text::Val CalcAppendLogfileHandler::GetName() const
{
    return PM("AppendLog");
}

void CalcAppendLogfileHandler::Handle()
{
    f_( filename_, messageType_, content_ );
}

void CalcAppendLogfileHandler::FromXml(pugi::xml_node& nd)
{
    filename_    = getRequiredChildString( nd, PM("filename") );
    content_     = getRequiredChildString( nd, PM("content") );
    messageType_.FromString( getRequiredChildString( nd, PM("type") ) );
}

/*  ------------------------------------------------------------------------*/

CalcLogMessageHandler::CalcLogMessageHandler(Functor f)
    : f_          ( f )
    , content_    ()
    , messageType_( engine::LogMessageType::Message() )
{
}

CalcLogMessageHandler::Ptr CalcLogMessageHandler::Clone() const
{
    return Ptr( new CalcLogMessageHandler(f_) );
}

Str::Text::Val CalcLogMessageHandler::GetName() const
{
    return PM("LogMessage");
}

void CalcLogMessageHandler::Handle()
{
    f_( messageType_, content_ );
}

void CalcLogMessageHandler::FromXml(pugi::xml_node& nd)
{
    content_     = getRequiredChildString( nd, PM("content") );
    messageType_.FromString( getRequiredChildString( nd, PM("type") ) );
}

} // namespace communication

#pragma once
#include "NamedSequence.h"
#include "PathDef.h"
#include "BAMHeader.h"

namespace BAM
{

class Concatenation
{

public:

    void AddPart(const Str::Path::Val& bamFile);

    void Concat(const Str::Path::Val& outputFile);

private:

    Str::Text::Vec bamFiles_;
};

}
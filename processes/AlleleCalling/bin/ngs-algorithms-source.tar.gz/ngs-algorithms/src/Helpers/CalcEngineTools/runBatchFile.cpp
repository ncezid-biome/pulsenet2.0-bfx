#include "stdafx.h"
#include "runBatchFile.h"
#include "helper.h"
#include "runextern_application.h"
#include "runextern_processInfo.h"
#include "runextern_manager.h"
#include "userbreak.h"
#include "CalcCommunicationReporter.h"

void runextern::RunBatchFile(const communication::CalcCommunication& comm, const Str::Path::Val& workingDir, const BatchFile& batchFile)
{
    /* --------------------------------------------------------------------------------------------
    	CREATE THE EXTERNAL APPLICATION
       -------------------------------------------------------------------------------------------- */

    MemoryBatchFileApp app(batchFile);

    /* --------------------------------------------------------------------------------------------
    	SET THE ENVIRONMENT PARAMETERS
       -------------------------------------------------------------------------------------------- */

    ProcessInfo info;
    info.setWorkingDir(ToRef(workingDir));

    /* --------------------------------------------------------------------------------------------
    	RUN THE APPLICATION
       -------------------------------------------------------------------------------------------- */
    ExternAppManager manager;
    CalcCommunicationReporter user(comm);
    manager.runApp(app, info, user, false);
}

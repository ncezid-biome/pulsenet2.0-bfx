#pragma once

// This file should be included in files that use samtoolslib

#include "sam.h"
#include "bam.h"
#include "STL_exports.h"


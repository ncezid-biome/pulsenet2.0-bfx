#pragma once

#include "boost/shared_ptr.hpp"
#include "boost/thread.hpp"

#include "Reporter.h"
#include "StringDef.h"

#include "runextern_process.h"


namespace runextern
{


class Listener
{
public:
    typedef boost::shared_ptr<Listener> Ptr;

public:
    Listener( Process::Ptr process );
    virtual ~Listener(){}

            //void listenInThread();
    void listen(Reporter& comm);

    void startListeningInThread(Reporter& comm);
    void stopListeningInThread();

protected:
    void SetContinue( bool mustContinue );

    Process::Ptr getProcess()  { return process_; }

private:
    virtual bool checkMemoryUsage() = 0;
    virtual void handleProgress(int millisecs, Reporter& comm) = 0;
    virtual void handleOutOfMemory(Reporter& comm) = 0;
    /**
        Implementor receives ownership of \a message!
    */
    virtual void handleMessage(const Str::Text::Val& message, Reporter& comm) = 0;
    virtual void handleEnd(ErrorCode lasterror, Reporter& comm) = 0;

private:
    Process::Ptr      process_;
    volatile bool     continue_;

    boost::scoped_ptr<boost::thread> listenThread_;
};

}

#pragma once


enum class FrameDirection
{
    Forward,
    Reverse
};

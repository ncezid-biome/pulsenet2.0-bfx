#include "stdafx.h"

#include "boost/test/unit_test.hpp"
#include "srsmapping_consensus.h"
#include "BAMCigar.h"
#include "BAMAlignmentEvaluator.h"
#include "align.h"

struct AlignmentEvaluatorTestsFixture {

    AlignmentEvaluatorTestsFixture()
    {
    }

    void PerformEvaluation(Str::Text::Arg cigar, Str::Text::Arg md, const AlignScores& expectedScore)
    {
        BAM::Cigar::CigarOps cig = BAM::Cigar::FromRLEString(cigar);
        SeqBAM::AlignmentEvaluator eva(&cig[0], cig.size(), md);

        AlignScores score;
        BOOST_CHECK_EQUAL(eva.Evaluate(score), true);

        BOOST_CHECK_EQUAL(score.n_matches, expectedScore.n_matches);
        BOOST_CHECK_EQUAL(score.n_mismatches, expectedScore.n_mismatches);
        BOOST_CHECK_EQUAL(score.n_opengap2, expectedScore.n_opengap2);
        BOOST_CHECK_EQUAL(score.n_extendgap2, expectedScore.n_extendgap2);
        BOOST_CHECK_EQUAL(score.n_opengap1, expectedScore.n_opengap1);
        BOOST_CHECK_EQUAL(score.n_extendgap1, expectedScore.n_extendgap1);
        BOOST_CHECK_EQUAL(score.n_begingaps2, expectedScore.n_begingaps2);
        BOOST_CHECK_EQUAL(score.n_endgaps2, expectedScore.n_endgaps2);
        BOOST_CHECK_EQUAL(score.n_begingaps1, expectedScore.n_begingaps1);
        BOOST_CHECK_EQUAL(score.n_endgaps1, expectedScore.n_endgaps1);
        BOOST_CHECK_EQUAL(score.length, expectedScore.length);
        BOOST_CHECK_EQUAL(score.readlength, expectedScore.readlength);

    }

};

BOOST_FIXTURE_TEST_SUITE( AlignmentEvaluatorTests, AlignmentEvaluatorTestsFixture );
BOOST_AUTO_TEST_CASE(exact1)
{
    AlignScores score;
    score.n_matches = 12;
    score.n_mismatches = 0;
    score.n_opengap2 = 0;
    score.n_extendgap2 = 0;
    score.n_opengap1 = 0;
    score.n_extendgap1 = 0;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 12;
    score.readlength = 0;

    PerformEvaluation("12M", "12", score); //ER:Z:MMMMMMMMMMMM
}

BOOST_AUTO_TEST_CASE(inserts_clean___)
{
    AlignScores score;
    score.n_matches = 12;
    score.n_mismatches = 0;
    score.n_opengap2 = 1;
    score.n_extendgap2 = 2;
    score.n_opengap1 = 0;
    score.n_extendgap1 = 0;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 15;
    score.readlength = 0;

    PerformEvaluation("5M3I7M", "12", score); //ER:Z:MMMMMIIIMMMMMMM
}

BOOST_AUTO_TEST_CASE(inserts_mutation)
{
    AlignScores score;
    score.n_matches = 11;
    score.n_mismatches = 1;
    score.n_opengap2 = 1;
    score.n_extendgap2 = 2;
    score.n_opengap1 = 0;
    score.n_extendgap1 = 0;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 15;
    score.readlength = 0;

    PerformEvaluation("5M3I7M", "8C3", score); //ER:Z:MMMMMIIIMMMXMMM
}

BOOST_AUTO_TEST_CASE(inserts_mutation_begin)
{
    AlignScores score;
    score.n_matches = 11;
    score.n_mismatches = 1;
    score.n_opengap2 = 1;
    score.n_extendgap2 = 2;
    score.n_opengap1 = 0;
    score.n_extendgap1 = 0;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 15;
    score.readlength = 0;

    PerformEvaluation("5M3I7M", "0A11", score); //ER:Z:XMMMMIIIMMMMMMM
}

BOOST_AUTO_TEST_CASE(inserts_mutation_end)
{
    AlignScores score;
    score.n_matches = 11;
    score.n_mismatches = 1;
    score.n_opengap2 = 1;
    score.n_extendgap2 = 2;
    score.n_opengap1 = 0;
    score.n_extendgap1 = 0;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 15;
    score.readlength = 0;

    PerformEvaluation("5M3I7M", "11C0", score); //ER:Z:MMMMMIIIMMMMMMX
}

BOOST_AUTO_TEST_CASE(inserts_mut_bef_insert)
{
    AlignScores score;
    score.n_matches = 11;
    score.n_mismatches = 1;
    score.n_opengap2 = 1;
    score.n_extendgap2 = 2;
    score.n_opengap1 = 0;
    score.n_extendgap1 = 0;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 15;
    score.readlength = 0;

    PerformEvaluation("5M3I7M", "4A7", score); //ER:Z:MMMMXIIIMMMMMMM
}

BOOST_AUTO_TEST_CASE(inserts_mut_aft_insert)
{
    AlignScores score;
    score.n_matches = 11;
    score.n_mismatches = 1;
    score.n_opengap2 = 1;
    score.n_extendgap2 = 2;
    score.n_opengap1 = 0;
    score.n_extendgap1 = 0;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 15;
    score.readlength = 0;

    PerformEvaluation("5M3I7M", "5C6", score); //ER:Z:MMMMMIIIXMMMMMM
}

BOOST_AUTO_TEST_CASE(insert_at_begin__)
{
    AlignScores score;
    score.n_matches = 11;
    score.n_mismatches = 0;
    score.n_opengap2 = 1;
    score.n_extendgap2 = 1;
    score.n_opengap1 = 0;
    score.n_extendgap1 = 0;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 13;
    score.readlength = 0;

    PerformEvaluation("2I11M", "11", score); //ER:Z:IIMMMMMMMMMMM
}

BOOST_AUTO_TEST_CASE(insert_at_end___)
{
    AlignScores score;
    score.n_matches = 11;
    score.n_mismatches = 0;
    score.n_opengap2 = 1;
    score.n_extendgap2 = 1;
    score.n_opengap1 = 0;
    score.n_extendgap1 = 0;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 13;
    score.readlength = 0;

    PerformEvaluation("11M2I", "11", score); //ER:Z:MMMMMMMMMMMII
}

BOOST_AUTO_TEST_CASE(deletion_clean___)
{
    AlignScores score;
    score.n_matches = 13;
    score.n_mismatches = 0;
    score.n_opengap2 = 0;
    score.n_extendgap2 = 0;
    score.n_opengap1 = 1;
    score.n_extendgap1 = 2;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 13;
    score.readlength = 0;

    PerformEvaluation("6M3D7M", "6^CCC7", score); //ER:Z:MMMMMMDDDMMMMMMM
}

BOOST_AUTO_TEST_CASE(deletion_mutation)
{
    AlignScores score;
    score.n_matches = 12;
    score.n_mismatches = 1;
    score.n_opengap2 = 0;
    score.n_extendgap2 = 0;
    score.n_opengap1 = 1;
    score.n_extendgap1 = 2;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 13;
    score.readlength = 0;

    PerformEvaluation("6M3D7M", "6^CCC3G3", score); //ER:Z:MMMMMMDDDMMMXMMM
}

BOOST_AUTO_TEST_CASE(deletion_mut_before)
{
    AlignScores score;
    score.n_matches = 12;
    score.n_mismatches = 1;
    score.n_opengap2 = 0;
    score.n_extendgap2 = 0;
    score.n_opengap1 = 1;
    score.n_extendgap1 = 2;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 13;
    score.readlength = 0;

    PerformEvaluation("6M3D7M", "5T0^CCC7", score); //ER:Z:MMMMMXDDDMMMMMMM
}

BOOST_AUTO_TEST_CASE(deletion_mut_after)
{
    AlignScores score;
    score.n_matches = 12;
    score.n_mismatches = 1;
    score.n_opengap2 = 0;
    score.n_extendgap2 = 0;
    score.n_opengap1 = 1;
    score.n_extendgap1 = 2;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 13;
    score.readlength = 0;

    PerformEvaluation("6M3D7M", "6^CCC0G6", score); //ER:Z:MMMMMMDDDXMMMMMM
}

BOOST_AUTO_TEST_CASE(deletion_at_begin__)
{
    AlignScores score;
    score.n_matches = 14;
    score.n_mismatches = 0;
    score.n_opengap2 = 0;
    score.n_extendgap2 = 0;
    score.n_opengap1 = 1;
    score.n_extendgap1 = 1;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 14;
    score.readlength = 0;

    PerformEvaluation("2D14M", "0^TT14", score); //ER:Z:DDMMMMMMMMMMMMMM
}

BOOST_AUTO_TEST_CASE(deletion_at_end___)
{
    AlignScores score;
    score.n_matches = 14;
    score.n_mismatches = 0;
    score.n_opengap2 = 0;
    score.n_extendgap2 = 0;
    score.n_opengap1 = 1;
    score.n_extendgap1 = 1;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 14;
    score.readlength = 0;

    PerformEvaluation("14M2D", "14^GG0", score); //ER:Z:MMMMMMMMMMMMMMDD
}

BOOST_AUTO_TEST_CASE(clipped_soft____)
{
    AlignScores score;
    score.n_matches = 8;
    score.n_mismatches = 0;
    score.n_opengap2 = 0;
    score.n_extendgap2 = 0;
    score.n_opengap1 = 0;
    score.n_extendgap1 = 0;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 8;
    score.readlength = 0;

    PerformEvaluation("8M4S", "8", score); //ER:Z:MMMMMMMM
}

BOOST_AUTO_TEST_CASE(clipped_hard____)
{
    AlignScores score;
    score.n_matches = 8;
    score.n_mismatches = 0;
    score.n_opengap2 = 0;
    score.n_extendgap2 = 0;
    score.n_opengap1 = 0;
    score.n_extendgap1 = 0;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 8;
    score.readlength = 0;

    PerformEvaluation("8M4H", "8", score); //ER:Z:MMMMMMMM
}

BOOST_AUTO_TEST_CASE(clipped_mutation)
{
    AlignScores score;
    score.n_matches = 7;
    score.n_mismatches = 1;
    score.n_opengap2 = 0;
    score.n_extendgap2 = 0;
    score.n_opengap1 = 0;
    score.n_extendgap1 = 0;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 8;
    score.readlength = 0;

    PerformEvaluation("8M4S", "5C2", score); //ER:Z:MMMMMXMM
}

BOOST_AUTO_TEST_CASE(multi_mutations___)
{
    AlignScores score;
    score.n_matches = 5;
    score.n_mismatches = 4;
    score.n_opengap2 = 0;
    score.n_extendgap2 = 0;
    score.n_opengap1 = 0;
    score.n_extendgap1 = 0;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 9;
    score.readlength = 0;

    PerformEvaluation("9M", "3N0N0A0C2", score); //ER:Z:MMMXXXXMM
}

BOOST_AUTO_TEST_CASE(del_post_multi_mut)
{
    AlignScores score;
    score.n_matches = 6;
    score.n_mismatches = 2;
    score.n_opengap2 = 0;
    score.n_extendgap2 = 0;
    score.n_opengap1 = 1;
    score.n_extendgap1 = 1;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 8;
    score.readlength = 0;

    PerformEvaluation("6M2D2M", "4N0N0^AC2", score); //ER:Z:MMMMXXDDMM
}

BOOST_AUTO_TEST_CASE(del_pre_multi_mut)
{
    AlignScores score;
    score.n_matches = 6;
    score.n_mismatches = 2;
    score.n_opengap2 = 0;
    score.n_extendgap2 = 0;
    score.n_opengap1 = 1;
    score.n_extendgap1 = 1;
    score.n_begingaps2 = 0;
    score.n_endgaps2 = 0;
    score.n_begingaps1 = 0;
    score.n_endgaps1 = 0;
    score.length = 8;
    score.readlength = 0;

    PerformEvaluation("1M2D7M", "1^GG0N0N5", score); //ER:Z:MDDXXMMMMM
}

BOOST_AUTO_TEST_CASE(invalid)
{
    AlignScores score;

    {
        BAM::Cigar::CigarOps cig = BAM::Cigar::FromRLEString("2D");
        SeqBAM::AlignmentEvaluator eva(&cig[0], cig.size(), "yolo");

        //deletion should be met with ^... in the MD
        BOOST_CHECK_EQUAL(eva.Evaluate(score), false);
    }

    {
        BAM::Cigar::CigarOps cig = BAM::Cigar::FromRLEString("yolo");
        SeqBAM::AlignmentEvaluator eva(&cig[0], cig.size(), "12");

        //cigar is empty
        BOOST_CHECK_EQUAL(eva.Evaluate(score), false);
    }

    {
        BAM::Cigar::CigarOps cig = BAM::Cigar::FromRLEString("15M");
        SeqBAM::AlignmentEvaluator eva(&cig[0], cig.size(), nullptr);

        //MD is a null ptr
        BOOST_CHECK_EQUAL(eva.Evaluate(score), false);
    }

    {
        BAM::Cigar::CigarOps cig = BAM::Cigar::FromRLEString("3000000D5M");
        SeqBAM::AlignmentEvaluator eva(&cig[0], cig.size(), "^oh shit, thats too long maaaaaan");

        //MD is a null ptr
        BOOST_CHECK_EQUAL(eva.Evaluate(score), false);
    }
}


BOOST_AUTO_TEST_SUITE_END();

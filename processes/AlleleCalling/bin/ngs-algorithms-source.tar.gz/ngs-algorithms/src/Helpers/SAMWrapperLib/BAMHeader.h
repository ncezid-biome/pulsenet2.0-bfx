#pragma once
#include <StringDef.h>
#include <vector>
#include <SAMToolsLib.h>
#include "SAMWrapper.h"
#include <boost/shared_ptr.hpp>
#include "BAMTypes.h"

namespace BAM
{

class STW_DLLPORT Header: protected BAMTypes
{

public:

    enum Sorting { UNKNOWN=0, UNSORTED=1, QUERYNAME=2, COORDINATE=3 };

    typedef boost::shared_ptr<bam_header_t> RawHeaderPtr;

public:

    Header(): version_("1.3"), sorting_(UNKNOWN)
    {

    }

    void SetSorting(Sorting sorting)
    {
        sorting_=sorting;
    }

    void SetVersion(Str::ID::Arg version)
    {
        version_=version;
    }

    BAMTypes::ReferenceID AddReference(Str::ID::Arg name, size_t length);

    void WriteToBAMFile(bamFile file) const;

    RawHeaderPtr CreateRawHeader() const;

private:

    Str::ID::Val version_;
    Sorting sorting_;

    std::vector<ReferenceInfo> references_;

    const static char* sortingText_[];

};

}


#pragma once

#include "runextern_process.h"
#include "runextern_MessageBuffer.h"


namespace runextern
{


class ParentListener
{
public:
    ParentListener();
    ParentListener( HANDLE readHandle, HANDLE writeHandle );

    bool checkForMessage(MessageBuffer& buffer, int &bytesRead);
    void sendMessage    (Str::Text::Arg message);

private:
    HANDLE readHandle_;
    HANDLE writeHandle_;
};

class WindowsProcess : public Process
{
public:
    typedef boost::shared_ptr<WindowsProcess> Ptr;

private:
    ProcessInfo    info_;		
    ProcessCmdLine cmdline_;		
    ProcessStatus  status_;
public:
    WindowsProcess();
    WindowsProcess(const ProcessCmdLine& cmd);
    WindowsProcess(const ProcessCmdLine& cmd, const ProcessInfo& info);
    ~WindowsProcess();

    virtual void setCmdLine(const ProcessCmdLine& cmd) override;
    virtual void setInfo(const ProcessInfo& info) override;
    ProcessInfo getInfo() const { return info_; }

    virtual const ProcessStatus& getStatus() override;
    virtual Memory getMemoryUsage() const override;

    virtual bool run() override;
    virtual void terminate( ErrorCode errorCode ) override;
    virtual bool checkForMessage(MessageBuffer& buffer, int &bytesRead) override;
    virtual void sendMessage( Str::Text::Arg message ) override;
	virtual int GetExitCode() override;
	virtual ErrorCode GetErrorCode() override;

private: //Handles to the process and the main thread of the process
    HANDLE handle_process_;
    HANDLE handle_thread_;
    DWORD id_main_thread_;
public:
    HANDLE getProcessHandle();
    DWORD getMainThreadId();


private: //Handles to the read/write pipes to be used by the parent
    HANDLE hreadParentFromChild_, hwriteParentToChild_;
    ParentListener listener_;

public:
    //the following functions provide access to the read/write handles used by the parent
    //the child process just uses stdin/stdout

    //get the read handle: this is the handle used by the parent to read from the child
    HANDLE getReadHandle(); 
    //get the write handle: this is the handle used by the parent to write to the child
    HANDLE getWriteHandle();

    bool isRunning() const;
    
    //
    static bool           SetMaxMemory( HANDLE hProcess, int maxMemory, ProcessStatus& status );
    static Str::Text::Val getLastErrorText();
	static Str::Text::Val getErrorText( ErrorCode errorCode );
    static bool           CanCreateJobObject();

private:
    static HANDLE         GetCurrentHandle();
    static bool           IsInJob();
};

} // namespace runextern

#pragma once
#include "StringDef.h"
#include "mathHelp.h"

class SeqBagGeneralStats {
public:
	typedef uint64_t CountType;
    typedef std::vector<CountType> CountVector;

    //"Sanger format can encode a Phred quality score from 0 to 93 using ASCII 33 to 126 (although in raw read data the Phred quality score rarely exceeds 60, higher scores are possible in assemblies or read maps)."
    //note: end is inclusive, so 93 [='~'-33] is also a valid score, hence the plus one
    static const size_t QRANGE = 93 + 1;

private:
	char tocode[256];
private:

	CountType npaired_, ntotal_;
	AvgMinMax<double> len_, len1_, len2_;
	AvgMinMax<double> qual_, qual1_, qual2_;
	CountVector qCounts_, qCounts1_, qCounts2_;
	CountType n_[5];	
public:
	SeqBagGeneralStats() : npaired_(0), ntotal_(0) {
		for(size_t i=0; i<5; ++i) n_[i]=0;
		qCounts_.resize(QRANGE, 0);
		qCounts1_.resize(QRANGE, 0);
		qCounts2_.resize(QRANGE, 0);

		for(size_t i=0; i<256; ++i) tocode[i]=4;
		
		tocode['A']=0; tocode['C']=1; tocode['G']=2; tocode['T']=3;
		tocode['a']=0; tocode['c']=1; tocode['g']=2; tocode['t']=3;
	}

	inline CountType getNSeqs() const { return ntotal_; }
	inline CountType getNPaired() const { return npaired_; }
	inline const AvgMinMax<double>& getTotLen() const { return len_; }
	inline const AvgMinMax<double>& getLen1() const { return len1_; }
	inline const AvgMinMax<double>& getLen2() const { return len2_; }
	inline const AvgMinMax<double>& getTotQual() const { return qual_; }
	inline const AvgMinMax<double>& getQual1() const { return qual1_; }
	inline const AvgMinMax<double>& getQual2() const { return qual2_; }
	inline CountType getTotBase(size_t i) const { return n_[i]; }
	inline const CountVector& getTotQCounts() const { return qCounts_; }
	inline const CountVector& getQCounts1() const { return qCounts1_; }
	inline const CountVector& getQCounts2() const { return qCounts2_; }



	inline void add(const char* seq1, const char* qual1, size_t size1, const char* seq2, const char* qual2, size_t size2, size_t qualOffset) {
		const char* myQual1 = qual1;
		size_t mySize1 = size1;
		const char* myQual2 = qual2;
		size_t mySize2 = size2;
		
		//adjust the sequence counters
		if (mySize1||mySize2)
			++ntotal_;
		if (mySize2)
			++npaired_;

		//add the first part (if any) 
		if (mySize1) {		
			//add the length
			len_+=mySize1;
			len1_+=mySize1;

			//add the individual bases and quality scores			
			if (myQual1) 
				for(size_t i=0; i<mySize1; ++i) {
                    qual_+=(myQual1[i]-qualOffset);	
					qual1_+=(myQual1[i]-qualOffset);
					for(size_t j=0; j<=myQual1[i]-qualOffset; ++j) {
						qCounts_[j] += 1;
						qCounts1_[j] += 1;
					}
					++n_[tocode[seq1[i]]];
				}
			else 
				for(size_t i=0; i<mySize1; ++i) ++n_[tocode[seq1[i]]];
		}

		//add the second part (if any) 
		if (mySize2) {			
			//add the length
			len_+=mySize2;
			len2_+=mySize2;

			//add the individual bases and quality scores			
			if (myQual2) 
				for(size_t i=0; i<mySize2; ++i) {
					qual_+=(myQual2[i]-qualOffset);
					qual2_+=(myQual2[i]-qualOffset);
					for(size_t j=0; j<=myQual2[i]-qualOffset; ++j) {
						qCounts_[j] += 1;
						qCounts2_[j] += 1;
					}
					++n_[tocode[seq2[i]]];
				}
			else 
				for(size_t i=0; i<mySize2; ++i) ++n_[tocode[seq2[i]]];
		}
	}
	inline void add(const SeqBagGeneralStats& other) {
		npaired_+=other.npaired_;
		ntotal_+=other.ntotal_;
		len_+=other.len_;
		len1_+=other.len1_;
		len2_+=other.len2_;
		qual_+=other.qual_;
		qual1_+=other.qual1_;
		qual2_+=other.qual2_;
		for(size_t i=0; i<5; ++i) n_[i]+=other.n_[i];		
		for(size_t i=0; i<QRANGE; ++i) {
			qCounts_[i]+=other.qCounts_[i];
			qCounts1_[i]+=other.qCounts1_[i];
			qCounts2_[i]+=other.qCounts2_[i];
		}
	}
};

#include "stdafx.h"

#include "runextern_processInfo.h"

#include "exception.h"
#include "extensionbrowser.h"


namespace runextern
{

    
ProcessInfo::ProcessInfo()
    : priority_(ProcessPriorities::normal), maxmemory_(-1),expected_runtime_(-1)
{
}
ProcessInfo::ProcessInfo(const ProcessInfo& other)
    : priority_(other.priority_), maxmemory_(other.maxmemory_), expected_runtime_(other.expected_runtime_), workingDir_(other.workingDir_)
{
}
ProcessInfo::~ProcessInfo()
{
}
ProcessInfo& ProcessInfo::operator = (const ProcessInfo& other)
{
    priority_=other.priority_;
    maxmemory_=other.maxmemory_;
    expected_runtime_=other.expected_runtime_;
    workingDir_=other.workingDir_;
    return *this;
}
void ProcessInfo::setPriority(ProcessPriorities::Priority priority)
{
    priority_=priority;
}
ProcessPriorities::Priority ProcessInfo::getPriority() const
{
    return priority_;
}
void ProcessInfo::setMemoryLimit(int megabytes)
{
    ASSERT(megabytes>0); //are you sure you want to use no memory at all? When proceeding, there will be no memory limit!
    maxmemory_=megabytes;
}
void ProcessInfo::setMemoryUnlimited()
{
    maxmemory_=-1;
}
bool ProcessInfo::hasMemoryLimit() const
{
    return maxmemory_>0;
}
int ProcessInfo::getMemoryLimit() const
{
    return maxmemory_;
}
void ProcessInfo::setExpectedRuntime(int seconds)
{
    expected_runtime_=seconds;
}
bool ProcessInfo::hasExpectedRuntime() const
{
    return expected_runtime_>0;
}
int ProcessInfo::getExpectedRuntime() const
{
    return expected_runtime_;
}

/**
    On windows, \a workingDir is not allowed to be an UNC path i.e. workingDir cannot be on a network
    drive (get 'The directory name is invalid (267)' error).
*/
void ProcessInfo::setWorkingDir(Str::Text::Arg workingDir)
{
#ifndef AMGNU
    if ( IsOnNetworkDrive(workingDir) )
        throw KError( PM("Process working directory cannot be on a network drive (%1)") )
            << workingDir;
#endif

    workingDir_=workingDir;
}

bool ProcessInfo::hasWorkingDir() const 
{
    return !workingDir_.empty();
}
Str::Text::Ref ProcessInfo::getWorkingDir() const
{
    return ToRef(workingDir_);
}

} // namespace runextern
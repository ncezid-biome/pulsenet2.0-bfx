#include "stdafx.h"

#include "BlastDatabase.h"

#include "runextern_manager.h"
#include "translate.h"
#include "exception.h"
#include "filetools.h"
#include "CalcCommunicationReporter.h"

#include "CE_LogAction.h"


BlastDatabase::BlastDatabase(const Str::Path::Val baseName, const communication::CalcCommunication& comm)
    : fileRotator_( 2 )
{
    if ( baseName.empty() )
        throw KError( PM("Empty name for BLAST database specified") );

    fileRotator_.SetBasename( baseName, comm );
}

/**
    Using makeblastdb, creates new blast databases. The name is based on the baseName
    given in the constructor, with the file rotation mechanism applied to it.
*/
void BlastDatabase::Create( const Str::Path::Val& sequenceFile, const communication::CalcCommunication& comm )
{
	using namespace runextern;

	auto const databaseFile = fileRotator_.GetNextFileBase().string();

	// nuke the existing BLAST database with name <databaseFile>
	// Rationale: if sequenceFile is empty, makeblastdb won't do anything
	// and keep the old one in place.  We need an empty database instead!
	RemoveFile(databaseFile + ".nhr");
	RemoveFile(databaseFile + ".nin");
	RemoveFile(databaseFile + ".nsq");

	
	//run the algorithm
	BatchFile batchFile;
	{
		//--- add the makeblastdb command line ---------------------------------------------------------
		{	
			ProcessCmdLine makeblastdb("makeblastdb");
			{
				//the executable
				makeblastdb << "-dbtype" << "nucl"; 

				//the input file
#ifndef AMGNU
				makeblastdb << "-in" << sequenceFile.filename().string();
#else
				makeblastdb << "-in" << sequenceFile.string();
#endif
				//the database. Use the next rotated name!
				makeblastdb << "-out" << databaseFile;
			}
			batchFile.addLine(makeblastdb);
		}
	}
		
	/* --------------------------------------------------------------------------------------------
		CREATE THE EXTERNAL APPLICATION 
	   -------------------------------------------------------------------------------------------- */

	MemoryBatchFileApp app(batchFile);

	/* --------------------------------------------------------------------------------------------
		SET THE ENVIRONMENT PARAMETERS
	   -------------------------------------------------------------------------------------------- */

    ProcessInfo info;
    {
#ifndef AMGNU
		// On Windows the directory names may contain spaces and that is not handled well by
		// the blast tools or at least by the version in use at the time of writing (2.2.28+)
		// the work around this is to ensure the working directory is set to the location of the
		// input file
		info.setWorkingDir(sequenceFile.parent_path().string());
#endif
    }
	
	/* --------------------------------------------------------------------------------------------
		RUN THE APPLICATION
	   -------------------------------------------------------------------------------------------- */
    ExternAppManager manager;
    CalcCommunicationReporter user( comm );
    manager.runApp(app, info, user, false);

    // Got here -> rotate the link file
    fileRotator_.RotateLinkfile( comm );
}

Str::Path::Val BlastDatabase::GetCurrentName()
{
    return fileRotator_.GetCurrentFileBase();
}

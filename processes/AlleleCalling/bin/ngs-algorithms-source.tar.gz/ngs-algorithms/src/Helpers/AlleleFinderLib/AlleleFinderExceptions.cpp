#include "stdafx.h"

#include "AlleleFinderExceptions.h"

#include "helper.h"



BLASTNException::BLASTNException(int exitCode)
    : KError( PM("blastn failed with exit code ") + ToStr(exitCode) + PM(". Please inspect the logs for more information.") )
{
}

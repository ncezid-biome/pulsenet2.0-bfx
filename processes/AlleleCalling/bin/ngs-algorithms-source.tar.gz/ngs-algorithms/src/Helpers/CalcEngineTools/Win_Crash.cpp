#include "stdafx.h"

#include "Win_Crash.h"

#include "PathDef.h"
#include "UniqueStringProvider.h"


#ifndef AMGNU

#include<DbgHelp.h>

typedef BOOL (WINAPI* MINIDUMPWRITEDUMP)(HANDLE hProcess, DWORD dwPid, HANDLE hFile, MINIDUMP_TYPE DumpType,
        CONST PMINIDUMP_EXCEPTION_INFORMATION ExceptionParam,
        CONST PMINIDUMP_USER_STREAM_INFORMATION UserStreamParam,
        CONST PMINIDUMP_CALLBACK_INFORMATION CallbackParam
                                        );


LONG WINAPI serviceExceptionFilter(_EXCEPTION_POINTERS* info)
{
    // Check winnt.h for the exception codes (convert from dec to hex)
    //
    // 3221225477 : STATUS_ACCESS_VIOLATION
    // 3222601744 : STATUS_SXS_INVALID_DEACTIVATION
    addmess( RawMessage(PM("***Unhandled exception: %1***"), info->ExceptionRecord->ExceptionCode).c_str() );

    LONG retval=EXCEPTION_CONTINUE_SEARCH;

    const Str::Text::Val debughelpDll = PM("DBGHELP.DLL");

    //load dbghelp module
    HMODULE hdll=NULL;
    char debughelppath[1000];
    if (GetModuleFileName(NULL,debughelppath,999)) {
        char* pslash=_tcsrchr(debughelppath,'\\');
        if (pslash) {
            _tcscpy(pslash+1,"DBGHELP.DLL" );
            addmess( RawMessage(PM("Trying to load '%1' from directory '%2'..."), debughelpDll, debughelppath).c_str() );
            hdll=::LoadLibrary(debughelppath);
        }

        if ( hdll )
            addmess( RawMessage(PM("Loading '%1' succeeded"), debughelpDll).c_str() );
        else
            addmess( RawMessage(PM("Loading '%1' failed"), debughelpDll).c_str() );
    }
    if (hdll == NULL) {
        addmess( RawMessage(PM("Trying to load '%1' from global library path..."), debughelpDll).c_str() );
        hdll=::LoadLibrary("DBGHELP.DLL" );
    }

    if ( hdll )
        addmess( RawMessage(PM("Loading '%1' succeeded"), debughelpDll).c_str() );
    else
        addmess( RawMessage(PM("Loading '%1' failed"), debughelpDll).c_str() );

    Str::Text::Val dumpcomment;

    if (hdll==NULL)
        dumpcomment = "Could not write dump: unable to find DBGHELP.DLL";
    else {
        MINIDUMPWRITEDUMP pdump = (MINIDUMPWRITEDUMP)::GetProcAddress( hdll, "MiniDumpWriteDump" );
        if (pdump==NULL)
            dumpcomment = "Could not write dump: too old version of DBGHELP.DLL";
        else {
            Str::Path::Val dumppath( G_homedir() );
            dumppath /= GetCrashdumpFilename();

            // Convert to unique name
            dumppath = GetUniqueFilename(dumppath, 500);

            HANDLE hfile=::CreateFile(ToRef(dumppath.string()),GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
            if (hfile==NULL)
                dumpcomment=Message(TXT("Could not write dump: unable to save file '%1'"),dumppath.string()).c_str();
            else {
                _MINIDUMP_EXCEPTION_INFORMATION ExInfo;
                ExInfo.ThreadId=::GetCurrentThreadId();
                ExInfo.ExceptionPointers=info;
                ExInfo.ClientPointers=NULL;
                BOOL ok=pdump(GetCurrentProcess(),GetCurrentProcessId(),hfile,MiniDumpNormal,&ExInfo,NULL,NULL);
                if (!ok) dumpcomment=Message("Failed to save dump to '%1'",dumppath).c_str();
                else {
                    dumpcomment=Message(TXT("Saved dump to '%1'"),dumppath.string()).c_str();
                    retval=EXCEPTION_EXECUTE_HANDLER;
                }
                ::CloseHandle(hfile);
            }
        }
    }

    addmess("************************* Unrecoverable error occurred *******************************");
    addmess(dumpcomment);

    // Give the application a chance to do something
    //FreeFuncImpl::GetInstance()->OnUnrecoverableError();

    return retval;
}


#endif // ! AMGNU

#pragma once


namespace seq
{


typedef std::vector<Str::Text::Val> Codons;

Codons getStartCodons();
Codons getStopCodons();


} // namespace seq

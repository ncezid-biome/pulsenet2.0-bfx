#pragma once

#include <cstdint>
#include "BAMTypes.h"

namespace BAM
{

class LevelFileTypes: public BAMTypes
{

public:

    //offset wrt the start of the file
    typedef uint32_t FileOffset;
    typedef uint64_t BlockAddress;
    //offset wrt the start of the block
    typedef uint16_t BlockOffset;

    typedef uint16_t ReadLevel;
};
}


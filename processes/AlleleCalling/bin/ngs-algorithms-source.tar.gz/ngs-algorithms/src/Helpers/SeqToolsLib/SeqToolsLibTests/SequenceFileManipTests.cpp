#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "SequenceFileManip.h"
#include "TempDirectory.h"
#include "ConsoleLogger.h"
#include "CalcCommunication.h"

using namespace seq;

struct  SequenceFileManipTestsFixture {

    SequenceFileManipTestsFixture(): cl(ConsoleLogger::LogMode::Text), comm(&cl)
    {
    }

    Str::Path::Val GetDataFilePath(const Str::Text::Val& filename)
    {
        //this needs compiler flag /FC to get the full path
        Str::Path::Val thisFile(__FILE__);

        return (thisFile.parent_path() / "Data" / filename);
    }

    TempDirectory tmpDir;

    ConsoleLogger cl;
    communication::CalcCommunication comm;
};

BOOST_FIXTURE_TEST_SUITE( SequenceFileManipTests,  SequenceFileManipTestsFixture );

BOOST_AUTO_TEST_CASE( filter_all_N_contigs )
{
    Str::Path::Val outputFile = tmpDir.path() / "filtered.fasta";
    seq::UnzipSequenceFileForBLAST(GetDataFilePath("all_N.fasta"), outputFile, comm);

    seq::NamedSequence seq;
    FastaFileReader reader(outputFile);

    BOOST_ASSERT(reader.hasMore());
    reader.getNextSeq(seq);
    BOOST_CHECK_EQUAL(seq.GetName(), "has_content_1");
    BOOST_CHECK_EQUAL(seq.GetData().c_str(), "NNNNNNNNNACNNNNNNNNNNN");

    BOOST_ASSERT(reader.hasMore());
    reader.getNextSeq(seq);
    BOOST_CHECK_EQUAL(seq.GetName(), "has_content_2");
    BOOST_CHECK_EQUAL(seq.GetData().c_str(), "AMCTGR");

    BOOST_ASSERT(reader.hasMore());
    reader.getNextSeq(seq);
    BOOST_CHECK_EQUAL(seq.GetName(), "all_but_one_N_1");
    BOOST_CHECK_EQUAL(seq.GetData().c_str(), "NNNNNNNNNNNC");

    BOOST_ASSERT(reader.hasMore());
    reader.getNextSeq(seq);
    BOOST_CHECK_EQUAL(seq.GetName(), "all_but_one_N_2");
    BOOST_CHECK_EQUAL(seq.GetData().c_str(), "ANNNNNNNN");

    BOOST_ASSERT(!reader.hasMore());
}

BOOST_AUTO_TEST_SUITE_END();

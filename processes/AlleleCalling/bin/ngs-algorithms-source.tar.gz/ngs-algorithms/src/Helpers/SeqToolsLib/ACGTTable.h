#pragma once

#include "BoolHelper.h"


namespace seq
{

class ACGTTable
{
public:
    typedef std::vector<char> Table;
private:
    static void Initialize(Table& table) 
    {
        table.resize(256, 0); 
        table['A'] = 1;
        table['C'] = 1;
        table['G'] = 1;
        table['T'] = 1;
    }
    static Table& GetTable() {
        static Table table_;
        static Bool<false> initialized_;
        if (!initialized_) { Initialize(table_); initialized_=true; }
        return table_;
    }
private:
    ACGTTable() {}
public:
    static const Table& Get() { return GetTable(); }
};


} // namespace seq
#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "Sequence.h"
#include "SequenceInspect.h"
#include "SequenceRangeInspect.h"


using namespace seq;


struct SequenceInspectTestsFixture
{
    SequenceInspectTestsFixture()
        : aaaa( PM("aaaa") )
        , acgt( PM("acgt") )
    {
    }

    Sequence aaaa;
    Sequence acgt;
};

BOOST_FIXTURE_TEST_SUITE( SequenceInspectTests, SequenceInspectTestsFixture );


//______________________________________________________________________________
// AreAllBasesACGTacgt

BOOST_AUTO_TEST_CASE( AreAllBasesACGTacgt_aaaa_True )
{
    BOOST_REQUIRE_EQUAL(true, AreAllBasesACGTacgt(aaaa));
}

BOOST_AUTO_TEST_CASE( AreAllBasesACGTacgt_AAAA_True )
{
    Sequence AAAA( PM("AAAA") );
    BOOST_REQUIRE_EQUAL(true, AreAllBasesACGTacgt(AAAA));
}

BOOST_AUTO_TEST_CASE( AreAllBasesACGTacgt_acgt_True )
{
    BOOST_REQUIRE_EQUAL(true, AreAllBasesACGTacgt(acgt));
}

BOOST_AUTO_TEST_CASE( AreAllBasesACGTacgt_acngt_False )
{
    Sequence acngt( PM("acngt") );
    BOOST_REQUIRE_EQUAL(false, AreAllBasesACGTacgt(acngt));
}

//______________________________________________________________________________
// SequenceContains

BOOST_AUTO_TEST_CASE( SequenceContains_acgt_oneletter_True )
{
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("a"))));
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("c"))));
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("g"))));
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("t"))));

    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("A"))));
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("C"))));
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("G"))));
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("T"))));
}

BOOST_AUTO_TEST_CASE( SequenceContains_acgt_n_false )
{
    BOOST_REQUIRE_EQUAL(false, SequenceContains(acgt, Sequence(PM("n"))));
    BOOST_REQUIRE_EQUAL(false, SequenceContains(acgt, Sequence(PM("N"))));
}

BOOST_AUTO_TEST_CASE( SequenceContains_acgt_twoletters_True )
{
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("ac"))));
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("cg"))));
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("gt"))));

    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("AC"))));
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("CG"))));
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("GT"))));
}

BOOST_AUTO_TEST_CASE( SequenceContains_acgt_threeletters_True )
{
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("acg"))));
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("cgt"))));

    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("ACG"))));
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("CGT"))));
}

BOOST_AUTO_TEST_CASE( SequenceContains_acgt_fourletters_True )
{
    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("acgt"))));

    BOOST_REQUIRE_EQUAL(true, SequenceContains(acgt, Sequence(PM("ACGT"))));
}

BOOST_AUTO_TEST_CASE( SequenceContains_acgt_acgta_False )
{
    BOOST_REQUIRE_EQUAL(false, SequenceContains(acgt, Sequence(PM("acgta"))));

    BOOST_REQUIRE_EQUAL(false, SequenceContains(acgt, Sequence(PM("ACGTa"))));
}

BOOST_AUTO_TEST_CASE( CountNonACGT_0 )
{
    BOOST_REQUIRE_EQUAL(0, CountNonACGT(acgt.begin(), acgt.end()));
}

BOOST_AUTO_TEST_CASE( CountNonACGT_4 )
{
    Sequence sequence( PM("ACYYGTYY") );
    BOOST_REQUIRE_EQUAL(4, CountNonACGT(sequence.begin(), sequence.end()));
}

BOOST_AUTO_TEST_CASE( AreaAllBasesN_0_True )
{
    Sequence sequence( PM("") );
    BOOST_REQUIRE_EQUAL(true, AreAllBasesN(sequence));
}

BOOST_AUTO_TEST_CASE( AreaAllBasesN_1_True )
{
    Sequence sequence( PM("N") );
    BOOST_REQUIRE_EQUAL(true, AreAllBasesN(sequence));
}

BOOST_AUTO_TEST_CASE( AreaAllBasesN_10_True )
{
    Sequence sequence( PM("NNNNNNNNNN") );
    BOOST_REQUIRE_EQUAL(true, AreAllBasesN(sequence));
}

BOOST_AUTO_TEST_CASE( AreaAllBasesN_10A_False )
{
    Sequence sequence( PM("NNNNNNNNNNA") );
    BOOST_REQUIRE_EQUAL(false, AreAllBasesN(sequence));
}

BOOST_AUTO_TEST_CASE( AreaAllBasesN_A10_False )
{
    Sequence sequence( PM("ANNNNNNNNNN") );
    BOOST_REQUIRE_EQUAL(false, AreAllBasesN(sequence));
}

BOOST_AUTO_TEST_SUITE_END();

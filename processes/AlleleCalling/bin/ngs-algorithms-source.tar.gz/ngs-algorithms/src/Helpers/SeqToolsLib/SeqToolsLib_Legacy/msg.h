/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

*/

#include <sstream>


#ifndef MSG_H
#define MSG_H

#include "StringDef.h"


class Msg
{
private:
	Str::Text::Val what_;
public:
	Msg() {}
	~Msg() {}

	template<class T>
	Msg& operator <<(const T& val) {
		std::stringstream s; s << val;
		what_ += s.str();
		return *this;
	}

	Str::Text::Ref c_str () const { return ToRef(what_); }
	operator Str::Text::Ref () const  { return ToRef(what_); }
    operator const Str::Text::Val& () const  { return what_; }
    operator Str::Text::Arg  () const  { return what_; }
};

#endif

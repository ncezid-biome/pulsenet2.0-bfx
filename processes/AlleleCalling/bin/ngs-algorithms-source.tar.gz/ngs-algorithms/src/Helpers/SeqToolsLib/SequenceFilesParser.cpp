#include "stdafx.h"

#include "SequenceFilesParser.h"

#include "boost/regex.hpp"

#include "helper.h"


namespace
{


/**
    Implementation: \a pairCandidates is searched for a pair candidate of \a myFile. A pair of paired-end files
    must satisfy the following criteria:

    - Exact same file name length
    - Only one character different
    - The single one differing character must be 1 in the one file, 2 in the other
    - The different character must be the last character in one of the following:
      - _1 and _2
      - _01 and _02
      - _R1 and _R2 or _r1 and _r2
	  - .R1 and .R2 or .r1 and .r2

    Only the file names are used for the comparison, not the paths! This means that e.g. sequence_1 and sequence_2 in
    different paths will be matched to each-other!

    \param otherFilePath Full path of the found paired-end file. Is the input file if none is found.
    \return Whether \a myFile was a paired-end file name
*/
bool getOtherPairedFilename( const Str::Text::Val            myFilePath,
                             const std::set<Str::Text::Val>& pairCandidates,
                             Str::Text::Val&                 otherFilePath
                           )
{
    otherFilePath = myFilePath;

    // myFile: filename only.
    const Str::Text::Val myFile = Str::Path::Val(myFilePath).filename().string();

    for ( const auto& candidatePath : pairCandidates ) {
        // candidate: filename only
        const Str::Text::Val candidate = Str::Path::Val(candidatePath).filename().string();

        // File names must have equal size
        if ( myFile.size() != candidate.size() )
            continue;

        // Find first and last different positions
        int differentChar = -1;
        {
            bool isValid  = true;
            for ( size_t ichar = 0; ichar < myFile.size(); ++ichar ) {
                if ( myFile[ichar] != candidate[ichar] ) {
                    if ( differentChar >= 0 ) {
                        // Found second different char -> not paired-end
                        isValid = false;
                        break;
                    }

                    differentChar = ichar;
                }
            }

            if ( ! isValid )
                continue;
        }

        // Did not find any differences -> same file -> skip
        if ( differentChar < 0 )
            continue;

        // Formatting checks
        if (! (myFile[differentChar] == '1' && candidate[differentChar] == '2') &&
            ! (myFile[differentChar] == '2' && candidate[differentChar] == '1') )
            continue;

		// find marker positions
        int underscoreChar = differentChar;
        for(; underscoreChar >= 0 && myFile[underscoreChar] != '_'; --underscoreChar ) {
        }
		int dotChar = differentChar;
		for (; dotChar >= 0 && myFile[dotChar] != '.'; --dotChar) {}
		
		// pattern marker '_' or '.' no farther than 2 characters of the numeral indicator '1' or '2'
		if ((underscoreChar < differentChar - 2) && (dotChar < differentChar - 2))
            continue;

        // Match _1 _2 _01 _02 _R1 _R2. Later addition, .R1 .R2
		// Note that we do not check explicitly here that we have both
        // _1 and _2 and not _1 and _R2. This is guaranteed however by the requirement that the string
        // sizes are equal + that only one character can differ.
        boost::regex re( PM("[_|.][0|R|r]?[1|2]") );

		// char position where to start trimming, up to different char
		auto const trimmingChar = std::max(underscoreChar, dotChar);
        if (   ! boost::regex_match(   myFile.substr(trimmingChar, differentChar - trimmingChar + 1), re )
            || ! boost::regex_match(candidate.substr(trimmingChar, differentChar - trimmingChar + 1), re ) )
            continue;

        // Got here -> valid paired-end files!
        otherFilePath = candidatePath;
        break;
    }

    return myFilePath != otherFilePath;
}

} // namespace

InputFileParser::InputFileParser()
    : singleFiles_()
    , parsedFiles_()
{
}

void InputFileParser::AddFile(const Str::Text::Val& filepath, bool doSanitizePath)
{
    Str::Text::Vec parts;
    splitstring(filepath, parts, PM("|"));

    for ( auto& part : parts ) {
        Str::Text::Val singleFile = part;

        if (doSanitizePath) sanitizePath(singleFile);

        if ( ! boost::filesystem::exists(singleFile) )
            throw KError( PM("File '%1' does not exist") ) << singleFile;

        if ( ! boost::filesystem::is_regular_file(singleFile) )
            throw KError( PM("File '%1' is not a regular file") ) << singleFile;

        // Add the current part as a local single file
        singleFiles_.insert(singleFile);
    }
}

void InputFileParser::ParseLocalFiles( SequenceFiles& files, bool doSanitizePaths ) const
{
    // Used for lookup and deletions
    std::set<Str::Text::Val> localFilesCopy = singleFiles_;
    std::set<Str::Text::Val> pairedEndFound;

    for ( auto it = singleFiles_.begin(); it != singleFiles_.end(); ++it ) {
        Str::Path::Vec allsinglefiles, allpairedfiles;

        Str::Text::Val p = *it;
        Str::Text::Val p2;

        // If p is a full-fledged path: make sure it is in a format we understand
       if (doSanitizePaths) sanitizePath(p);

        // Have we already processed this file?
        if ( pairedEndFound.find(p) != pairedEndFound.cend() )
            continue;

        bool isPaired = false;
        if ( getOtherPairedFilename(p, localFilesCopy, p2) ) {
            // Got here -> is paired-end file. First check if we already found the other file on disk. Needed
            // to prevent adding the two paired-end files twice.
            if ( localFilesCopy.find(p2) != localFilesCopy.cend() ) {
                isPaired = true;

                pairedEndFound.insert( p  );
                pairedEndFound.insert( p2 );

                // Prevent files from being added twice
                localFilesCopy.erase( p  );
                localFilesCopy.erase( p2 );
            }
        }

        if ( isPaired ) {
			if (p<p2) {
				allpairedfiles.push_back(p);
				allpairedfiles.push_back(p2);
			}
			else {
				allpairedfiles.push_back(p2);
				allpairedfiles.push_back(p);
			}
        }
        else {
            allsinglefiles.push_back(p);
        }

        if (!allsinglefiles.empty()) {
            files.files.resize(files.files.size()+1);
            files.files.back().paired = false;
            files.files.back().filetype = PM("fastq.gz");
            files.files.back().files = allsinglefiles;
        }
        if (!allpairedfiles.empty()) {
            files.files.resize(files.files.size()+1);
            files.files.back().paired = true;
            files.files.back().filetype = PM("fastq.gz");
            files.files.back().files = allpairedfiles;
        }
    }

    singleFiles_.clear();
}

SequenceFiles InputFileParser::GetFiles(bool doSanitizePaths) const
{
    ParseLocalFiles( parsedFiles_, doSanitizePaths);
    return parsedFiles_;
}

/**
    Helper method, provided for testing the getOtherPairedFilename implementation
*/
bool InputFileParser::IsPaired(const Str::Text::Val& file1, const Str::Text::Val& file2)
{
    std::set<Str::Text::Val> candidates;
    candidates.insert( file2 );

    Str::Text::Val otherFile;
    return getOtherPairedFilename( file1, candidates, otherFile );
}

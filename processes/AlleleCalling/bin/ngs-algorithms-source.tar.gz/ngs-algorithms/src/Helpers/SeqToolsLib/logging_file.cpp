/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#include "stdafx.h"
#include "logging_file.h"

#include "exception.h"


LoggerToFile::LoggerToFile(Str::Path::Arg filename)
	: filename_(filename.c_str())
{
	std::ofstream os(ToRef(filename_));
}
LoggerToFile::~LoggerToFile()
{
}
void LoggerToFile::addLog(Str::Text::Arg line)
{
	std::ofstream os(ToRef(filename_), std::ios::app);
	if (!os.is_open())
		throw KError("could not open file %1." ) << filename_;

	os << line << std::endl;
}

#include"stdafx.h"
#include "Blast.h"
#include "runextern_manager.h"
#include "runextern_application.h"
#include "runextern_cmdline.h"
#include "RunExceptions.h"
#include "AlleleFinderExceptions.h"
#include "CE_ExecuteEnvironment.h"
#include "CE_FileSystem.h"
#include "CalcCommunicationImpl.h"
#include "CalcCommunicationReporter.h"

#include "exception.h"
#include "CalcCommunication.h"

#include "CE_FileSystem.h"


#define OPTION_HELP "help"
#define OPTION_SETTINGSFILE "settingsFile"


BlastSettings::BlastSettings()
    : algorithmType         ( PM("dc-megablast") )
    , k                     ( -1 )
    , maxNHits              ( 1000000 )
    , reward                (  2 )
    , penalty               ( -3 )
    , ungapped              ( false )
    , gapopen               ( 5 )
    , gapextend             ( 2 )
    , percentIdentity       ( 70 )
    , doDusting				( true )
	, relMinOverlap			( 0.6 )
{
}
void BlastSettings::addOptions(boost::program_options::options_description& descr)
{
    //add the options
    descr.add_options()
    (OPTION_HELP,
     "produce help message")
    (OPTION_SETTINGSFILE,
     boost::program_options::value<Str::Path::Val>(),
     "settings file")
    ("algorithm",
     boost::program_options::value<Str::ID::Val>(&algorithmType),
     "BLAST algorithm")
    ("db",
     boost::program_options::value<Str::Path::Val>(&dbName),
     "blast database")
    ("k",
     boost::program_options::value<size_t>(&k),
     "keyword size (if set to -1, the default value is used)")
    ("maxNHits",
     boost::program_options::value<size_t>(&maxNHits),
     "maximum number of hits")
    ("reward",
     boost::program_options::value<int>(&reward),
     "match score")	 
    ("penalty",
     boost::program_options::value<int>(&penalty),
     "mismatch score")
	 ("ungapped",
     boost::program_options::value<bool>(&ungapped),
     "allow gapped alignment")	 
    ("gapopen",
     boost::program_options::value<int>(&gapopen),
     "gap open cost")
    ("gapextend",
     boost::program_options::value<int>(&gapextend),
     "gap extend cost")
    ("percentIdentity",
     boost::program_options::value<double>(&percentIdentity),
     "percent identity (0-1)")
     ("doDusting",
	 boost::program_options::value(&doDusting),
     "perform dusting procedure to mask low-complexity regions")
	;

}

Str::Path::Val RunBlast(const Str::Path::Val& fastaFile, const BlastSettings& settings,
				const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm
			)
{
	return RunBlast(fastaFile, settings.algorithmType, settings.dbName, settings.maxNHits, settings.k, 
				settings.percentIdentity, settings.reward, settings.penalty, settings.ungapped, settings.gapopen, 
				settings.gapextend, settings.doDusting, env, comm);

}


Str::Path::Val RunBlast(const Str::Path::Val& fastaFile, const Str::Text::Val& task, const Str::Path::Val& dbName, int maxNHits, int wordSize, 
				double percentIdentity, int reward, int penalty, bool ungapped, int gapopen, int gapextend, bool doDusting,
				const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm
			)
{
	using namespace runextern;

	Str::Path::Val workingDir = env.localDir;
	Str::Path::Val const outputFile = (env.localDir / "blastout.txt");

	 /* --------------------------------------------------------------------------------------------
        BUILD THE BATCH FILE
       -------------------------------------------------------------------------------------------- */

    BatchFile batchFile;
    {
        //--- add the blastn command line ---------------------------------------------------------
        {
            ProcessCmdLine blastn("blastn");
            {
                blastn << "-task" << task;

				auto GetPath = [](Str::Path::Val const & path)
				{
#ifndef AMGNU
					//on Windows, files may reside on shares therefore the full path needs additional padding
					//escapePath also adds double quotes, but thats fine, since it returns a Str::Text and not a Str::Path
					//which means that ProcessCmdLine will not add any
					return engine::escapePath(path);
#else
					return path.string();
#endif
				};

                //the query file
                blastn << "-query" << GetPath(fastaFile);

                //the database
#ifndef AMGNU
				// On Windows the directory names may likely contain spaces and that is not handled well by
				// 'blastn' or at least by the version in use at the time of writing (2.2.28+)
				// the work around this is to ensure the working directory is set to the location of the database
				// all other paths should refer to absolute paths
				Str::Path::Val dbdir(dbName);
				workingDir = dbdir.parent_path();
				blastn << "-db" << dbdir.filename();
#else
				blastn << "-db" << dbName;
#endif

                //the output format
                blastn << "-outfmt" << "7";

                //the output file
                blastn << "-out" << GetPath(outputFile);

                //the number of output lines
                blastn << "-max_target_seqs" << maxNHits;

                //the k-mer size
                if (wordSize!=-1 && wordSize!=0)
                    blastn << "-word_size" << wordSize;

                blastn << "-perc_identity" << percentIdentity;

                blastn << "-reward" << reward;
                blastn << "-penalty" << penalty;

                if (ungapped)
                    blastn << "-ungapped";
                else {
                    blastn << "-gapopen" << gapopen;
                    blastn << "-gapextend" << gapextend;
                }

                //number of threads to use
                blastn << "-num_threads" << env.GetMaxNumThreads();


				//switch off dusting for low-complexity regions
				if (!doDusting)
					blastn << "-dust" << "no";

            }
            batchFile.addLine(blastn);
        }
    }

    /* --------------------------------------------------------------------------------------------
        CREATE THE EXTERNAL APPLICATION
       -------------------------------------------------------------------------------------------- */

    MemoryBatchFileApp app(batchFile);

    /* --------------------------------------------------------------------------------------------
        SET THE ENVIRONMENT PARAMETERS
       -------------------------------------------------------------------------------------------- */

    ProcessInfo info;
    {
        info.setWorkingDir(ToRef(workingDir));
    }

    /* --------------------------------------------------------------------------------------------
        RUN THE APPLICATION
       -------------------------------------------------------------------------------------------- */
    ExternAppManager manager;
    comm.Send( communication::CalcMessage("Running BLAST identification ... "));
    CalcCommunicationReporter user(comm);

    try {
        manager.runApp(app, info, user, false);
    } catch(  ChildProcessExitWithErrorException& e ){
        // Catch exceptions due to abnormal termination of BLAST: nice error message
        throw BLASTNException( e.exitcode );
    }

	return outputFile;
}

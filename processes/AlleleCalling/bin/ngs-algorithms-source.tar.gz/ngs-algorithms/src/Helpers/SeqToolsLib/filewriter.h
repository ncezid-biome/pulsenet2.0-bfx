/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

    ******************************************************
    ADD WRITERS HERE -> ALSO ADD THEM TO fillWriterFactory
    ******************************************************
*/

#ifndef FILEWRITER_H
#define FILEWRITER_H

#include <fstream>

#include "boost/thread/mutex.hpp"

#include "factorycounter.h"
#include "compression.h"
#include "FileWriterFwd.h"
#include "FileWriterChunk.h"



void fillWriterFactory();

class SeqFileWriter : public FactoryPrototypeBase<SeqFileWriter, SeqFileWriterPtr>
                    , public Cloneable<SeqFileWriter>
{
public:
	typedef SeqFileWriterPtr   Ptr;
    typedef FactoryIDType::Val Id;
    typedef FactoryIDType::Ref IdRef;
protected:
	std::ofstream os_;
	CompressedWriter writer_;
protected:
	void writeLine      (Str::Text::Arg line, size_t size);
    void WriteLineAlways(Str::Text::Arg line, size_t size);
    void WriteNewline   ();
public:
	SeqFileWriter();
	SeqFileWriter(const Str::Path::Val& path, bool gzipped=false, size_t  buffsize=5000000);
	virtual ~SeqFileWriter();

	void init(const Str::Path::Val& path, bool gzipped=false, size_t  buffsize=5000000);

	virtual void writeSeq(const Str::Text::Val& name, const Str::Text::Val& seq) =0;
	virtual void writeSeq(const Str::Text::Val& name, const Str::Text::Val& seq, const Str::Text::Val& qual) =0;	
};

class FastaFileWriter : public SeqFileWriter
                      , public LeafClassBase<FastaFileWriter>
{
public:
	static IdRef GetTypeName();
	virtual IdRef GetFactoryType() const override;
	virtual SeqFileWriter::Ptr Clone() const;
public:
	FastaFileWriter();
	FastaFileWriter(const Str::Path::Val& path, bool gzipped=false, size_t  buffsize=5000000);
	~FastaFileWriter();

	virtual void writeSeq(const Str::Text::Val& name, const Str::Text::Val& seq);
	virtual void writeSeq(const Str::Text::Val& name, const Str::Text::Val& seq, const Str::Text::Val& qual);
};

class FastQFileWriter : public SeqFileWriter
{
public:
	FastQFileWriter();
	FastQFileWriter(const Str::Path::Val& path, bool gzipped, size_t  buffsize);
	~FastQFileWriter();

	virtual void writeSeq(const Str::Text::Val& name, const Str::Text::Val& seq);
	virtual void writeSeq(const Str::Text::Val& name, const Str::Text::Val& seq, const Str::Text::Val& qual);
};

class UncompressedFastQFileWriter : public FastQFileWriter
                                  , public LeafClassBase<UncompressedFastQFileWriter>
{
public:
	static IdRef GetTypeName();
	virtual IdRef GetFactoryType() const override;
	virtual SeqFileWriter::Ptr Clone() const override;
public:
	UncompressedFastQFileWriter();
	UncompressedFastQFileWriter(const Str::Path::Val& path, size_t  buffsize=5000000);
	~UncompressedFastQFileWriter();	
};


class GZippedFastQFileWriter : public FastQFileWriter
                             , public LeafClassBase<GZippedFastQFileWriter>
{
public:
	static IdRef GetTypeName();
	virtual IdRef GetFactoryType() const override;
	virtual SeqFileWriter::Ptr Clone() const override;
public:
	GZippedFastQFileWriter();
	GZippedFastQFileWriter(const Str::Path::Val& path, size_t  buffsize=5000000);
	~GZippedFastQFileWriter();
};


class ThreadSafeFileWriters
{
public:
    typedef FileWriterChunk Chunk;

private:
	std::vector<SeqFileWriter::Ptr> writers_;	
private:	
	boost::mutex mutex_;
public:
	ThreadSafeFileWriters();
	ThreadSafeFileWriters(SeqFileWriter::Id type, const Str::Path::Vec& paths, bool gzipped=false, size_t  buffsize=5000000);
	ThreadSafeFileWriters(std::vector<SeqFileWriter::Ptr> writers);

	void		clear();
	size_t		size() const;
	void		push_back(SeqFileWriter::Ptr writer);
	
	void		writeChunks(const std::vector<Chunk>& chunk);
	//const SeqFileWriter* getWriter() const; 
};

#endif
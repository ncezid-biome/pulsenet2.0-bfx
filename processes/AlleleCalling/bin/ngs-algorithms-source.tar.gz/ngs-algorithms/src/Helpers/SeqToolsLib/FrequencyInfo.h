#ifndef FREQUENCYINFO_H
#define FREQUENCYINFO_H

#include "StringDef.h"
#include "intdef.h"

class FrequencyInfo {
public:
	class ScreenData {
public:
	ScreenData() {}
	ScreenData(Str::Text::Arg name, size_t index) {}
};
public:
	UInt32 fwdFreq, revFreq;
public:
	FrequencyInfo() : fwdFreq(0), revFreq(0) {}		
	FrequencyInfo(Str::Text::Arg name, size_t index) : fwdFreq(0), revFreq(0) {}
		
	inline void loadSeq(Str::Text::Arg sequence, size_t size) {}
	inline void add(const FrequencyInfo& data, size_t pos, bool fwd) {
		fwdFreq+=fwd;
		revFreq+=(!fwd);
	}
	inline void screen(const ScreenData& data, size_t pos, bool fwd) {
	}
	inline void toStream(std::ostream& os) const {
		os.write((const char*)(&fwdFreq), sizeof(UInt32));
		os.write((const char*)(&revFreq), sizeof(UInt32));
	}
	inline void fromStream(std::istream& is) {
		is.read((char*)(&fwdFreq), sizeof(UInt32));
		is.read((char*)(&revFreq), sizeof(UInt32));
	}
	inline size_t getFwd() const { return fwdFreq; }
	inline size_t getRev() const { return revFreq; }
	inline size_t getFreq() const { return fwdFreq + revFreq; }
};

#endif
#include "stdafx.h"

#include "AlleleInfoFile.h"
#include <set>

#include "strdef.h"
#include "PathDef.h"
#include "IBuffImpl.h"

#include "CalcCommunicationImpl.h"

#include "AlleleFinderExceptions.h"

#include "filereader.h"
#include "CE_LogAction.h"
#include "CodonManip.h"

using namespace seq;


AlleleInfoFile::AlleleInfoFile( const Str::Path::Val& baseName, const communication::CalcCommunication& comm )
    : alleleRotator_( baseName, 2, comm )
    , fileName_     ()
{
    UpdateFilename();
}

/**
    Writes a new allele info file, i.e. does not overwrite the current but writes
    a new rotation, then updates the current rotation link.

    Note that writing a new file points the current info file to this new file!
*/
void AlleleInfoFile::Write(const SeqFileReader& reader, const Str::Text::Vec& startCodons, const Str::Text::Vec& stopCodons, const communication::CalcCommunication& comm )
{
    Str::Path::Val infoFileName = alleleRotator_.GetNextFile();

    {
        engine::LogAction action(
            comm,
            RawMessage(PM("Writing allele info file '%1'"), ToRef(infoFileName) ).c_str() );

        std::ofstream os( ToRef(infoFileName) );
        {	
            while(reader.hasMore()){
                NamedSequence sequence;
                reader.getNextSeq(sequence);

                Str::Text::Val locus = sequence.GetName().substr(0, sequence.GetName().find_last_of('_'));
                bool hasStartStop = StartsAndEndsWithCodons(sequence.GetData(), startCodons, stopCodons)
                    && (sequence.GetData().GetLength() % 3 == 0);

                os << sequence.GetName() << '\t' << locus << '\t' << sequence.GetData().GetLength() << '\t' << (hasStartStop?'1':'0') << '\n';  
            }
        }
    }

    {
        // Update the link file
        alleleRotator_.RotateLinkfile( comm );
    }

    // Now let ourself point to the new file
    UpdateFilename();
}

Str::Path::Val AlleleInfoFile::GetFilename() const
{
    return alleleRotator_.GetCurrentFile();
}

void AlleleInfoFile::UpdateFilename()
{
    fileName_ = alleleRotator_.GetCurrentFile();
}


void LoadAlleleDescriptors(const Str::Path::Val& flName, LocusList& loci, AlleleDescriptors& descriptors, const communication::CalcCommunication& comm)
{
    comm.Send( communication::CalcMessage("Reading allele information ... "));
    std::set<Str::Text::Val> myLoci;
    //read in the allele info file
    TextFileBuffer is( ToRef(flName) );
    is.Open();
    Str::Text::Val line;
    Str::Text::Vec parts;
    while (is.IsOk()) 
    {
        is.ReadLine(line);            
        if (line.empty()) continue;

        splitstring(line, parts, "\t");
        if (parts.size()==4) 
        {
            descriptors[parts[0]] = AlleleDescriptor(parts[1], ParseThrow<size_t>(parts[2]), ParseThrow<int>(parts[3])!=0);
            if (myLoci.find(parts[1]) == myLoci.end()) 
            {
                loci.push_back(parts[1]);
                myLoci.insert(parts[1]);
            }
        }
        else 
        {
            throw MalformedAlleleFileException(RawMessage(PM("Malformed allele information. Expected 4 columns, got '%1'"), line));
        }
    }
}

#pragma once
#include <boost/interprocess/mapped_region.hpp>
#include <PathDef.h>
#include "SAMWrapper.h"
#include "BAMPileFileTypes.h"

namespace BAM
{

class STW_DLLPORT PileFileReader: protected PileFileTypes
{

public:
    PileFileReader(): referenceCount_(0), positions_(nullptr), references_(nullptr) {}

    void Open(const Str::Path::Val& file);
    void Close();

    DrawPosition GetLength(ReferenceID refID) const;
    FullPileHeight GetMaxHeight(ReferenceID refID) const;

    FullPileHeight GetFwdCoverageAt(ReferenceID refID, DrawPosition pos) const;
    FullPileHeight GetRevCoverageAt(ReferenceID refID, DrawPosition pos) const;
    FullMateDistance GetMateDistanceAt(ReferenceID refID, DrawPosition pos) const;

    FullPileHeight GetMaxFwdCoverage(ReferenceID refID) const;
    FullPileHeight GetMaxRevCoverage(ReferenceID refID) const;
    MateDistanceInfo GetMateDistanceInfo(ReferenceID refID) const;

    ReferencePosition DrawPositionToReferencePosition(ReferenceID refID, DrawPosition drawPos, bool clip) const;

    DrawPosition ReferencePositionToDrawPosition(ReferenceID refID, ReferencePosition refPos, bool extendBeyondReference = false) const;

protected:

    bool inline IsInRange(ReferenceID refID, DrawPosition position) const
    {

        return refID < referenceCount_ && position < references_[refID].length;
    }

    template<int M> inline uint32_t UnscaleIfScaled(uint32_t input, uint32_t max) const
    {
        if(max > M)
            return ((uint64_t)input) * max / M;
        else
            return (uint32_t)input;
    }

private:
    PileFileReader(const PileFileReader&);
    PileFileReader& operator=(const PileFileReader&);

private:

    size_t referenceCount_;

    boost::interprocess::mapped_region mappedRegion_;
    const ReferenceCoverageInfo* references_;
    const PositionInfo* positions_;
};

}
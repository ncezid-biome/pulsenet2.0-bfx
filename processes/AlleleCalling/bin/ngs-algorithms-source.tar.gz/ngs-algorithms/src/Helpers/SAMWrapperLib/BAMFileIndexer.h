#pragma once
#include <PathDef.h>
#include "SAMWrapper.h"
#include "BAMFileResolver.h"

namespace BAM
{

class STW_DLLPORT FileIndexer
{
public:

    bool HasIndex(FileResolver::Ptr files);
    void CreateIndexFile(FileResolver::Ptr files);

private:
    bool CheckFileProperties(FileResolver::Ptr files);
};

}
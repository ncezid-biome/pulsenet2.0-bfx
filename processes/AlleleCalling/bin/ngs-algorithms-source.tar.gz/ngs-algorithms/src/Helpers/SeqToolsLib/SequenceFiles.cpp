#include "stdafx.h"

#include "SequenceFiles.h"

#include "CalcCommunicationImpl.h"



bool SequenceFiles::isEmpty() const
{
    return files.empty();
}

void SequenceFiles::merge(const SequenceFiles& other)
{
    files.insert(files.end(), other.files.begin(), other.files.end());
}

void SequenceFiles::Log(const Str::Text::Val& info, const communication::CalcCommunication& comm) const
{
    using namespace communication;

    comm.Send( CalcMessage( RawMessage(PM("%1:"), info).c_str()) );
    for ( auto& fileList : files ) {
        comm.Send( CalcMessage( RawMessage(PM("  -> Type: %1\t Paired: %2:"),
            fileList.filetype, fileList.paired ).c_str()) );

        for ( auto& file : fileList.files ) {
            comm.Send( CalcMessage( RawMessage(PM("\t- %1"), file.string()).c_str()) );
        }
    }

    if(files.size() <= 0)
        comm.Send( communication::CalcMessage("\tNone"));

}

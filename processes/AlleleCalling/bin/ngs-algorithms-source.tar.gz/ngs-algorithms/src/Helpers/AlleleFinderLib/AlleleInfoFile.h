#pragma once

#include "HashMap.h"

#include "boost/shared_ptr.hpp"

#include "StringDef.h"
#include "PathDef.h"
#include "CalcCommunication.h"

#include "FileRotator.h"

class SeqFileReader;


/**
    Contains information about all the alleles, in three columns:
    - Allele name
    - Allele locus
    - Allele sequence length
*/
class AlleleInfoFile
{
public:
    typedef boost::shared_ptr<AlleleInfoFile> Ptr;
    typedef boost::shared_ptr<const AlleleInfoFile> ConstPtr;

public:
    AlleleInfoFile( const Str::Path::Val& baseName, const communication::CalcCommunication& comm );

    Str::Path::Val GetFilename() const;
    void           Write( const SeqFileReader& reader, const Str::Text::Vec& startCodons, const Str::Text::Vec& stopCodons, const communication::CalcCommunication& comm );

private:
    void UpdateFilename();

private:
    /**
        Store the filename at once -> if the current link rotation changes we still have the
        same file.
    */
    Str::Path::Val    fileName_;
    SingleFileRotator alleleRotator_;
};


struct AlleleDescriptor {
    Str::ID::Val locus;
    size_t length;
    bool hasstartstop;
    AlleleDescriptor() : length(0) {}
    AlleleDescriptor(Str::ID::Arg ilocus, size_t ilength, bool ihasstartstop) : locus(ilocus),  length(ilength), hasstartstop(ihasstartstop) {}
};

typedef std::hash_map<Str::ID::Val, AlleleDescriptor> AlleleDescriptors;
typedef Str::Text::Vec LocusList;
	
void LoadAlleleDescriptors(const Str::Path::Val& flName, LocusList& loci, AlleleDescriptors& descriptors, const communication::CalcCommunication& calc);
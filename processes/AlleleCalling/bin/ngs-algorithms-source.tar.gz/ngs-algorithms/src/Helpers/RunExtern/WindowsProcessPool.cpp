#include "stdafx.h"

#include "WindowsProcessPool.h"



namespace runextern
{


WindowsProcessPool::WindowsProcessPool()
{
}


WindowsProcess* WindowsProcessPool::CreateProcess()
{
    return new WindowsProcess();
}


} // namespace runextern

#pragma once
#include <SAMToolsLib.h>
#include <boost/shared_ptr.hpp>
#include "SAMWrapper.h"

namespace BAM
{

class STW_DLLPORT ConsensusCaller
{

public:

    typedef boost::shared_ptr<ConsensusCaller> Ptr;

public:

    class STW_DLLPORT Settings
    {

    public:
        Settings():
            minCoverage(10),
            minFwdCoverage(5),
            minRevCoverage(5),

            gapThreshold(50),
            singleThreshold(75),
            doubleThreshold(85),
            tripleThreshold(95),

            keepFrame(false)
        {
        }

    public:
        int minCoverage;
        int minFwdCoverage;
        int minRevCoverage;

        int gapThreshold;
        int singleThreshold;
        int doubleThreshold;
        int tripleThreshold;

        bool keepFrame;
    };

public:

    const static char GAP = '-';
    const static char INSUFFICIENT_COVERAGE = '-';

public:

    ConsensusCaller(Settings settings): settings_(settings)
    {
    }

    char GetConsensusBase(int n, const bam_pileup1_t pl[], int offset);

private:
    const Settings settings_;
};

}

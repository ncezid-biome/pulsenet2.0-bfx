#pragma once

#include "runextern_listener.h"
#include "runextern_process.h"


namespace runextern
{


/**
    Listen to a running application, handles communication with that process through a 
    UserBreak object.
*/
class ExternAppListener : public Listener
{
private:
    int             expectedruntime_;
    double          factor_;
    Process::Memory maxmemory_;
    bool            interpretXml_;

private:
    virtual bool checkMemoryUsage() override;
    virtual void handleMessage(const Str::Text::Val& message, Reporter& comm) override;
    virtual void handleProgress(int millisecs, Reporter& comm) override;
    virtual void handleEnd(ErrorCode lasterror, Reporter& comm) override;
    virtual void handleOutOfMemory(Reporter& comm) override;

    void killProcess(ErrorCode errorcode);

public:
    ExternAppListener(Process::Ptr process, const ProcessInfo& info, bool interpretXml=false);
};


} // namespace runextern

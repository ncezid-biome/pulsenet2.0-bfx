#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "SequenceFileName.h"
#include "TestSequenceFiles.h"


BOOST_AUTO_TEST_SUITE( SequenceFileNameTests );

BOOST_AUTO_TEST_CASE( EmptyFile_DoesNotExist )
{
    SequenceFileName filename;
    BOOST_CHECK( ! filename.Exists() );
}

BOOST_AUTO_TEST_CASE( ExistingFile_Exists )
{
    const test::SequenceFile seqfile = test::SequenceFiles::GetFiveSeqsFile_Fasta(Compression::None);

    SequenceFileName filename( seqfile.filename );
    BOOST_CHECK( filename.Exists() );
}

BOOST_AUTO_TEST_CASE( ReplaceExtension_StripsExtension )
{
    SequenceFileName filename( PM("My_filename.fasta.gz") );
    filename.ReplaceExtension();
    BOOST_CHECK_EQUAL( filename.ToString(), PM("My_filename") );
}

BOOST_AUTO_TEST_CASE( ReplaceExtension_NameWithDots_StripsExtension )
{
    SequenceFileName filename( PM("My.filename.fasta.gz") );
    filename.ReplaceExtension();
    BOOST_CHECK_EQUAL( filename.ToString(), PM("My.filename") );
}

BOOST_AUTO_TEST_CASE( ReplaceExtension_gzonly_StripsExtension )
{
    SequenceFileName filename( PM("My_filename.gz") );
    filename.ReplaceExtension();
    BOOST_CHECK_EQUAL( filename.ToString(), PM("My_filename") );
}

BOOST_AUTO_TEST_CASE( ReplaceExtension_fastaonly_StripsExtension )
{
    SequenceFileName filename( PM("My_filename.fasta") );
    filename.ReplaceExtension();
    BOOST_CHECK_EQUAL( filename.ToString(), PM("My_filename") );
}

BOOST_AUTO_TEST_CASE( ReplaceExtension_fastaToFastQ )
{
    SequenceFileName filename( PM("My_filename.fasta.gz") );
    filename.ReplaceExtension( PM("fastq.gz") );
    BOOST_CHECK_EQUAL( filename.ToString(), PM("My_filename.fastq.gz") );
}

BOOST_AUTO_TEST_CASE( ReplaceExtension_fastaToFastQ_withdot )
{
    SequenceFileName filename( PM("My_filename.fasta.gz") );
    filename.ReplaceExtension( PM(".fastq.gz") );
    BOOST_CHECK_EQUAL( filename.ToString(), PM("My_filename.fastq.gz") );
}

BOOST_AUTO_TEST_SUITE_END();

#include "stdafx.h"

#include "CdsFilter.h"
#include "SnpUtil.h"
#include "SnpSequenceData.h"

#include "Message.h"

namespace snp
{

Str::Text::Val CdsFilter::GetSnpDisplayInfo(const SnpCache& snp, const SequenceSnpData& sequenceSnps, const SequenceData&) const 
{
    assert(snp.index < sequenceSnps.mutations.size());
    const Mutation& mutation = sequenceSnps.mutations[snp.index];

    if (mutation.isIntergenic())
    {
        return PM("intergenic");
    }
    else if (mutation.isMissense())
    {
        assert(mutation.from != 0 && mutation.to != 0);
        return pm("%1 to %2").arg(mutation.from).arg(mutation.to);
    }
    else
    {
        assert(mutation.isSynonymous());
        assert(mutation.from != 0);
        return pm("%1").arg(mutation.from);
    }
}

double CdsFilter::GetSnpSortValue(const SnpCache& snp, const SequenceSnpData& sequenceSnps, const SequenceData&) const 
{
    assert(snp.index < sequenceSnps.size());
    const Mutation& mutation = sequenceSnps.mutations[snp.index];
    return (mutation.from != mutation.to ? 1 << 16 : 0) | (mutation.from << 8) | mutation.to;
}

} // namespace snp

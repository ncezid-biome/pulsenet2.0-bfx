#include "stdafx.h"

#include "CE_StringManip.h"

#include "boost/algorithm/string/classification.hpp"
#include "boost/algorithm/string/predicate.hpp"

#include "boost/date_time/posix_time/posix_time.hpp"
#include "boost/date_time/time_clock.hpp"

namespace engine
{

namespace tools
{


Str::Text::Val getFormattedTimeString()
{
    boost::posix_time::ptime now = boost::posix_time::second_clock::universal_time();

    char timeString[20];

    sprintf(
        timeString,
        PM("%.4d-%.2d-%.2d %.2d:%.2d:%.2d"),
        static_cast<int>(now.date().year()),
        static_cast<int>(now.date().month()),
        static_cast<int>(now.date().day()),
        static_cast<int>(now.time_of_day().hours()),
        static_cast<int>(now.time_of_day().minutes()),
        static_cast<int>(now.time_of_day().seconds()) );

    return timeString;
}


} // namespace tools

} // namespace engine

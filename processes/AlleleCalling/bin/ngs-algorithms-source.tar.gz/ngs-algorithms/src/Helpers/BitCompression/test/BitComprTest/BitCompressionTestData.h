#pragma once

#include "PathDef.h"


class BitCompressionTestData
{
public:
    static Str::Path::Val GetLargeFlexstorageFile1();

private:
    static Str::Path::Val GetBitCompressionFiledir();
};

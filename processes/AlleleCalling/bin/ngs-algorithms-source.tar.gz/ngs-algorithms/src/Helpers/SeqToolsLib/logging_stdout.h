/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#include "strdef.h"
#include "logging.h"

#ifndef LOGGING_STDOUT_H
#define LOGGING_STDOUT_H

class LoggerToStdOut: public Logger{
public:
	LoggerToStdOut();
	~LoggerToStdOut();

	void addLog(Str::Text::Arg line);
};

#endif
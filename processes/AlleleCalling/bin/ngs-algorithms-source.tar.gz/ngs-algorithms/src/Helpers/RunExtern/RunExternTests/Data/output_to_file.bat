@echo off

echo I feel the heat wave and I like it
echo %*

REM Do a ping of 2 to get 1 seconds
@ping -n 2 127.0.0.1 >nul

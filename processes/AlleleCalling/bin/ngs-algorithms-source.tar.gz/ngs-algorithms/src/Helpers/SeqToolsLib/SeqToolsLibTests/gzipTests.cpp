#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "filereader.h"
#include "filewriter.h"

#include "TestSequenceFiles.h"
#include "OutputManager.h"

using namespace seq;


struct gzipTestFicture
{
};

BOOST_FIXTURE_TEST_SUITE( gzipTests, gzipTestFicture );


BOOST_AUTO_TEST_CASE(gzip_fastq_WriteEmpty_ReadEmpty)
{
    Str::Path::Val filename = test::OutputManager::PrepareOutputFile( PM("WriteEmpty_ReadEmpty.fastq.gz") );

    {
        GZippedFastQFileWriter writer( filename.string() );
    }

    {
        FastQFileReader reader( filename.string() );
        BOOST_CHECK( ! reader.hasMore() );
    }
}

BOOST_AUTO_TEST_CASE(gzip_fastq_WriteEmpty_GetSeqReturnsEmpty)
{
    Str::Path::Val filename = test::OutputManager::PrepareOutputFile( PM("WriteEmpty_GetSeqReturnsEmpty.fastq.gz") );

    {
        GZippedFastQFileWriter writer( filename.string() );
    }

    {
        FastQFileReader reader( filename.string() );
        seq::NamedSequence sequence;

        BOOST_CHECK      ( ! reader.hasMore() );
        reader.getNextSeq( sequence );

        BOOST_CHECK_EQUAL( sequence.GetName(), Str::Text::Val() );
        BOOST_CHECK_EQUAL( sequence.GetData(), seq::Sequence("") );
        BOOST_CHECK      ( ! reader.hasMore() );
    }
}

BOOST_AUTO_TEST_CASE(gzip_fastq_ReadWriteSingleSeq)
{
    const Str::Path::Val filename = test::OutputManager::PrepareOutputFile( PM("ReadWriteSingleSeq.fastq.gz") );
    const Str::Text::Val name     = PM("Small");
    const Str::Text::Val sequence = PM("ACGT");
    const Str::Text::Val quality  = PM("!''*");

    {
        GZippedFastQFileWriter writer( filename.string() );
        writer.writeSeq( name, sequence, quality );
    }

    {
        FastQFileReader reader( filename.string() );
        Str::Text::Val tname;
        Str::Text::Val tseq;
        Str::Text::Val tqual;
        reader.getNextSeq( tname, tseq, tqual );

        BOOST_CHECK_EQUAL( name,     tname );
        BOOST_CHECK_EQUAL( sequence, tseq );
        BOOST_CHECK_EQUAL( quality,  tqual );
        BOOST_CHECK      ( ! reader.hasMore() );
    }
}

BOOST_AUTO_TEST_CASE(gzip_fastq_ReadEmpty_GetSeqReturnsEmpty)
{
    const test::SequenceFile seqfile = test::SequenceFiles::GetEmptySequenceFile_Fastq(Compression::gzip);

    {
        FastQFileReader reader( seqfile.filename.string() );
        seq::NamedSequence sequence;

        BOOST_CHECK      ( ! reader.hasMore() );
        reader.getNextSeq( sequence );

        BOOST_CHECK_EQUAL( sequence.GetName(), Str::Text::Val() );
        BOOST_CHECK_EQUAL( sequence.GetData(), seq::Sequence("") );
        BOOST_CHECK      ( ! reader.hasMore() );
    }
}

BOOST_AUTO_TEST_CASE(gzip_fastq_ReadSingleSeq_Ok)
{
    const test::SequenceFile seqfile = test::SequenceFiles::GetSingleLineSequenceFile_Fastq(Compression::gzip);

    {
        FastQFileReader reader( seqfile.filename.string() );

        seq::NamedSequence sequence;
        reader.getNextSeq( sequence );

        BOOST_CHECK_EQUAL( seqfile.sequences[0].name, sequence.GetName() );
        BOOST_CHECK_EQUAL( Sequence(seqfile.sequences[0].sequence), sequence.GetData() );
        BOOST_CHECK      ( ! reader.hasMore() );
    }
}

BOOST_AUTO_TEST_CASE(gzip_fasta_ReadFiveSeqs_Ok)
{
    const test::SequenceFile seqfile = test::SequenceFiles::GetFiveSeqsFile_Fasta(Compression::gzip);

    {
        FastaFileReader reader( seqfile.filename.string() );

        for ( auto& sequence : seqfile.sequences ){
            NamedSequence rsequence;
            reader.getNextSeq( rsequence );

            BOOST_CHECK_EQUAL( sequence.name, rsequence.GetName() );
            BOOST_CHECK_EQUAL( Sequence(sequence.sequence), rsequence.GetData() );
        }

        BOOST_CHECK( ! reader.hasMore() );
    }
}

BOOST_AUTO_TEST_SUITE_END();

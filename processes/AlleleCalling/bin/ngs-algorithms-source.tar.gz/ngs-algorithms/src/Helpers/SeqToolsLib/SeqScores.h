#pragma once
#include "phred.h"
#include <boost/smart_ptr.hpp>

namespace seq
{

class SeqScores
{
public:
    typedef boost::shared_ptr<SeqScores> Ptr;

public:

    SeqScores(size_t size): size_(size)
    {

    }

    virtual double p(size_t idx) const = 0;

    virtual Ptr CreateNew(size_t size) const = 0;

    virtual void Shrink(size_t size) = 0;

    Ptr Reverse() const
    {
        Ptr reversed = this->CreateNew(size_);

        for (size_t m = 0; m < size_; m++) {

            reversed->Set(m, Get(size_ - m - 1));
        }
        return reversed;
    }

    Ptr Copy() const
    {
        Ptr copy = this->CreateNew(size_);

        for (size_t m = 0; m < size_; m++) {

            copy->Set(m, Get(m));
        }
        return copy;
    }

    virtual void Set(size_t idx, char c) = 0;

    virtual char Get(size_t idx) const = 0;

    Str::Text::Val ToString() const
    {
        Str::Text::Val qual(size_, '\0');

        for(size_t m = 0; m < size_; m++) {
            qual[m] = Get(m);
        }

        return qual;
    }

    size_t GetSize() const
    {
        return size_;
    }

protected:
    size_t size_;
};

class CharSeqScores: public SeqScores
{

public:

    CharSeqScores(const char* scores): SeqScores(strlen(scores)), scores_(scores)
    {
    }

    CharSeqScores(const char* scores, size_t size): SeqScores(size), scores_(scores)
    {
    }

    CharSeqScores(size_t size): SeqScores(size), scoresUnique_(new char[size]), scores_(scoresUnique_.get())
    {
        //scores_ is != nullptr if initialised properly: this depends on the order of the member variables declaration http://stackoverflow.com/a/1242845
        ASSERT(scores_);
    }

    inline double p(size_t idx) const
    {
        //transform '!',... into 0,... and cap at 63
        return errorprobs[(scores_[idx] - '!') & 0x3F];
    }

    const char* GetRawChars()
    {
        return scores_;
    }

    Ptr CreateNew(size_t size) const
    {
        return boost::make_shared<CharSeqScores>(size);
    }

    void Shrink(size_t size)
    {
        ASSERT(size <= size_);
        ASSERT(scoresUnique_);

        if(scoresUnique_ && size < size_) {
            scoresUnique_[size] = '\0';
            size_ = size;
        }
    }

    void Set(size_t idx, char c)
    {
        ASSERT(scoresUnique_);

        if(scoresUnique_) {
            scoresUnique_[idx] = c;
        }
    }

    char Get(size_t idx) const
    {
        return scores_[idx];
    }

private:
    //do not reorder these two
    std::unique_ptr<char[]> scoresUnique_;
    const char* const scores_;
};

}


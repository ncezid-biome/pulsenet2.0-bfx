#pragma once

#include "StringDef.h"


class FileWriterChunk
{
private:		
    std::vector<std::string> names_, sequences_, qualities_;
    size_t size_, chunkSize_;
public:
    FileWriterChunk () : chunkSize_(0), size_(0) {}

    inline void init(size_t chunkSize) { 
        if (chunkSize_!=chunkSize) {
            chunkSize_=chunkSize;
            names_.resize(chunkSize);			
            sequences_.resize(chunkSize);	
            qualities_.resize(chunkSize);				
        }
        size_ = 0;
    }
    inline void reset() {
        size_ = 0;
    }
    inline void addOne() {
        size_+=1;
    }
    inline Str::Text::Val& getCurrentName() {
        return names_[size_-1];
    }
    inline Str::Text::Val& getCurrentSeq() {
        return sequences_[size_-1];
    }	
    inline Str::Text::Val& getCurrentQual() {
        return qualities_[size_-1];
    }
    inline size_t maxSize() const { 
        return chunkSize_; 
    }
    inline size_t size() const { 
        return size_; 
    }
    inline const Str::Text::Val& getName(size_t i) const {
        return names_[i];
    }
    inline const Str::Text::Val& getSeq(size_t i) const {
        return sequences_[i];
    }
    inline const Str::Text::Val& getQual(size_t i) const {
        return qualities_[i];
    }		
};

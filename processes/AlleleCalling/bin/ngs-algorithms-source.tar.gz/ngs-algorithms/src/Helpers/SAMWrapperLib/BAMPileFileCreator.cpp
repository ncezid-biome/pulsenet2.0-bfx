#include "stdafx.h"
#include <fstream>
#include <iostream>
#include <iosfwd>
#include "BAMPileFileCreator.h"
#include <vector>

namespace BAM
{

void PileFileCreator::AddPositionInfo(ReferencePosition pos, FullPositionInfo& fpi)
{

    positions_.push_back(fpi);
}

int PileFileCreator::PileupCallback(ReferenceID refId, ReferencePosition pos, int n, const bam_pileup1_t pl[])
{

    int max_ins=0;

    FullPositionInfo positionInfo;

    // calculate maximum insert
    for(int i=0; i<n; ++i) {
        if (pl[i].indel > 0 && max_ins < pl[i].indel)
            max_ins=pl[i].indel;
    }

    //this draw position corresponds to the following reference position
    positionInfo.refPosition=pos;

    //count the number of reads that contribute an actual base to the pile
    positionInfo.fwdCoverage = 0;
    positionInfo.revCoverage = 0;
    for(int i=0; i<n; ++i) {

        if(!pl[i].is_del) {

            if(bam1_strand(pl[i].b))
                positionInfo.revCoverage++;
            else
                positionInfo.fwdCoverage++;
        }
    }

    maxFwdCoverage_ = std::max(maxFwdCoverage_, positionInfo.fwdCoverage);
    maxRevCoverage_ = std::max(maxRevCoverage_, positionInfo.revCoverage);

    //determine median mate position
    {
        std::vector<ReferencePosition> distances;

        for(int i = 0; i < n; ++i) {

            //tlen is called isize, how odd
            if(pl[i].b->core.isize != 0) {

                ReferencePosition distance = std::abs(pl[i].b->core.isize);
                distance = std::min(distance, GetFileHeader()->target_len[refId] - distance);

                distances.push_back(distance);
            }
        }

        if(distances.size() > 0) {

            const size_t middle = distances.size() / 2;
            std::nth_element(distances.begin(), distances.begin() + middle, distances.end());

            positionInfo.mateDistance = distances[middle];
        }
        else
            positionInfo.mateDistance = 0;

        //remember largest median distance globally
        maxMateDistance_ = std::max(maxMateDistance_, positionInfo.mateDistance);
    }

    AddPositionInfo(pos, positionInfo);

    ////process the inserts that immediately follow this line

    for(int j = 1; j <= max_ins; j++) {

        positionInfo.fwdCoverage = 0;
        positionInfo.revCoverage = 0;

        for (int i = 0; i < n; ++i) {

            if(j <= pl[i].indel) {

                if(bam1_strand(pl[i].b))
                    positionInfo.revCoverage++;
                else
                    positionInfo.fwdCoverage++;
            }
        }

        AddPositionInfo(pos, positionInfo);
    }

    return 0;
}

void PileFileCreator::CreatePileFile(FileResolver::Ptr files)
{
    OpenFile(files);
    const uint16_t refCount=GetFileHeader()->n_targets;

    std::ofstream output(files->GetBAMPileFile().string(), std::ios::binary);

    //write file header: magic + number of references
    Header header= { {'B', 'P', 'F', '0'}, refCount };
    output.write((char*)&header, sizeof(Header));

    //reserve space for the reference information
    output.seekp(sizeof(Header)+refCount*sizeof(ReferenceCoverageInfo));

    //for every reference, this struct will be written to file, just after the header
    ReferenceCoverageInfo refInfo= { 0, 0, 0 };

    for(size_t m=0; m<refCount; m++) {

        maxFwdCoverage_ = 0;
        maxRevCoverage_ = 0;
        maxMateDistance_ = 0;
        positions_.clear();
        CreatePileup(m, 0, GetFileHeader()->target_len[m]-1);

        //calculate distances median and MAD
        {
            std::vector<int32_t> values;
            values.reserve(positions_.size());
            
            for(auto it=positions_.cbegin(); it!=positions_.cend(); ++it) {

                //ignore zeros to display truncated BAM files properly
                if(it->mateDistance) {
                    values.push_back(it->mateDistance);
                }
            }

            const size_t middle = values.size() / 2;

            //find (approximate) median
            {
                std::nth_element(values.begin(), values.begin() + middle, values.end());
                refInfo.mateDistanceInfo.median = values[middle];
            }

            //calculate mad
            {
                const int32_t median=refInfo.mateDistanceInfo.median;

                std::transform (values.begin(), values.end(), values.begin(), [median](int32_t val) {
                    return std::abs(median-val);
                });

                std::nth_element(values.begin(), values.begin() + middle, values.end());
                refInfo.mateDistanceInfo.mad = values[middle];
            }

            //limit range to something more moderate than actual maximum
            refInfo.mateDistanceInfo.rangeMax = std::min(maxMateDistance_, refInfo.mateDistanceInfo.median + std::max(refInfo.mateDistanceInfo.median, 5 * refInfo.mateDistanceInfo.mad));
            refInfo.mateDistanceInfo.max = maxMateDistance_;
        }

        //write pile data to file
        for(auto it=positions_.cbegin(); it!=positions_.cend(); ++it) {

            const FullPositionInfo& fpi=*it;

            PositionInfo pi;
            pi.refPosition=fpi.refPosition;

            //only scale height if necessary
            pi.fwdCoverage = ScaleIfNeeded<MAXHEIGHT, PileHeight>(fpi.fwdCoverage, maxFwdCoverage_);
            pi.revCoverage = ScaleIfNeeded<MAXHEIGHT, PileHeight>(fpi.revCoverage, maxRevCoverage_);
            pi.mateDistance = ScaleIfNeeded<MAXDISTANCE, MateDistance>(fpi.mateDistance, refInfo.mateDistanceInfo.rangeMax);

            output.write((char*)&pi, sizeof(PositionInfo));
        }

        refInfo.length=positions_.size();
        refInfo.maxFwdCoverage = maxFwdCoverage_;
        refInfo.maxRevCoverage = maxRevCoverage_;

        //write header
        output.seekp(sizeof(Header)+m*sizeof(ReferenceCoverageInfo));
        output.write((char*)&refInfo, sizeof(ReferenceCoverageInfo));
        //seek back to end of file
        output.seekp(0, std::ios_base::end);

        //remember offset for next reference
        refInfo.offset+=positions_.size();
    }

    output.close();
    CloseFile();
}
bool PileFileCreator::HasPileFile(FileResolver::Ptr files)
{
    using namespace boost::filesystem;

    //TODO: sanity check on header or something

    if(exists(files->GetBAMPileFile())) {

        std::time_t lastWrite=last_write_time(files->GetBAMPileFile());

        if(lastWrite >= last_write_time(files->GetSortedBAMFile())
            && lastWrite >= last_write_time(files->GetBAMIndexFile()))
            return true;
    }

    return false;
}

}
#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "BitCompressor.h"
#include "mathHelp.h"
#include "BitIterators.h"

using namespace compression;


namespace 
{

template<int N, typename BuffType, bool sign>
void TestNumbers(){
    const int BORDER_MAX = 300;
	const int count = sign ? 2*BORDER_MAX-1 : BORDER_MAX;

	typedef std::vector<BuffType> Buffer;
	Buffer buffer;
	int offset=0;
	int offset2=0;
	int buffOffset = 0;
	
    for(size_t j = 0; j<count; ++j){
        int x = j;
        if ( sign )
            x -= (BORDER_MAX-1);
            
		bool neg = x<0;
		OutVecBufferIterator<BuffType> outIt(buffer);
		SaveNumber<N, OutVecBufferIterator<BuffType>, int, sign>(outIt, x*(neg?-1:1), offset, neg);
		InputVecBufferIterator<BuffType> it(buffer.begin()+buffOffset);
		//typename std::vector<BuffType>::const_iterator it = buffer.begin()+buffOffset;
		neg=true;
		int y = LoadNumber<N, InputVecBufferIterator<BuffType>, int, sign>(it, offset2, neg);
		
        BOOST_REQUIRE_EQUAL(x,y);

		buffOffset = it.it_ - buffer.begin();
	}
}

}


BOOST_AUTO_TEST_SUITE( BitCompressionTests );

BOOST_AUTO_TEST_CASE( TestNumbers_3_u )
{
    TestNumbers<3, unsigned char, true>();
}

BOOST_AUTO_TEST_CASE(TestNumbers_4_u)
{
    TestNumbers<4, unsigned char, true>();
}

BOOST_AUTO_TEST_CASE(TestNumbers_5_u)
{
    TestNumbers<5, unsigned char, true>();
}

BOOST_AUTO_TEST_CASE(TestNumbers_6_u)
{
    TestNumbers<6, unsigned char, true>();
}

BOOST_AUTO_TEST_CASE(TestNumbers_7_u)
{
    TestNumbers<7, unsigned char, true>();
}

BOOST_AUTO_TEST_CASE(TestNumbers_3_s)
{
    TestNumbers<3, unsigned char, false>();
}

BOOST_AUTO_TEST_CASE(TestNumbers_4_s)
{
    TestNumbers<4, unsigned char, false>();
}

BOOST_AUTO_TEST_CASE(TestNumbers_5_s)
{
    TestNumbers<5, unsigned char, false>();
}

BOOST_AUTO_TEST_CASE(TestNumbers_6_s)
{
    TestNumbers<6, unsigned char, false>();
}

BOOST_AUTO_TEST_CASE(TestNumbers_7_s)
{
    TestNumbers<7, unsigned char, false>();
}

BOOST_AUTO_TEST_SUITE_END();

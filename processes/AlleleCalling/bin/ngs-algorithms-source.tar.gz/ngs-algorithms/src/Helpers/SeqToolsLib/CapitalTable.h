#pragma once

#include "BoolHelper.h"


namespace seq
{


/**
    Use this for fast upper-casing of a sequence.
    
    \note every non-acgt base is turned into 'N'
    
    Singleton implementation, should remove that
*/
class CapitalTable
{
public:
    typedef std::vector<char> Table;
private:
    static void Initialize(Table& table) 
    {
        table.resize(256, 'N'); 
        table['A'] = 'A';
        table['C'] = 'C';
        table['G'] = 'G';
        table['T'] = 'T';
        table['a'] = 'A';
        table['c'] = 'C';
        table['g'] = 'G';
        table['t'] = 'T';
    }
    static Table& GetTable() {
        static Table table_;
        static Bool<false> initialized_;
        if (!initialized_) { Initialize(table_); initialized_=true; }
        return table_;
    }
private:
    CapitalTable() {}
public:
    static const Table& Get() { return GetTable(); }
};



} // namespace seq
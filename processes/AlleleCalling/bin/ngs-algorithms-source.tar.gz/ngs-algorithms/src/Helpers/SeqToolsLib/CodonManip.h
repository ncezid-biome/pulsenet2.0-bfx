#pragma once
/**
    Unit tests in CodonTests.cpp

    \sa CodonRangeManip.h
*/

#include "Sequence.h"
#include "Codons.h"
#include "FrameRange.h"
#include "FrameDirection.h"


namespace seq
{


bool StartsWithStartCodon   ( const Sequence& sequence, const Codons& startCodons );
bool EndsWithStopCodon      ( const Sequence& sequence, const Codons& stopCodons  );
bool StartsAndEndsWithCodons( const Sequence& sequence, const Codons& startCodons, const Codons& stopCodons  );

bool ContainsInternalStopCodon( const Sequence& sequence, const Codons& stopcodons, FrameDirection frame );

// Somewhat more low-level inspection methods
bool ContainsCodonAt            ( const Sequence& sequence, size_t position, const Codons& codons );
bool ContainsCodonInForwardFrame( const Sequence& sequence, const Codons& codons, FrameRange range = FrameRange::All );
bool ContainsCodonInReverseFrame( const Sequence& sequence, const Codons& codons, FrameRange range = FrameRange::All );

} // namespace seq

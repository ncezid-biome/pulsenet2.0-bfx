#include "stdafx.h"
#include "OrganismSettings.h"
#include "CalcCommunication.h"


namespace engine
{

#define OPTION_ORGANISMSETTINGSFILE 
#define OPTION_ORGANISM "organism"

OrganismSettings::OrganismSettings(bool asSub)
	: ProgramOptions("Organism", asSub)
{
	AddOption("organism", "organism abbreviation", organism_);
	AddOption("organismSettings", "organism settings file (if empty, we assume it is in the shared folder)", organismSettingsFile_);
}

OrganismSettings::~OrganismSettings()
{
}

Str::Text::Val OrganismSettings::GetOrganism() const
{
	return organism_;
}

void OrganismSettings::SetOrganism(Str::Text::Arg organism)
{
	organism_ = organism;
}

bool OrganismSettings::HasOrganism() const
{
	return !organism_.empty();
}

/**
 * \brief loads a settingsfile and if everything goes well stores this in pt and passes it to LoadEnvSettingsImpl
*/
void OrganismSettings::LoadEnvSettings(const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm, LoadSettingsImplementation impl)
{
	if (organism_.empty()) {
		comm.Send(communication::CalcMessage(TXT("No organism abbreviation specified, organism settings have not been loaded.")));
		return;
	}

	comm.Send(communication::CalcMessage(TXT("Trying to load organism settings file...")));

	Str::Path::Val settingsFlName = organismSettingsFile_;

	if (settingsFlName.empty()) {
		comm.Send(communication::CalcMessage(Message(TXT("\t Trying to find settings file in organism folder for organism '%1'..."), organism_)));
		if (!organism_.empty()) {
			Str::Path::Val basePath = env.sharedDir / organism_;
			settingsFlName = basePath / "OrganismSettings.json";
			comm.Send(communication::CalcMessage(Message(TXT("\t New settings file name: %1"), settingsFlName)));
		}
	}

	if (!settingsFlName.empty() && boost::filesystem::exists(settingsFlName)) {
		comm.Send(communication::CalcMessage(Message(TXT("\t Final settings file '%1' found"), settingsFlName)));

		boost::property_tree::ptree pt;
		{
			std::ifstream iFile(ToRef(settingsFlName));
			boost::property_tree::read_json(iFile, pt);
		}

		comm.Send(communication::CalcMessage(Message(TXT("\t Done reading settings file '%1'"), settingsFlName)));
		
		// this calls a lambda that then executes code that is specific for the settings used by the calling executable.
		impl(pt, env, comm);		
	}
	else
	{
		comm.Send(communication::CalcMessage(Message(TXT("\t Settings file '%1' not found"), settingsFlName)));
	}

	comm.Send(communication::CalcMessage(TXT("Done loading organism settings")));
}

}
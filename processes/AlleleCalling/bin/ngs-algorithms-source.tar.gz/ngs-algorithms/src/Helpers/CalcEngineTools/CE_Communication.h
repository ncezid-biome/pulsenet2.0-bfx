#pragma once
/**
    \file CE_Communication.h

    Declares various custom handlers for messages of calculation engine algorithms.

    Complete list of messages available for these algorithms:

    - CalcMessage          : Set progress message. Progress messages are always appended
                             to the general log file.
    - CalcCanceled         : User canceled the calculation
    - CalcError            : Error during calculation
    - CalcWarning          : Warning during calculation
    - CalcLinearProgress   : Set progress (single computation thread)
    - CalcIncrMaxProgress  : Set max progress (multi-threaded)
    - CalcIncrProgress     : Tick progress (multi-threaded)

    - CalcCreateResultFile : Create a result file
    - CalcAppendLogFile    : Append to a custom log file
    - CalcLogMessage       : Append to the general log file. Note that these log messages
                             are only displayed if the verbose command-line option is
                             specified for the algorithm.
*/

#include "CalcCommunication.h"
// Include for convenience of users
#include "CalcCommunicationImpl.h"
#include "translate.h"

#include "CE_LogMessageType.h"
#include "CompressionTypePtr.h"




namespace communication
{

/**
    Message to send for creating a result file
*/
class CalcCreateResultFile : public communication::CalcInfo
{
public:
    CalcCreateResultFile( const Str::Text::Val& filename,
                          const Str::Text::Val& content,
						  CompressionTypePtr compressionType = nullptr);

private:
    virtual Str::Text::Val GetName() const override;
    virtual void           ToXml(pugi::xml_node& nd) const override;

private:
    Str::Text::Val filename_;
    Str::Text::Val content_;
	Str::ID::Val compressionTypeId_;
};

/**
    Append to a log file
*/
class CalcAppendLogFile : public communication::CalcInfo
{
public:
    CalcAppendLogFile( const Str::Text::Val& filename,
                       const Str::Text::Val& content,
                       const engine::LogMessageType& messageType = engine::LogMessageType::Message() );

private:
    virtual Str::Text::Val GetName() const override;
    virtual void           ToXml(pugi::xml_node& nd) const override;

private:
    Str::Text::Val filename_;
    Str::Text::Val content_;
    engine::LogMessageType messageType_;
};

/**
    Append to the general log file, if the verbose flag is specified. Use this message
    to write log messages that are useful for debugging purposes but are not useful
    for everyday use.
*/
class CalcLogMessage : public communication::CalcInfo
{
public:
    CalcLogMessage( Str::Text::Arg content,
                    const engine::LogMessageType& messageType = engine::LogMessageType::Message() );

private:
    virtual Str::Text::Val GetName() const override;
    virtual void           ToXml(pugi::xml_node& nd) const override;

private:
    Str::Text::Val filename_;
    Str::Text::Val content_;
    engine::LogMessageType messageType_;
};



} // namespace communication
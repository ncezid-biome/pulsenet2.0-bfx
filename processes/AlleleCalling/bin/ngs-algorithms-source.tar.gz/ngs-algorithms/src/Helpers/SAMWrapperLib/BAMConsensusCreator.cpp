#include "stdafx.h"
#include "BAMConsensusCreator.h"
#include "debugstr.h"
#include "CalcCommunicationImpl.h"

void BAM::ConsensusCreator::AddCoverages(int n, const bam_pileup1_t pl[], int offset)
{
    int fwdCovTotal=0;
    int fwdCov[16]= {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    int revCovTotal=0;
    int revCov[16]= {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    for(size_t m=0; m<n; m++) {

        //skip positions that are either deletions (A) or paddings to allow for inserts in other reads (B)
        //in case of padding, skip only if the read has run out of contributions (C)
        //  (A)             (B)        (C)
        if(pl[m].is_del || (offset && offset>pl[m].indel))
            continue;

        uint8_t b=bam1_seqi(bam1_seq(pl[m].b), pl[m].qpos + offset);

        if(bam1_strand(pl[m].b)) {

            revCov[b]++;
            revCovTotal++;
        }
        else {
            fwdCov[b]++;
            fwdCovTotal++;
        }
    }

    forwardCoverage_.AppendCoverageCounts(fwdCov[bam_nt16_table['A']], fwdCov[bam_nt16_table['C']],
                                          fwdCov[bam_nt16_table['G']], fwdCov[bam_nt16_table['T']],
                                          fwdCovTotal);

    reverseCoverage_.AppendCoverageCounts(revCov[bam_nt16_table['A']], revCov[bam_nt16_table['C']],
                                          revCov[bam_nt16_table['G']], revCov[bam_nt16_table['T']],
                                          revCovTotal);
}

void BAM::ConsensusCreator::AddPosition(char c, int n/*=0*/, const bam_pileup1_t pl[]/*=nullptr*/, int offset/*=0*/)
{
    if(insertPipe_) {
        insertPipe_ = false;
        AddPosition('|');
    }

    consensus_.push_back(c);
    AddCoverages(n, pl, 0);
}

int BAM::ConsensusCreator::PileupCallback(ReferenceID tid, ReferencePosition pos, int n, const bam_pileup1_t pl[])
{
    char c=consensusCaller_.GetConsensusBase(n, pl, 0);

    //omit gaps and insufficiently covered positions, UNLESS we should be maintaining the reference frame
    if(c!=ConsensusCaller::INSUFFICIENT_COVERAGE && c!=ConsensusCaller::GAP) {

        AddPosition(c, n, pl);
    }
    else if(settings_.keepFrame) {

        AddPosition('N', n, pl);
    }

    //handle inserts (or don't if we should be maintaining the reference frame)
    if(!settings_.keepFrame) { 

        // calculate maximum insert
        int max_ins=0;

        for(int i=0; i<n; ++i) {
            if (pl[i].indel > 0 && max_ins < pl[i].indel)
                max_ins=pl[i].indel;
        }

        for(int j=1; j<=max_ins; j++) {

            c=consensusCaller_.GetConsensusBase(n, pl, j);

            if(c!=ConsensusCaller::INSUFFICIENT_COVERAGE && c!=ConsensusCaller::GAP) {

                AddPosition(c, n, pl, j);
            }
        }
    }

    calc_->ContinueOrAbort();

    return 0;
}

void BAM::ConsensusCreator::CreateConsensus(const communication::CalcCommunication& calc, FileResolver::Ptr files, const ReferenceID refID, const ReferencePosition start, const ReferencePosition end)
{
    calc_=&calc;
    calc.Send(communication::CalcMessage("Creating consensus..."));

    OpenFile(files);

    forwardCoverage_.Reset(end-start);
    reverseCoverage_.Reset(end-start);
    insertPipe_ = false;

    CreatePileup(refID, start, end);
    CloseFile();
}

void BAM::ConsensusCreator::CreateConsensus(const communication::CalcCommunication& calc, FileResolver::Ptr files)
{
    calc_=&calc;
    calc.Send(communication::CalcMessage("Creating full consensus..."));

    OpenFile(files);

    std::vector<BAMTypes::ReferenceInfo> refInfos=GetReferencesInfo();
    size_t totalLength = refInfos.size() - 1;

    for(auto refInfo: refInfos) {
        totalLength+=refInfo.length;
    }

    consensus_.clear();
    consensus_.reserve(totalLength);
    forwardCoverage_.Reset(totalLength);
    reverseCoverage_.Reset(totalLength);
    insertPipe_ = false;

    CreatePileup();
    CloseFile();
}

void BAM::ConsensusCreator::ReferenceChanged(ReferenceID refID)
{
    if(refID && refID != NOREFERENCE) {

        if(settings_.keepFrame)
            //we do the piping manually when keeping the frame
            AddPosition('|');
        else if(consensus_.size())
            //just before adding the next position, add a pipe, prettyplx?
            insertPipe_ = true;
    }
}

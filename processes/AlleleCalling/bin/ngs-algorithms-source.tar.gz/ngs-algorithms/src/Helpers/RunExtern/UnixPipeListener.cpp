#include "stdafx.h"

#ifdef AMGNU

#include "UnixPipeListener.h"

#include <unistd.h>

#include "exception.h"


namespace runextern
{


UnixPipeListener::UnixPipeListener()
    : readPipe_ ()
    , writePipe_()
{
}

UnixPipeListener::UnixPipeListener(UnixPipe::Ptr readPipe, UnixPipe::Ptr writePipe)
    : readPipe_ ( readPipe )
    , writePipe_( writePipe )
{
}

/**
    You probably want to use checkForLine instead!

    Read until the buffer is full or until the stream closes. Note that this method
    only returns if the buffer is full or the stream closes! In the latter case
    further reads will not have any effect any more.

    \note Made private because after using this method once you cannot read from this
          pipe again, this is probably quite unexpected. Use checkForLine instead. If
          this functionality is needed at some point it could be made public.

    \sa checkForLine
*/
bool UnixPipeListener::checkForMessage(MessageBuffer& buffer, int &bytesRead)
{
    int c = 0;
    FILE* stream = fdopen (readPipe_->getReadDescriptor(), PM("r"));

    if ( ! stream ){
        bytesRead = 0;
        return false;
    }

    for (bytesRead = 0;
         bytesRead < buffer.getBufferSize()
         && (c = fgetc (stream)) != EOF; ++bytesRead)
    {
        buffer.getBuffer()[bytesRead] = c;
    }

    // This also prevents the stream from being opened again.
    fclose (stream);

    if ( bytesRead < buffer.getBufferSize() )
        buffer.getBuffer()[bytesRead] = 0;

    return bytesRead > 0;
}

/**
    Read a line.
*/
bool UnixPipeListener::checkForLine(MessageBuffer& buffer, int &bytesRead)
{
    ssize_t ret = read( readPipe_->getReadDescriptor(), buffer.getBuffer(), buffer.getBufferSize() );

    if ( ret == -1 ){
        throw KError( TXT("Error when reading from pipe: %1") )
            << errno;
    } else {
        bytesRead = ret;
        buffer.truncate(bytesRead);
    }

    // Success if we actually read something. If the pipe has been closed -> get 0 bytes -> return false
    return bytesRead > 0;
}

void UnixPipeListener::sendMessage(Str::Text::Arg message)
{
    sendMessage( writePipe_, message );
}

void UnixPipeListener::sendMessage( UnixPipe::Ptr unixPipe, int message )
{
    write(unixPipe->getWriteDescriptor(), &message, sizeof(int));
}

void UnixPipeListener::sendMessage(UnixPipe::Ptr unixPipe, Str::Text::Arg message)
{
    ssize_t ret = write( unixPipe->getWriteDescriptor(), message, strlen(message) );

    if ( ret == -1 ){
        throw KError( TXT("Error when writing to pipe: %1") )
            << errno;
        }
}


} // namespace runextern


#endif // #ifdef AMGNU

#include "stdafx.h"
#include "BAMAlignmentEvaluator.h"

SeqBAM::AlignmentEvaluator::AlignmentEvaluator(bam1_t* read) : cigar(nullptr), md(nullptr)
{
    cigar_left = read->core.n_cigar;
    cigar = (BAM::Cigar::CigarOp*)bam1_cigar(read);

    const uint8_t* mdp = bam_aux_get(read, "MD");
    if(mdp)
        md = bam_aux2Z(mdp);
}

SeqBAM::AlignmentEvaluator::AlignmentEvaluator(const BAM::Cigar::CigarOp* cig, int ciglen, const char* mdv): cigar(cig), cigar_left(ciglen), md(mdv)
{
}

bool SeqBAM::AlignmentEvaluator::Evaluate(AlignScores& score)
{
    if(!cigar || !cigar_left || !md)
        return false;

    md_end = md + strlen(md);

    ParseMD();
    ReadCigar();

    while(HasCigarLeft() && (md_left || cigar_op == BAM_CINS)) {

        if(cigar_op == BAM_CINS) {

            ApplyScore(BAM_CINS, cigar_len, score);
            AdvanceCigar();
        }
        else if(cigar_op == BAM_CDEL) {

            if(md_len == 0 && md_char == '^') {

                if(!AdvanceMD(cigar_len + 1))
                    return false;
                ParseMD();
            }
            else
                return false;

            ApplyScore(BAM_CDEL, cigar_len, score);
            AdvanceCigar();
        }
        else if(md_char >= 'A' && md_char <= 'Z') {

            //a mismatch (always one base)
            ApplyScore(BAM_CDIFF, 1, score);

            if(!AdvanceMD(1))
                return false;
            ParseMD();

            cigar_len--;

        }
        else if(cigar_len == md_len) {

            ApplyScore(cigar_op, cigar_len, score);
            ParseMD();
            AdvanceCigar();

        }
        else if(cigar_len < md_len) {

            ApplyScore(cigar_op, cigar_len, score);
            md_len -= cigar_len;
            AdvanceCigar();
        }
        else if(md_len > 0) {

            ApplyScore(cigar_op, md_len, score);
            cigar_len -= md_len;
            ParseMD();
        }
        else {
            //md_len==0 should be met with a cigar_op = D and md_char = ^
            //something is wrong, man
            return false;
        }
    }

    return true;
}

void SeqBAM::AlignmentEvaluator::ApplyScore(char op, int len, AlignScores& score) const
{
    switch(op) {

    case BAM_CMATCH:
    case BAM_CEQUAL:
        score.n_matches += len;
        score.length += len;
        break;
    case BAM_CDIFF:
    case BAM_CSOFT_CLIP:
    case BAM_CHARD_CLIP:
        score.n_mismatches += len;
        score.length += len;
        break;
    case BAM_CINS:
        //insertion into reference
        score.n_opengap2++;
        score.n_extendgap2 += len - 1;
        score.length += len;
        break;
    case BAM_CDEL:
        //deletion from reference=gap in read
        score.n_opengap1++;
        score.n_extendgap1 += len - 1;
        break;
    }
}

void SeqBAM::AlignmentEvaluator::ReadCigar()
{
    cigar_op = cigar->op;
    cigar_len = cigar->length;
}

void SeqBAM::AlignmentEvaluator::AdvanceCigar()
{
    cigar++;
    cigar_left--;
    ReadCigar();
}

bool SeqBAM::AlignmentEvaluator::HasCigarLeft()
{
    return cigar_left > 0;
}

void SeqBAM::AlignmentEvaluator::ParseMD()
{
    if(*md)  {

        md_left = true;

        if(*md >= '0' && *md <= '9') {

            ConsumeMDLen();

            if(md_len == 0)
                //we're prolly dealing with "0^ACT..."
                md_char = *md;
            else
                md_char = '\0';
        }
        else {
            md_len = 0;
            md_char = *md;
        }
    }
    else
        md_left = false;
}

bool SeqBAM::AlignmentEvaluator::AdvanceMD(int dist)
{
    md += dist;
    return md <= md_end;
}

void SeqBAM::AlignmentEvaluator::ConsumeMDLen()
{
    char* end;
    md_len = strtol(md, &end, 10);
    md = end;
}

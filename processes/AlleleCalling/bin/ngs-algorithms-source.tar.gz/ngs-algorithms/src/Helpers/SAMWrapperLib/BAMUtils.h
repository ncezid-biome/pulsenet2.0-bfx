#pragma once

#include <bam.h>
#include "SAMWrapper.h"

namespace BAM
{

class Utils
{

public:
    static inline char Convert4BitsToChar(uint8_t bitRep)
    {
        return bam_nt16_rev_table[bitRep & 0xF];
    }

    static inline uint8_t ConvertCharTo4Bits(char ch)
    {
        return bam_nt16_table[ch];
    }

    /**
     * Whether or not \p c is covered by the given IUPAC code. E.g. 'G' and 'T' are covered by 'K', but 'A' and 'C' aren't.
     * Inversely, 'K' is covered by both 'B' and 'D'.
     */
    static inline bool MatchesIUPACCode(char iupac, char c)
    {
        //K=1100, ~K=0011
        //G=0100, G&~K=0000 => ok
        //T=1000, T&~K=0000 => ok
        //A=0001, A&~K=0001 => not ok
        //C=0010, C&~K=0010 => not ok
        return (bam_nt16_table[c] & ~bam_nt16_table[iupac])==0;
    }

protected:

};
}


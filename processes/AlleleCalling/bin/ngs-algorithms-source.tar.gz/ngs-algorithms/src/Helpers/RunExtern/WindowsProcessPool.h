#pragma once

#include "runextern_processPool.h"

#include "WindowsProcess.h"


namespace runextern
{


class WindowsProcessPool : public ProcessPool
{
public:
    WindowsProcessPool();

    virtual WindowsProcess* CreateProcess() override;

};


} // namespace runextern

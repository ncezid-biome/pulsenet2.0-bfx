#pragma once

#include "boost/program_options.hpp"

#include "StringDef.h"


namespace engine
{

/**
    Encapsulate the optional extra algorithm command line arguments.
*/
class OptionalExtraArguments
{
public:
    OptionalExtraArguments();

    void AddOptions( boost::program_options::options_description& options );
    void Parse     ( int argc, char* argv[] );

    bool           HasNumThreads() const;
    int            GetNumThreads() const;

    bool           HasLocalDir() const;
    Str::Text::Val GetLocalDir() const;

    bool           PrintVersion() const;
    bool           MustShowHelp() const;

private:
    void Init();

private:
    boost::program_options::options_description options_;

    int            numThreads_;
    Str::Text::Val localDir_;
    bool           ishelp_;
    bool           printVersion_;
};

} // namespace engine

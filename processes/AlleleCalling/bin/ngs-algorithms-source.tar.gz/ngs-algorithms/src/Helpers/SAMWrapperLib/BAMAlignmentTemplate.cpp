#include "stdafx.h"
#include "BAMAlignmentTemplate.h"
#include <boost/smart_ptr/make_shared.hpp>

void BAM::AlignmentTemplate::AddSegment(Alignment::Ptr segment)
{
    segment->SetName(name_);
    segments_.push_back(segment);
}

void BAM::AlignmentTemplate::WriteToBAMFile(bamFile file)
{
    //sort segments on position
    std::sort(segments_.begin(), segments_.end(),  [] (const Alignment::Ptr& a, const Alignment::Ptr& b) {
        return a->position_<b->position_;
    });

    if(segments_.size()>1) {

        Alignment::Ptr& first=*segments_.begin();
        Alignment::Ptr& last=*segments_.rbegin();

        //mark first segment as such
        first->flags_|=BAM_FREAD1;
        //mark last segment as second read in segment (?)
        last->flags_|=BAM_FREAD2;

        //set segment length of first and last segment
        int32_t segmentLength=last->position_+last->sequenceLen_ - first->position_;
        first->templateLength_=segmentLength;
        last->templateLength_=-segmentLength;

        //link every segment with the next. SetMate takes care of the REVERSE and MREVERSE flags.
        //It also ensures that RNEXT and PNEXT are correct.
        for(size_t m=0; m<segments_.size()-1; m++) {

            segments_[m]->SetMate(segments_[m+1]);
        }
        last->SetMate(first);

        //mark all segments as part of a segment
        for(Alignment::Ptr& a: segments_) {

            a->flags_|=BAM_FPAIRED;
        }
    }

    for(Alignment::Ptr& a: segments_) {

        a->WriteToBAMFile(file);
        //thoroughly break circular depencency
        a->ResetMate();
    }
}

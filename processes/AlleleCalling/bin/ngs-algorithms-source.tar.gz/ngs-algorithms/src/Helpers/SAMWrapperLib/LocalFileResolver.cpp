#include "stdafx.h"
#include "LocalFileResolver.h"

void BAM::LocalFileResolver::SetBamFile(Str::Path::Val bamFile)
{
    BasicFileResolver::SetBamFile(bamFile);
    // put extra files alongside bam file
    // a.bam => a.bam.sorted.bam, a.bam.sorted.bai, ...
    SetBasePath(bamFile);
}

void BAM::LocalFileResolver::SetSortedBamFile(Str::Path::Val sortedBamFile)
{
    BasicFileResolver::SetSortedBamFile(sortedBamFile);
    // put extra files alongside sorted bam file
    // a.bam => a.bai, a.blf, ...
    SetSortedBasePath(sortedBamFile);
}
/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#include "stdafx.h"
#include "logging_stdout.h"
#include <iostream>

LoggerToStdOut::LoggerToStdOut()
{
}
LoggerToStdOut::~LoggerToStdOut()
{
}
void LoggerToStdOut::addLog(Str::Text::Arg line)
{
	std::cout << line << std::endl;
}

#pragma once

#include "translate.h"
#include "PathDef.h"
#include "StringDef.h"


namespace communication
{
	class CalcCommunication;
}

namespace engine
{

enum class FileExistsMode
{
	OverwriteExisting,
	KeepExisting,
	ThrowIfExisting
};

//Str::Path::Val makeNative          ( const Str::Path::Val& inputPath );
Str::Text::Val getFullExtension    ( Str::Path::Val path );
void           checkDirectoryexists( const Str::Path::Val& path, const Str::Text::Val& dirName = PM("") );
void           copyFile            ( const Str::Path::Val& inpath, const Str::Path::Val& outPath, FileExistsMode onFileExists, const communication::CalcCommunication& comm );
Str::Text::Val getFileContent      ( const Str::Path::Val& path );
int            getMaxCommandlineLength();

Str::Text::Val escapePath( Str::Text::Val pathString );
Str::Text::Val escapePath( Str::Path::Val pathString );

//void sanitizePath   ( Str::Text::Val& pathString );
//void sanitizePath   ( Str::Path::Val& path );
//void sanitizeUNCPath( Str::Text::Val& pathString );
//void sanitizeUNCPath( Str::Path::Val& path );

void copyDirectory( const Str::Path::Val& old, const Str::Path::Val& dest );

} // namespace engine

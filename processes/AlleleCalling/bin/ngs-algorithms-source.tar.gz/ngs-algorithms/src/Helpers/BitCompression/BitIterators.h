#pragma  once

/**
This file contains a set of iterator classes that support the bitcompression requierements
*/
#include <vector>
#include <fstream>
#include "IoBuffer.h"
#include "StringDef.h"

namespace compression{

#pragma region Output iterator
/**
Classes which can be used in the output functions
This on stores in a character buffer, binary
*/
template<typename T>
class  OutVecBufferIterator{
public:
	typedef  T   value_type;
public:
	OutVecBufferIterator(std::vector<T>& v)
		: v_(v)
	{
	}

	inline void operator ++(){
		v_.push_back(0);
	
	}
	inline OutVecBufferIterator& operator*(){
		return *this;
	}
	inline void operator|=(T t){
		v_.back() |= t;
	}
	static size_t   GetBitSize(){
		return 8;
	}
private:
	std::vector<T>& v_;
	OutVecBufferIterator(const OutVecBufferIterator&);
	OutVecBufferIterator& operator=(const OutVecBufferIterator&);
};


/**
Classes which can be used in the output functions
This on stores in a character buffer, b64
*/
//template<typename T>
//class  OutStrB64Iterator{
//public:
//	typedef  T   value_type;
//public:
//	OutStrB64Iterator(std::vector<T>& v)
//		: v_(v)
//	{
//	}
//	~OutStrB64Iterator()
//	{
//		if(!v_.empty())
//			v_.back() = translate[c];
//	}
//
//	inline void operator ++(){
//		if(!v_.empty())
//			v_.back() = translate[c];
//		v_.push_back(0);
//		c=0;
//	}
//	inline OutStrB64Iterator& operator*(){
//		return *this;
//	}
//	inline void operator|=(T t){
//		c |= t;
//	}
//	static size_t   GetBitSize(){
//		return 6;
//	}
//private:
//	const static char   translate[];
//	T					current_;//untranslated
//	Str::Buffer::Val& v_;
//	OutStrB64Iterator(const OutStrB64Iterator&);
//	OutStrB64Iterator& operator=(const OutStrB64Iterator&);
//};
//
//template<typename T>
//const  char   OutStrB64Iterator<T>::translate[]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+*";


/**
Writes output to a file in raw binary form
*/
template<typename T, int N=4000>
class  OutRawFileBufferIterator{
public:
	typedef  T   value_type;
	inline OutRawFileBufferIterator(std::ostream&	os)
		: os_(os)
		, offset_(-1)
	{}
	inline ~OutRawFileBufferIterator()
	{
		if(offset_!=N){
			t_[offset_] = current_;
			++offset_;
		}
		Purge();
	}
	inline OutRawFileBufferIterator& operator*(){
		return *this;
	}
	inline void operator ++(){
		if(offset_>=0){
			t_[offset_] = current_;
		}
		++offset_;
		if(offset_==N){
			Purge();
		}
		current_ = 0;
	}
	inline void operator|=(T t){
		current_ |= t;
	}
	static size_t   GetBitSize(){
		return 8;
	}
private:
	std::ostream&	os_;
	T				current_;//untranslated
	T				t_[N];
	int				offset_;
	void 		Purge(){
		os_.write((const char*)t_, offset_*sizeof(T)); //convert to bytes
		offset_=0;
	}

private:
	OutRawFileBufferIterator(const OutRawFileBufferIterator&);
	OutRawFileBufferIterator& operator=(const OutRawFileBufferIterator&);

};

/**
Writes output to a file in (kind of) base64 encoding
*/
template<typename T, int N=4000>
class  OutFileBufferIterator{
public:
	typedef  T   value_type;
	inline OutFileBufferIterator(std::ostream&	os)
		: os_(os)
		, offset_(-1)
	{}
	inline ~OutFileBufferIterator()
	{
		if(offset_!=N){
			t_[offset_] = translate[current_];
			++offset_;
		}
		Purge();
	}
	inline OutFileBufferIterator& operator*(){
		return *this;
	}
	inline void operator ++(){
		if(offset_>=0){
			ASSERT(current_<64);
			t_[offset_] = translate[current_];
		}
		++offset_;
		if(offset_==N){
			Purge();
		}
		current_ = 0;
	}
	inline void operator|=(T t){
		current_ |= t;
	}
	static size_t   GetBitSize(){
		return 6;
	}
private:
	const static char   translate[];
	std::ostream&	os_;
	T					current_;//untranslated
	T					t_[N];
	int				offset_;
	void 		Purge(){
		os_.write((const char*)t_, offset_*sizeof(T)); //convert to bytes
		offset_=0;
	}

private:
	OutFileBufferIterator(const OutFileBufferIterator&);
	OutFileBufferIterator& operator=(const OutFileBufferIterator&);

};

template<typename T, int N>
const  char   OutFileBufferIterator<T,N>::translate[]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+*";

#pragma endregion 


#pragma region Input iterator

/**
Buffer use with n-bit compression. Reads from a raw in memory vector-based buffer
*/
template<typename T>
class  InputVecBufferIterator{
	public:
	typedef  unsigned char   value_type;
	inline InputVecBufferIterator(typename std::vector<T>::const_iterator it)
		: it_(it)
	{
	}
	inline value_type operator*(){
		return *it_;
	}
	inline void operator ++(){
		++it_;
	}
	static size_t   GetBitSize(){
		return 8;
	}
//private:
	typename std::vector<T>::const_iterator	it_;
};

/**
Buffer use with n-bit compression. Reads from a raw IBuffer
*/
class  InputRawFileBufferIterator{
	public:
	typedef  unsigned char   value_type;
	inline InputRawFileBufferIterator(IBuffer&	is)
		: is_(is)
	{
		c_ = is_.Get();
	}
	inline ~InputRawFileBufferIterator()
	{
	}
	inline value_type operator*(){
		return c_;
	}
	inline void operator ++(){
		c_ =  is_.Get();
	}
	static size_t   GetBitSize(){
		return 8;
	}
private:
	IBuffer&	is_;
	char c_;
private:
	InputRawFileBufferIterator(const InputRawFileBufferIterator&);
	InputRawFileBufferIterator& operator=(const InputRawFileBufferIterator&);

};

/**
Buffer use with n-bit compression. Reads from a base 64 encoded IBuffer
*/
class  InputFileBufferIterator{
	public:
	typedef  unsigned char   value_type;
	inline InputFileBufferIterator(IBuffer&	is)
		: is_(is)
	{
		if(translate_[0]==0){
			for(size_t i=0; i<256;++i){
				translate_[i]=0;
			}
			for(size_t i=0; i<64;++i){
				translate_[translateBase_[i]] = static_cast<char>(i);
			}
		}
		c_ =  translate_[is_.Get()];
	}
	inline ~InputFileBufferIterator()
	{
	}
	inline value_type operator*(){
		return c_;
	}
	inline void operator ++(){
		c_ =  translate_[is_.Get()];
	}
	static size_t   GetBitSize(){
		return 6;
	}
private:
	const static 	char translateBase_[];
	static 	char translate_[256];
	IBuffer&	is_;
	char c_;
private:
	InputFileBufferIterator(const InputFileBufferIterator&);
	InputFileBufferIterator& operator=(const InputFileBufferIterator&);

};


#pragma endregion 

}//namespace compression{


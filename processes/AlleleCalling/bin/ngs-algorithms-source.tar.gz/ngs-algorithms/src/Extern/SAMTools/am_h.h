#pragma once

// This file contains all the things that are required to make sense of the SAMTools headers

#define EXIT_EXCEPTION  1130

#ifndef AMGNU

#include <BaseTsd.h>
typedef SSIZE_T ssize_t;

#ifdef __cplusplus
#include <xutility>
#endif

/*
 * When building the DLL code, you should define SLW32_BUILD so that
 * the variables/functions are exported correctly. When using the DLL,
 * do NOT define SLW32_BUILD, and then the variables/functions will
 * be imported correctly.
 */
//for SamtoolsLib
#ifndef SLW32_STATIC_LIB
#  ifdef SLW32_BUILD
#    define SLW32_DLLPORT __declspec(dllexport)
#  else
#    define SLW32_DLLPORT __declspec(dllimport)
#  endif
#else
#  define SLW32_DLLPORT
#endif

//for BCFtools
#ifndef BCFW32_STATIC_LIB
#  ifdef BCFW32_BUILD
#    define BCFW32_DLLPORT __declspec(dllexport)
#  else
#    define BCFW32_DLLPORT __declspec(dllimport)
#  endif
#else
#  define BCFW32_DLLPORT
#endif

#else
#define SLW32_DLLPORT
#define BCFW32_DLLPORT

#endif
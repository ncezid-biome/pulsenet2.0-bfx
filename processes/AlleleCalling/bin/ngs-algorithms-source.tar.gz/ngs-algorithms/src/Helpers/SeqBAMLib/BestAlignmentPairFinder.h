#pragma once
#include "BestPositionFinder.h"
#include "AlignmentPair.h"

namespace SeqBAM
{

namespace Bowtie2Filter
{

class BestAlignmentPairFinder: public GenericBestPosFinder<AlignmentPair>
{

public:

    BestAlignmentPairFinder(double minScore_);

    bool accept(const AlignmentPair& p) const;

    double score(const AlignmentPair& p) const;

    void addPair(AlignmentWithScore* one, AlignmentWithScore* two);

    AlignmentPair::MatchPosition matchPosition(const AlignmentPair& t) const;

private:
    const double minScore;
};

}

}

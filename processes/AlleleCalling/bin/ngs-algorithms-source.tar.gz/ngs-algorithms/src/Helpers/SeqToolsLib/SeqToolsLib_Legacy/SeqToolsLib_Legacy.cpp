#include"stdafx.h"
#include <iostream>

int main(int argc, char *argv[])
{
	using namespace std;
	char sz[]  = "Helloo World!\n";	//Hover mouse over "sz" while debugging to see its contents
	// Str::Text::Val  st = "Ik baal van abba %1 %2 ";
	// ReplaceString(st, "ba" , "b");
	// cout << Message(st.c_str(), "boem", 1.2345).c_str() <<  endl;	

	cout << argv[0]<<  endl;	                                        
	return 0;
}
#pragma once

#ifdef AMGNU

#include "StringDef.h"
#include <boost/shared_ptr.hpp>


namespace runextern
{

    
class UnixPipe
{
public:
    typedef boost::shared_ptr<UnixPipe> Ptr;

public:

    UnixPipe();
    UnixPipe( int pipes[2] );

    ~UnixPipe();

    bool create();

    int  getReadDescriptor();
    int  getWriteDescriptor();

    void closeForReading();
    void closeForWriting();
    void setCloseWriteOnExit();

    void captureStdOut();
    void captureStdErr();
    void captureStdIn();

    static Str::Text::Val getErrorText( int errorCode );   

private:
    //don't copy a pipe, use Ptr instead to pass it around
    UnixPipe(const UnixPipe& pipe) {}

private:
    int pipes_[2];
};


} // namespace runextern


#endif // #ifdef AMGNU

#pragma once
#include "strdef.h"
#include "CheckedMalloc.h"
#include "iupac.h"
#include "SeqScores.h"

#ifdef INFINITY
#undef INFINITY
#endif

#define INFINITY 10000000

struct AlignParams {			
	int				score_match;			//score for a match 
	int				score_mismatch;			//score for a mismatch 	
	bool			allow_gaps1;			//whether or not gaps in the first sequence are allowed
	int				score_opengap1;			//score for opening a gap in the first sequence
	int				score_extendgap1;		//score for extending a gap in the first sequence
	bool			allow_gaps2;			//whether or not gaps in the second sequence are allowed
	int				score_opengap2;			//score for opening a gap in the second sequence
	int				score_extendgap2;		//score for extending a gap in the second sequence
	size_t			max_nr_gaps;			//maximum number of gaps
	bool			has_max_nr_gaps;		//whether or not there is a maximum number of gaps

	double			threshold_seqid;		//threshold for the sequence identity
	double			threshold_maxpenalty;	//threshold for the maximum penalty score	

public:
	AlignParams(bool ihas_max_nr_gaps=true) 
		: has_max_nr_gaps(ihas_max_nr_gaps), score_match(1), score_mismatch(-1)
		, allow_gaps1(false), score_opengap1(-2), score_extendgap1(-1)
		, allow_gaps2(false), score_opengap2(-2), score_extendgap2(-1)
		, max_nr_gaps(5), threshold_seqid(0.9), threshold_maxpenalty(5)
	{
	}

	AlignParams(const AlignParams& other)
		: has_max_nr_gaps(other.has_max_nr_gaps), score_match(other.score_match), score_mismatch(other.score_mismatch)
		, allow_gaps1(other.allow_gaps1), score_opengap1(other.score_opengap1), score_extendgap1(other.score_extendgap1)
		, allow_gaps2(other.allow_gaps2), score_opengap2(other.score_opengap2), score_extendgap2(other.score_extendgap2)
		, max_nr_gaps(other.max_nr_gaps), threshold_seqid(other.threshold_seqid), threshold_maxpenalty(other.threshold_maxpenalty)
	{
	}
};



namespace local_alignment {

template<class ScoreType=double>
class LATable {
private:
	int				nrows_, maxdeviation_;
	ScoreType**		table_;
	int**			steplength_;
	int**			parentrow_;
	int**			parentcol_;
public:
	LATable() : table_(0), parentrow_(0), parentcol_(0),steplength_(0), nrows_(0), maxdeviation_(0) {}
	~LATable() { 
		if (table_) {
			for(int i=0; i<nrows_; ++i) free(table_[i]);
			free(table_); 
		}			
		if (steplength_) {
			for(int i=0; i<nrows_; ++i) free(steplength_[i]);
			free(steplength_); 
		}
		if (parentrow_) {
			for(int i=0; i<nrows_; ++i) free(parentrow_[i]);
			free(parentrow_); 
		}
		if (parentcol_) {
			for(int i=0; i<nrows_; ++i) free(parentcol_[i]);
			free(parentcol_); 
		}
	}

	void reallocate(int nrows, int maxdeviation) {
		if (table_) {
			for(int i=0; i<nrows_; ++i) {
				free(table_[i]);
				free(parentrow_[i]);
				free(parentcol_[i]);
				free(steplength_[i]);
			}			
		}

		nrows_=nrows; maxdeviation_=maxdeviation;
		table_=(ScoreType**)realloc(table_, nrows_*sizeof(ScoreType*));
		parentrow_=(int**)realloc(parentrow_, nrows_*sizeof(int*));
		parentcol_=(int**)realloc(parentcol_, nrows_*sizeof(int*));
		steplength_=(int**)realloc(steplength_, nrows_*sizeof(int*));
		for(int i=0; i<nrows_; ++i) {
			table_[i]=(ScoreType*)malloc((2*maxdeviation+1+2)*sizeof(ScoreType));
			table_[i][0]=-INFINITY; table_[i][2*maxdeviation+2]=-INFINITY;
			parentrow_[i]=(int*)malloc((2*maxdeviation+1)*sizeof(int));
			parentcol_[i]=(int*)malloc((2*maxdeviation+1)*sizeof(int));
			steplength_[i]=(int*)malloc((2*maxdeviation+1)*sizeof(int));
		}
	}
	
	void resize(int nrows, int maxdeviation) {
		//provide the memory
		if (nrows>nrows_ || maxdeviation>maxdeviation_) reallocate(nrows, maxdeviation);		
	}

	inline void setStartRow() {
		for(size_t i=0; i<2*maxdeviation_+1; ++i) {
			table_[0][i+1]=0;
			parentrow_[0][i]=0;
			parentcol_[0][i]=i-1;
			steplength_[0][i]=0;
		}

	}

	inline ScoreType& score(int i, int j) { 
		assert(i<nrows_); assert(j-i>=-1); assert(j-i+1<2*maxdeviation_+3); 
		return table_[i][j-i+1]; 
	}
	inline int& parentRow(int i, int j) { 
		assert(i<nrows_); assert(j-i>=0); assert(j-i<2*maxdeviation_+1); 
		return parentrow_[i][j-i]; 
	}
	inline int& parentCol(int i, int j) { 
		assert(i<nrows_); assert(j-i>=0); assert(j-i<2*maxdeviation_+1); 
		return parentcol_[i][j-i]; 
	}
	inline int& length(int i, int j) {
		assert(i<nrows_); assert(j-i>=0); assert(j-i<2*maxdeviation_+1); 
		return steplength_[i][j-i]; 
	}
	
	inline const ScoreType& score(int i, int j) const {
		assert(i<nrows_); assert(j-i>=-1); assert(j-i<2*maxdeviation_+2); 
		return table_[i][j-i+1]; 
	}
	inline const int& parentRow(int i, int j) const { 
		assert(i<nrows_); assert(j-i>=0); assert(j-i<2*maxdeviation_+1); 
		return parentrow_[i][j-i]; 
	}
	inline const int& parentCol(int i, int j) const { 
		assert(i<nrows_); assert(j-i>=0); assert(j-i<2*maxdeviation_+1); 
		return parentcol_[i][j-i]; 
	}
	inline const int& length(int i, int j) const { 
		assert(i<nrows_); assert(j-i>=0); assert(j-i<2*maxdeviation_+1); 
		return steplength_[i][j-i]; 
	}
};



class LABuffer {
private:
	char* buffer_;	
	char* pos_;
	size_t size_;
public:
	LABuffer() : buffer_(0), size_(0) {
        resize(1);
        startRev();
    };
	~LABuffer() { if (buffer_) free(buffer_); }

	inline void resize(size_t size) {
		if (size_<size) {
			size_=size;
            //add extra byte for null-termination in startRev
			buffer_=(char*)CheckedRealloc(buffer_, (size_ + 1)*sizeof(char));
			pos_=0;
		}		
	}
	inline size_t buffSize() const {
		return size_;
	}

	inline void startRev() { assert(pos_==0 || pos_-buffer_>=0); buffer_[size_]='\0'; pos_=buffer_+size_-1; }
	inline void setRev(char val) { assert(pos_-buffer_>=0); *pos_=val; --pos_; }

	inline void startFwd() { ++pos_; assert(pos_-buffer_>=0); }
	inline bool hasMoreFwd() { assert(pos_-buffer_>=0); return pos_<buffer_+size_; }
	inline char getFwd() { assert(pos_-buffer_>=0); ++pos_; return *(pos_-1); }
	inline char* getFwdPos() {  assert(pos_-buffer_>=0); return pos_; }
    inline const char* getFwdPos() const {  assert(pos_-buffer_>=0); return pos_; }
	inline size_t getFwdSize() { assert(pos_-buffer_>=0); return size_-(pos_-buffer_); }
	inline void moveFwd(size_t nsteps) { assert(pos_-buffer_>=0); pos_+=nsteps; }

};

template<class ScoreType=double>
class LAParams {
public:
	ScoreType score_match;
	ScoreType score_mismatch;
	ScoreType score_opengap2;
	ScoreType score_extendgap2;
	ScoreType score_opengap1;
	ScoreType score_extendgap1;
	int maxoffset;

	double			threshold_seqid;		//threshold for the sequence identity
	double			threshold_maxpenalty;	//threshold for the maximum penalty score

    LAParams() {

    }

    LAParams(const AlignParams& alignParams)
    {
        const ScoreType minusInfinity=std::numeric_limits<ScoreType>::lowest();

        score_match = alignParams.score_match;
        score_mismatch = alignParams.score_mismatch;

        maxoffset = alignParams.max_nr_gaps;

        threshold_seqid=alignParams.threshold_seqid;
        threshold_maxpenalty=alignParams.threshold_maxpenalty;

        if (alignParams.allow_gaps1) {
            score_opengap1 = alignParams.score_opengap1;
            score_extendgap1 = alignParams.score_extendgap1;
        }
        else {
            score_opengap1 = minusInfinity;
            score_extendgap1 = minusInfinity;
        }

        if (alignParams.allow_gaps2) {
            score_opengap2 = alignParams.score_opengap2;
            score_extendgap2 = alignParams.score_extendgap2;
        }
        else {
            score_opengap2 = minusInfinity;
            score_extendgap2 = minusInfinity;
        }
    }
};

}


struct AlignScores {

    //for read/reference alignments:
    //first seq: read
    //second seq: reference

    int				n_matches;			//number of matches
    int				n_mismatches;		//number of mismatches
    int				n_opengap2;			//number of open gaps in the second sequence
    int				n_extendgap2;		//number of extend gaps in the second sequence
    int				n_opengap1;			//number of open gaps in the first sequence
    int				n_extendgap1;		//number of extend gaps in the first sequence
    int				n_begingaps2;		//number of gaps at the beginning of the second sequence
    int				n_endgaps2;			//number of gaps at the end of the second sequence
    int				n_begingaps1;		//number of gaps at the beginning of the first sequence
    int				n_endgaps1;			//number of gaps at the end of the first sequence
    int				length;				//total length of the alignment
    size_t			readlength;         //total length of the read

    bool			accepted;			//whether the alignment is acceptable
    double			weightedscore;
public:
    AlignScores() 
        : n_matches(0), n_mismatches(0)
        ,  n_opengap2(0), n_extendgap2(0), n_opengap1(0), n_extendgap1(0)
        , n_begingaps2(0), n_endgaps2(0), n_begingaps1(0), n_endgaps1(0)
        , length(0), readlength(0),
        weightedscore(0.0), accepted(false)
    {}

    inline double sequence_identity() const //true relative holomogy : number of matches / length
    {
        if (length)
            return double(n_matches) / length;
        return 0.0;
    }

    //use this for testing only!
    void Set_sequence_identity(double seqid)
    {
        n_matches = seqid * 1e9;
        length = 1e9;
    }

    template<typename T> double GetPenalty(const local_alignment::LAParams<T>& params) const
    {
        return n_mismatches * params.score_mismatch
               + n_opengap1 * params.score_opengap1 + n_extendgap1 * params.score_extendgap1
               + n_opengap2 * params.score_opengap2 + n_extendgap2 * params.score_extendgap2;
    }
};


namespace local_alignment {

template<class ScoreType=double>
class LA {
	/*
	the align function takes as input:
		- seq, qual, seqsize: short sequence (also quality and size) to be mapped to a big sequence
		- refseq, refseqsize: long sequence (also size) to be mapped against
		- mapping parameters
		- table: the right dynamic programming table
		- scores: the resulting scores
		- pos: the estimated position of the start of the short sequence with respect to the long sequence
		- alignedseq, alignedrefseq: reuslt of the alignment
	ScoreType should be a floating-point type, otherwise there is nopoint in working with qualities
	*/
private:
	void setFailed(int& pos, AlignScores& scores, LABuffer& alignedseq, LABuffer& alignedrefseq) const {
		scores.accepted=false;
	};
public:
	LA() {}
	~LA() {}

	void align(const char* seq1, const seq::SeqScores* qual, int seqsize1, const char* seq2, int seqsize2, 
				const LAParams<ScoreType>& params, LATable<ScoreType>& table, 
							AlignScores& scores, int& pos, LABuffer& alignedseq, LABuffer& alignedrefseq) const;	
};





template<class ScoreType>
void LA<ScoreType>::align(const char* seq, const seq::SeqScores* qual, int seqsize, 
							const char* refseq, int refseqsize, 
							const LAParams<ScoreType>& params, 
							LATable<ScoreType>& table, AlignScores& scores,
							int& pos, LABuffer& alignedseq, LABuffer& alignedrefseq) const
{	
	//--- remember the input data ----------------------------------------------------------------
	const char* inputseq=seq;
	int inputseqsize=seqsize;

    //reset scores
    memset(&scores, 0, sizeof(AlignScores));
    scores.readlength = seqsize;

	char c1, c2;
	//--- chop off everything that you can't use --------------------------------------------------
	//--- first case: read starts before the reference --------------------------------------------
	int extrapos=0;
	if (pos<0) { 
		extrapos=pos;
		if (-pos>=seqsize) { //nothing can be used
			setFailed(pos, scores, alignedseq, alignedrefseq); 
			return; 
		}
		else { //at least some part of the read sequence can be used
			seq-=pos;
			seqsize+=pos;			
			pos=0;
		}
	}

	//--- second case: read ends after the reference ----------------------------------------------
	if (pos+seqsize>refseqsize) {
		if (pos>=refseqsize){ //nothing can be used
			setFailed(pos, scores, alignedseq, alignedrefseq); 
			return; 
		}
		else { //at least some part of the read sequence can be used
			seqsize-=pos+seqsize-refseqsize;
		}
	}

	assert(pos>=0);

	//--- get the reference sequence right --------------------------------------------------------
	int refoffset, refpos=pos-params.maxoffset;
	if (refpos>=refseqsize) { 
		setFailed(pos, scores, alignedseq, alignedrefseq); 
		return; 
	}	
	if (refpos>0) { refseq+=refpos; refoffset=0; }
	else { refoffset=refpos; }

	int minlen =0;

	//--- define some counters --------------------------------------------------------------------
	int i, j=0, k=0, jj, kk,  parentrow, parentcol, len;
	ScoreType s, s1, s2, s3, q;

	//--- initialize the LATable ------------------------------------------------------------------
	table.resize(seqsize+1, params.maxoffset);
	
	//--- iterate over the rows in the table and fill in the values -------------------------------
	
	i=0; //set the first row
	{ 
		for(i=0; i<2*params.maxoffset+1; ++i) {
			table.score(0,i)=0;
			table.parentRow(0,i)=0;
			table.parentCol(0,i)=i-1;
			table.length(0,i)=0;
		}
	}	
		
	i=1;
	for(; i<=seqsize; ++i) { //iterate over the sequence
		j=i;
		k=i+2*params.maxoffset;
		while (refpos+j-1<0 && j<=k) {
			table.score(i,j)=0;
			table.length(i,j)=table.length(i-1,j-1)+1;
			table.parentCol(i,j)=j-1;
			table.parentRow(i,j)=i-1;
			++j;
		}
		while(j<=k && refpos+j-1<refseqsize) {			
			
			assert(refpos+j-1<refseqsize);
			assert(i-1<seqsize);

			//--- calculate the score for moving a letter in both sequences -----------------------
			s1=table.score(i-1, j-1);
			if (qual) q=0.3+0.7*(1.0-qual->p(i-1)); else q=1.0; 
			if (seq[i-1]==refseq[j-1+refoffset]) 
				s1+=(100.0*params.score_match+q*params.score_match + (1.0-q)*params.score_mismatch)/101.0; 
			else 
				s1+=(100.0*params.score_mismatch+params.score_mismatch*(q+2*(1.0-q)/3.0) + params.score_match*(1.0-q)/3.0)/101.0;
						
			//--- calculate the score for opening/extending a gap in the reference ----------------
			s2=table.score(i-1, j);
			if (s2!=-INFINITY) {
				if (table.parentRow(i-1, j)==i-2 && table.parentCol(i-1, j)==j) s2+=params.score_extendgap2;
				else s2+=params.score_opengap2;
			}

			//--- calculate the score for opening/extending a gap in the read ---------------------
			s3=table.score(i, j-1);
			if (s3!=-INFINITY) {
				if (table.parentRow(i, j-1)==i && table.parentCol(i, j-1)==j-2) s3+=params.score_extendgap1;
				else s3+=params.score_opengap1;
			}

			//--- find the best score (prefer mismatch over gap, and gap in read over gap in ref) -			
			if (s1>=s2 && s1>=s3) {	s=s1; parentrow=i-1; parentcol=j-1; len=table.length(i-1, j-1)+1; }
			else {
				if (s2>=s3) { s=s2; parentrow=i-1; parentcol=j; len=table.length(i-1, j)+1; }
				else { s=s3; parentrow=i; parentcol=j-1; len=table.length(i, j-1)+1; }
			}		

			//--- write the result to the table ---------------------------------------------------
			table.score(i,j)=s;
			table.parentRow(i,j)=parentrow; assert(parentrow>=0);
			table.parentCol(i,j)=parentcol;	assert(parentcol>=0);
			table.length(i,j)=len;

			++j;
		}

		while(j<=k) {		
			s=table.score(i-1, j-1);
			table.score(i,j)=table.score(i-1, j-1);
			table.length(i,j)=table.length(i-1,j-1)+1;
			table.parentCol(i,j)=j-1;
			table.parentRow(i,j)=i-1;
			++j;
		}
	}

	//--- find the best possible value at the end of the read -------------------------------------			
	i=seqsize;
    ScoreType score = -INFINITY;
	minlen=10*seqsize;

	for(size_t i=seqsize; i<seqsize+2*params.maxoffset+1; ++i) {
		s=table.score(seqsize, i);
		len=table.length(seqsize,i);
		if (s>score) { score=s; j=seqsize; k=i; minlen=len; }
		else if (s==score) {
			if (len<minlen) { minlen=len; j=seqsize; k=i; }
		}
	}

	scores.weightedscore = score;

//	//--- if the score obtained here is not better than the score we already had, return now ------
//	if (j==-1 && k==-1) { score=-INFINITY; return; }

//	//--- start the traceback ---------------------------------------------------------------------
	int mylen=minlen;
	if( inputseqsize-1-extrapos>=seqsize) mylen+=(inputseqsize-1-extrapos)-seqsize+1;
	if (-extrapos-1>=0) mylen+=-extrapos-1+1;

	if (mylen+3*params.maxoffset>alignedseq.buffSize()) alignedseq.resize(mylen+3*params.maxoffset);
	if (mylen+3*params.maxoffset>alignedrefseq.buffSize()) alignedrefseq.resize(mylen+3*params.maxoffset);

	alignedseq.startRev();
	alignedrefseq.startRev();

	//--- first situation: there is some extra at the end -----------------------------------------

	jj=inputseqsize-1;
	while (jj>=seqsize-extrapos) {
		alignedseq.setRev(inputseq[jj]);
		alignedrefseq.setRev(iupac_N);
		++scores.n_endgaps2;
        ++scores.length;
		--jj;
	}
    
	//--- second situation: traceback through the LATable -----------------------------------------
	bool gap2_open=false;
	bool gap1_open=false;
	//assert(k-1+refoffset<refseqsize);
	while (j>0 && k>0) {		
		jj=table.parentRow(j,k); kk = table.parentCol(j,k);		
		if (jj==j) { //gap in read
			gap2_open=false;
			if (gap1_open) { ++scores.n_extendgap1; }
			else { gap1_open=true; ++scores.n_opengap1; }
			alignedseq.setRev(GAP);
			alignedrefseq.setRev(refseq[k-1+refoffset]);
			++scores.length;
		}
		else if (kk==k) { //gap in ref
			gap1_open=false;			
			if (gap2_open) { ++scores.n_extendgap2; }
			else { gap2_open=true; ++scores.n_opengap2; }
			alignedseq.setRev(seq[j-1]);
			alignedrefseq.setRev(GAP);
			++scores.length;
		}
		else {
			gap1_open=false;
			gap2_open=false;
			c1=seq[j-1];			
			if (refpos+k-1+refoffset>=refseqsize){
				c2=iupac_N; 
				++scores.n_endgaps2; 
                ++scores.length;
			}
			else if (k-1+refoffset<0) {
				c2=iupac_N;
				++scores.n_begingaps2; 
                ++scores.length;
			}
			else {
				c2=refseq[k-1+refoffset];
				if (c1==c2) ++scores.n_matches;
				else ++scores.n_mismatches;
				++scores.length;
			}
			alignedseq.setRev(c1);
			alignedrefseq.setRev(c2);
						
		}		
		j=jj; k=kk;	
	}

	//--- third situation: there is some extra in the beginning ----------------------------------
	jj=-extrapos-1;
	while (jj>=0) {
		alignedseq.setRev(inputseq[jj]);
		alignedrefseq.setRev(iupac_N);
		++scores.n_begingaps2;
        ++scores.length;
		--jj;
	}
    
	//--- set the position variable right ---------------------------------------------------------
	pos=refpos+k+extrapos;

	scores.accepted = (scores.sequence_identity() >= params.threshold_seqid) 
		&& (-scores.GetPenalty(params) <= params.threshold_maxpenalty); 

}
}


template<class T=double>
struct LocalAlign {
	local_alignment::LATable<T>		table;
	local_alignment::LAParams<T>	params;
	local_alignment::LA<T>			la;
	local_alignment::LABuffer		seqbuf, newseqbuf;	
public:
	LocalAlign(const AlignParams& alignparams): params(alignparams) {

	}

	void align(const char* seq1, int seqsize1, const char* seq2, int seqsize2, int& pos, AlignScores& alignment) {
		la.align(seq1, seqsize1, seq2, seqsize2, params, table, alignment, pos, newseqbuf, seqbuf);
	}
	void getAlignedSeqs(Str::Text::Val& seq1, Str::Text::Val& seq2) {
		
		seq1.clear(); seq2.clear();

		newseqbuf.startFwd();	
		seqbuf.startFwd();

		seq1.resize(newseqbuf.getFwdSize());
		seq2.resize(newseqbuf.getFwdSize());
		for(size_t i=0; i<newseqbuf.getFwdSize(); ++i) {
			seq1[i]=newseqbuf.getFwdPos()[i];
			seq2[i]=seqbuf.getFwdPos()[i];
		}
	}
};
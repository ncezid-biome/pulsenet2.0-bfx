/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele
*/

#include "stdafx.h"
#include "error.h"

Error::Error(Str::Text::Arg what)
	: KError(what)
{
}
Error::Error(const Msg& message)
	: KError(message.c_str())
{
}
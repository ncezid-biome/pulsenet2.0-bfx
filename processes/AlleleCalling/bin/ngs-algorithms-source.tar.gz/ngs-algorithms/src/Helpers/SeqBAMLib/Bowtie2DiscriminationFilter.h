#pragma once
#include "PathDef.h"
#include "BAMIterator.h"
#include "AlignmentWithScore.h"
#include "srsmapping_settings.h"

namespace SeqBAM
{

namespace Bowtie2Filter
{

struct DiscriminationSettings {

public:
    DiscriminationSettings(double minSeqId_, double minDiscr_, size_t maxDegen_): minSeqId(minSeqId_), minDiscr(minDiscr_), maxDegen(maxDegen_)
    {

    }

    DiscriminationSettings(const MappingSettings& mappingSettings): minSeqId(mappingSettings.thresholdSeqId), minDiscr(mappingSettings.minDiscrimination), maxDegen(mappingSettings.maxDegeneracy)
    {
    }

    double minSeqId;
    double minDiscr;
    size_t maxDegen;
};

class DiscriminationFilter
{

public:
    DiscriminationFilter(const DiscriminationSettings& s): sett(s)
    {
    }

    void Filter(const Str::Path::Val& inputFile, const Str::Path::Val& outputPath);

private:
    bool CompareSingle(BAM::Iterator& it, bamFile& outputFile, AlignmentWithScore& first);

    bool ComparePaired(BAM::Iterator& it, bamFile& outputFile, AlignmentWithScore& first);

private:
    std::vector<AlignmentWithScore> first_seg;
    std::vector<AlignmentWithScore> last_seg;

    const DiscriminationSettings sett;

public:
    //number of degenerate alignments that did not meet the criteria
    size_t pruned_;
    //number of degenerate alignments that did make the cut
    size_t retained_;
};

}
}


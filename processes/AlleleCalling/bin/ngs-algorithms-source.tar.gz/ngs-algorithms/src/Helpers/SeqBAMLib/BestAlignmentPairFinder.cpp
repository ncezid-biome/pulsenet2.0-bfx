#include "stdafx.h"
#include "BestAlignmentPairFinder.h"

SeqBAM::Bowtie2Filter::BestAlignmentPairFinder::BestAlignmentPairFinder(double minScore_) : minScore(minScore_)
{

}

bool SeqBAM::Bowtie2Filter::BestAlignmentPairFinder::accept(const AlignmentPair& p) const
{
    const bam1_t* r1 = p.first->read;
    const bam1_t* r2 = p.second->read;

    //BAM_FPROPER_PAIR flags are not always set (bowtie2)... dunno why
    //should we allow only the pairs that bowtie2 made? r1->core.pos == r2->core.mpos && r1->core.mpos == r2->core.pos
    //TODO: check insert size?
    return (r1->core.flag & BAM_FUNMAP) == 0 && (r2->core.flag & BAM_FUNMAP) == 0 && p.score >= minScore;
}

double SeqBAM::Bowtie2Filter::BestAlignmentPairFinder::score(const AlignmentPair& p) const
{
    return p.score;
}

void SeqBAM::Bowtie2Filter::BestAlignmentPairFinder::addPair(AlignmentWithScore* one, AlignmentWithScore* two)
{
    AlignmentPair p(one, two);
    add(p);
}

SeqBAM::Bowtie2Filter::AlignmentPair::MatchPosition SeqBAM::Bowtie2Filter::BestAlignmentPairFinder::matchPosition(const AlignmentPair& t) const
{
    return t.matchPosition();
}

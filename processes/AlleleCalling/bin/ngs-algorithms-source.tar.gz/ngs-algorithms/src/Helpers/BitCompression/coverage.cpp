#include "stdafx.h"

#include "Coverage.h"

#include <algorithm>


namespace compression
{

#pragma region CoverageItf

CoverageDrawerItf::~CoverageDrawerItf() {}

CoverageReaderItf::~CoverageReaderItf() {}

CoverageReaderItf::CountType  CoverageReaderItf::GetTotDiff(size_t basePos) const
{
    if(basePos==0) {
        return GetTot(basePos) ;
    }
    return GetTot(basePos) -GetTot(basePos-1) ;
}

size_t			CoverageReaderItf::GetMaxBaseNr(size_t base) const
{
    int el[4] = { GetBaseCount(base,0), GetBaseCount(base,1), GetBaseCount(base,2), GetBaseCount(base,3)};
    return std::max_element(el, el+4) - el;

};

}//compression
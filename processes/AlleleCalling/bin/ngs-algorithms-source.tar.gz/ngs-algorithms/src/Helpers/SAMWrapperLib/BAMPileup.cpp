#include "stdafx.h"
#include <exception.h>
#include <translate.h>
#include "BAMPileup.h"

namespace BAM
{

Pileup::Pileup(bool padCallback): padCallback_(padCallback), samFile_(nullptr), bamIndex_(nullptr)
{
}

Pileup::~Pileup()
{
    CloseFile();
}

void Pileup::OpenFile(FileResolver::Ptr files)
{
    samFile_=samopen(ToRef(files->GetSortedBAMFile()), PM("rb"), 0);
    if(samFile_==nullptr) {
        throw KError("Could not open BAM-file %1") << files->GetSortedBAMFile();
    }

    bamIndex_=bam_index_load_directly(ToRef(files->GetBAMIndexFile())); // load BAM index
    if(bamIndex_==nullptr) {
        //samFile_ is closed in destructor
        throw KError("Could not open index for BAM-file %1") << files->GetSortedBAMFile();
    }

    refInfos_=GetReferencesInfo();
}

Str::ID::Vec Pileup::GetReferenceNames() const
{
    Str::ID::Vec names;

    if(samFile_) {

        for(int32_t m=0; m<samFile_->header->n_targets; m++) {

            names.push_back(samFile_->header->target_name[m]);
        }
    }

    return names;
}

std::vector<BAMTypes::ReferenceInfo> Pileup::GetReferencesInfo() const
{
    std::vector<ReferenceInfo> refsInfo;

    if(samFile_) {

        for(int32_t m=0; m<samFile_->header->n_targets; m++) {

            ReferenceInfo refInfo={samFile_->header->target_name[m], samFile_->header->target_len[m]};

            refsInfo.push_back(refInfo);
        }
    }

    return refsInfo;
}

void Pileup::CloseFile()
{

    if(bamIndex_) {

        bam_index_destroy(bamIndex_);
        bamIndex_=nullptr;
    }
    if(samFile_) {

        samclose(samFile_);
        samFile_=nullptr;
    }
}

// internal: callback for bam_lplbuf_init()
int Pileup::pileup_func(ReferenceID tid, ReferencePosition pos, int n, const bam_pileup1_t* pl, void* data)
{
    Pileup* pileup=static_cast<Pileup*>(data);

    //this can happen if multiple references have the same name in a SAM file
    if(pos >= pileup->samFile_->header->target_len[tid])
        return 0;

    //if necessary, call ReferenceChanged
    //this also takes care of any end padding
    pileup->PerformReferenceChanged(tid);

    pileup->PerformPadCallback(tid, pos);
    pileup->lastPos_=pos;
    return pileup->PileupCallback(tid, pos, n, pl);
}

//////////// Pileup

// Default implementation: add all reads
int Pileup::FetchCallback(bam1_t& b)
{

    bam_plbuf_push(&b, buf_);
    return 0;
}

// internal: callback for bam_fetch()
int Pileup::fetch_func(bam1_t* b, void* data)
{
    Pileup* pileup=static_cast<Pileup*>(data);
    return pileup->FetchCallback(*b);
}

/**
 * Create a pileup for the given region. Only reads that have at least on base in [regionBegin, regionEnd],
 * are reported. Calling this function with range 1..5 will yield [1,5].
 */
void Pileup::CreatePileup(ReferenceID refId, ReferencePosition regionBegin, ReferencePosition regionEnd, bool countMultipleAlignments)
{
    ASSERT(regionBegin<2000000000UL);
    ASSERT(regionEnd<2000000000UL);

    if(samFile_) {

        //don't worry about underflow, it's supposed to do that if regionBegin==0
        lastPos_=regionBegin-1;
        currentTid_=refId;

        buf_=bam_plbuf_init(pileup_func, this);
		if (countMultipleAlignments)
			bam_plp_set_mask(buf_->iter, BAM_FUNMAP | BAM_FQCFAIL | BAM_FDUP); //do count alternative positions!


        bam_fetch(samFile_->x.bam, bamIndex_, refId, regionBegin, regionEnd+1, this, reinterpret_cast<bam_fetch_f>(fetch_func));

        //finalize pileup
        bam_plbuf_push(0, buf_);
        PerformPadCallback(refId, regionEnd+1);

        PileupFinished();

        bam_plbuf_destroy(buf_);
    }
}

// Create a pileup for the entire BAM-file
void Pileup::CreatePileup(bool countMultipleAlignments)
{
    if(samFile_) {

        bam1_t* b;
        b=stl_bam_init1();

        lastPos_=NOPOSITION;
        currentTid_=NOREFERENCE;

        buf_=bam_plbuf_init(pileup_func, this);
		if (countMultipleAlignments)
			bam_plp_set_mask(buf_->iter, BAM_FUNMAP | BAM_FQCFAIL | BAM_FDUP); //do count alternative positions!

        while(samread(samFile_, b)>=0) {

            bam_plbuf_push(b, buf_);
        }

        //finalize pileup
        bam_plbuf_push(0, buf_);

        PerformReferenceChanged(NOREFERENCE);
        PileupFinished();

        bam_plbuf_destroy(buf_);
        stl_bam_destroy1(b);
    }
}

//////////// Pileup with levels

// Default implementation: add all reads
int Pileup::LeveledFetchCallback(bam1_t& b)
{

    bam_lplbuf_push(&b, lbuf_);
    return 0;
}

// internal: callback for bam_fetch() in LeveledPileup
int Pileup::lfetch_func(bam1_t* b, void* data)
{

    Pileup* pileup=static_cast<Pileup*>(data);
    return pileup->LeveledFetchCallback(*b);
}

/**
 * Create a pileup (with levels) for the given region. Only reads that have at least on base in [regionBegin, regionEnd],
 * are reported.
 */
void Pileup::CreateLeveledPileup(ReferenceID refId, ReferencePosition regionBegin, ReferencePosition regionEnd)
{
    ASSERT(regionBegin<2000000000UL);
    ASSERT(regionEnd<2000000000UL);

    if(samFile_) {

        //don't worry about underflow, it's supposed to do that if regionBegin==0
        lastPos_=regionBegin-1;
        currentTid_=refId;
        lbuf_=bam_lplbuf_init(pileup_func, this);

        bam_fetch(samFile_->x.bam, bamIndex_, refId, regionBegin, regionEnd+1, this, reinterpret_cast<bam_fetch_f>(lfetch_func));

        //finalize pileup
        bam_lplbuf_push(0, lbuf_);
        PerformPadCallback(refId, regionEnd+1);

        PileupFinished();

        bam_lplbuf_destroy(lbuf_);
    }
}

// Create a pileup (with levels) for the entire BAM-file
void Pileup::CreateLeveledPileup()
{
    if(samFile_) {

        bam1_t* b;
        b=stl_bam_init1();

        lastPos_=NOPOSITION;
        currentTid_=NOREFERENCE;

        lbuf_=bam_lplbuf_init(pileup_func, this);

        while(samread(samFile_, b)>=0) {

            bam_lplbuf_push(b, lbuf_);
        }

        //finalize pileup
        bam_lplbuf_push(0, lbuf_);

        PerformReferenceChanged(NOREFERENCE);
        PileupFinished();

        bam_lplbuf_destroy(lbuf_);
        stl_bam_destroy1(b);
    }
}

/**
 * Perform, if needed and enabled, some padding callbacks. If the last position for
 * which the callback was executed was pos-5, then this method will invoke the callback
 * for pos-4...pos-1
 */
void Pileup::PerformPadCallback(ReferenceID tid, ReferencePosition pos)
{
    if(padCallback_) {

        //if lastPos_ is UINT32_MAX, then lastPos_+1=0
        //if pos is 1, then a padding call is made for pos=0
        while(pos>lastPos_+1) {

            lastPos_++;
            PileupCallback(tid, lastPos_, 0, nullptr);
        }
    }
}

/**
 * Notify, if needed, the implementor that we've crossed the boundary between two
 * references. This method also takes care of any padding needed for the reference
 * that has ended. It also resets the lastPos_ counter that is used in PerformPadCallback.
 */
void Pileup::PerformReferenceChanged(ReferenceID tid)
{
    if(currentTid_!=tid) {

        if(currentTid_ != NOREFERENCE)
            PerformPadCallback(currentTid_, refInfos_[currentTid_].length);

        currentTid_ ++;

        //switch to and pad contigs that have been skipped
        for(; currentTid_ < tid && currentTid_ < refInfos_.size(); currentTid_++) {

            ReferenceChanged(currentTid_);
            lastPos_ = NOREFERENCE;

            PerformPadCallback(currentTid_, refInfos_[currentTid_].length);
        }

        ReferenceChanged(tid);
        lastPos_ = NOREFERENCE;
    }
}

}
#pragma once
#include "BestPositionFinder.h"
#include "AlignmentWithScore.h"

namespace SeqBAM
{
namespace Bowtie2Filter
{

class BestAlignmentFinder: public GenericBestPosFinder<AlignmentWithScore, int>
{

public:

    BestAlignmentFinder(double minScore_);

    bool accept(const AlignmentWithScore& t) const;

    double score(const AlignmentWithScore& t) const;

    void addSwap(AlignmentWithScore& t)
    {

        AlignmentWithScore tmp;
        std::swap(t, tmp);

        add(tmp);
    }

private:
    const double minScore;

};

}

}

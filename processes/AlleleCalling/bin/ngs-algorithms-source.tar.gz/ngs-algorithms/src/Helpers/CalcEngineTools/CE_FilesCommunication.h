#pragma once

#include "boost/thread/mutex.hpp"

#include "CalcCommunication.h"
#include "CalcListener.h"
#include "CommunicationFromCalc.h"


namespace engine
{
    
class Logger;

class FilesCommunication : public communication::CommunicationFromCalc
{
public:
    typedef boost::shared_ptr<FilesCommunication> Ptr;

public:
    FilesCommunication( Logger* logger );

    virtual void                 TransferInfo(const communication::CalcInfo& info) override;
    virtual const volatile bool& MustContinue() const override;
    virtual bool                 CanUseInThread() const override;

private:
    void    SetupListeners();
    Logger* GetLogger() { return logger_; }

private:
    Logger*      logger_;
    bool         mustContinue_;
    boost::mutex mutex_;

    int curProgress_;
    int maxProgress_;

    communication::CalcListener listeners_;
};


} // namespace engine

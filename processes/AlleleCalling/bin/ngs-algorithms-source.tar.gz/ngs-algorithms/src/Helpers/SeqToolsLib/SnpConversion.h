#pragma once


namespace snp
{

static const int minNumber=1, maxNumber=17;

int    baseToNumber(char base);
char   numberToBase(int number);


} // namespace snp

#include "stdafx.h"
#include "BAMCoverage.h"

void BAM::Coverage::Reset(size_t minLength)
{
    for(int m=0; m<5; m++) {
        coverages_[m].clear();
        coverages_[m].reserve(minLength);
    }
}

size_t BAM::Coverage::GetCount() const
{
    return coverages_[0].size();
}

BAM::Coverage::CountType BAM::Coverage::GetTot(size_t basePos) const
{
    return coverages_[4][basePos];
}

BAM::Coverage::CountType BAM::Coverage::GetBaseCount(size_t basePos, size_t baseNr) const
{
    return coverages_[baseNr][basePos];
}

void BAM::Coverage::AppendCoverageCounts(CountType a, CountType c, CountType g, CountType t, CountType total)
{
    coverages_[0].push_back(a);
    coverages_[1].push_back(c);
    coverages_[2].push_back(g);
    coverages_[3].push_back(t);

    coverages_[4].push_back(total);
}

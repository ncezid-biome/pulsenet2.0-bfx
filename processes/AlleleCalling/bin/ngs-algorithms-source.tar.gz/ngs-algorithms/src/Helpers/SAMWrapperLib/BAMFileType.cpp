#include "stdafx.h"
#include "BAMFileType.h"


Str::Text::Ref BAM::GetTypeReadMode(FileType t)
{
    if(t == FileType::SAM)
        return "r";
    return "rb";
}

Str::Text::Ref BAM::GetTypeWriteMode(FileType t)
{
    if(t == FileType::SAM)
        return "w";
    return "wb";
}

Str::Text::Ref BAM::ToString(FileType t)
{
    if(t == FileType::SAM)
        return "SAM";
    return "BAM";
}

BAM::FileType BAM::GetFileType(const Str::Path::Val& path)
{
    if(boost::iequals(path.extension().string(), ".sam"))
        return FileType::SAM;
    return FileType::BAM;
}

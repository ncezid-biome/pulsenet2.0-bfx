/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#include <exception>
#include <sstream>
#include "msg.h"
#include "exception.h"

#ifndef ERROR_FILE_H
#define ERROR_FILE_H

class Error : public KError {
public:
	Error(Str::Text::Arg what);
	Error(const Msg& message);
};

#define ErrorMsg(X) Error(Msg() << X);

#endif
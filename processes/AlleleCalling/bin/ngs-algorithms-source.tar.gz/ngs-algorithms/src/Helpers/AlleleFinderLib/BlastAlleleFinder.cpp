#include "stdafx.h"

#include "BlastAlleleFinder.h"

#include <map>
#include <set>
#include <unordered_set>

#include <boost/algorithm/string/case_conv.hpp>

#include "exception.h"
#include "CalcCommunication.h"
#include "StringDef.h"
#include "XmlReportBuilder.h"
#include "textfile.h"
#include "filereader.h"
#include "filewriter.h"
#include "IBuffImpl.h"
#include "runextern_manager.h"
#include "Message.h"
#include "CalcCommunicationReporter.h"

#include "LocusOutput.h"

#include "RunExceptions.h"
#include "AlleleFinderExceptions.h"
#include "BlastAlleleFinderSettings.h"
#include "CE_FileSystem.h"
#include "NamedSequence.h"
#include "SequenceManip.h"
#include "SequenceRangeManip.h"
#include "CodonManip.h"
#include "CodonRangeManip.h"
#include "SequenceRangeInspect.h"
#include "AlleleName.h"
#include "SequenceFileManip.h"

#include "Repeats.h"
#include "Blast.h"
#include "Contigs.h"


#include "GzipCompressionType.h"


using namespace std;
using namespace communication;


BlastAlleleFinderAlgorithm::BlastAlleleFinderAlgorithm()
{
    RegisterFactoryTrait<MegaBlastAlleleFinder>::RegisterItem();
}

int BlastAlleleFinderAlgorithm::ExecuteImpl(int argc, char* argv[], const ExecuteEnvironment& env, const communication::CalcCommunication& comm)
{
    BlastAlleleFinderSettings settings;
    if (settings.ParseAndSetup(argc, argv, env, comm)) {
		//make sure the organism is filled in
		if (!settings.organismsettings.HasOrganism()) { //this would be the case of a BN76 client and a BN8 CE
			settings.organismsettings.SetOrganism(settings.GetOrganismFromAlleleInfoPath());
		}
		//load specific settings
		engine::OrganismSettings::LoadSettingsImplementation impl = [&](const engine::ProgramOptions::EnvSettings& envSettings, 
																const engine::ExecuteEnvironment& env, 
																const communication::CalcCommunication& comm) 
																{ settings.LoadEnvSettingsImpl(envSettings, env, comm); };
		settings.organismsettings.LoadEnvSettings(env, comm, impl);
		//log the settings
		settings.LogSettings(comm);
        //run the algorithm
        BlastAlleleFinder::Apply(settings, env, comm);
    }
	else
	{ 
		settings.showHelp(std::cout);
	}
    return 0;
}

/**
    Use this method to directly call the allele finder algorithm without the need to construct a custom
    command line. Good for e.g. unit testing.

    \note Throws on error
*/
int BlastAlleleFinderAlgorithm::Execute(BlastAlleleFinderSettings& settings, const ExecuteEnvironment& env, const communication::CalcCommunication& comm)
{
    PrepareManualRun( env );

    BlastAlleleFinder::Apply(settings, env, comm);
    return 0;
}





BlastAlleleFinder::BlastAlleleFinder()
{
}
BlastAlleleFinder::~BlastAlleleFinder()
{
}
void BlastAlleleFinder::apply(BlastAlleleFinderSettings& settings, const ExecuteEnvironment& env, const communication::CalcCommunication& comm) const
{
    BlastAlleleFinderData data( settings, comm );

    checkPre (settings, data, env, comm);
    applyImpl(settings, data, env, comm);
}
void BlastAlleleFinder::Apply(BlastAlleleFinderSettings& settings, const ExecuteEnvironment& env, const communication::CalcCommunication& comm)
{
    Ptr finder = BlastAlleleFinder::Factory::GetMap(settings.algorithmType);
    if (finder==0)
        throw KError(TXT("Could not find algorithm '%1'.")) << settings.algorithmType;

    finder->apply(settings, env, comm);
}




MegaBlastAlleleFinder::MegaBlastAlleleFinder()
{
}

MegaBlastAlleleFinder::FactoryIDType::Ref	MegaBlastAlleleFinder::GetTypeName()
{
    return "MegaBlast";
}
MegaBlastAlleleFinder::FactoryIDType::Ref	MegaBlastAlleleFinder::GetFactoryType() const
{
    return GetTypeName();
}
void MegaBlastAlleleFinder::checkPre(BlastAlleleFinderSettings& settings, BlastAlleleFinderData& data, const ExecuteEnvironment& env, const communication::CalcCommunication& comm) const
{
	if (settings.k < 11 || settings.k > 12)
	{
		if (settings.clientVersion < 2)
		{
			// old client versions were sending k=20 as defaults. fix. that without much fuzz
			comm.Send(communication::CalcMessage( Message("Word size %1 is not supported by the algorithm, using 11 instead.") << settings.k ));
		}
		else 
		{
			// this is not a bug in client anymore, somethings wronk in the database.
			comm.Send(communication::CalcWarning( Message("Word size %1 is not supported by the algorithm, using 11 instead. Contact curator to verify settings.") << settings.k ));
		}
		settings.k = 11;
	}
}

struct Hit {
    Str::ID::Val allele;
    Str::Text::Val sequence, seqbefore, seqafter;
    double score, evalue;
    int bitscore;
    int length;
    int start, stop;
    int nmismatches, ngapopens;
    bool fwd, requiresStartStop, startsWithStart, stopsWithStop, fullLength, internalStop;
    Str::Text::Val contigname;

    Hit(Str::ID::Arg iallele, Str::Text::Arg isequence, double iscore, int ilength, int istart, int istop, Str::Text::Arg icontigname, bool ifwd, int inmismatches, int ingapopens, Str::Text::Arg iseqbefore, Str::Text::Arg iseqafter, double ievalue,int ibitscore, bool iRequiresStartStop, bool iStartsWithStart, bool iStopsWithStop, bool iFullLength, bool iInternalStop)
        : allele(iallele), sequence(isequence), score(iscore), length(ilength), start(istart), stop(istop), contigname(icontigname), fwd(ifwd), nmismatches(inmismatches), ngapopens(ingapopens), seqbefore(iseqbefore), seqafter(iseqafter), evalue(ievalue), bitscore(ibitscore), requiresStartStop(iRequiresStartStop), startsWithStart(iStartsWithStart), stopsWithStop(iStopsWithStop), fullLength(iFullLength), internalStop(iInternalStop) {}
};
typedef std::vector<Hit> Hits;
typedef std::map<Str::ID::Val, Hits> BestHits;

void RemoveOverlappingHits(BestHits& hits, double minOverlap, const communication::CalcCommunication& comm)
{
	/* 
	//this is the original sort func
	auto sortFunc = 
		[](const Hit& hit1, const Hit& hit2) {		
			return ((hit1.stop-hit1.start) == (hit2.stop-hit2.start) && hit1.score>hit2.score) || ((hit1.stop-hit1.start) > (hit2.stop-hit2.start));
		};
	*/

	auto hitLen = [](const Hit& hit) { return hit.stop-hit.start; };
	auto hitLenComp = [&hitLen](const Hit& hit1,const Hit& hit2) { return hitLen(hit1)>hitLen(hit2); };
    {
        size_t cnt=0;
        for(BestHits::iterator it = hits.begin(); it!=hits.end(); ++it) {

			if (it->second.size()<=1) continue;

			auto maxLenHit = std::max_element(it->second.begin(), it->second.end(), hitLenComp);
			double maxLen = hitLen(*maxLenHit);

			auto scoreFunc = [maxLen, &hitLen](const Hit& hit) {
				return 10000.0*((!hit.requiresStartStop && hit.fullLength) || (hit.startsWithStart && hit.stopsWithStop))
						+ 10000.0*((!hit.requiresStartStop && hit.fullLength) || (!hit.internalStop))
						+ (10000.0*hitLen(hit))/maxLen
						+ hit.score/100.0;
			};

			auto sortFunc = 
				[&scoreFunc](const Hit& hit1, const Hit& hit2) {
					return scoreFunc(hit1)>scoreFunc(hit2);		
			};

            std::vector<char> toremove_perfectHits(it->second.size(), 0);
            std::sort(it->second.begin(), it->second.end(), sortFunc);

            for(size_t i=0; i<it->second.size(); ++i) {
                if (toremove_perfectHits[i]) continue;
                for(size_t j=i+1; j<it->second.size(); ++j) {
                    if (toremove_perfectHits[j]) continue;

					double overlap = (double)std::min(it->second[j].stop, it->second[i].stop) - (double)std::max(it->second[j].start, it->second[i].start);
					double minlen = std::min(it->second[j].stop-it->second[j].start, it->second[i].stop-it->second[i].start);
                    
					if (overlap>=minOverlap*minlen)
                    //if (it->second[j].start>=it->second[i].start && it->second[j].stop<=it->second[i].stop)
                        toremove_perfectHits[j] = 1;
                }
            }


            for (size_t j=toremove_perfectHits.size(); j>0; --j) {
                if (toremove_perfectHits[j-1]) {
                    it->second.erase(it->second.begin() + j-1);
                    cnt+=1;
                }
            }
        }
        comm.Send( communication::CalcMessage( Message("Removed %1 overlapping hits.", cnt).str() ) );
    }
}

void ReplaceAcceptedAlleles(BestHits& hits, const Str::Path::Val& acceptedAllelesFile, const communication::CalcCommunication& comm)
{
    if ( acceptedAllelesFile.empty() ) 
    {
        return;
    }

    typedef std::unordered_map<Str::Text::Val, Str::Text::Val> AllelesPerLocus;
    typedef std::unordered_map<Str::Text::Val, AllelesPerLocus> AcceptedAlleles;

    AcceptedAlleles acceptedAlleles;
    
    // read in the accepted alleles
    SeqFileReaderPtr reader = SeqFileReader::AutoDetect(acceptedAllelesFile)->Clone();
    comm.Send( communication::CalcMessage( Message("Opening file of type: '%1'...") << reader->GetFactoryType() ) );
    reader->init(acceptedAllelesFile, 5000000);
    while (reader->hasMore()) 
    {
        seq::NamedSequence seq;
        reader->getNextSeq(seq);

        //do we really need this, or is IUPACToUpperCase (built-in into NamedSequence) sufficient?
        seq::ActgToUpperCase(seq.GetData());

        const Str::Text::Val locus = AlleleName::ExtractLocusName(seq.GetName());
        const Str::Text::Val allele = seq.GetName();
        acceptedAlleles[locus][seq.GetData().ToString()] = allele;
    }

    for(BestHits::iterator hi = hits.begin(); hi != hits.end(); ++hi) 
    {
        const Str::ID::Val& locus = hi->first;
        
		const AcceptedAlleles::const_iterator si = acceptedAlleles.find( locus );
        if (si == acceptedAlleles.end() )
        {
            continue;
        }
        
		const AllelesPerLocus& perLocus = si->second;
        for (Hit& hit : hi->second)
        {
            const AllelesPerLocus::const_iterator ai = perLocus.find( hit.sequence );
            if (ai == perLocus.end())
            {
                continue;
            }
            
			const Str::Text::Val allele = ai->second;
			hit.allele = allele;
            hit.score = 100.0;
            hit.nmismatches = 0;
			hit.ngapopens = 0;
        }
    }
}

void MegaBlastAlleleFinder::applyImpl(const BlastAlleleFinderSettings& settings, BlastAlleleFinderData& data, const ExecuteEnvironment& env, const communication::CalcCommunication& comm) const
{
    using namespace runextern;

	//--- log the start codons we use -------------------------------------------------------------
	comm.Send( communication::CalcMessage("The following start codons will be used:"));
	for (size_t i=0; i<settings.startCodons.size(); ++i)
		comm.Send( communication::CalcMessage("\t"+settings.startCodons[i]));

	//--- log the hunting setting -----------------------------------------------------------------
	comm.Send( communication::CalcMessage( (RawMessage("Hunting for start/stop codons: %1") << (settings.huntForStartStop?"Yes":"No")).str() ) );
	
    //--- make sure we have the right local directory ---------------------------------------------
    Str::Path::Val workingDir = env.localDir;

    //--- make sure we have a proper fasta file (uncompress if needed) ----------------------------
    const Str::Path::Val fastaFile = workingDir / "genome.fasta";

    // Special unzip: modify leading reads that do not fit with what blastn expects
    seq::UnzipSequenceFileForBLAST( settings.sequenceFile, fastaFile, comm );

	Str::Path::Val outputFile = RunBlast(	
		fastaFile,
		"dc-megablast", 
		data.GetBlastDatabaseName(),
		settings.maxNHits,
		settings.k,
		settings.percentIdentity,
		settings.reward,
		settings.penalty,
		settings.ungapped,
		settings.gapopen,
		settings.gapextend,
		settings.doDusting,
		env, comm);

    /* --------------------------------------------------------------------------------------------
        COPY THE RESULTS TO THE DATA DIRECTORY
       -------------------------------------------------------------------------------------------- */
    if (!settings.destDataDir.empty()) {
        //nothing to be copied
    }

    /* --------------------------------------------------------------------------------------------
        PREPARE THE RESULT FILES:
        (1) loci.txt
        (2) alleles.100.txt
       -------------------------------------------------------------------------------------------- */

    //--- fetch the allele info -------------------------------------------------------------------
    struct AlleleInfo {
        Str::ID::Val locus;
        size_t length;
        bool hasstartstop;
        AlleleInfo() : length(0) {}
        AlleleInfo(Str::ID::Arg ilocus, size_t ilength, bool ihasstartstop) : locus(ilocus),  length(ilength), hasstartstop(ihasstartstop) {}
    };
    typedef std::map<Str::ID::Val, AlleleInfo> AllAlleleInfo;

    Str::Text::Vec loci;
    AllAlleleInfo myAlleleInfo;
    {
        comm.Send( communication::CalcMessage("Reading allele information ... "));
        std::set<Str::Text::Val> myLoci;
        //read in the allele info file
        TextFileBuffer is( ToRef(data.GetAlleleFileName()) );
        is.Open();
        Str::Text::Val line;
        Str::Text::Vec parts;
        while (is.IsOk()) 
        {
            is.ReadLine(line);            
            if (line.empty()) continue;

            splitstring(line, parts, "\t");
            if (parts.size()==4) 
            {
                myAlleleInfo[parts[0]] = AlleleInfo(parts[1], ParseThrow<size_t>(parts[2]), ParseThrow<int>(parts[3])!=0);
                if (myLoci.find(parts[1]) == myLoci.end()) 
                {
                    loci.push_back(parts[1]);
                    myLoci.insert(parts[1]);
                }
            }
            else 
            {
                throw MalformedAlleleFileException(RawMessage(PM("Malformed allele information. Expected 4 columns, got '%1'"), line));
            }
        }
    }

    const AllAlleleInfo& alleleInfo = myAlleleInfo;

    //--- fetch the accepted alleles --------------------------------------------------------------




    //--- fetch the contig sequences --------------------------------------------------------------    
    Contigs contigs, reverseContigs;
    {
        comm.Send( communication::CalcMessage("Reading contig sequences ... "));
        FastaFileReader reader(fastaFile);

        while(reader.hasMore()) {
            seq::NamedSequence sequence;
            reader.getNextSeq(sequence);

            //do we really need this, or is IUPACToUpperCase (built-in into NamedSequence) sufficient?
            seq::ActgToUpperCase(sequence.GetData());

            reverseContigs[sequence.GetName()] = seq::ReverseComplementCopy(sequence.GetData());
            contigs[sequence.GetName()] = std::move(sequence.GetData());
        }
    }

    // --- fetch the BLAST results ----------------------------------------------------------------
    //	for every locus, keep track of
    //		(1) the best hit
    //		(2) the second-best hit

    const int nBasesBefore  = 300;
    const int nBasesAfter   = 300;
    const double lengthOverlap = settings.lengthOverlap;
	const double hitOverlap = settings.hitOverlap;

    BestHits perfectHits;
    BestHits bestHits;

	AlleleRepeatMask alleleRepeatMask;

    {
        SkippedAllellesInfo skipped;

        comm.Send( communication::CalcMessage("Reading BLAST hits ... "));

        TextFileBuffer is( ToRef(outputFile) );
        is.Open();       
        Str::Text::Val line;
        Str::Text::Vec parts;

        while (is.IsOk()) {

            is.ReadLine(line);
            if (line.empty() || line.front() == '#' /*a comment line*/)
                continue;

            splitstring(line, parts, "\t");

            if ( parts.size() != 12 ){
                comm.Send(CalcWarning(RawMessage(PM("Unable to parse BLAST output line: '%1'"), line).c_str()));
                continue;
            }

            const Str::Text::Val contigId = parts[0];
            const Str::Text::Val alleleId = parts[1];
            double score = ParseThrow<double>(parts[2]);
            int length = ParseThrow<int>(parts[3]); // BLAST alignment length
            const int nmismatches = ParseThrow<int>(parts[4]);
            const int ngapopens = ParseThrow<int>(parts[5]);
            int start = ParseThrow<int>(parts[6])-1; //this is the real starting position
            int stop = ParseThrow<int>(parts[7]); //this is the real ending position
            int refstart = ParseThrow<int>(parts[8]);
            int refstop = ParseThrow<int>(parts[9]);
            const double evalue = ParseThrow<double>(parts[10]);
            const int bitscore = atoi(parts[11].c_str()); //ParseThrow<int>(parts[11]);

            auto alleleInfoIt = alleleInfo.find(alleleId);
            if (alleleInfoIt == alleleInfo.end()) 
            {
                throw MissingAllelException( RawMessage(PM("Could not find allele information for allele '%1'."), alleleId) );
            }
            const Str::Text::Val locusId = alleleInfoIt->second.locus;
            const int alleleLength = static_cast<int>(alleleInfoIt->second.length);
			assert(alleleLength > 0 && static_cast<size_t>(alleleLength) == alleleInfoIt->second.length);

            if (alleleLength < 1 || alleleLength < settings.k) 
            {
                comm.Send( communication::CalcWarning(Message(TXT("Allele '%1' is too short to be considered (length %2, which is smaller than %3)."), alleleId, alleleLength, settings.k)));
                ++skipped.alleleTooShort;
                continue;
            }

            const bool fwd = refstart < refstop;
			
			if ((1.0*length)>=lengthOverlap*alleleLength) {
				if (fwd)
					alleleRepeatMask.updateRepeatScore(locusId, contigId, alleleLength, start, stop, score);
				else 				
					alleleRepeatMask.updateRepeatScore(locusId, contigId, alleleLength, start, stop, score);
			}
			

            const seq::Sequence& contig = fwd ? contigs[contigId] : reverseContigs[contigId];
			const int contigLength = static_cast<int>(contig.GetLength());
			assert(contigLength > 0 && static_cast<size_t>(contigLength) == contig.GetLength());
            if (!fwd)
            {
                std::swap(refstart, refstop);

                // by now, start and stop are a zero-based right open interval [start, stop) on the forward contig.
                // readjust to reversed contig.
				
                const int tmpStop = contigLength - start;
                start = contigLength - stop;
                stop = tmpStop;
            }

            // from now, we can peacefully assume that the allele is found in forward direction.
            // start < stop, start codons are start codons and stop codons are stops.
            // The only thing that reminds us of it being any different is 'fwd'.

            const int originalStart = start;
            const int originalStop = stop;			

            const bool fullLength = refstart == 1 && refstop == alleleLength;
            if (!fullLength)
            {
                score = ReduceScore(
                    score,
                    pm("Found allele does not fully cover reference allele (fwd: %1, ref start: %2, ref stop: %3, allele length: %4)")
                        .arg(fwd).arg(refstart).arg(refstop).arg(alleleLength),
                    comm);
            }

            bool requiresStartStop = alleleInfoIt->second.hasstartstop;
            bool startsWithStart = seq::StartsWithStartCodon( contig.GetIter(start),  contig.GetIter(start+3), settings.startCodons );
            bool stopsWithStop   = seq::EndsWithStopCodon   ( contig.GetIter(stop-3), contig.GetIter(stop), settings.stopCodons );

            //start and stop need to be in frame
            if (startsWithStart && stopsWithStop && (stop-start)%3!=0) 
            {
                comm.Send( CalcLogMessage(
                    pm("Allele has start and stop codons but they are not in frame (start: %1, stop: %2). Resetting %3 status to 0.")
                        .arg(start).arg(stop).arg(fwd ? PM("stop") : PM("start"))
                    ));
                stopsWithStop = false;
            }

            //avoid internal stop codons
            if ( stopsWithStop ){
                const bool hasInternalStop = seq::ContainsInternalStopCodon(
                    contig.GetIter(start), contig.GetIter(stop), settings.stopCodons, FrameDirection::Forward);

                if (hasInternalStop){
                    comm.Send( CalcLogMessage(
                        pm("Allele has end codon and internal stop codon. Resetting 'has stop codon' to false.")
                        ));

                    stopsWithStop = false;
                }
            }

            if ( (!settings.huntForStartStop) || (!alleleInfoIt->second.hasstartstop)) 
            {
                // no point in hunting for start and stop
                if ((1.0*length)<(1.0*alleleLength))
                {
                    // Alignment length < allele length -> partial allele match
                    if (! settings.huntForStartStop)
                        ++skipped.partialMatchAndNoStartStopHunt;
                    else
                        ++skipped.partialMatchAndNoStartStop;
                    continue;
                }
                
            }
            else 
            {
                //hunt for start and stop if required
                requiresStartStop = true;
                
                if ((1.0*length)<(lengthOverlap*alleleLength))
                {
                    //alignment too short, ignore it
                    ++skipped.potentialOverlapTooSmall;
                    continue;
                }

                ////start hunting for starts and stops
                //startsWithStart = seq::StartsWithStartCodon( contig.GetIter(start),  contig.GetIter(start+3), settings.startCodons );
                //stopsWithStop   = seq::EndsWithStopCodon   ( contig.GetIter(stop-3), contig.GetIter(stop), settings.stopCodons );

                ////start and stop need to be in frame
                //if (startsWithStart && stopsWithStop && (stop-start)%3!=0) 
                //{
                //    comm.Send( CalcLogMessage(
                //        pm("Allele has start and stop codons but they are not in frame (start: %1, stop: %2). Resetting %3 status to 0.")
                //            .arg(start).arg(stop).arg(fwd ? PM("stop") : PM("start"))
                //        ));
                //    stopsWithStop = false;
                //}

                ////avoid internal stop codons
                //if ( stopsWithStop ){
                //    const bool hasInternalStop = seq::ContainsInternalStopCodon(
                //        contig.GetIter(start), contig.GetIter(stop), settings.stopCodons, FrameDirection::Forward);

                //    if (hasInternalStop){
                //        comm.Send( CalcLogMessage(
                //            pm("Allele has end codon and internal stop codon. Resetting 'has stop codon' to false.")
                //            ));

                //        stopsWithStop = false;
                //    }
                //}

                if (!startsWithStart || !stopsWithStop) 
                {
                    const int expectedStart = start - (refstart - 1);
                    const int expectedStop = stop + (alleleLength - refstop);

                    comm.Send( communication::CalcLogMessage(Message(TXT("Locus %1, hunting for start and stop codons ... "), locusId)));
                    comm.Send( communication::CalcLogMessage(Message(TXT("\tcurrent start: %1 current stop %2,	current length %4, targeted length %3, expected start %5, expected stop %6... ")) << start <<  stop <<  alleleLength << length <<  expectedStart <<  expectedStop));
                    //comm.Send( communication::CalcMessage(Message(TXT("\tref start: %1 ref stop %2 ... "), refstart, refstop)));

                    //get all start and stop codons

                    const int extra = static_cast<int>(settings.extraBasesForStartStop);
					assert(extra >= 0 && static_cast<size_t>(extra) == settings.extraBasesForStartStop);
                    int maxExtend = 2*extra;
                    if (settings.extrapolateAlignment && alleleLength > length) 
                    {
                        maxExtend += (alleleLength - length);
                    }

                    std::vector<int> startPositions;
                    if ( refstart == 1 && startsWithStart) 
                    { 
                        startPositions.push_back(start); // already found the start
                    }
                    else 
                    {
                        //hunt for the start codon											
                        const int increment = -1;

                        int myPos  = start + extra + increment;
                        int extend = 0;

                        // Make sure we're not outside of the contig
                        if ( myPos >= contigLength ){
                            extend += myPos - contigLength + 1;
                            myPos   = contigLength - 1;
                        }
                        
                        for( ;
                             myPos >= 0 && extend <= maxExtend;
                             myPos += increment, ++extend )
                        {
                            if ( seq::ContainsCodonAt(&contig[myPos], settings.startCodons) )
                            {
                                startPositions.push_back(myPos);                                                        
                            }
                        }
                    }

                    std::vector<int> stopPositions;
                    if (refstop==alleleLength && stopsWithStop) 
                    {
                        stopPositions.push_back(stop); // already found the stop
                    }
                    else 
                    {
                        //hunt for the stop codon
                        const int increment = 1;

                        int myPos  = stop - 3 - extra + increment;
                        int extend = 0;

                        // Make sure we're not outside of the contig
                        if ( myPos < 0 ){
                            extend += -myPos;
                            myPos   = 0;
                        }

                        for (;
                              myPos+3 <= contigLength && extend <= maxExtend;
                              myPos += increment, extend += 1 )
                        {
                            if ( seq::ContainsCodonAt(&contig[myPos], settings.stopCodons) )
                            {
                                stopPositions.push_back(myPos +3);   
                            }
                        }
                    }

                    //find the pairs of start/stop codons that are in the same frame
                    int bestStart = -1, bestStop = -1;

                    //choose the start/stop codon that best fits the start position
                    int bestDiff = -1;
                    for(size_t i1=0; i1<startPositions.size(); ++i1) 
                    {
                        int myDiff = abs(expectedStart - startPositions[i1]);
                        if (bestDiff == -1 || myDiff < bestDiff) 
                        {
                            bestDiff = myDiff;
                            bestStart = startPositions[i1];
                        }
                    }

                    //find the correct stop position 
                    std::sort(stopPositions.begin(), stopPositions.end());
                    for (size_t i2 = 0; i2 < stopPositions.size(); ++i2) 
                    {
                        if (   (stopPositions[i2] - bestStart) % 3 == 0
                            &&  stopPositions[i2] >= bestStart )
                        {
                            bestStop = stopPositions[i2];
                            break;
                        }
                    }

                    //comm.Send( communication::CalcMessage(Message(TXT("\t best start: %1 best stop: %2 ... "), bestStart, bestStop)));

                    if (bestStart!=-1 && bestStop!=-1) 
                    {
                        if (start != bestStart || stop != bestStop) 
                        { 
                            //avoid perfect matches here
                            score = ReduceScore(
                                score,
                                pm("Codon start and stop positions are not the best start and stop positions. (start, stop: %1;%2, best: %3;%4)")
                                    .arg(start).arg(stop).arg(bestStart).arg(bestStop),
                                comm);
                        }
                        start = bestStart;
                        stop = bestStop;
                        length = bestStop - bestStart;
                        startsWithStart = true;
                        stopsWithStop = true;
                    }

                    comm.Send( communication::CalcLogMessage(Message(TXT("\t found allele at [%1, %2[   starts with start? %3   stops with stop? %4!"), start, stop, (startsWithStart?"Y":"N"), (stopsWithStop?"Y":"N"))));
                }
            }

            //extract the allele
            {
                const seq::Sequence sequence = contig.Sub(start, stop);

                const size_t beforeStart = static_cast<size_t>(std::max<int>(0, start - nBasesBefore));
                const seq::Sequence seqbefore = contig.Sub(beforeStart, start);

                const size_t afterStop = std::min<int>(contigLength, stop + nBasesAfter);
                const seq::Sequence seqafter = contig.Sub(stop, afterStop);

                //check for internal start/stop
                bool hasInternalStop = false;
                if (requiresStartStop && startsWithStart) 
                {
                    // Only forward search: sequence has been reverse complemented here, if required.
                    if ( ContainsInternalStopCodon(sequence, settings.stopCodons, FrameDirection::Forward) )
                    {
                        hasInternalStop = true;

                        //avoid perfect matches here
                        score = ReduceScore(
                            score,
                            PM("Allele contains internal stop codon"),
                            comm);
                    }
                }

                bool hasStart = startsWithStart;
                bool hasStop = stopsWithStop;
                if (requiresStartStop && (!hasStart || !hasStop)) {
                    score = ReduceScore(
                        score,
                        pm("Reference allele has start and stop codons but found allele does not (start: %1, stop: %2)")
                            .arg(hasStart).arg(hasStop),
                        comm);
                }
                //check for truncatedness
                {
                    const int expectedStart = originalStart - (refstart-1);
                    const int expectedStop = originalStop + (alleleLength - refstop);

                    std::vector<char> acceptedChars(256,0);
                    acceptedChars['A']=1;acceptedChars['C']=1;acceptedChars['G']=1;acceptedChars['T']=1;
                    acceptedChars['a']=1;acceptedChars['c']=1;acceptedChars['g']=1;acceptedChars['t']=1;
                    int contigStart1=contigLength, contigStop1=0;
                    for(int i=0; i<contigLength; ++i) 
                    {
                        if (acceptedChars[contig[i]]) 
                        {
                            contigStart1=i;
                            break;
                        }
                    }
                    for(int i=contigLength; i>0; --i) 
                    {
                        if (acceptedChars[contig[i-1]]) 
                        {
                            contigStop1=i;
                            break;
                        }
                    }

                    int contigStart2 = contigStart1;
                    if (expectedStart>contigStart1) 
                    {
                        int cntN = 0;
                        for(int i = start-1; i>=std::max<int>(0, expectedStart) && contigStart2 == contigStart1; --i) 
                        {
                            if (!acceptedChars[contig[i]]) contigStart2=i;
                        }
                    }

                    int contigStop2 = contigStop1;
                    if (expectedStop<contigStop1) 
                    {
                        int cntN = 0;
                        for(int i = stop; i<std::min<int>(expectedStop, contigLength) && contigStop2 == contigStop1; ++i) 
                        {
                            if (!acceptedChars[contig[i]]) contigStop2=i;
                        }
                    }

                    int contigStart = std::max(contigStart1, contigStart2);
                    int contigStop = std::min(contigStop1, contigStop2);
                    
                    if (expectedStart<contigStart) 
                    {
                        score = ReduceScore(
                            score,
                            pm("Contig start position (%1) exceeds the expected start position (%2)")
                                .arg(contigStart).arg(expectedStart),
                            comm);

                        hasStart = false;
                    }
                    if (expectedStop>contigStop)
                    {
                        score = ReduceScore(
                            score,
                            pm("Contig stop position (%1) is smaller than the expected stop position (%2)")
                                .arg(contigStop).arg(expectedStop),
                            comm);

                        hasStop = false;
                    }
                }

                if (!fwd)
                {
                    // we need to flip things back to the reverse case
                    std::swap(refstart, refstop);
                    const int tmpStop = contigLength - start;
                    start = contigLength - stop;
                    stop = tmpStop;
                }

                if (score==100.0) 
                {
                    BestHits::iterator it = perfectHits.find(locusId);
                    if (it==perfectHits.end())
                        perfectHits[locusId].push_back(Hit(alleleId, sequence.ToString(), score, length, start, stop, contigId, refstart<refstop, nmismatches, ngapopens, seqbefore.ToString(), seqafter.ToString(), evalue, bitscore, requiresStartStop, hasStart, hasStop, fullLength, hasInternalStop));
                    else
                        it->second.push_back(Hit(alleleId, sequence.ToString(), score, length, start, stop, contigId, refstart<refstop, nmismatches, ngapopens, seqbefore.ToString(), seqafter.ToString(), evalue, bitscore, requiresStartStop, hasStart, hasStop, fullLength, hasInternalStop));
                }
                else 
                {
                    BestHits::iterator it = bestHits.find(locusId);
                    if (it==bestHits.end()) 
                    {
                        bestHits[locusId].push_back(Hit(alleleId, sequence.ToString(), score, length, start, stop, contigId, refstart<refstop, nmismatches, ngapopens, seqbefore.ToString(), seqafter.ToString(), evalue, bitscore, requiresStartStop, hasStart, hasStop, fullLength, hasInternalStop));
                        bestHits[locusId].push_back(Hit("", "", 0, alleleLength, start, stop, contigId, refstart<refstop, nmismatches, ngapopens, seqbefore.ToString(), seqafter.ToString(), evalue, bitscore, requiresStartStop, hasStart, hasStop, fullLength, hasInternalStop));
                    }
                    else 
                    {
                        if (score > it->second[0].score) 
                        {
                            it->second[1] = it->second[0];
                            it->second[0] = Hit(alleleId, sequence.ToString(), score, length, start, stop, contigId, refstart<refstop, nmismatches, ngapopens, seqbefore.ToString(), seqafter.ToString(), evalue, bitscore, requiresStartStop, hasStart, hasStop, fullLength, hasInternalStop);
                        }
                        else if (score > it->second[1].score) 
                        {
                            it->second[1] = Hit(alleleId, sequence.ToString(), score, length, start, stop, contigId, refstart<refstop, nmismatches, ngapopens, seqbefore.ToString(), seqafter.ToString(), evalue, bitscore, requiresStartStop, hasStart, hasStop, fullLength, hasInternalStop);
                        }
                    }
                }
            }
        } // read loci.xml

        comm.Send( communication::CalcMessage(PM("Done reading BLAST hits")));
        comm.Send( communication::CalcMessage(PM("Skipped BLAST hits:")));
        comm.Send( communication::CalcMessage(RawMessage(PM("  %1 : allele too short"), skipped.alleleTooShort).c_str()));
        comm.Send( communication::CalcMessage(RawMessage(PM("  %1 : partial match but no start-stop codons present in reference allele"), skipped.partialMatchAndNoStartStop).c_str()));
        comm.Send( communication::CalcMessage(RawMessage(PM("  %1 : partial match but no start-stop codon hunt"), skipped.partialMatchAndNoStartStopHunt).c_str()));
        comm.Send( communication::CalcMessage(RawMessage(PM("  %1 : partial match smaller than limiting percentage (%2)"), skipped.potentialOverlapTooSmall, lengthOverlap*100).c_str()));
    } // Scoping

    //--- merge all hits in the locus
    BestHits allHits;
    allHits.insert(perfectHits.begin(), perfectHits.end());
	for (auto it = bestHits.begin(); it!=bestHits.end(); ++it) {
		auto iit = allHits.find(it->first);
		if (iit==allHits.end()) 
			allHits[it->first] = it->second;
		else 
			iit->second.insert(iit->second.end(), it->second.begin(), it->second.end());
	}

	/*
    for (auto i = allHits.begin(), end = allHits.end(); i != end; ++i)
    {
		//if there are hits without internal stop, remove all hits with internal stops
        {
			Hits& hits = i->second;
			bool anyWithoutInternalStop = false;
			for(const Hit& hit: hits)
			{
				if (!hit.internalStop) 
				{
					anyWithoutInternalStop = true;
					break;
				}
			}
			if (anyWithoutInternalStop)
			{
				Hits filteredHits;
				for(const Hit& hit: hits)
				{
					if (!hit.internalStop) 
					{
						filteredHits.push_back(hit);
					}
				}
				hits.swap(filteredHits);
			}
		}		
		{
			//if there are hits with start/stop, remove all hits without start/stop
			Hits& hits = i->second;
			bool anyWithStartStop = false;
			for(const Hit& hit: hits)
			{
				if (hit.startsWithStart && hit.stopsWithStop) 
				{
					anyWithStartStop  = true;
					break;
				}
			}
			if (anyWithStartStop)
			{
				Hits filteredHits;
				for(const Hit& hit: hits)
				{
					if (hit.startsWithStart && hit.stopsWithStop) 
					{
						filteredHits.push_back(hit);
					}
				}
				hits.swap(filteredHits);
			}
		}
    }
	*/

    //--- make sure there are no overlapping hits within one locus (take the largest) -------------
    RemoveOverlappingHits(allHits, hitOverlap, comm);

    ReplaceAcceptedAlleles(allHits, data.GetAcceptedAlleleFileName(), comm);

	//--- create the repeat mask ------------------------------------------------------------------
	//RepeatMask repeatMask(contigs);
	//if (settings.doRepeatMasking) CreateRepeatMask(fastaFile, repeatMask, settings, env, comm);

    //--- calculate the results -------------------------------------------------------------------
    comm.Send( communication::CalcMessage("Performing output ... "));
    size_t nLoci = loci.size(), nAssignedLoci =0, nUniqueLoci =0, nMultipleLoci =0, nNewAlleles =0, nRepeated = 0;

    LocusOutput output;

     {
        BestHits::const_iterator it,it2;
        bool hasPerfectHits, isRepeated;
        for(size_t i=0; i<loci.size(); ++i) {

            LocusOutput::Locus l;
            //set the name
            l.locus = loci[i];

            it = allHits.find(loci[i]);
                        
            if (it!=allHits.end()) {
            
                if (it->second.size()>1) ++nMultipleLoci;
                if (it->second.size()==1) ++nUniqueLoci;
                                                
                hasPerfectHits = false;

                for(size_t j=0; j<it->second.size(); ++j) {
                    hasPerfectHits = hasPerfectHits  || it->second[j].score==100.0;
					isRepeated = false;
                    LocusOutput::Allele a;
                    {
                        a.id = AlleleName::ExtractAlleleNumber(it->second[j].allele);
                        a.sequenceIdentity = it->second[j].score;
                        a.start = it->second[j].start;
                        a.stop = it->second[j].stop;
						//a.repeatScore = repeatMask.getRepeatScore(it->second[j].contigname, a.start, a.stop);
						//if (a.repeatScore>=settings.repeatScoreThreshold) nRepeated+=1;
						//a.repeatScore = repeatMask.getRepeatCount(it->second[j].contigname, a.start, a.stop, settings.percentIdentity);
						a.repeatScore = alleleRepeatMask.getRepeatScore(l.locus, hitOverlap);
						if (a.repeatScore>0.0) {
							nRepeated+=1;
							isRepeated=true;
						}
                        a.fwd = it->second[j].fwd;
                        a.nMismatches = it->second[j].nmismatches;
                        a.nGapOpens= it->second[j].ngapopens;
                        a.contigId = it->second[j].contigname;
                        a.seqBefore = it->second[j].seqbefore;
                        a.seqAfter = it->second[j].seqafter;
                        a.sequence = it->second[j].sequence;
                        a.eValue = it->second[j].evalue;
                        a.bitScore = it->second[j].bitscore; 
                        a.alignmentLength = it->second[j].length;
                        a.nonACGT = seq::CountNonACGT(a.sequence.begin(), a.sequence.end());
                        a.requiresStartStop = it->second[j].requiresStartStop;
                        a.startsWithStart = it->second[j].startsWithStart;
                        a.stopsWithStop = it->second[j].stopsWithStop;
                        a.fullLength = it->second[j].fullLength;
                        a.hasInternalStop = it->second[j].internalStop;
                    }
                    //if (!isRepeated || !settings.doRepeatMasking) 
					l.alleles.push_back(a);
                }

                if (!hasPerfectHits) ++nNewAlleles;
            }
            output.addLocus(l);
        }

    //{
    //    BestHits::const_iterator it,it2;
    //    bool hasPerfectHits;
    //    for(size_t i=0; i<loci.size(); ++i) {

    //        it = perfectHits.find(loci[i]);
    //        it2 = bestHits.find(loci[i]);

    //        LocusOutput::Locus l;
    //        //set the name
    //        l.locus = loci[i];

    //        //if there are perfect hits, add them
    //        if (it!=perfectHits.end()) {
    //            hasPerfectHits = true;
    //            ++nAssignedLoci;
    //            if (it->second.size()>1) ++nMultipleLoci;
    //            else ++nUniqueLoci;

    //            //add the alleles
    //            for(size_t j=0; j<it->second.size(); ++j) {
    //                LocusOutput::Allele a;
    //                {
    //                    a.id = GetAlleleNrFromAllele(it->second[j].allele);
    //                    a.sequenceIdentity = 100;
    //                    a.start = it->second[j].start;
    //                    a.stop = it->second[j].stop;
    //                    a.fwd = it->second[j].fwd;
    //                    a.nMismatches = it->second[j].nmismatches;
    //                    a.nGapOpens= it->second[j].ngapopens;
    //                    a.contigId = it->second[j].contigname;
    //                    a.seqBefore = it->second[j].seqbefore;
    //                    a.seqAfter = it->second[j].seqafter;
    //                    a.sequence = it->second[j].sequence;
    //                    a.eValue = it->second[j].evalue;
    //                    a.bitScore = it->second[j].bitscore;
    //                    a.alignmentLength = it->second[j].length;
    //                }
    //                l.alleles.push_back(a);
    //            }
    //        }


    //        //if there are almost perfect hits, write them in the second column
    //        it=it2;
    //        if (it!=bestHits.end()) {
                //
                //++nAssignedLoci;
    //            if (it->second.size()>1) ++nMultipleLoci;
    //            else ++nUniqueLoci;

    //            
                //hasPerfectHits = false;

    //            for(size_t j=0; j<it->second.size(); ++j) {
                //	hasPerfectHits = hasPerfectHits  || it->second[j].score==100.0;
    //                LocusOutput::Allele a;
    //                {
    //                    a.id = GetAlleleNrFromAllele(it->second[j].allele);
    //                    a.sequenceIdentity = it->second[j].score;
    //                    a.start = it->second[j].start;
    //                    a.stop = it->second[j].stop;
    //                    a.fwd = it->second[j].fwd;
    //                    a.nMismatches = it->second[j].nmismatches;
    //                    a.nGapOpens= it->second[j].ngapopens;
    //                    a.contigId = it->second[j].contigname;
    //                    a.seqBefore = it->second[j].seqbefore;
    //                    a.seqAfter = it->second[j].seqafter;
    //                    a.sequence = it->second[j].sequence;
    //                    a.eValue = it->second[j].evalue;
    //                    a.bitScore = it->second[j].bitscore;
    //                    a.alignmentLength = it->second[j].length;
    //                }
    //                l.alleles.push_back(a);
    //            }

                //if (!hasPerfectHits) ++nNewAlleles;
    //        }
    //        output.addLocus(l);
    //    }

        Str::Text::Val xml;
        output.toString(xml);
        comm.Send( communication::CalcCreateResultFile("loci.xml", xml, boost::make_shared<GzipCompressionType>()));
		comm.Send( communication::CalcMessage( RawMessage( PM("Number of loci with repeated sequence content: %1"), nRepeated).str() ) );

    }


    /* output order:
        locus
        allele numbers (comma-separated)
        score
        start (comma-separated)
        stop (comma-separated)
        direction (fwd=1, comma-separated)
        contig id (comma-separated)
        nmismatches (comma-separated)
        ngapopens (comma-separated)
        seq before (comma-separated)
        seq after (comma-separated)
    */

    //{
    //	std::ostringstream os1 /*loci info*/, os2 /*new allele sequences*/;
    //	BestHits::const_iterator it,it2;
    //	bool hasPerfectHits;
    //	for(size_t i=0; i<loci.size(); ++i) {
    //
    //		it = perfectHits.find(loci[i]);
    //		it2 = bestHits.find(loci[i]);

    //		//if there are perfect hits, write them in the first column
    //		if (it!=perfectHits.end()) {
    //			hasPerfectHits = true;
    //			++nAssignedLoci;
    //			if (it->second.size()>1) ++nMultipleLoci; else ++nUniqueLoci;
    //			os1
    //				<< loci[i] << '\t'
    //				<< GetAlleleNrFromAllele(it->second[0].allele);
    //
    //			for(size_t j=1; j<it->second.size(); ++j) os1 << ", " << GetAlleleNrFromAllele(it->second[j].allele);
    //
    //			os1
    //				<< '\t' << "100" << '\t';

    //			//add start, stop, direction, nmismatches, ngapopens and contig id
    //			for(size_t j=0; j<it->second.size(); ++j) {
    //				if (j>0) os1 << ", ";
    //				os1 << it->second[j].start;
    //			}
    //			os1 << "\t";
    //			for(size_t j=0; j<it->second.size(); ++j) {
    //				if (j>0) os1 << ", ";
    //				os1 << it->second[j].stop;
    //			}
    //			os1 << "\t";
    //			for(size_t j=0; j<it->second.size(); ++j) {
    //				if (j>0) os1 << ", ";
    //				os1 << it->second[j].fwd?"1":"0";
    //			}
    //			os1 << "\t";
    //			for(size_t j=0; j<it->second.size(); ++j) {
    //				if (j>0) os1 << ", ";
    //				os1 << it->second[j].nmismatches;
    //			}
    //			os1 << "\t";
    //			for(size_t j=0; j<it->second.size(); ++j) {
    //				if (j>0) os1 << ", ";
    //				os1 << it->second[j].ngapopens;
    //			}
    //			os1 << "\t";
    //			for(size_t j=0; j<it->second.size(); ++j) {
    //				if (j>0) os1 << ", ";
    //				os1 << it->second[j].contigname;
    //			}
    //			os1 << "\t";
    //			for(size_t j=0; j<it->second.size(); ++j) {
    //				if (j>0) os1 << ", ";
    //				os1 << it->second[j].seqbefore;
    //			}
    //			os1 << "\t";
    //			for(size_t j=0; j<it->second.size(); ++j) {
    //				if (j>0) os1 << ", ";
    //				os1 << it->second[j].seqafter;
    //			}

    //		}
    //		else {
    //			hasPerfectHits=false;
    //			if (it2!=bestHits.end())
    //				os1 << loci[i] << '\t' << "?" << '\t' << "100" << '\t'<< '\t'<< '\t'<< '\t'<<'\t'<<'\t' << '\t'<<'\t' << '\t';
    //			else
    //				os1 << loci[i] << '\t' << "" << '\t' << "100" << '\t'<< '\t'<< '\t'<< '\t'<<'\t'<<'\t' << '\t'<<'\t' << '\t';
    //		}
    //

    //
    //		//if there are almost perfect hits, write them in the second column
    //		it=it2;
    //		if (it!=bestHits.end()) {
    //			if (!hasPerfectHits) ++nNewAlleles;
    //			os1
    //				<< GetAlleleNrFromAllele(it->second[0].allele) << '\t'			//the runner-up allele (if any)
    //				<< it->second[0].score << '\t';			//the runner-up score (if any)

    //			//add start, stop and contig id
    //			os1 << it->second[0].start << "\t";
    //			os1 << it->second[0].stop << "\t";
    //			os1 << (it->second[0].fwd?"1":"0") << "\t";
    //			os1 << it->second[0].nmismatches << "\t";
    //			os1 << it->second[0].ngapopens << "\t";
    //			os1 << it->second[0].contigname << "\t";
    //			os1 << it->second[0].seqbefore << "\t";
    //			os1 << it->second[0].seqafter << "\t";

    //			if (!hasPerfectHits && it!=bestHits.end()) {
    //				os2 << loci[i] << '\t'
    //					<< it->second[0].sequence << '\n';
    //			}
    //			else {
    //				os2 << loci[i] << '\t'
    //					<< "" << '\n';
    //			}
    //		}
    //		else {
    //			os1
    //				<< "" << '\t'			//the runner-up allele (if any)
    //				<< "" << '\t';			//the runner-up score (if any)
    //		}

    //		os1 << "\n";

    //		/*if (!hasPerfectHits && it!=bestHits.end()) {
    //			os2 << loci[i] << '\t'
    //				<< it->second[0].sequence << '\n';
    //		}
    //		else {
    //			os2 << loci[i] << '\t'
    //				<< "" << '\n';
    //		}*/


    //	}
    //	comm.Send( communication::CalcCreateResultFile("loci.txt", os1.str()));
    //	comm.Send( communication::CalcCreateResultFile("loci_seqs.txt", os2.str()));
    //}

    /* --------------------------------------------------------------------------------------------
        PERFORM THE REPORTING
        We plan to report on:
            (1) overall startistics on the identification:
                    number of uniquely determined loci,
                    number of loci that have multiple hits
            (2) for the loci with a runner-up, the score of teh best hit and the score of the runner-up
       -------------------------------------------------------------------------------------------- */
    {
        using namespace xmlrprt::builder;
        XmlReportBuilder builder;
        {
            XmlReport report(builder, "BLAST identification report");
            {
                Section s(report, "Parameters");
                {
                    Table t(s, 5, 2, "", Table::DisplayHints::KeyValuePairs);
                    {
                        t(0, 0) = "algorithm";
                        t(0, 1) = "MegaBlast";
                        t(1, 0) = "k";
                        t(1, 1) = ToStr(settings.k);
                    }
                }
            }
            {
                Section s(report, "Statistics");
                {
                    Table t(s, 5, 2, "", Table::DisplayHints::KeyValuePairs);
                    {
                        t(0, 0) = "Number of loci";
                        t(0, 1) = ToStr(nLoci);
                        t(1, 0) = "Number of assigned loci";
                        t(1, 1) = ToStr(nAssignedLoci);
                        t(2, 0) = "Number of uniquely assigned loci";
                        t(2, 1) = ToStr(nUniqueLoci);
                        t(3, 0) = "Number of multiply assigned loci";
                        t(3, 1) = ToStr(nMultipleLoci);
                        t(4, 0) = "Number of new alleles";
                        t(4, 1) = ToStr(nNewAlleles);
                    }
                }
                {
                }
            }
        }
        comm.Send( communication::CalcCreateResultFile("blast_report.xml", builder.toString()));
    }

    comm.Send( communication::CalcMessage("Finished BLAST allele finder!"));
}

/**
    Reduce the score, is a hack to allow alleles that are a 100% match of only a part of the sequence to be considered
    for submission by the client plugin. Can be removed once the client plugin takes differences in allele length
    and ref allele length into account, as opposed to checking only SI.
*/
double MegaBlastAlleleFinder::ReduceScore(double score, const Str::Text::Val& reason, const communication::CalcCommunication& comm)
{
    // Only log if verbose mode is active
    comm.Send( communication::CalcLogMessage(
        pm("Reducing score from %1 to %2 (reason: %3)").arg(score).arg(score*0.99).arg(reason)));
    return 0.99*score;
}



SkippedAllellesInfo::SkippedAllellesInfo()
    : alleleTooShort(0)
    , partialMatchAndNoStartStop(0)
    , partialMatchAndNoStartStopHunt(0)
    , potentialOverlapTooSmall(0)
{
}

#include "stdafx.h"

#include "CE_Logger.h"

#include <iomanip>
#include <fstream>

#include "boost/algorithm/string.hpp"

#include "PathDef.h"
#include "translate.h"
#include "helper.h"

#include "CE_StringManip.h"
#include "CE_FileSystem.h"
#include "NoCompressionType.h"
#include "CompressedString.h"
#include "base64buf.h"


namespace engine
{


Logger::Logger()
    : resultsDir_   ()
    , doCompressionType_()
	, isVerbose_    ( false )
    , currentIndent_( 0 )
{
}

void Logger::CreateResultFile(const Str::Text::Val& filename, const Str::Text::Val& content, const Str::ID::Val& compressionTypeId)
{
	Str::Text::Val	 compressedFilename;	//regular filename + compression extension (if compressed)
    // compression + base64
    Str::Buffer::Val compressedContent;

    if ((!doCompressionType_.empty()) && (compressionTypeId!=NoCompressionType::GetTypeName())) 
    {
        CompressionTypePtr compressionTypePtr = CompressionType::GetByID(compressionTypeId);
        {
            Str::Buffer::Val tmp;
            Compress(content, tmp, compressionTypePtr, false); //beware! there _will_ be \0's in tmp!
            {
                int len = 0;
                Base64Encode(ToRef(tmp), tmp.size(), compressedContent, &len);
                //eeeeeum base64encode gives you a double-null terminated string????
                compressedContent.resize(compressedContent.size()-1);
            }
        }
        compressedFilename = filename + "." + compressionTypePtr->GetFileExtension();
    }
    else 
    {
        compressedContent  = content;
        compressedFilename = filename;
    }

	std::ofstream of( (GetResultsPath() / compressedFilename).string(), std::ios::binary );
    if ( ! of.is_open() )
        throw KError( PM("Unable to open result file '%1' for writing") )
            << compressedFilename;

    of << compressedContent;
}

namespace
{

enum class Header
{
    No,
    Yes
};

Str::Text::Val getHeader()
{
    std::ostringstream oss;
    oss << PM("#              Time")
        << '\t'
        << std::setw(8)
        << PM("Type")
        << '\t'
        << PM("Message");
    return oss.str();
}

Str::Text::Val formatLogString( const Str::Text::Val inputString,
                                const engine::LogMessageType& messageType )
{
    std::ostringstream oss;
    oss << tools::getFormattedTimeString()
        << '\t'
        << std::setw(8)
        << messageType.ToString()
        << '\t'
        << inputString;

    return oss.str();
}

void WriteHeader( const Str::Path::Val& filepath )
{
	// write new content to file, truncating any existing
    std::ofstream of( filepath.string(), std::ios::trunc );
    of << getHeader() << PM("\n");
}

void appendToLog( const Str::Text::Val          content,
                  const engine::LogMessageType& messageType,
                  const Str::Path::Val&         logfile,
                  std::ios_base::openmode       openMode,
                  Header                        header
                  )
{
    try
	{
		bool isSinglelineFile = boost::starts_with(logfile.filename().string(), "__");

        if (!isSinglelineFile && (header == Header::Yes))
		{
			WriteHeader(logfile);

            if ( openMode == std::ios_base::out )
			{
                // If we wrote the header and we want to write (-> i.e. make empty) to the file: append
                // instead because the file was cleared when writing the header
                openMode = std::ios_base::app;
            }
        }

        std::ofstream textFile( logfile.string(), openMode );
        textFile << (isSinglelineFile ? content : formatLogString(content, messageType))
                 << PM("\n");
    }
    // Writing something in the log is not allowed to throw!
    catch ( std::exception&) {
        ASSERT(0);
    }
    catch (...) {
        ASSERT(0);
    }
}

} // namespace

void Logger::CreateLogFile( const Str::Text::Val& filename,
                            const engine::LogMessageType& messageType,
                            const Str::Text::Val& content
                          )
{
    appendToLog( content, messageType, GetLogsPath() / filename, std::ios_base::out, Header::Yes );
}

void Logger::AppendLogFile( const Str::Text::Val& filename,
                            const engine::LogMessageType& messageType,
                            const Str::Text::Val& content)
{
    appendToLog( content, messageType, GetLogsPath() / filename, std::ios_base::app, Header::No );
}

void Logger::SetProgress( int progress, const Str::Text::Val& message )
{
    SetProgress( progress );
    SetProgressMessage( message );
}

void Logger::SetProgress(int progress)
{
    CreateLogFile( GetProgressFilename(), LogMessageType::Progress(), ToStr(progress) );
}

void Logger::SetProgressMessage(Str::Text::Val progressMessage)
{
    AppendLogFile( GetAllMessagesFilename(), LogMessageType::Message(), progressMessage );

    // Only update this file if the message is not empty
    boost::trim( progressMessage );
    if ( ! progressMessage.empty() )
        CreateLogFile( GetMessageFilename(), LogMessageType::Progress(), progressMessage );
}

void Logger::AddWarning( const Str::Text::Val& warning )
{
    AddMessage   ( LogMessageType::Warning(), warning );
    AppendLogFile( GetWarningsFilename(), LogMessageType::Warning(), warning );
}

/**
    Append a message, taking the current indentation into account
*/
void Logger::AddMessage(LogMessageType messageType, const Str::Text::Val& message)
{
    AppendLogFile( GetAllMessagesFilename(),
                   messageType,
                   Str::Text::Val(currentIndent_, ' ') + message );
}

/**
    \note There typically is only one error, if an error occurs the program should
          quit. We do provide an AddError and no SetError to prevent overwriting
          errors if multiple levels of error handling try to write something
          into the error log
*/
void Logger::AddError(const Str::Text::Val& error)
{
    AddMessage   ( LogMessageType::Error(), error );

    // Don't use special formatting or timestamps for the error log: we want the unsoiled message.
    std::ofstream textFile( (GetLogsPath() / GetErrorFilename()).string(), std::ios_base::app );
    textFile << error << PM("\n");
}

void Logger::SetResultsDir(const Str::Text::Val& resultsDir)
{
    // Need to trim away "" and '', these can come from the command line parsing but we
    // never want those in the path
    Str::Text::Val trimmedResultsdir = resultsDir;
    boost::trim_if( trimmedResultsdir, boost::is_any_of(" \"'") );
    resultsDir_ = trimmedResultsdir;

    checkDirectoryexists( GetResultsPath(), PM("Results") );
    checkDirectoryexists( GetLogsPath(),    PM("Logs") );
}

void Logger::SetDoCompressionType( const Str::Text::Val& compressionType)
{
	doCompressionType_ = compressionType;
}

const Str::Path::Val Logger::GetResultsPath()
{
    return GetResultsPath( resultsDir_ );
}

const Str::Path::Val Logger::GetResultsPath( const Str::Path::Val& basePath )
{
    return basePath / GetResultsDirname();
}

const Str::Path::Val Logger::GetLogsPath()
{
    return resultsDir_ / GetLogsDir();
}

const Str::Path::Val Logger::GetResultsDirname()
{
    return PM("results");
}

const Str::Path::Val Logger::GetLogsDir()
{
    return PM("logs");
}

const Str::Text::Val Logger::GetProgressFilename()
{
    return PM("__progress__.txt");
}

const Str::Text::Val Logger::GetMessageFilename()
{
    return PM("__message__.txt");
}

const Str::Text::Val Logger::GetAllMessagesFilename()
{
    return PM("messages.txt");
}

const Str::Text::Val Logger::GetWarningsFilename()
{
    return PM("warnings.txt");
}

const Str::Text::Val Logger::GetErrorFilename()
{
    return PM("error.txt");
}

void Logger::SetVerbose(bool isVerbose)
{
    isVerbose_ = isVerbose;
}

void Logger::IncreaseIndent()
{
    currentIndent_ += indentAmount;
}

void Logger::DecreaseIndent()
{
    currentIndent_ -= indentAmount;
}



} // namespace engine

#include "stdafx.h"

#include "runextern_manager.h"

#include "messagesub.h"
#include "translate.h"
#include "CalcCommunicationImpl.h"
#include "exception.h"
#include "Message.h"

#include "runextern_process.h"
#include "runextern_appListener.h"


namespace runextern
{



ExternAppManager::ExternAppManager()
    : processes_( ProcessPool::Create() )
{
}

void ExternAppManager::runApp(const ExternalApp& app, const ProcessInfo& info, Reporter& comm, bool interpretXml)
{
	//--- fetch the batch file --------------------------------------------------------------------
	BatchFile file; app.createBatchFile(file);

	//--- run each line of the batch file ---------------------------------------------------------
	for(auto it=file.begin(); it!=file.end() && comm.Continue(); ++it) {
		runCmd(*it, info, comm, interpretXml);
	}

	comm.SetProgress(100.0, 100.0);
	comm.Ended();
}

int ExternAppManager::runCmd(const ProcessCmdLine& cmdline, const ProcessInfo& info, Reporter& comm, bool interpretXml)
{	
	//--- create and run the process --------------------------------------------------------------
	Process::Ptr p( processes_->CreateProcess() );
    p->setCmdLine( cmdline );
    p->setInfo   ( info );
	p->run();

	//--- check that the process was started correctly --------------------------------------------
	if (p->getStatus().failed()) {
		//--- hmm, the process is not running -----------------------------------------------------
		const ProcessStatus& status(p->getStatus());
		ErrorCode errorcode=status.getErrorCode();
		Message m(PM("%1"));
		if (status.failedToCreatePipes()) {
			m << Message(TXT("Failed to start external process (Error: could not create pipes, code %1).\nCommand: %2\nMessage: %3"), errorcode, cmdline.getCmdLine(), status.getErrorText()).c_str();			
		}
		else if (status.failedToStart()) {
			m << Message(TXT("Failed to start external process (Error: could not create process, code %1).\nCommand: %2\nMessage: %3"), errorcode, cmdline.getCmdLine(), status.getErrorText()).c_str();			
		}
		else if (status.failedToSetPriority()) {
			m << Message(TXT("Failed to start external process (Error: could not set the process priority, code %1).\nCommand: %2\nMessage: %3"), errorcode, cmdline.getCmdLine(), status.getErrorText()).c_str();			
		}
		else {
			ASSERT(status.failedToSetMemoryLimit());
			m << Message(TXT("Failed to start external process (Error: could not set the memory restrictions, code %1).\nCommand: %2\nMessage: %3"), errorcode, cmdline.getCmdLine(), status.getErrorText()).c_str();
		}
		comm.Failed(m.c_str());

        throw KError( m.c_str() );
	}
	else {
		//--- the process is running --------------------------------------------------------------
		comm.Message( pm("Executing '%1'").arg(cmdline.getCmdLine()) );

		//--- make sure someone is listening ------------------------------------------------------
		ExternAppListener listener(p, info, interpretXml);
		listener.listen(comm);	//the listening is being done in the current thread!
	}

	// return process exit code
	return p->GetExitCode();
}

} // namespace runextern

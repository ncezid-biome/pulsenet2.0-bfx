#include "stdafx.h"

#include "StatsCalculator.h"

#include "StatsCalculatorImpl.h"

#include "seqbagstats_info.h"


struct StatsCalculator::OpaquePointer
{
    OpaquePointer()
        : factory_( StatsCalculatorImpl::CreateFactory() )
    {
    }

    StatsCalculatorImpl::Factory::Ptr factory_;
};


StatsCalculator::StatsCalculator()
    : d_(  new OpaquePointer() )
{
}

StatsCalculator::~StatsCalculator()
{
}

void StatsCalculator::Calculate(
    const SRSStatsCalculatorSettings&       settings,
    const engine::ExecuteEnvironment&       env,
    const communication::CalcCommunication& comm) const
{
    StatsCalculatorImpl::Ptr finder = d_->factory_->GetMap(settings.algorithmType);

	SeqBagInfo info;
    finder->Apply(settings, info, env, comm);
}

void StatsCalculator::Calculate(
    const SRSStatsCalculatorSettings&       settings,
	SeqBagInfo& info, 
    const engine::ExecuteEnvironment&       env,
    const communication::CalcCommunication& comm) const
{
    StatsCalculatorImpl::Ptr finder = d_->factory_->GetMap(settings.algorithmType);

    finder->Apply(settings, info, env, comm);
}


void StatsCalculator::Calculate(
    const SRSStatsCalculatorSettings&       settings,
	std::string& info, std::string& stats,
    const engine::ExecuteEnvironment&       env,
    const communication::CalcCommunication& comm) const
{
    StatsCalculatorImpl::Ptr finder = d_->factory_->GetMap(settings.algorithmType);
	SeqBagInfo returnInfo;
    finder->Apply(settings, returnInfo, info, stats, env, comm);
}

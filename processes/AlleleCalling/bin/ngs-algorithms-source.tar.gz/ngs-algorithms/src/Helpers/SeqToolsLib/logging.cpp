/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#include "stdafx.h"

#include "logging.h"

#include <sstream>

#include "boost/date_time/posix_time/posix_time.hpp"
#include "boost/date_time/time_clock.hpp"

#include "translate.h"


Logger::Logger()
{
}
Logger::~Logger()
{
}

#include <time.h>
#include <string.h>

Str::Text::Val GetNow()
{	
    boost::posix_time::ptime now = boost::posix_time::second_clock::universal_time();

    char timeString[20];

    sprintf(
        timeString,
        PM("%.4d-%.2d-%.2d %.2d:%.2d:%.2d"),
        static_cast<int>(now.date().year()),
        static_cast<int>(now.date().month()),
        static_cast<int>(now.date().day()),
        static_cast<int>(now.time_of_day().hours()),
        static_cast<int>(now.time_of_day().minutes()),
        static_cast<int>(now.time_of_day().seconds()) );

    return timeString;
}

std::vector<Logger*> Logging::loggers_=std::vector<Logger*>();
int Logging::prevprogress_=0;

void Logging::AddError(Str::Text::Arg error)
{
	std::stringstream s;
	s << GetNow() << "\t | \t" << "Error! " << error;
	for(size_t i=0; i<loggers_.size(); ++i) 
			if (loggers_[i]) loggers_[i]->addLog(s.str().c_str());
}
void Logging::AddWarning(Str::Text::Arg warning)
{
	std::stringstream s;
	s << GetNow() << "\t | \t" <<"Warning! " << warning;
	for(size_t i=0; i<loggers_.size(); ++i) 
			if (loggers_[i]) loggers_[i]->addLog(s.str().c_str());
}
void Logging::AddLog(Str::Text::Arg line)
{
	std::stringstream s;
	s << GetNow() << "\t | \t" <<"Log! " << line;
	for(size_t i=0; i<loggers_.size(); ++i) 
			if (loggers_[i]) loggers_[i]->addLog(s.str().c_str());
}
void Logging::AddProgress(float progress, float total)
{
	if (total==0) return;
	double newprogress = progress/total;
	if (100*newprogress<prevprogress_ || 100*newprogress>prevprogress_+1) {
		prevprogress_=100*newprogress;
		std::stringstream s;
		s << GetNow() << "\t | \t" << "Progress! " << prevprogress_;
		for(size_t i=0; i<loggers_.size(); ++i) 
			if (loggers_[i]) loggers_[i]->addLog(s.str().c_str());
	}
}
void Logging::Start(Logger* logger)
{
	loggers_.push_back(logger);
	AddLog("Logging started");
}
void Logging::Start(Logger* logger1, Logger* logger2)
{
	loggers_.push_back(logger1);
	loggers_.push_back(logger2);
	AddLog("Logging started");
}
void Logging::Stop()
{
	AddLog("Logging ended");
	loggers_.clear();
}

LoggedCalc::LoggedCalc(Str::Text::Arg message) 
{
	Logging::AddLog(message);
}
LoggedCalc::~LoggedCalc() 
{
	Logging::AddLog("Done!");
}


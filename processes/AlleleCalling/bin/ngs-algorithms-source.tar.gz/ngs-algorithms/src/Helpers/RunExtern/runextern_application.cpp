#include "stdafx.h"
#include "runextern_application.h"
#include <sstream>


using namespace runextern;
BatchFile::BatchFile()
{
}
BatchFile::BatchFile(const ProcessCmdLine& line)
	: lines_(1, line)
{
}
BatchFile::BatchFile(Str::Text::Arg lines)
{
	std::stringstream s; s.str(lines.c_str());
	std::string line;
	while (!s.eof()) {
		std::getline(s,line);
		lines_.push_back(ProcessCmdLine(line));
	}
}
BatchFile::BatchFile(const BatchFile& other)
	: lines_(other.lines_)
{
}
BatchFile::~BatchFile()
{
}
BatchFile& BatchFile::operator =(const BatchFile& other)
{
	if (this==&other) return *this;
	lines_=other.lines_;
	return *this;
}
void BatchFile::addLine(const ProcessCmdLine& line)
{
	lines_.push_back(line);
}
BatchFile::cmdline_iterator BatchFile::begin()
{
	return lines_.begin();
}
BatchFile::cmdline_iterator BatchFile::end()
{
	return lines_.end();
}



ExternalApp::ExternalApp()
{
}
ExternalApp::~ExternalApp()
{
}



#include "textfile.h"

BatchFileApp::BatchFileApp()
{
}
BatchFileApp::BatchFileApp(Str::Text::Arg filename)
	: filename_(filename)
{
}
BatchFileApp::~BatchFileApp()
{
}
void BatchFileApp::setFilename(Str::Text::Arg filename)
{
	filename_=filename;
}
void BatchFileApp::createBatchFile(BatchFile& file) const
{
	TextFile ifile;
	ifile.OpenRead(filename_);
	if (ifile.IsOpened()) {
		std::string line;
		while (!ifile.IsEnd()) {
			ifile.ReadLine(line);
			if (!line.empty()) file.addLine(ProcessCmdLine(line));
		}
	}
}




MemoryBatchFileApp::MemoryBatchFileApp()
{
}
MemoryBatchFileApp::MemoryBatchFileApp(const BatchFile& file)
	: file_(file)
{
}
MemoryBatchFileApp::MemoryBatchFileApp(const ProcessCmdLine& cmdline)	
{
	file_.addLine(cmdline);
}
MemoryBatchFileApp::~MemoryBatchFileApp()
{
}
void MemoryBatchFileApp::setBatchFile(const BatchFile& file)
{
	file_=file;
}
void MemoryBatchFileApp::createBatchFile(BatchFile& file) const
{
	file=file_;
}
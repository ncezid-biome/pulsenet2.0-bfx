#ifndef SNPINFO_H
#define SNPINFO_H

#include "StringDef.h"
#include "intdef.h"

class SNPInfo {
public:
	class ScreenData {
	public:
		UInt32 nA, nC, nG, nT;
	public:
		ScreenData() {}
		ScreenData(Str::Text::Arg name, size_t index) {}

		inline void loadSeq(Str::Text::Arg sequence, size_t size) {			
			nA=sequence[size/2]=='A';
			nC=sequence[size/2]=='C';
			nG=sequence[size/2]=='G';
			nT=sequence[size/2]=='T';
		}
	};
public:
	UInt32 fA, fC, fG, fT;
	UInt32 rA, rC, rG, rT;
public:
	SNPInfo() : fA(0), fC(0), fG(0), fT(0), rA(0), rC(0), rG(0), rT(0) {}
	SNPInfo(Str::Text::Arg name, size_t index) : fA(0), fC(0), fG(0), fT(0), rA(0), rC(0), rG(0), rT(0) {}
		
	inline void reset() {
		fA=0; fC=0; fG=0; fT=0; rA=0; rC=0; rG=0; rT=0;
	}

	inline void loadSeq(Str::Text::Arg sequence, size_t size) {
		fA=sequence[size/2]=='A';
		fC=sequence[size/2]=='C';
		fG=sequence[size/2]=='G';
		fT=sequence[size/2]=='T';
	}
	inline void add(const SNPInfo& data, size_t pos, bool fwd) {
		if (fwd) { //means: read and key are in the same direction
			fA+=data.fA;
			fC+=data.fC;
			fG+=data.fG;
			fT+=data.fT;		
		}
		else { //means: read and key are in different directions
			rA+=data.fT;
			rC+=data.fG;
			rG+=data.fC;
			rT+=data.fA;		
		}
	}
	inline void update(const SNPInfo& data) {
		fA+=data.fA;
		fC+=data.fC;
		fG+=data.fG;
		fT+=data.fT;				
		rA+=data.rA;
		rC+=data.rC;
		rG+=data.rG;
		rT+=data.rT;
	}
	inline void screen(const ScreenData& data, size_t pos, bool fwd) {
		//this is read mumbo-jumob
		if (fwd) { //means: read and key are in the same direction
			fA+=data.nA;
			fC+=data.nC;
			fG+=data.nG;
			fT+=data.nT;		
		}
		else { //means: read and key are in different directions
			rA+=data.nT;
			rC+=data.nG;
			rG+=data.nC;
			rT+=data.nA;		
		}
	}
	inline void toStream(std::ostream& os) const {
		os.write((const char*)(&fA), sizeof(UInt32));
		os.write((const char*)(&fC), sizeof(UInt32));
		os.write((const char*)(&fG), sizeof(UInt32));
		os.write((const char*)(&fT), sizeof(UInt32));
		os.write((const char*)(&rA), sizeof(UInt32));
		os.write((const char*)(&rC), sizeof(UInt32));
		os.write((const char*)(&rG), sizeof(UInt32));
		os.write((const char*)(&rT), sizeof(UInt32));
	}
	inline void fromStream(std::istream& is) {
		is.read((char*)(&fA), sizeof(UInt32));
		is.read((char*)(&fC), sizeof(UInt32));
		is.read((char*)(&fG), sizeof(UInt32));
		is.read((char*)(&fT), sizeof(UInt32));
		is.read((char*)(&rA), sizeof(UInt32));
		is.read((char*)(&rC), sizeof(UInt32));
		is.read((char*)(&rG), sizeof(UInt32));
		is.read((char*)(&rT), sizeof(UInt32));
	}
	inline UInt32 getFwdA() const { return fA; }
	inline UInt32 getFwdC() const { return fC; }
	inline UInt32 getFwdG() const { return fG; }
	inline UInt32 getFwdT() const { return fT; }	
	inline UInt32 getRevA() const { return rA; }
	inline UInt32 getRevC() const { return rC; }
	inline UInt32 getRevG() const { return rG; }
	inline UInt32 getRevT() const { return rT; }	
	inline UInt32 getA() const { return fA+rA; }
	inline UInt32 getC() const { return fC+rC; }
	inline UInt32 getG() const { return fG+rG; }
	inline UInt32 getT() const { return fT+rT; }	
	inline UInt32 getFwd() const { return fA + fC + fG + fT; }
	inline UInt32 getRev() const { return rA + rC + rG + rT; }
	inline UInt32 getTotal() const { return getFwd() + getRev(); }
	inline bool hasSingleBase(double sbThreshold, char& b) const {
		UInt32 total = getTotal();  
		if (getA() >= sbThreshold * total) { b='A'; return true; }
		if (getC() >= sbThreshold * total) { b='C'; return true; }
		if (getG() >= sbThreshold * total) { b='G'; return true; }
		if (getT() >= sbThreshold * total) { b='T'; return true; }
		return false;

	}
	inline bool isAmbiguous() const {
		return (getA()!=0) + (getC()!=0) + (getG()!=0) + (getT()!=0) > 1;
	}
};


class RefSNPInfo {
public:
	class ScreenData {
	public:
		UInt32 nA, nC, nG, nT;
	public:
		ScreenData() {}
		ScreenData(Str::Text::Arg name, size_t index) {}

		inline void loadSeq(Str::Text::Arg sequence, size_t size) {			
			nA=sequence[size/2]=='A';
			nC=sequence[size/2]=='C';
			nG=sequence[size/2]=='G';
			nT=sequence[size/2]=='T';
		}
	};
public:
	UInt32 refA, refC, refG, refT;
	UInt32 fA, fC, fG, fT;
	UInt32 rA, rC, rG, rT;
public:
	RefSNPInfo() : refA(0), refC(0), refG(0), refT(0), fA(0), fC(0), fG(0), fT(0), rA(0), rC(0), rG(0), rT(0) {}
	RefSNPInfo(Str::Text::Arg name, size_t index) : fA(0), fC(0), fG(0), fT(0), rA(0), rC(0), rG(0), rT(0) {}
	
	inline void reset() {
		fA=0; fC=0; fG=0; fT=0; rA=0; rC=0; rG=0; rT=0;
	}
	inline void loadSeq(Str::Text::Arg sequence, size_t size) {
		//this is all reference mumbo-jumobo
		refA=sequence[size/2]=='A';
		refC=sequence[size/2]=='C';
		refG=sequence[size/2]=='G';
		refT=sequence[size/2]=='T';
	}
	inline void add(const RefSNPInfo& data, size_t pos, bool fwd) {
		//this is all reference mumbo-jumobo
		refA+=data.refA;
		refC+=data.refC;
		refG+=data.refG;
		refT+=data.refT;				
	}
	inline void screen(const ScreenData& data, size_t pos, bool fwd) {
		//this is read mumbo-jumob
		if (fwd) { //means: read and key are in the same direction
			fA+=data.nA;
			fC+=data.nC;
			fG+=data.nG;
			fT+=data.nT;		
		}
		else { //means: read and key are in different directions
			rA+=data.nT;
			rC+=data.nG;
			rG+=data.nC;
			rT+=data.nA;		
		}
	}
	inline void update(const SNPInfo& data) {
		fA+=data.fA;
		fC+=data.fC;
		fG+=data.fG;
		fT+=data.fT;				
		rA+=data.rA;
		rC+=data.rC;
		rG+=data.rG;
		rT+=data.rT;
	}
	inline void toStream(std::ostream& os) const {
		os.write((const char*)(&refA), sizeof(UInt32));
		os.write((const char*)(&refC), sizeof(UInt32));
		os.write((const char*)(&refG), sizeof(UInt32));
		os.write((const char*)(&refT), sizeof(UInt32));
		os.write((const char*)(&fA), sizeof(UInt32));
		os.write((const char*)(&fC), sizeof(UInt32));
		os.write((const char*)(&fG), sizeof(UInt32));
		os.write((const char*)(&fT), sizeof(UInt32));
		os.write((const char*)(&rA), sizeof(UInt32));
		os.write((const char*)(&rC), sizeof(UInt32));
		os.write((const char*)(&rG), sizeof(UInt32));
		os.write((const char*)(&rT), sizeof(UInt32));
	}
	inline void fromStream(std::istream& is) {
		is.read((char*)(&refA), sizeof(UInt32));
		is.read((char*)(&refC), sizeof(UInt32));
		is.read((char*)(&refG), sizeof(UInt32));
		is.read((char*)(&refT), sizeof(UInt32));
		is.read((char*)(&fA), sizeof(UInt32));
		is.read((char*)(&fC), sizeof(UInt32));
		is.read((char*)(&fG), sizeof(UInt32));
		is.read((char*)(&fT), sizeof(UInt32));
		is.read((char*)(&rA), sizeof(UInt32));
		is.read((char*)(&rC), sizeof(UInt32));
		is.read((char*)(&rG), sizeof(UInt32));
		is.read((char*)(&rT), sizeof(UInt32));
	}
	inline UInt32 getFwdA() const { return fA; }
	inline UInt32 getFwdC() const { return fC; }
	inline UInt32 getFwdG() const { return fG; }
	inline UInt32 getFwdT() const { return fT; }	
	inline UInt32 getRevA() const { return rA; }
	inline UInt32 getRevC() const { return rC; }
	inline UInt32 getRevG() const { return rG; }
	inline UInt32 getRevT() const { return rT; }	
	inline UInt32 getA() const { return fA+rA; }
	inline UInt32 getC() const { return fC+rC; }
	inline UInt32 getG() const { return fG+rG; }
	inline UInt32 getT() const { return fT+rT; }	
	inline UInt32 getFwd() const { return fA + fC + fG + fT; }
	inline UInt32 getRev() const { return rA + rC + rG + rT; }
	inline UInt32 getTotal() const { return getFwd() + getRev(); }
	inline bool hasSingleBase(double sbThreshold, char& b) const {
		UInt32 total = getTotal();  
		if (getA() >= sbThreshold * total) { b='A'; return true; }
		if (getC() >= sbThreshold * total) { b='C'; return true; }
		if (getG() >= sbThreshold * total) { b='G'; return true; }
		if (getT() >= sbThreshold * total) { b='T'; return true; }
		return false;
	}
	inline bool isAmbiguous() const {
		return (refA!=0) + (refC!=0) + (refG!=0) + (refT!=0) > 1;
	}
};

#endif
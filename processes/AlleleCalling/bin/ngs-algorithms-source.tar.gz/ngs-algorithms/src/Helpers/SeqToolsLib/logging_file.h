/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#include <fstream>

#include "strdef.h"
#include "logging.h"

#ifndef LOGGING_FILE_H
#define LOGGING_FILE_H

class LoggerToFile : public Logger{
private:
	Str::Path::Val filename_;
public:
	LoggerToFile(Str::Path::Arg filename);
	~LoggerToFile();

	void addLog(Str::Text::Arg line);
};

#endif
#ifndef ALLELEFINDER_H
#define ALLELEFINDER_H

#include "boost/shared_ptr.hpp"
#include "factorycounter.h"
#include "CE_Algorithm.h"
#include "SequenceFilesParser.h"

class AlleleFinderSettings;
class AlleleFinderData;

class AlleleFinder;
typedef boost::shared_ptr<AlleleFinder> AlleleFinderPtr;

void fillFinderFactory();

namespace engine
{
class ExecuteEnvironment;
};

class AlleleFinderAlgorithm : public engine::Algorithm
{
protected:
    virtual int ExecuteImpl(int argc, char* argv[], const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm);
public:
    AlleleFinderAlgorithm();
    ~AlleleFinderAlgorithm();
};

class AlleleFinder : public FactoryPrototypeBase<AlleleFinder>
{
protected:
    virtual void checkPre(const AlleleFinderSettings& settings, const communication::CalcCommunication& comm) const =0;
    virtual void parseFiles(const AlleleFinderSettings& settings, SequenceFiles& files, const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm) const;
    virtual void applyImpl(const AlleleFinderSettings& settings, const SequenceFiles& files, const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm) const =0;

public:
    AlleleFinder();
    virtual ~AlleleFinder();

    virtual void apply(const AlleleFinderSettings& settings, const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm) const;

    static void Apply(const AlleleFinderSettings& settings, const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm);
};

class KMerAlleleFinder : public AlleleFinder, public LeafClassBase<KMerAlleleFinder>
{
protected:
    virtual void checkPre(const AlleleFinderSettings& settings, const communication::CalcCommunication& comm) const;
    virtual void applyImpl(const AlleleFinderSettings& settings, const SequenceFiles& files, const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm) const;
public:
    KMerAlleleFinder();
    ~KMerAlleleFinder();

    static FactoryIDType::Ref GetTypeName();
    virtual FactoryIDType::Ref GetFactoryType() const;
    virtual AlleleFinderPtr Clone() const;
};

#endif
/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele
*/


#ifndef KMERHASHTABLE_H
#define KMERHASHTABLE_H

#include <hash_set>
#include <vector>
#include <bitset>
#include <sstream>
#include <iostream>
#include <functional>
#include "intdef.h"
#include "strdef.h"
#include "HashMap.h"

typedef UInt32 KMerSize;


template<class KeyType>
KeyType GetKey(const char* seq, KMerSize k) 
{
	ASSERT(0);
	return KeyType();
}


template<class KeyType, KMerSize k> 
class SimpleKey {
public:
	typedef KeyType KeyType;
	static const KMerSize kMerSize = k;
private:
	SimpleKey() {}
public:
	inline static UInt32 KeyLen() { return kMerSize; }
	inline static KeyType GetKey(const char* seq) { return GetKey<KeyType>(seq, kMerSize); }
	inline static Str::Text::Val GetDir() { 
		std::stringstream s; for(size_t i=0; i<k; ++i) s << '-';
		return s.str();
};



template<class Key, class Info>
class KMerHashTable {
public:	
	typedef typename Key::KeyType KeyType;
	typedef Info Info;
	typedef typename Info::Data InfoData;
private:	
	std::unordered_map<KeyType, typename Info::Data> table_;	
public:
	KMerHashTable () {}
	~KMerHashTable() {}

	inline size_t size() const {
		return table_.size();
	}
	inline void add(const char* seq, size_t seqlen, const typename Info::UpdateData& updateData, bool addnewkeys) {
		if (seqlen<Key::KeyLen()) return;
		
		KeyType key;
		for(UInt32 i=0; i<=seqlen-key_.keyLen(); ++i) {
			key = Key::GetKey(seq+i); 
			auto it = table_.find(key);
			if (it!=table_.end()) typename Info::Update(it->second, i, updateData);
			else if (addnewkeys) table_[key]=typename Info::Create(i, updateData);
		}
	}
	inline bool updateIfPresent(const Key& key, size_t pos, const typename Info::UpdateData& updateData) {
		auto it = table_.find(key);
		if (it!=table_.end()) {
			 typename Info::Update(it->second, pos, updateData); return true;
		}
		else {
			return false;
		}		
	}

	typedef std::function<void (const KeyType& key, InfoData& data)> Visitor;
	typedef std::function<void (const KeyType& key, const InfoData& data)> ConstVisitor;
	void visit(Visitor& v) {
		for(auto it = table_.begin(); it!=table_.end(); ++it) v(it->first, it->second);
	}
	void visit(ConstVisitor& v) const {
		for(auto it = table_.begin(); it!=table_.end(); ++it) v(it->first, it->second);
	}

	void serialize(std::ostream& os) const {		
		UInt32 sz = table_.size(); 
		os.write((const char*)(&sz), sizeof(UInt32));		
		for(auto it=table_.begin(); it!=table_.end(); ++it) {			
			os.write((const char*)(&(it->first)), sizeof(KeyType)); 
			Info::Serialize(it->second, os); 
		};
	}
	template<class InputStream>
	void deserialize(InputStream& is) {		
		UInt32 sz; is.read((char*)(&sz), sizeof(UInt32));
		InfoData data; KeyType key;
		for(size_t i=0; i<sz; ++i) {
			is.read((char*)(&key), sizeof(KeyType)); 
			Info::Deserialize(data, is);			
			table_.insert(std::make_pair(key, data));
		}
	}
};

//info class for counting the frequency of each kmer
class FrequencyInfo {
public:
	typedef UInt32 Data;
	typedef UInt32 UpdateData;
	
	static inline Data Create(UInt32 pos, const UpdateData& updateData) { return 1; }
	static inline void Update(Data& data, UInt32 pos, const UpdateData& updateData) { data+=1; }
	static void Serialize(const Data& data, std::ostream& os) { os.write((const char*)(&data), sizeof(data)); }
	template<class InputStream>
	static void Deserialize(Data& data, InputStream& is) { is.read((char*)(&data), sizeof(data)); }

	static UpdateData GetUpdateData(Str::Text::Arg name, UInt32 idx) { return UpdateData(0); }
	static Str::Text::Val GetDir() { return "Frequency"; }
};

typedef KMerHashTable<SimpleKey<UInt64>, FrequencyInfo> FrequencyHashTable;

//info class for remembering the position of each kmer
class PositionInfo {
public:
	typedef std::vector<UInt32> Data;
	typedef UInt32 UpdateData;
	inline Data Create(UInt32 pos, const UpdateData& updateData) { return Data(1, pos); }
	inline void Update(Data& data, UInt32 pos, const UpdateData& updateData) { data.push_back(pos); }
	static void Serialize(const Data& data, std::ostream& os) { 
		UInt32 sz = data.size();
		os.write((const char*)(&sz), sizeof(UInt32)); 
		if (sz)	os.write((const char*)(&data[0]), sz*sizeof(UInt32));
	}
	template<class InputStream>
	static Data Deserialize(Data& data, InputStream& is) { 
		UInt32 sz; is.read((char*)(&sz), sizeof(UInt32)); data.resize(sz);
		if (sz)	is.read((char*)(&data[0]), sz*sizeof(UInt32));
	}	
	static UpdateData GetUpdateData(Str::Text::Arg name, UInt32 idx) { return UpdateData(0); }
	static Str::Text::Val GetDir() { return "SingleSeq"; }
};

typedef KMerHashTable<SimpleKey<UInt64>, PositionInfo> SeqHashTable;

//info class for remembering the read id of each kmer
template<class ReadId>
class ReadInfo {
public:
	struct ReadData {
		ReadId id;
		UINT32 pos;

		ReadData() : id(-1), pos(-1) {}
		ReadData(const ReadId& iid, UInt32 ipos) : id(iid), pos(ipos) {}
		ReadData(const ReadData& other) :  id(other.id), pos(other.pos) {}
	};

	typedef std::vector<ReadData> Data;
	typedef typename ReadId UpdateData;
	inline Data Create(UInt32 pos, const UpdateData& updateData) { return Data(1, ReadData(updateData, pos)); }
	inline void Update(Data& data, UInt32 pos, const UpdateData& updateData) { data.push_back(ReadData(pos, updateData)); }

	static void Serialize(const Data& data, std::ostream& os) { 
		UInt32 sz = data.size();
		os.write((const char*)(&sz), sizeof(UInt32)); 
		if (sz)	os.write((const char*)(&data[0]), sz*sizeof(ReadData));
	}
	template<class InputStream>
	static void Deserialize(Data& data, InputStream& is) { 
		UInt32 sz; is.read((char*)(&sz), sizeof(UInt32)); data.resize(sz);
		if (sz)	is.read((char*)(&data[0]), sz*sizeof(ReadData));
	}

	static UpdateData GetUpdateData(Str::Text::Arg name, UInt32 idx) { return ReadId(idx); }
	static Str::Text::Val GetDir() { return "MultiSeq"; }
};

typedef KMerHashTable<SimpleKey<UInt64>, PositionInfo> ReadSetHashTable;


#include "filereader.h"
class KMerHashTableDb {
private:
	static Str::Text::Val& GetDbDir() {
		static Str::Text::Val dbDir_;
		return dbDir_;
	};
private:
	template<class Key, class Info>	
	static Str::Text::Val GetPath(Str::Text::Arg filename, bool fwd) {
		Str::Text::Val path = GetDbDir(); 
		path += Key::GetDir(); path += "\\"; 
		path += Info::GetDir(); path += "\\"; 
		path+=filename; if (fwd) path+=".hash_fwd"; else path+=".hash_rev";
		return path;
	}
	template<class Key, class Info>
	static void HasTable(Str::Text::Arg filename, bool fwd) {		
		return ExistsFile(GetPath<Key, Info>(filename, fwd));
	}
	template<class Key, class Info>
	static void LoadTable(Str::Text::Arg filename, bool fwd, KMerhashTable<Key, Info>& table) {
		std::ifstream is(GetPath<Key, Info>(filename, fwd));		
		table.deserialize(is);
	}	
	template<class Key, class Info>
	static void CreateTable(Str::Text::Arg filename, Str::Text::Arg filetype, bool fwd, KMerhashTable<Key, Info>& table) {
		SeqFileReader* reader = SeqFileReader::AutoDetect(filename, filetype);
		reader->init(filename);

		Str::Text::Val name, seq;
		while (reader->hasMore()) {
			reader->getNextSeq(name, seq);
			if (!seq.empty())
				hash.add(ToRef(seq), seq.size(), Info::GetUpdateData(ToRef(name), i), true);
		}

		delete reader;
	}
public:
	static void SetDbDir(Str::Text::Arg idir) {
		Str::Text::Val& dir = GetDbDir();
		dir = idir;
		if (!idir.empty() && idir.back()!='\\') idir +='\\';
	}
	template<class Key, class Info>
	static void StoreTable(Str::Text::Arg filename, bool fwd, KMerhashTable<Key, Info>& table) {
		std::ofstream os(GetPath<Key, Info>(filename), fwd);
		table.serialize(os);
	}
	template<class Key, class Info>
	static void LoadOrCreateTable(Str::Text::Arg filename, Str::Text::Arg filetype, bool fwd, MerhashTable<Key, Info>& table) {
		if (HasTable<Key, Info>(filename)) LoadTable<Key, Info>(filename, fwd, table)
		else {
			CreateTable<Key, Info>(filename, filetype, fwd, table);
			StoreTable<Key, Info>(filename, fwd, table);
		}
	}
};






template<>
inline UInt64 GetKey(const char* seq, KMerSize k) 
{
	//ASSERT(k<=32);
	unsigned __int32 vals[2]; 
	
	vals[0]=0; vals[1]=0;
	{
		std::bitset<32> bits;
		size_t i;
		{		
			i=0;		
			for(; i<std::min<size_t>(16, k); ++i) {
				bits[2*i] = (seq[i]=='C' || seq[i]=='T');
				bits[2*i+1] = (seq[i]=='G' || seq[i]=='T');
			}
			for(; i<16; ++i) {
				bits[2*i] = false;
				bits[2*i+1] = false;
			}
			vals[0] = bits.to_ulong();
		}
		if (k>16) {
			i=0;
			for(; i<k-16; ++i) {
				bits[2*i] = (seq[16+i]=='C' || seq[16+i]=='T');
				bits[2*i+1] = (seq[16+i]=='G' || seq[16+i]=='T');
			}
			for(; i<16; ++i) {
				bits[2*i] = false;
				bits[2*i+1] = false;
			}
			vals[1] = bits.to_ulong();
		}
	}
	return *(UInt64*)(&vals[0]);
}

template<>
inline UInt32 GetKey(const char* seq, KMerSize k) 
{
	//ASSERT(k<=16);
	std::bitset<32> bits;
	size_t i =0;
	{
		for(; i<std::min<size_t>(16, k); ++i) {
			bits[2*i] = (seq[i]=='C' || seq[i]=='T');
			bits[2*i+1] = (seq[i]=='G' || seq[i]=='T');
		}
		for(; i<16; ++i) {
			bits[2*i] = false;
			bits[2*i+1] = false;
		}
	}
	return bits.to_ulong();
}

template<>
inline UInt16 GetKey(const char* seq, KMerSize k) 
{
	//ASSERT(k<=8);
	std::bitset<16> bits;
	size_t i=0;
	for(; i<k; ++i) {
		bits[2*i] = (seq[i]=='C' || seq[i]=='T');
		bits[2*i+1] = (seq[i]=='G' || seq[i]=='T');
	}
	for(; i<8; ++i) {
		bits[2*i] = false;
		bits[2*i+1] = false;
	}
	return bits.to_ulong();
}

//
//inline Str::Text::Val GetFrequencyHashTableFile(Str::Text::Arg workingDir, Str::Text::Arg filename, size_t kmerlen, bool fwd) 
//{	
//	std::string myfilename=filename, myworkingdir = workingDir;
//	if (!myworkingdir.empty() && myworkingdir.back()!='\\') myworkingdir+="\\";
//	
//	std::ostringstream outputFileName; 
//	outputFileName << myworkingdir;
//	outputFileName << "HashTables\\";
//	size_t pos1=myfilename.find_last_of("\\");
//	size_t pos2=myfilename.find_last_of(".");
//	outputFileName << myfilename.substr(pos1+1, pos2-pos1-1);
//	outputFileName << "_" << kmerlen;
//	if (fwd) outputFileName << ".fwd_hash";
//	else outputFileName << ".rev_hash";
//
//	return outputFileName.str();
//}





#endif

#include "stdafx.h"

#include "CE_LogAction.h"

#include "CalcCommunicationImpl.h"

#include "CE_Logger.h"


namespace engine
{



/**
    MessageType defaults to Message
*/
LogBlock::LogBlock( const Str::Text::Val& message, const communication::CalcCommunication& comm )
    : communication_ ( comm )
    , type_   ( LogMessageType::Message() )
    , message_( message )
{
    Init();
}

LogBlock::LogBlock( LogMessageType type, const Str::Text::Val& message, const communication::CalcCommunication& comm )
    : communication_ ( comm )
    , type_   ( type )
    , message_( message )
{
    Init();
}

void LogBlock::LogSuccess()
{
    communication_.Send( communication::CalcMessage(message_ + PM(" succeeded!")) );
}

void LogBlock::Init()
{
    communication_.Send( communication::CalcMessage(message_ + PM("...")) );
}

LogAction::LogAction( const communication::CalcCommunication& comm, const Str::Text::Val& message)
    : logBlock_( message, comm )
{
}

LogAction::LogAction( const communication::CalcCommunication& comm, LogMessageType type, const Str::Text::Val& message)
    : logBlock_( type, message, comm )
{
}

LogAction::~LogAction()
{
    try {
        logBlock_.LogSuccess();
    }
    catch ( ... ) {
        ASSERT(0);
    }
}


} // namespace engine

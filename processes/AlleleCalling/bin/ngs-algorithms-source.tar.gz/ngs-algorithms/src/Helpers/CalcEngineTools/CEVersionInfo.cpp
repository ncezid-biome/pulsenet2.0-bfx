#include "stdafx.h"

#include "CEVersionInfo.h"
#include "BuildInfo.h"

Str::Text::Val GetVersionInfo()
{
    return RawMessage(
        PM("%1 Build %2:%3 [ %4 ]"),
        GetCEVersion(),
        GetBuildBranch(),
        GetBuildNumber(),
        GetBuildDate()
        ).c_str();
}

void PrintVersionInfo()
{
    std::cout << GetVersionInfo() << std::endl;
}

void PrintVersionInfo( const Str::Text::Val& shortName, const Str::Text::Val& longName )
{
    RawMessage message( PM("%1 %2 Build %3:%4 [ %5 ] (%6)") );
    
    message << shortName
            << GetCEVersion()
            << GetBuildBranch()
            << GetBuildNumber()
            << GetBuildDate()
            << longName;

    std::cout << message.c_str()
              << std::endl;
}

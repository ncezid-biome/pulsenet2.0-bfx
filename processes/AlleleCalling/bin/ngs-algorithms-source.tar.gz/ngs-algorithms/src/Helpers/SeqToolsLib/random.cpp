/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#include "stdafx.h"
#include "random.h"
#include <stdlib.h>

char bases[] = {'A', 'C', 'G', 'T'};

bool GetRandomBool(double p)
{
	return rand() < p*RAND_MAX;
}
char GetRandomBase() 
{
	return bases[rand()%4]; 
}
double GetRandomNumber(double low, double high) 
{
	double val = (rand() + RAND_MAX*rand()) / ((1.0+RAND_MAX)*RAND_MAX);
	return low + (high-low) * val;
}

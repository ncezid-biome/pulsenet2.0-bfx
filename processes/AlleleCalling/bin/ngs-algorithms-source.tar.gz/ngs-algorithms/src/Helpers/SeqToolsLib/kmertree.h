/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele
*/


#include <bitset>
#include<functional>
#include "strdef.h"

#ifndef KMER_TREE_H
#define KMER_TREE_H

namespace kmer {

	extern int NodeCount;
	extern int LeafCount;

	typedef char Nucleotide;
	typedef std::bitset<2> PackedNucleotide;

	class NucleotideEncoding {
	public:	
		inline static PackedNucleotide Encode(Nucleotide base) {
			PackedNucleotide packed;
			packed[0] = base=='C' || base=='T';
			packed[1] = base=='G' || base=='T';
			return packed;
		}
		inline static Nucleotide Decode(PackedNucleotide base) {
			if (base[0] && base[1]) return 'T';
			else if (base[0]) return 'C';
			else if (base[1]) return 'G';
			else return 'A';			
		}
		inline static size_t GetIndex(Nucleotide base) {
			return (base=='C' || base=='T') + 2*(base=='G' || base=='T');
		}
	};

	template<class Info>
	class KMerTreeNode {
	public:
		typedef typename Info::InfoUpdate UpdateInfo;
	private:		
		KMerTreeNode* children_[4];
	public:
		KMerTreeNode()
		{
			++NodeCount;
			children_[0]=0;			
			children_[1]=0;
			children_[2]=0;
			children_[3]=0;
		}		
		KMerTreeNode(Nucleotide nucl) 
			//: nucl_(NucleotideEncoding::Encode(nucl))
		{
			++NodeCount;
			children_[0]=0;			
			children_[1]=0;
			children_[2]=0;
			children_[3]=0;
		}		
		virtual ~KMerTreeNode() { 
			delete children_[0];			
			delete children_[1];
			delete children_[2];
			delete children_[3];		
		}

		void init(const typename Info::InfoUpdate& update) {
			children_[0]=0;			
			children_[1]=0;
			children_[2]=0;
			children_[3]=0;
		}

		KMerTreeNode* addOrCreate(Nucleotide letter, bool leaf, const typename Info::InfoUpdate& update) {					
			size_t idx = NucleotideEncoding::GetIndex(letter);
			KMerTreeNode* node = children_[idx];			
			if (node==0) {				
				if (leaf) children_[idx]=new KMerTreeLeaf<Info>(letter, update);
				else children_[idx]=new KMerTreeNode<Info>(letter);				
				node=children_[idx];				
			}
			else if (leaf) {
				typename Info::Update(((KMerTreeLeaf<Info>*)node)->getInfo(), update);
			}
			return node;
		}
		
		KMerTreeNode* getChild(Nucleotide letter) {
			return children_[GetIndex(letter)];
		}
		const KMerTreeNode* getChild(Nucleotide letter) const {
			return children_[GetIndex(letter)];
		}


		typedef std::function<void (typename Info::InfoData& info)> LeafVisitor;
		typedef std::function<void (const typename Info::InfoData& info)> ConstLeafVisitor;

		virtual void visitLeafs(LeafVisitor& visitor) {
			for(size_t i=0;  i<4; ++i) {
				if (children_[i]) children_[i]->visitLeafs(visitor);
			}
		}
		virtual void visitLeafs(ConstLeafVisitor& visitor) const {
			for(size_t i=0;  i<4; ++i) {
				if (children_[i]) children_[i]->visitLeafs(visitor);
			}
		}
	};

	template<class NodeClass>
	class KMerTreeNodeRepos {
	private:
		NodeClass** nodes_;
		size_t nChunks_;
		size_t current_chunk_, current_node_;
	public:
		KMerTreeNodeRepos() : nodes_(0), nChunks_(0), current_chunk_(0), current_node_(10000) {}
		~KMerTreeNodeRepos() {
			for(size_t i=0; i<nChunks_; ++i) free(nodes_[i]);
			free(nodes_);
		}

		NodeClass* getNode(const typename NodeClass::UpdateInfo& update) {
			if (current_node_==10000) {
				if (current_chunk_==nChunks_) {
					nodes_=(NodeClass**)realloc(nodes_, sizeof(NodeClass*) * (nChunks_+5));
					for(size_t i=nChunks_; i<nChunks_+5; ++i) {
						nodes_[i]=(NodeClass*)malloc(sizeof(NodeClass)*10000);						
					}
					nChunks_+=5;			
				}
				current_node_=0;			
				
			}
			NodeClass* node = &nodes_[current_chunk_][current_node_];
			node->init(update);
			
			current_node_++;
			if 	(current_node_==10000) 	++current_chunk_;
			
			return node;
		}

	};

	template<class Info>
	class KMerTreeLeaf : public KMerTreeNode<Info> {
	private:
		typename Info::InfoData info_;
	public:
		KMerTreeLeaf(Nucleotide nucl, const typename Info::InfoUpdate& update) : KMerTreeNode(nucl) { ++LeafCount; typename Info::Create(info_, update); };
		~KMerTreeLeaf() {}

		void init(const typename Info::InfoUpdate& update) {
			__super::init(update);
			typename Info::Create(info_, update);
		}

		inline typename Info::InfoData& getInfo() { return info_; }
		inline const typename Info::InfoData& getInfo() const { return info_; }
		
		virtual void visitLeafs(LeafVisitor& visitor) {
			visitor(info_);
		}
		virtual void visitLeafs(ConstLeafVisitor& visitor) const {
			visitor(info_);
		}
	};

	template<class Info>
	class KMerTree {
	private:
		size_t k_;
		KMerTreeNode<Info> root_;
	public:
		KMerTree(size_t k) : k_(k) {}
		~KMerTree() {}

		void add(const Nucleotide* seq, size_t seqlen, const typename Info::InfoUpdate& update) {
			KMerTreeNode<Info>* node;
			for(size_t i=0; i<seqlen-k_; ++i) {
				node = &root_;
				for(size_t j=0; j<k_; ++j) {
					node = node->addOrCreate(seq[i+j], j+1==k_, update);
				}
			}
		}
	
		const typename Info::InfoData* getInfo(const char* kmer)  const{
			const KMerTreeNode<Info>* node = &root;
			for(size_t i=0; i<k_; ++i) {
				node = node->getChild(kmer[i]);
				if (node==0) return 0;
			}
			return (const KMerTreeLeaf<Info>*)node->getInfo();
		}
		typename Info::InfoData* getInfo(const char* kmer) {
			KMerTreeNode<Info>* node = &root;
			for(size_t i=0; i<k_; ++i) {
				node = node->getChild(kmer[i]);
				if (node==0) return 0;
			}
			return (KMerTreeLeaf<Info>*)node->getInfo();
		}		

		typedef typename KMerTreeNode<Info>::LeafVisitor LeafVisitor;
		typedef typename KMerTreeNode<Info>::ConstLeafVisitor ConstLeafVisitor;
		void visitLeafs(LeafVisitor& visitor) {
			root_.visitLeafs(visitor);
		}
		void visitLeafs(ConstLeafVisitor& visitor) const {
			root_.visitLeafs(visitor);
		}
	};

	template<class ReadId>
	class ReadInfo {
	public:
		typedef std::vector<ReadId> InfoData;
		typedef ReadId InfoUpdate;

		static inline void Create(InfoData& data, const InfoUpdate& update) { data.resize(1, update); }
		static inline void Update(InfoData& data, const InfoUpdate& update) { data.push_back(update); }
	};

	class PresenceInfo {
	public:
		struct Info {
			size_t cnt;
			bool present;
		};
		typedef Info InfoData;
		typedef bool InfoUpdate;

		static inline void Create(InfoData& data, const InfoUpdate& update) { data.cnt=1; data.present=true; }
		static inline void Update(InfoData& data, const InfoUpdate& update) { data.cnt+=1; data.present=true; }
	};

	extern KMerTreeNodeRepos<KMerTreeNode<PresenceInfo>> nodeRepos;
	extern KMerTreeNodeRepos<KMerTreeLeaf<PresenceInfo>> leafRepos;

}//end namespace
#endif
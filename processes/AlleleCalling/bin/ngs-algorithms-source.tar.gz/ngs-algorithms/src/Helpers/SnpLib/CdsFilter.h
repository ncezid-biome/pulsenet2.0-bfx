#pragma once

#include "PerSequenceCachedSNPAlgorithm.h"

#include "Optionlist.h"


namespace snp
{

/** Intermediate base class for filters that work on the mutation type
 */
class CdsFilter : public PerSequenceCachedSNPAlgorithm
{
public:

    virtual Str::Text::Val GetSnpDisplayInfo(
                                const SnpCache& snp,
                                const SequenceSnpData& sequenceSnps,
                                const SequenceData&    reference ) const override;

    virtual double         GetSnpSortValue(
                                const SnpCache& snp,
                                const SequenceSnpData& sequenceSnps,
                                const SequenceData&    reference ) const override;

    virtual FilterCategory GetCategory() const override { return FilterCategory::Any; }
};

} // namespace snp

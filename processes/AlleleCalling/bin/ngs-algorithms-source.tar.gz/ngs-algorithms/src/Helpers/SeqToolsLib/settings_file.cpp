/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#include "stdafx.h"
#include <fstream>
#include "settings_file.h"

#include "exception.h"


SettingsFromFile::SettingsFromFile(Str::Path::Arg filename)
{
	read(filename);
}
SettingsFromFile::~SettingsFromFile()
{
}
bool SettingsFromFile::hasSetting(const Id& id) const
{
	return settings_.find(id) != settings_.end();
}
SettingsFromFile::Val SettingsFromFile::getSetting(const Id& id) const
{
	auto it = settings_.find(id);
	if (it==settings_.end())
		throw KError("Could not find setting with id %1.") << id;

	return it->second;
}
void SettingsFromFile::read(Str::Path::Arg filename)
{
	settings_.clear();

	std::ifstream is(filename);
	if (!is.is_open())
		throw KError("Could not open file %1.") << filename;

	std::string line; size_t pos; 
	Settings::Id id;
	Settings::Val val;
	while (std::getline(is, line)) {
		pos  = line.find_first_of('=');
		if (pos!=std::string::npos) {
			id = line.substr(0, pos);
			while (!id.empty() && id.back()==' ') id.pop_back();
			val=line.substr(pos+1, std::string::npos);
			while (!val.empty() && val.front()==' ') val.erase(val.begin());
			settings_[id] = val;
		}
	}
}
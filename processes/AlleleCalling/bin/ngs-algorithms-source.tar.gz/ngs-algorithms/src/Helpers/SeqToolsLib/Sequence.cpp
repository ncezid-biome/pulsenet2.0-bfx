#include "stdafx.h"

#include "Sequence.h"

#include "SequenceManip.h"
#include "SequenceRangeManip.h"
#include "SequenceHash.h"
#include "Message.h"


namespace seq
{
 
struct Sequence::OpaquePointer
{
    OpaquePointer()
        : data()
    {
    }

    Str::Text::Val data;
};

Sequence::Sequence()
    : d_( new OpaquePointer() )
{
}

Sequence::Sequence(const Str::Text::Val& sequence)
    : d_( new OpaquePointer() )
{
    // Use Append to make sure everything is upper-cased
    AppendSequence(sequence);
}

Sequence::Sequence(Sequence&& rhs) throw()
    : d_( std::move(rhs.d_) )
{
}

/**
    Move assignment
*/
Sequence& Sequence::operator=(Sequence&& rhs)
{
    d_ = std::move(rhs.d_);
    return *this;
}

/**
    Needed for unique_ptr pimpl
*/
Sequence::~Sequence()
{
}

/**
    Auto converts IUPAC codes to upper case, other bases are converted to N!
*/
Sequence& Sequence::AppendSequence(const Str::Text::Val& sequence)
{
    size_t oldsize = GetLength();
    d_->data += sequence;

    IUPACToUpperCase( d_->data.begin() + oldsize, d_->data.end() );

    return *this;
}

Sequence&  Sequence::Set(const Str::Text::Val& sequence)
{
    d_->data = sequence;
    IUPACToUpperCase( d_->data.begin(), d_->data.end() );

    return *this;
}

Sequence::iterator Sequence::begin()
{
    return d_->data.begin();
}

Sequence::iterator Sequence::end()
{
    return d_->data.end();
}

Sequence::const_iterator Sequence::begin() const
{
    return d_->data.cbegin();
}


Sequence::const_iterator Sequence::end() const
{
    return d_->data.cend();
}

const char* Sequence::c_str() const
{
    return d_->data.c_str();
}

/**
    Preferably use SequenceContains instead of this method.

    Provided as an alternative to exposing the internal string
*/
bool Sequence::Contains(const Sequence& other) const
{
    return d_->data.find(other.d_->data) != std::string::npos;
}

size_t Sequence::GetLength() const
{
    return d_->data.size();
}

bool Sequence::operator==(const Sequence& rhs) const
{
    return d_->data == rhs.d_->data;
}

bool Sequence::operator!=(const Sequence& rhs) const
{
    return d_->data == rhs.d_->data;
}

const Str::Text::Val& Sequence::ToString() const
{
    return d_->data;
}

Sequence Sequence::Copy() const
{
    return Sequence( d_->data );
}

Sequence Sequence::Sub(size_t start, size_t stop) const
{
    if( stop < start )
        throw KError( "Invalid start and stop for sequence subsampling: %1;%2" )
            << start
            << stop;

    return Sequence(d_->data.substr(start, stop - start));
}

Sequence::const_iterator Sequence::GetIter(size_t pos) const
{
    return d_->data.begin() + pos;
}

bool Sequence::IsEmpty() const
{
    return d_->data.empty();
}

char& Sequence::operator[](size_t index)
{
    return d_->data[index];
}

const char& Sequence::operator[](size_t index) const
{
    return d_->data[index];
}

/**
    Warning: does not enter default values for new bases!
*/
Sequence&  Sequence::Resize(size_t size)
{
    d_->data.resize(size);
    return *this;
}

/**
    Allow inserting e.g. | into the sequence, if you want to.
*/
Sequence&  Sequence::AppendVerbatim(const Str::Text::Val& string)
{
    d_->data += string;
    return *this;
}

Sequence& Sequence::TrimAmbiguous()
{
	// filter out ambiguous bases at the start and end of contig
	auto & sequence = d_->data;
	while (!sequence.empty() && (sequence.front() == 'N' || sequence.front() == 'n'))
	{
		sequence.erase(0, 1);
	}
	while (!sequence.empty() && (sequence.back() == 'N' || sequence.back() == 'n'))
	{
		sequence.pop_back();
	}
	return *this;
}

size_t Sequence::Hash(const SequenceHash& hasher) const
{
    return hasher.stringhash(d_->data);
}

void Sequence::Swap(Sequence& other)
{
    d_.swap(other.d_);
}

/**
    Throws is \a pos is invalid
*/
Sequence& Sequence::Insert(size_t pos, const Str::Text::Val& sequence)
{
    if ( pos > GetLength() )
        throw KError( pm("Invalid insertion position: %1 (sequence length: %2)").arg(pos).arg(GetLength()) );

    d_->data.insert(pos, sequence);
    return *this;
}

/**
    Does a verbatim append!
*/
Sequence Sequence::operator+(const Str::Text::Val& string) const
{
    Sequence copy(this->Copy());
    copy.AppendVerbatim(string);
    return copy;
}

/**
    Does a verbatim append!
*/
Sequence Sequence::operator+(const Sequence& sequence) const
{
    Sequence copy(this->Copy());
    copy.AppendVerbatim(sequence.d_->data);
    return copy;
}

void Sequence::clear()
{
    d_->data.clear();
}

std::ostream& operator<<(std::ostream& stream, const Sequence& sequence)
{
    return stream.write(sequence.c_str(), sequence.GetLength());
}

bool operator==(const Str::Text::Val& string, const Sequence& sequence)
{
    // string must be in front, otherwise we're doing pointer compare
    return string == sequence.c_str();
}

Sequence::iterator begin(Sequence& sequence)
{
    return sequence.begin();
}

Sequence::const_iterator begin(const Sequence& sequence)
{
    return sequence.begin();
}

Sequence::iterator end(Sequence& sequence)
{
    return sequence.end();
}

Sequence::const_iterator end(const Sequence& sequence)
{
    return sequence.end();
}

} // namespace seq

namespace std
{
    hash<seq::Sequence>::result_type hash<seq::Sequence>::operator()(const argument_type &s) const
    {
        seq::SequenceHash h;
        return s.Hash(h);
    }
}
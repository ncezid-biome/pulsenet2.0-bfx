#include "stdafx.h"
#include "runextern_cmdline.h"
#include "CommandLine.h"

using namespace runextern;


ProcessCmdLine::ProcessCmdLine()
	: redirectStderr_{false}
{
}
/**
 Do not include command line arguments! Stream them into this object, in proper parts.
 */
ProcessCmdLine::ProcessCmdLine(Str::Text::Arg cmdline)
	: redirectStderr_{false}
{
    setCmdLine(cmdline);
}
/**
 Do not include command line arguments! Stream them into this object, in proper parts.
 */
void ProcessCmdLine::setCmdLine(Str::Text::Arg cmdline)
{
	clearCmdLine();

	cmdline_=cmdline;

    //try splitting the input into parts
    arguments_.clear();
    stringToCommandline(Str::Text::Val(cmdline), arguments_);

    if(arguments_.size() > 0) {

        command_ = arguments_[0];
        arguments_.erase(arguments_.begin());
    }
    else
        throw KError("Command line string is empty");
}
void ProcessCmdLine::clearCmdLine()
{
	cmdline_.clear();
    command_.clear();
    arguments_.clear();
}
void ProcessCmdLine::addToCmdLine(Str::Text::Arg part)
{
	cmdline_+=part;
}
Str::Text::Ref ProcessCmdLine::getCmdLine() const
{
	return ToRef(cmdline_);
}

void runextern::ProcessCmdLine::AddPath(const Str::Path::Val& path)
{
    {
        //streaming of a path adds double quotes
        std::ostringstream line;
        line << " " << path;

        addToCmdLine(line.str());
    }

    arguments_.push_back(path.string());
}

void runextern::ProcessCmdLine::AddArgument(Str::Text::Arg argument)
{
    //TODO: check for spaces and add quotes if necessary
    addToCmdLine(" " + argument);

    arguments_.push_back(argument.str());
}

void runextern::ProcessCmdLine::SetCommand(Str::Text::Arg command)
{
    command_=command;
    setCmdLine(command);
}

Str::Text::Ref runextern::ProcessCmdLine::GetCommand() const
{
    return ToRef(command_);
}

/**
 Returns an array of c strings, suitable for passing along to execv*.
 */
ProcessCmdLine::ArgvPtr runextern::ProcessCmdLine::GetArgv() const
{
    const size_t argc=arguments_.size();

    ArgvPtr argv(new char*[argc+2]);
    char** raw_argv=argv.get();

    raw_argv[0]=const_cast<char *>(GetCommand());

    for(size_t m=0; m<argc; m++) {

        raw_argv[m+1]=const_cast<char *>(arguments_[m].c_str());
    }

    raw_argv[argc+1]=nullptr;

    return argv;
}

runextern::ProcessCmdLine& runextern::ProcessCmdLine::operator<<(const Str::Path::Val& path)
{
    AddPath(path);
    return *this;
}


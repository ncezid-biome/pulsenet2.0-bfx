#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "filereader.h"
#include "TestSequenceFiles.h"


BOOST_AUTO_TEST_SUITE( AutoDetectReaderTests );

BOOST_AUTO_TEST_CASE( AutoDetect_Fasta_Ok )
{
    test::SequenceFile file = test::SequenceFiles::GetFiveSeqsFile_Fasta( Compression::None );

    SeqFileReaderPtr reader = SeqFileReader::AutoDetect( file.filename );

    BOOST_CHECK      (reader);
    BOOST_CHECK_EQUAL(reader->GetFactoryType(), PM("fasta"));
}

BOOST_AUTO_TEST_CASE( AutoDetect_Fasta_GzipFile_GzipExt_Ok )
{
    test::SequenceFile file = test::SequenceFiles::GetFiveSeqsFile_Fasta( Compression::gzip );

    BOOST_CHECK_EQUAL( file.filename.extension(), PM(".gz") );

    SeqFileReaderPtr reader = SeqFileReader::AutoDetect( file.filename );

    BOOST_CHECK      (reader);
    BOOST_CHECK_EQUAL(reader->GetFactoryType(), PM("fasta"));
}

#ifdef AMGNU
BOOST_AUTO_TEST_CASE( AutoDetect_Fasta_bz2File_bz2Ext_Ok )
{
    test::SequenceFile file = test::SequenceFiles::GetFiveSeqsFile_Fasta( Compression::bz2 );

    BOOST_CHECK_EQUAL( file.filename.extension(), PM(".bz2") );

    SeqFileReaderPtr reader = SeqFileReader::AutoDetect( file.filename );

    BOOST_CHECK      (reader);
    BOOST_CHECK_EQUAL(reader->GetFactoryType(), PM("fasta"));
}
#endif

BOOST_AUTO_TEST_CASE( AutoDetect_Fastq_Ok )
{
    test::SequenceFile file = test::SequenceFiles::GetSingleLineSequenceFile_Fastq( Compression::None );

    SeqFileReaderPtr reader = SeqFileReader::AutoDetect( file.filename );

    BOOST_CHECK      (reader);
    BOOST_CHECK_EQUAL(reader->GetFactoryType(), PM("fastq"));
}

BOOST_AUTO_TEST_CASE( AutoDetect_Fastq_GzipFile_GzipExt_Ok )
{
    test::SequenceFile file = test::SequenceFiles::GetSingleLineSequenceFile_Fastq( Compression::gzip );

    BOOST_CHECK_EQUAL( file.filename.extension(), PM(".gz") );

    SeqFileReaderPtr reader = SeqFileReader::AutoDetect( file.filename );

    BOOST_CHECK      (reader);
    BOOST_CHECK_EQUAL(reader->GetFactoryType(), PM("fastq"));
}

#ifdef AMGNU
BOOST_AUTO_TEST_CASE( AutoDetect_Fastq_bz2File_bz2Ext_Ok )
{
    test::SequenceFile file = test::SequenceFiles::GetSingleLineSequenceFile_Fastq( Compression::bz2 );

    BOOST_CHECK_EQUAL( file.filename.extension(), PM(".bz2") );

    SeqFileReaderPtr reader = SeqFileReader::AutoDetect( file.filename );

    BOOST_CHECK      (reader);
    BOOST_CHECK_EQUAL(reader->GetFactoryType(), PM("fastq"));
}
#endif

BOOST_AUTO_TEST_CASE( AutoDetect_Fastq_NoQuality_Throws )
{
    test::SequenceFile file = test::SequenceFiles::GetSingle_NoQuality_Fastq( Compression::None );

    BOOST_CHECK_THROW( SeqFileReader::AutoDetect( file.filename ), KError );
}

BOOST_AUTO_TEST_CASE( AutoDetect_Fastq_gzipFile_NoQuality_Throws )
{
    test::SequenceFile file = test::SequenceFiles::GetSingle_NoQuality_Fastq( Compression::gzip );

    BOOST_CHECK_THROW( SeqFileReader::AutoDetect( file.filename ), KError );
}

#ifdef AMGNU
BOOST_AUTO_TEST_CASE( AutoDetect_Fastq_bz2File_NoQuality_Throws )
{
    test::SequenceFile file = test::SequenceFiles::GetSingle_NoQuality_Fastq( Compression::bz2 );

    BOOST_CHECK_THROW( SeqFileReader::AutoDetect( file.filename ), KError );
}
#endif

BOOST_AUTO_TEST_SUITE_END();

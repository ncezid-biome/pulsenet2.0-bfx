#pragma once

#include "StringDef.h"
#include "PathDef.h"


namespace engine
{

namespace tools
{
class CommandLine;
} // namespace tools


/**
    Exposes some parameters related to running the algorithm
*/
class ExecuteEnvironment
{
public:
    ExecuteEnvironment();

    void SetMaxNumThreads( int numThreads );
    bool HasMaxNumThreads() const;
    int  GetMaxNumThreads() const;

    /**
       The local directory where the algorithm is run. You can use this to read/write
       temporary files
    */
    Str::Path::Val localDir;

    /**
        Shared directory where long-term files can be read/stored.

        \sa sharedTempDir
    */
    Str::Path::Val sharedDir;

    /**
      The shared directory where temporary files are stored. You can use this to read/write
      temporary files that need to be shared across jobs (or not).

      \sa sharedDir
    */
    Str::Path::Val sharedTempDir;


    /**
        The result home directory. You should probably never use this directly, use the
        CalcCommunication mechanism to write results files.

        \note The actual results directory is the results subdirectory of \a resultsDir ; )
    */
    Str::Path::Val resultsDir;

    /**
        Has show help been requested on the command line?
    */
    bool showhelp;

    void Update( const tools::CommandLine& commandLine );

	/**
	 * \brief Retrieve the content of the environment variable with the given name.
	 *
	 * May return an empty string should the variable not be set in the environment.
	 */
	Str::Text::Val GetVariable(Str::Text::Val const & variable) const;

private:
    int maxNumThreads_;
};

} // namespace engine

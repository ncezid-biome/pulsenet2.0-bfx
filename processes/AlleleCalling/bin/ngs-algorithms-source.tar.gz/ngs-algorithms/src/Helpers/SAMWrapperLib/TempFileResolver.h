#pragma once
#include "BasicFileResolver.h"

namespace BAM
{

class TempFileResolver: public BasicFileResolver
{

public:

    TempFileResolver(const Str::Path::Val& tempDir):
        BasicFileResolver(boost::filesystem::unique_path(tempDir / "%%%%%%%%.bam"))
    {
    }

};

}
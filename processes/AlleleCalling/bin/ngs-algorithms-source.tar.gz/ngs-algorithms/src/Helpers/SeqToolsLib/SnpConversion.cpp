#include "stdafx.h"

#include "SnpConversion.h"



namespace snp
{
	
/**
    Don't use 0: if we implement 'treat absent as zero' to penalize absent values then
    not using 0 works for any other letter is best.

    \sa numberToBase
*/
int baseToNumber(char base)
{
    switch( base ){
    case 'A': return  2;
    case 'C': return  3;
    case 'G': return  4;
    case 'T': return  5;
    case 'U': return  6;
    case 'R': return  7;
    case 'Y': return  8;
    case 'M': return  9;
    case 'K': return 10;
    case 'W': return 11;
    case 'S': return 12;
    case 'B': return 13;
    case 'D': return 14;
    case 'H': return 15;
    case 'V': return 16;
    default:
    case 'N': return 17;
    case ' ':
    case '-':
        return 1;
    }
}

/**
    \sa baseToNumber
*/
char numberToBase(int number)
{
    switch( number ){
    case  2: return 'A';
    case  3: return 'C'; 
    case  4: return 'G'; 
    case  5: return 'T'; 
    case  6: return 'U'; 
    case  7: return 'R'; 
    case  8: return 'Y'; 
    case  9: return 'M'; 
    case 10: return 'K'; 
    case 11: return 'W'; 
    case 12: return 'S'; 
    case 13: return 'B'; 
    case 14: return 'D'; 
    case 15: return 'H'; 
    case 16: return 'V'; 
    default:
    case 17: return 'N';
    case 1:  return '-';
    }
}


} // namespace snp

#include "stdafx.h"

#include "AlleleKMerTable.h"

#include "filetools.h"
#include "CE_LogAction.h"
#include "CalcCommunicationImpl.h"

AlleleKMerTable::ShortAlleleInfo::ShortAlleleInfo(Str::Text::Arg   name, size_t	length)
	:   name_(name)
	,	length_(length)
{}



AlleleKMerTable::AlleleKMerTable()
    : table_()
{
}

AlleleKMerTable::AlleleKMerTable(size_t k)
    : table_(k, 0, 100000, 0)
{
}

/**
    Based on a sequence file reader, create an allele table
    and a list of allele names

    \sa Store
*/
void AlleleKMerTable::Fill(const SeqFileReader& reader, AllelesInfo& alleleNames, const communication::CalcCommunication& comm)
{
    Str::Text::Val name;
    Str::Text::Val seq;
    Str::Text::Val qual;

    size_t iread = 0;
    for ( iread = 0; reader.hasMore(); ++iread) {
        reader.getNextSeq(name, seq, qual);
        alleleNames.push_back(ShortAlleleInfo(name, seq.length()));
        table_.add(seq, qual, seq.size(), !qual.empty(), AlleleInfo(name, iread));
    }

    comm.Send( communication::CalcMessage( RawMessage(PM("Read %1 reads"), iread).c_str() ) );
}

KMerTable<AlleleInfo>& AlleleKMerTable::GetTable()
{
    return table_;
}

void AlleleKMerTable::ReportStats(const communication::CalcCommunication& comm)
{
    using namespace communication;

    comm.Send( CalcMessage(RawMessage(PM("KMer table:")).c_str()) );
    comm.Send( CalcMessage(RawMessage(PM("\tk:              %1"), table_.getK()).c_str()) );
    comm.Send( CalcMessage(RawMessage(PM("\tSize:           %1"), table_.size()).c_str()) );
    comm.Send( CalcMessage(RawMessage(PM("\tMin quality:    %1"), table_.getMinQual()).c_str()) );
    comm.Send( CalcMessage(RawMessage(PM("\tQuality offset: %1"), table_.getQualOffset()).c_str()) );
    comm.Send( CalcMessage(RawMessage(PM("\tMax violations: %1"), table_.getMaxNViolations()).c_str()) );
}

/**
    \param table must outlive this instance!
*/
AlleleKMerTableIO::AlleleKMerTableIO(AlleleKMerTable* table, const Str::Path::Val& baseName, const communication::CalcCommunication& comm)
    : kmerTable_  ( table )
    , fileRotator_( baseName, 2, comm )
{
    check::IsNotNull( kmerTable_ );
}

void AlleleKMerTableIO::Read()
{
    std::ifstream is;
    OpenBinary(is, fileRotator_.GetCurrentFile());
    kmerTable_->GetTable().fromStream( is );
}

/**
    Write a table with allele info to disk
*/
void AlleleKMerTableIO::Store( const communication::CalcCommunication& comm )
{
    Str::Path::Val filename = fileRotator_.GetNextFile();

    {
        engine::LogAction action( comm, RawMessage(PM("Storing kmer table file '%1'"), filename).c_str() );

        std::ofstream os;
        OpenBinary(os, filename);
        GetTable().GetTable().toStream(os);
    }

    {
        fileRotator_.RotateLinkfile( comm );
    }
}

AlleleKMerTable& AlleleKMerTableIO::GetTable()
{
    return *kmerTable_;

}

const AlleleKMerTable& AlleleKMerTableIO::GetTable() const
{
    return *kmerTable_;
}


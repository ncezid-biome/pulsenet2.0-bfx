#pragma once

#include "StringDef.h"



namespace runextern
{


class ProcessStatus;

/**
    Use a Job Object to set properties of running processes, e.g. per-process max memory,
    global max memory, ...

    You can assign multiple processes to a single JobObject instance, assigning multiple
    JobObject instances to a single process is as of yet not supported. It is possible though,
    see http://msdn.microsoft.com/en-us/library/windows/desktop/hh448388%28v=vs.85%29.aspx.
*/
class JobObject
{
public:
    typedef Str::Text::Val JobName;
    typedef HANDLE         ProcessPtr ;

public:
    JobObject();
    JobObject( const JobName& jobName );

    bool SetMaxMemory ( int maxMemoryMB, ProcessStatus& status );
    bool AssignProcess( ProcessPtr process, ProcessStatus& status );

private:
    void CreateHandle( LPCTSTR jobName );

private:
    JobObject( const JobObject& rhs );
    JobObject& operator=( const JobObject& rhs );

private:
    HANDLE jobhandle_;
};

} // namespace runextern

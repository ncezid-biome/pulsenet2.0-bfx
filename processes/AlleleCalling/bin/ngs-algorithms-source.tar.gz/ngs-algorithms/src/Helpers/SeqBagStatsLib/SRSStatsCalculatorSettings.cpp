#include "stdafx.h"

#include "SRSStatsCalculatorSettings.h"

#include "Checks.h"
#include "zip_range.h"

#include "exception.h"
#include "filereader.h"
#include "CE_FileSystem.h"
#include "BasicSRSStatsCalculator.h"



#define OPTION_HELP "statshelp"
#define OPTION_SETTINGSFILE "statsSettingsFile"


using namespace engine;


/**
    \param standalone: true if running the stats calculator on its own, false if it is running
        as sub-component, meaning that the input files are fed in manually (AddFile(s)) instead 
        of using the command line.
*/
SRSStatsCalculatorSettings::SRSStatsCalculatorSettings( Standalone standalone )
	: engine::ProgramOptions("Statistics")
	, algorithmType(BasicSRSStatsCalculator::GetTypeName())
	, qualOffset(33)
    , outputFileNameInfo("info.xml")
    , outputFileNameStats("stats.xml")
	, doSanitizePath(true)
{
    //add the generic options
    AddOption("statsalgorithm", "algorithm", algorithmType, algorithmType);
	AddListOption("statstype", "sequence read file type", readFileTypes);
	AddOption("statsqualOffset", "quality score offset", qualOffset, qualOffset);

    if ( standalone == Standalone::Yes ){
        // Only add the file option if running standalone, to prevent mixup of the command line for the
        // "master" algorithm with that of the stats algorithm
        AddListOption("file", "sequence read file", readFiles);
    }
}

SRSStatsCalculatorSettings::~SRSStatsCalculatorSettings()
{
}
bool SRSStatsCalculatorSettings::ParseAndSetup(int argc, char* argv[], const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm)
{
	bool showHelp = ParseCmdLine(argc, argv, env, comm);

    //remove any single or double quotes from the file names
    for (size_t i = 0; i < readFiles.size(); ++i)
        SanitizeFile(i);

    //add missing file types with default file type
    for(size_t i = readFileTypes.size(); i < readFiles.size(); ++i)
        readFileTypes.push_back( PM("fastq.gz") );

    //true = everything ok, false = show the help stuff
    return !showHelp;
}

void SRSStatsCalculatorSettings::AddFile(const Str::Text::Val& file, const Str::Text::Val& filetype)
{
    readFiles.push_back( file );
    SanitizeFile( readFiles.size() - 1 );

    readFileTypes.push_back(filetype);
}

void SRSStatsCalculatorSettings::SanitizeFile(size_t index)
{
    check::IsSmaller( index, readFiles.size() );

    ReplaceString(readFiles[index], "'", "");
    ReplaceString(readFiles[index], "\"", "");

    sanitizePath( readFiles[index] );
}

void SRSStatsCalculatorSettings::AddFiles(const Str::Text::Vec& files, const Str::Text::Vec& filetypes)
{
    check::IsEqual( readFiles.size(), readFileTypes.size() );
    check::IsEqual( files.size(), filetypes.size() );

    for ( auto&& t : zip_range(files, filetypes) )
        AddFile( t.get<0>(), t.get<1>() );
}

void SRSStatsCalculatorSettings::AddFiles(const SequenceFiles& files)
{
    for(const SequenceFile& group : files.files) {
        for(const Str::Path::Val& file : group.files) {
            AddFile(file.string(), group.filetype);
        }
    }
}

#pragma once

#include <cstdint>
#include <StringDef.h>

namespace BAM
{

class BAMTypes
{

public:
    typedef uint32_t ReferencePosition;
    typedef uint32_t ReferenceID;

    typedef uint64_t BamTold;

    typedef struct {
        Str::ID::Val name;
        size_t length;
    } ReferenceInfo;

public:
    const static ReferencePosition NOPOSITION=-1;
    const static ReferenceID NOREFERENCE=-1;
};

}

#pragma once
#include "CalcCommunication.h"
#include <PathDef.h>
#include "SAMWrapper.h"
#include "BAMFileResolver.h"
#include "LocalFileResolver.h"

namespace BAM
{

class STW_DLLPORT FileLoader
{

public:

    static FileResolver::Ptr LoadBAMFile(const communication::CalcCommunication& calc, const Str::Path::Val& inputFile);

    static FileResolver::Ptr LoadBAMFile(const communication::CalcCommunication& calc, const Str::Path::Val& inputFile, const Str::Path::Val& tempDir);

    FileLoader(): createPileFile_(true), createLevelFile_(true)
    {
    }

    FileLoader(bool createPileFile, bool createLevelFile): createPileFile_(createPileFile), createLevelFile_(createLevelFile)
    {
    }

    FileResolver::Ptr Load(const communication::CalcCommunication& calc, const Str::Path::Val& inputFile, BasicFileResolver::Ptr files);

    FileResolver::Ptr Load(const communication::CalcCommunication& calc, const Str::Path::Val& inputFile, const Str::Path::Val& tempDir);

private:

    static void ErrorCallback(const char* message, const communication::CalcCommunication* calc);

private:
    const bool createPileFile_;
    const bool createLevelFile_;
};

}

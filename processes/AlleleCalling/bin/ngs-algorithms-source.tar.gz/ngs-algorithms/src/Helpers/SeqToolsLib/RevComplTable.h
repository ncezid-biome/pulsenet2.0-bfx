#pragma once

#include "BoolHelper.h"


namespace seq
{

    
/**
    Singleton implementation, should remove that.
*/
class RevComplTable
{
public:
    typedef std::vector<char> Table;
private:
    static void Initialize(Table& table) 
    {
        table.resize(256, 'N'); 
        table['A'] = 'T';
        table['C'] = 'G';
        table['G'] = 'C';
        table['T'] = 'A';

        table['a'] = 't';
        table['c'] = 'g';
        table['g'] = 'c';
        table['t'] = 'a';
    }
    static Table& GetTable() {
        static Table table_;
        static Bool<false> initialized_;
        if (!initialized_) { Initialize(table_); initialized_=true; }
        return table_;
    }
private:
    RevComplTable() {}
public:
    static const Table& Get() { return GetTable(); }
};


} // namespace seq

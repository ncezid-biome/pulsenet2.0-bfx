#pragma once


#include "CalcCommunication.h"

#include "SRSStatsCalculatorSettings.h"


namespace engine
{

class ExecuteEnvironment;

} // namespace engine

class SeqBagInfo;

class StatsCalculator
{
public:
    StatsCalculator();
    ~StatsCalculator();

    void Calculate( const SRSStatsCalculatorSettings&       settings,
                    const engine::ExecuteEnvironment&       env,
                    const communication::CalcCommunication& comm ) const;

	void Calculate( const SRSStatsCalculatorSettings&       settings,
					SeqBagInfo& info,
                    const engine::ExecuteEnvironment&       env,
                    const communication::CalcCommunication& comm ) const;

	void Calculate( const SRSStatsCalculatorSettings&       settings,
					std::string& info, std::string& stats,
                    const engine::ExecuteEnvironment&       env,
                    const communication::CalcCommunication& comm ) const;

private:
    struct OpaquePointer;
    std::unique_ptr<OpaquePointer> d_;
};

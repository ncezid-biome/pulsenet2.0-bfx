#pragma once

#include "StringDef.h"


class AlleleName
{
public:
    static Str::Text::Val ExtractLocusName   (const Str::Text::Val& allelename);
    static size_t         ExtractAlleleNumber(const Str::Text::Val& allelename);
};

# README #

## What is this repository for? ##

This repository contains proprietary algorithms to process NGS data.
-> BLASTAlleleFinder
-> wgSNPAnalyzer

## How do I get set up? ##

### Setup local machine to compile the code ###

In order to compile and run the standalone executables on your local computer, you need a Linux distribution with gcc-4.8 installed.
On bioMérieux computers, enable WSL2, then install the "Ubuntu-18.04" distro (later distros no longer have the gcc-4.8 packages available).

`> wsl --install -d Ubuntu-18.04`

And don't forget to start WSL with this distro when you want to compile the code.

`> wsl -d Ubuntu-18.04`

You can run the `./build/build_local.sh` bash script to install all the required dependencies and launch the `./build/build_all.sh`.

The algorithms are installed in the folder `./targets/bin/algorithms`.

### CI/CD ###

The bitbucket pipeline contains an example to build the standalone executables that can be used in an NGS pipeline.
In the example, the executables are not published to some artifact store.

## Contribution guidelines ##

Branching/Commit/Pull request strategy follows gitflow guidelines, integrated with out JIRA issue tracking.

## Who do I talk to? ##

dolf.michielsen@biomerieux.com

Specific NGS/bio-informatics:
* joaoandre.carrico@biomerieux.com
* hannes.pouseele@biomerieux.com

Specific DEV/source code control:
* mahdi.aici@biomerieux.com
* vincent.orveillon@biomerieux.com

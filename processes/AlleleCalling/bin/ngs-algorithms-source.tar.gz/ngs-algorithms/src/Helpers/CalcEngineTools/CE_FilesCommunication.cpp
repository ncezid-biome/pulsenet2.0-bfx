#include "stdafx.h"

#include "CE_FilesCommunication.h"

#include "boost/thread/lock_guard.hpp"

#include "Checks.h"
#include "calclistenerImpl.h"
#include "CalcInfo.h"

#include "CE_CommunicationHandlers.h"
#include "CE_Logger.h"


#define LOCK boost::lock_guard<boost::mutex> lock( mutex_ );

namespace engine
{


FilesCommunication::FilesCommunication(Logger* logger)
    : logger_      ( logger )
    , mustContinue_( true )
    , listeners_   ()
{
    check::IsNotNull( logger_ );

    SetupListeners();
}

void FilesCommunication::TransferInfo(const communication::CalcInfo& info)
{
    listeners_.OnMessage( info.ToString() );
}

const volatile bool& FilesCommunication::MustContinue() const
{
    // Could implement canceling on this level but more general is just to
    // let the grid engine to the canceling.
    return mustContinue_;
}

bool FilesCommunication::CanUseInThread() const
{
    return true;
}

void FilesCommunication::SetupListeners()
{
    using namespace communication;

    listeners_.AddHandler(CalcInfoHandler::Ptr(new CalcMessageHandler([this](Str::Text::Arg m) {
        GetLogger()->SetProgressMessage( Str::Text::Val(m) );
    })));

    listeners_.AddHandler(CalcInfoHandler::Ptr(new CalcErrorHandler([this](Str::Text::Arg m) {
        GetLogger()->AddError( Str::Text::Val(m) );
    })));

    listeners_.AddHandler(CalcInfoHandler::Ptr(new CalcWarningHandler([this](Str::Text::Arg m) {
        GetLogger()->AddWarning( Str::Text::Val(m) );
    })));

    listeners_.AddHandler(CalcInfoHandler::Ptr(new CalcLinearProgressHandler([this](float frac) {
        GetLogger()->SetProgress( static_cast<int>(frac + 0.5) );
    })));

    listeners_.AddHandler(CalcInfoHandler::Ptr(new CalcCanceledHandler([this]() {
        LOCK
        mustContinue_ = false;
    })));

    listeners_.AddHandler(CalcInfoHandler::Ptr(new CalcEndedHandler([this]() {

    })));

    listeners_.AddHandler(CalcIncrMaxProgressHandler::Ptr(new CalcIncrMaxProgressHandler([this](int maxProg) {
        LOCK
        maxProgress_ = maxProg;
    })));

    listeners_.AddHandler(CalcIncrProgressHandler::Ptr(new CalcIncrProgressHandler([this]() {
        int progress = 0;
        {
            LOCK
            ++curProgress_;
            progress = static_cast<int>( 0.5 + curProgress_ / maxProgress_);
        }
        if( maxProgress_ != 0 )
            GetLogger()->SetProgress( progress );
    })));

    // Handlers for custom listeners

    listeners_.AddHandler(CalcCreateResultFileHandler::Ptr(
                              new CalcCreateResultFileHandler([this]( const Str::Text::Val& filename,
    const Str::Text::Val& content, const Str::ID::Val& compressionTypeId ) {
        GetLogger()->CreateResultFile( filename, content, compressionTypeId );
    })));

    listeners_.AddHandler(CalcAppendLogfileHandler::Ptr(
                              new CalcAppendLogfileHandler([this]( const Str::Text::Val& filename,
                                      const LogMessageType&    messageType,
    const Str::Text::Val& content) {
        GetLogger()->AppendLogFile( filename, messageType, content );
    })));

    listeners_.AddHandler(CalcAppendLogfileHandler::Ptr(
                              new CalcLogMessageHandler([this]( const LogMessageType&    messageType,
    const Str::Text::Val& content) {
        if ( GetLogger()->IsVerbose() )
            GetLogger()->AppendLogFile( GetLogger()->GetAllMessagesFilename(), messageType, content );
    })));

}


} // namespace engine

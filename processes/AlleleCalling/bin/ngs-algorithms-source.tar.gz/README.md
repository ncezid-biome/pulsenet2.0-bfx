# Introduction

This repository contains the Nextflow pipeline provided to the CDC.

[TOC]

If you need to do some modifications on this pipeline, please refer to the [CONTRIBUTING.md file](./CONTRIBUTING.md)

# Getting started

## Authenticate with AWS to pull images

When executing the pipeline, if you specify a docker registry to use, you'll need to be logged-in to be able to pull images.
To authenticate with AWS, run the following scripts : 

```bash
source .env
aws sso login --profile $PROFILE
aws ecr get-login-password --profile $PROFILE --region $AWS_REGION | docker login --username AWS --password-stdin "$REMOTE_DOCKER_REPO"
```

## Authenticate with AWS to use S3/Batch resources

If you need to execute the pipeline with the `cloud` profile, or access S3 buckets, you must have AWS credentials available for nextflow.

> Nextflow is not able to use SSO profiles, that's why we need to manually set the access / secret keys.

Go to the [AWS SSO Portal](https://biomerieux.awsapps.com/start/#/), select a profile and click on the `Command line or programmatic access` action.

Then, copy the Option 2 and paste it in the `~/.aws/credentials`, and modify the profile name to `default`

> You can use any other profile name, but then you'll have to set the environment variable AWS_PROFILE.


## Local execution

To run the pipeline, use this command :

`scripts/entrypoint.sh -a examples/scenario_3/accessions.csv -w work/ -o output/ -s true -p standard`

> Make sure you have downloaded the knowledge bases to `local/knowledge_bases` first.

> Don't forget to adapt the parameters according to your test (accessions or reads or reads file, stub, etc...).

> Except if you've build locally the needed processes, you need to specify an external docker registry (`-d`). You can use the $REMOTE_DOCKER_REPO from env files.

The following parameters are accepted

| Short Parameter | Long Parameter          | Description                                                        | Possible Values  | Required | Default |
| --------------- | ----------------------- | ------------------------------------------------------------------ | ---------------- | -------- | ------- |
| -p              | --profile               | Execution profile to use                                           | standard, cloud  | No       | cloud   |
| -c              | --custom_reads          | Custom reads to use                                                |                  | No       |         |
| -f              | --custom_reads_file     | File describing reads to use                                       | Local or S3 Path | No       |         |
| -a              | --accessions_file       | File describing accessions to use                                  | Local or S3 Path | No       |         |
| -i              | --input                 | File describing input to use                                       | Local or S3 Path | No       |         |
| -k              | --knowledge-base-folder | Folder where knowledge bases are located                           | Local or S3 path | No       |         |
| -d              | --docker_registry       | Docker registry to use to pull process images                      |                  | No       |         |
| -w              | --work_dir              | Location to store work dirs                                        | Local or S3 Path | Yes      |         |
| -o              | --output_dir            | Location to store                                                  | Local or S3 Path | Yes      |         |
| -s              | --stub                  | Use stub mode                                                      | True \| False    | No       |         |
| -u              | --use_sample_id         | Use sample_id as output folder name                                | True \| False    | No       |         |
| -r              | --run_directory         | Subfolder to use in output dir                                     |                  | No       |         |
| -q              | --aws_queue             | AWS Batch queue to use for process tasks                           |                  | No       |         |
|                 | --cache_dir             | Enable the long-term cache feature (using storeDir)                | Local or S3 Path | No       |         |
|                 | --write_nf_reports      | Enable the nextflow reports on pipeline execution                  | True \| False    | No       |         |
|                 | --resume_pipeline       | Pass the `resume` parameter to nextflow                            | True \| False    | No       |         |
|                 | --hash_on_filename      | Calculate the hashed_id only on filename, not on complete file URI | True \| False    | No       |         |
|                 | --config_file           | Alternative NF config file                                         | Local Path       | No       |         |



*Note :* You can also use directly the nextflow command :

`nextflow run main.nf --accessions_file examples/scenario_3/accessions.csv --output_dir output/ -work-dir work -stub`

This is not recommended as some consistency checks are done by the entrypoint script.
Please refer to the [pipeline parameter list](#parameters) to know which one you should set when using the nextflow command.

## Hybrid execution (local runner & cloud process)

> TODO : add authentication details so nextflow can create tasks on AWSBatch

If you want to launch the pipeline on your local environment and use a Cloud Environment to run the processes, simply remove the `-p` parameter in your command.
By default, the entrypoint.sh script will use the cloud profile, which will connect to your Cloud Infrastructure and setup all the computing ressources and populate tasks queues.

## Cloud execution

The entrypoint.sh script is the entrypoint of this Pipeline Docker image, so if you want to completely run the pipeline in a cloud environment, simply deploy this pipeline's Docker Image and run it with the according parameters.


## Cloud provider

The cloud profile is configured for AWS Batch, if you need to run using Azure Batch you need to modify `nextflow.config`, see the [official documentation](https://www.nextflow.io/docs/latest/azure.html#azure-batch) for an example configuration.  
`profiles/cloud/process/executor` in the configuration is currently set to `awsbatch`, that needs to be updated to `azurebatch`, the `queue` parameter can then be dropped (and its requirement with cloud profile in `entrypoint.sh` as well). You also need to configure `profiles/cloud/azure` with your own settings.


# Pipeline definition

## Parameters

In addition to the nextflow `run` command parameters, the following are used by the pipeline to adapt its operation.

| Parameter              | Description                                                                   | Possible Values  | Required | Default |
| ---------------------- | ----------------------------------------------------------------------------- | ---------------- | -------- | ------- |
| accessions_file        | File describing accessions to use                                             | Local or S3 Path | No       |         |
| custom_reads_file      | File describing reads to use                                                  | Local or S3 Path | No       |         |
| inputs                 | File describing the inputs of the pipeline (samples)                          | Local or S3 Path | No       |         |
| custom_reads           | Custom reads to use                                                           | String           | No       |         |
| knowledge_bases_folder | Knowledge bases folder                                                        | Local or S3 Path | No       |         |
| docker_registry        | Docker registry to use to pull process images                                 | String           | No       |         |
| work_dir               | Location to store work dirs                                                   | Local or S3 Path | Yes      |         |
| output_dir             | Location to store                                                             | Local or S3 Path | Yes      |         |
| stub                   | Use stub mode                                                                 | True \| False    | No       |         |
| use_sample_id          | Use sample_id as output folder name                                           | True \| False    | No       |         |
| run_directory          | Subfolder to use in output dir                                                | String           | No       |         |
| aws_queue              | AWS Batch queue to use for process tasks                                      | String           | No       | False   |
| cache_dir              | Enable the long-term cache feature (using storeDir)                           | Local or S3 Path | No       | False   |
| hash_on_filename       | Calculate the hashed_id only on filename, not on complete file URI            | True \| False    | No       | False   |
| force_bypass           | byPass all processes with an outputs.json file , without checking the version | True \| False    | No       | False   |
| disable_bypass         | No bypass, every processes will be ran, for every samples                     | True \| False    | No       | False   |


## Input files

To run the pipeline, you must provide either : 
- A CSV file containing a list of custom reads
- A CSV file containing a list of accession samples (NCBI)
- A JSON file containing a list of accession or read samples (cannot be a mix)

### Custom Reads file

The Custom Reads file must contain the following columns : 
- id
- label
- genus
- species
- read1_file_ref
- read2_file_ref

> The order of the columns is not important.

Alternatively, you can directly provide the custom reads attributes when launching the pipeline. You must separate each sample by `;` and each sample's attribute by `,` 

Example : 

```bash
scripts/entrypoint.sh -c "SRR24084271,SRR24084271,s3://dev-predictive-diagnostics-team/ngs-pipeline-integration-test/saas/input/fastq/CAMPYLOBACTER/SRR24084271_1.fastq.gz,s3://dev-predictive-diagnostics-team/ngs-pipeline-integration-test/saas/input/fastq/CAMPYLOBACTER/SRR24084271_2.fastq.gz,CAMPYLOBACTER,;SRR24084434,SRR24084434,s3://dev-predictive-diagnostics-team/ngs-pipeline-integration-test/saas/input/fastq/CRONOBACTER/SRR24084434_1.fastq.gz,s3://dev-predictive-diagnostics-team/ngs-pipeline-integration-test/saas/input/fastq/CRONOBACTER/SRR24084434_2.fastq.gz,CRONOBACTER,"
```

> In this case, the order of attributes **is** important

### Accession file

The Accession file must contains the following columns : 
- id
- accession_id
- genus
- species

> The order of the columns is not important.

### Inputs JSON file

The Input JSON file must contains the following structure : 
```json
{
    "samples": [
        {
            "id": "ERR2519466",
            "accessionId": "ERR2519466",
            "organism": {
                "genus": "LISTERIA",
                "species": "MONOCYTOGENES"
            },
            "processes": {
                "downloadReads": {
                    "previousExecution": {
                        "outputsJson": "filepath"
                    },
                    "publishDir": "",
                    "results": {}
                },
                ...
            }
        },
        ...
    ]
}
```

> Note : the outputsJson path can be a directory path. In this case, the pipeline will search for a default outputs.json file within this directory.

## Knowledge-bases
They are required by most processes and are a collection of inputs that are not expected to change much over time for a given process (and organism).  
Their structure is simple, it is a folder that contains an `info.json` file:
```json
{
    "meta": {
        "name": <name of the knowledge base>,
        "version": <version of the knowledge base>
    }
}
```
The `meta` field is mandatory.  
Additional fields such as relative paths to other files or values define the content of the knowledge base.

In `nextflow.config` the paths defined in the `knowledge_bases` section should be relative to the path passed as `knowledge_bases_folder` to the pipeline. They should be defined on a per-process basis. 

Some knowledge bases are tracked inside this repo, namely:
- qc (for all the processes that involve a quality control step)
- genome for `cleanup-reads`
- cleaning for `correct-assembly`
- scheme_mapping for `mlst`
- allele-filtering-SALMONELLA for `allele-filtering` with Salmonella  

Make sure that you update the `nextflow.config` file so that the provided paths are valid (the paths in the current configuration include a level for the version that is not present in repo).

The knowledge bases for `kraken`, `allele-calling`, `allele-naming` and `reference-mapping` are not _fully_ provided within this repo.
Although the required JSON files are provided, the databases themselves have been ommited due to their sizes, and must be downloaded from external sources, and then placed inside their respective directories.
Below you will find some information regarding the expected content for each of them.

**kraken**
```json
{
    "meta": {
        "name": "kraken",
        "version": "1.2.0"
    },
    "db": "kraken2_db",
    "organism_mapping": "organism_mapping.json"
}
```
The `kraken2_db` directory can be found here: 
- s3://ngs-pipeline.eu-west-1.224016688692/inputs/knowledge_bases/kraken/v1.2.0/kraken2_db/

**allele-calling** 
```json
{
    "meta": {
        "name": <name of the allele-calling knowledge base>,
        "version": <version of allele-calling the knowledge base>
    },
    "db": "blast_db",
    "loci": "loci.tsv",
    "similarity": <similarity percentage in [0.0, 100.0]>
}
```

with `loci.tsv`:
```tsv
ID	allele_type
<locus ID>	<core or accessory>
...
```
and `blast_db/`:  
The allele database, for a given organism, downloaded from BioNumerics CE. The database for _Mycobacterium tuberculosis_ can be found here:
- s3://ngs-pipeline.eu-west-1.224016688692/inputs/cdc/knowledge_bases/allele-calling-MYCOBACTERIUM/v1.0.0/blast_db/

**allele-naming**
```json
{
    "meta": {
        "name": <name of the allele-naming knowledge base>,
        "version": <version of allele-naming the knowledge base>
    },
    "cache": "cache"
}
```

with `cache/` a folder that contains:
- `acceptedalleles_0.fasta.gz` the fasta files containing the already submitted accepted alleleles
- `acceptedalleles_1.fasta.gz` (optionally, if `acceptedalleles_link` is set to `1`)
- `acceptedalleles_link`: a simple text file containing either `0` or `1`

**reference-mapping**
```json
{
    "meta": {
        "name": "reference-genome-MYCOBACTERIUM",
        "version": "1.0.0"
    },
    "reference": "NC_000962.fasta.gz",
    "ambiguity_thresholds": "ambiguity_thresholds.json"
}
```
The reference genome for _Mycobacterium tuberculosis_ can be found here: 
- s3://ngs-pipeline.eu-west-1.224016688692/inputs/cdc/knowledge_bases/reference-mapping-MYCOBACTERIUM/NC_000962.fasta.gz


## Subworkflows

### wGetAndClassifyReads

Depending on the input parameters, this workflow will have a different first step : 
- If accessions are specified : Download the reads files from NCBI to S3
- If reads are specified : Extract the S3 URI of reads file from custom read parameter or custom reads file

Then, it runs the classification process to determine the genus & species of each sample.

**Result channels** 
- `classifiedReads` : list of sample_id with their reads file, filtered on QC result (FAIL are excluded)
- `classifiedOrganisms` : list of sample_id with their determined organism

### wCleanupReads

**Input channels**
- `reads` : list of sample_id with their reads files
- `organism` : list of sample_id with their organism (user-specified or determined)

This workflow call the Cleanup process on each sample_id with their reads and organism

**Result channels** 
- `cleanedReads` : list of sample_id with their reads file, filtered on QC result (FAIL are excluded)


### wGetAssembly

**Input channels**
- `reads` : list of sample_id with their reads files

This workflow call the Generate Assembly process on each sample_id with their reads

**Result channels** 
- `assembly` : list of sample_id with their assembly file

### wCorrectAssembly

**Input channels**
- `reads` : list of sample_id with their reads files
- `assembly` : list of sample_id with their assembly file
- `organism` : list of sample_id with their organism (user-specified or determined)

This workflow calls the Correct Assembly process on each sample_id with their reads, assembly and organism

**Result channels** 
- `correctedAssembly` : list of sample_id with their corrected assembly file, filtered on QC result (FAIL are excluded)
- `correctedAlignment` : list of sample_id with their alignment file, filtered on QC result (FAIL are excluded)

### wAlleleCalling

**Input channels**
- `assembly` : list of sample_id with their assembly file
- `organism` : list of sample_id with their organism (user-specified or determined)

This workflow calls the Allele Calling process on each sample_id with their assembly and organism

**Result channels** 
Nothing (every data is published into files.)

### wAnalyzeCorrectedAssembly

**Input channels**
- `assembly` : list of sample_id with their assembly file
- `organism` : list of sample_id with their organism (user-specified or determined)

This workflow calls the FindGenes & Mlst processes on each sample_id with their assembly and organism

**Result channels** 
Nothing (every data is published into files.)


## Profiles

Standard

The processes are launched on the runner's computer 

cloud (default)

The processes are launched on AWS Batch infrastructure, using the region & queue defined in `nextflow.config`

# License 

Shield: [![CC BY-NC-SA 4.0][cc-by-nc-sa-shield]][cc-by-nc-sa]

This work is licensed under a
[Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License][cc-by-nc-sa].

[![CC BY-NC-SA 4.0][cc-by-nc-sa-image]][cc-by-nc-sa]

[cc-by-nc-sa]: http://creativecommons.org/licenses/by-nc-sa/4.0/
[cc-by-nc-sa-image]: https://licensebuttons.net/l/by-nc-sa/4.0/88x31.png
[cc-by-nc-sa-shield]: https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-lightgrey.svg

&copy; 2023-2025 bioMérieux - all right reserved

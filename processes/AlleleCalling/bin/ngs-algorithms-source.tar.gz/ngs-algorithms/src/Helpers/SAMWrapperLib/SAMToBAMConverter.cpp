#include "stdafx.h"
#include <exception.h>
#include <translate.h>
#include <SAMToolsLib.h>
#include "SAMToBAMConverter.h"

#ifdef AMGNU

#include "helper.h"

#define _TRY_ try
#define _CATCH_(c, b)                   \
    catch(KError &k) {                  \
        int code;                       \
        Parse<int>(k.geterror(), code); \
        if(code==(c)) {                 \
            b;                          \
        }                               \
    }
#else
#define _TRY_ __try
#define _CATCH_(c, b)                   \
    __except(GetExceptionCode()==(c)) { \
        b;                              \
    }
#endif

bool BAM::SAMToBAMConverter::CopyReads(samfile_t* samInput, samfile_t* bamOutput)
{
    bam1_t* b=stl_bam_init1();

    _TRY_ {

        int r;

        while((r=samread(samInput, b))>= 0) {
            samwrite(bamOutput, b);
        }
    }
    _CATCH_(EXIT_EXCEPTION, {

        //samread called exit()... invalid SAM file

        stl_bam_destroy1(b);
        return false;
    })

    stl_bam_destroy1(b);
    return true;
}

void BAM::SAMToBAMConverter::ConvertFile(const Str::Path::Val& input, const Str::Path::Val& output)
{
    samfile_t* samInput=samopen(ToRef(input), "r", nullptr);
    if(samInput==nullptr) {
        throw KError("Could not open SAM-file %1") << input;
    }

    if(samInput->header==nullptr) {

        samclose(samInput);
        throw KError("Could not read the header of SAM-file %1") << input;
    }

    samfile_t* bamOutput=samopen(ToRef(output), "wb", samInput->header);
    if(bamOutput==nullptr) {

        samclose(samInput);
        throw KError("Could not open output BAM-file %1") << input;
    }

    //if we put the body of CopyReads here, the compiler errors:
    //error C2712: Cannot use __try in functions that require object unwinding
    bool copied=CopyReads(samInput, bamOutput);

    samclose(bamOutput);
    samclose(samInput);

    if(!copied) {

        throw KError("File %1 is not a valid SAM-file") << input;
    }
}


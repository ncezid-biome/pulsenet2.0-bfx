#pragma once


/**
    Allow specifying the boundaries of the frame in a verbose way, i.e. without
    doing +3 or -3 by hand.
*/
enum class FrameRange
{
    All,            //!< The entire sequence
    EndExcluded,    //!< The sequence excluding the last amino-acid (3 bases)
    StartExcluded,  //!< The sequence excluding the first amino-acid
    Internal        //!< The sequence excluding the first and last amino-acids
};

#include "stdafx.h"
#include "seqbagstats_info.h"
#include "seqbagstats_general.h"
#include "helper.h"
#include "xmlwrapper.h"

SeqBagInfo::SeqBagInfo()
	: nseqs_(0), nPaired_(0)
	, len_min_(0), len_max_(0), len_avg_(0), len_stdev_(0)
	, qual_min_(0), qual_max_(0), qual_avg_(0), qual_stdev_(0), hasQual_(false)
	, len_min_1_(0), len_max_1_(0), len_avg_1_(0), len_stdev_1_(0)
	, qual_min_1_(0), qual_max_1_(0), qual_avg_1_(0), qual_stdev_1_(0)
	, len_min_2_(0), len_max_2_(0), len_avg_2_(0), len_stdev_2_(0)
	, qual_min_2_(0), qual_max_2_(0), qual_avg_2_(0), qual_stdev_2_(0)
	, nA_(0), nC_(0), nG_(0), nT_(0), nN_(0), qScores_(SeqBagGeneralStats::QRANGE, 0), qScores1_(SeqBagGeneralStats::QRANGE, 0), qScores2_(SeqBagGeneralStats::QRANGE, 0)
{
}

SeqBagInfo::~SeqBagInfo()
{
}

void SeqBagInfo::Reset()
{
	nseqs_=0;
	nPaired_=0;
	len_min_=0;
	len_max_=0;
	len_avg_=0;
	len_stdev_=0;
	len_min_1_=0;
	len_max_1_=0;
	len_avg_1_=0;
	len_stdev_1_=0;
	len_min_2_=0;
	len_max_2_=0;
	len_avg_2_=0;
	len_stdev_2_=0;
	qual_min_=0;
	qual_max_=0;
	qual_avg_=0;
	qual_stdev_=0;
	qual_min_1_=0;
	qual_max_1_=0;
	qual_avg_1_=0;
	qual_stdev_1_=0;
	qual_min_2_=0;
	qual_max_2_=0;
	qual_avg_2_=0;
	qual_stdev_2_=0;
	nA_=0;
	nC_=0; 
	nG_=0; 
	nT_=0; 
	nN_=0;
	qScores_.resize(SeqBagGeneralStats::QRANGE, 0);
	qScores1_.resize(SeqBagGeneralStats::QRANGE, 0);
	qScores2_.resize(SeqBagGeneralStats::QRANGE, 0);
	hasQual_=false;
}

void SeqBagInfo::SetInfo(
	size_t nseqs, size_t nPaired, 
		double len_avg, double len_stdev, double len_min, double len_max, 
		double len_avg1, double len_stdev1, double len_min1, double len_max1,
		double len_avg2, double len_stdev2, double len_min2, double len_max2,
		double qual_avg, double qual_stdev, double qual_min, double qual_max, 
		double qual_avg1, double qual_stdev1, double qual_min1, double qual_max1,
		double qual_avg2, double qual_stdev2, double qual_min2, double qual_max2,
		size_t nA, size_t nC, size_t nG, size_t nT, size_t nN, 
		const SeqBagGeneralStats::CountVector& qScores,const SeqBagGeneralStats::CountVector& qScores1,const SeqBagGeneralStats::CountVector& qScores2)
{
	nseqs_=nseqs-nPaired; //paired-end sequences are being counted twice
	nPaired_=nPaired;
	len_min_=len_min; len_max_=len_max; len_avg_=len_avg; len_stdev_=len_stdev;
	if (len_min_>len_max_) { len_max_=0; len_min_=0; }
	qual_min_=qual_min; qual_max_=qual_max; qual_avg_=qual_avg; qual_stdev_=qual_stdev;
	if (qual_min_>qual_max_) { qual_min_=0; qual_max_=0; hasQual_=false; } else hasQual_=true;
	
	len_min_1_=len_min1; len_max_1_=len_max1; len_avg_1_=len_avg1; len_stdev_1_=len_stdev1;
	if (len_min_1_>len_max_1_) { len_max_1_=0; len_min_1_=0; }
	qual_min_1_=qual_min1; qual_max_1_=qual_max1; qual_avg_1_=qual_avg1; qual_stdev_1_=qual_stdev1;
	if (qual_min_1_>qual_max_1_) { qual_min_1_=0; qual_max_1_=0; }

	len_min_2_=len_min2; len_max_2_=len_max2; len_avg_2_=len_avg2; len_stdev_2_=len_stdev2;
	if (len_min_2_>len_max_2_) { len_max_2_=0; len_min_2_=0; }
	qual_min_2_=qual_min2; qual_max_2_=qual_max2; qual_avg_2_=qual_avg2; qual_stdev_2_=qual_stdev2;
	if (qual_min_2_>qual_max_2_) { qual_min_2_=0; qual_max_2_=0; }

	nA_=nA;
	nC_=nC;
	nG_=nG;
	nT_=nT;
	nN_=nN;
	qScores_= qScores;
	qScores1_= qScores1;
	qScores2_= qScores2;
}

void SeqBagInfo::fromCounts(const SeqBagGeneralStats& counts)
{
	SetInfo(
		counts.getNSeqs()+counts.getNPaired(), counts.getNPaired(),
		counts.getTotLen().GetAvg(), counts.getTotLen().GetStdDev(), counts.getTotLen().GetMin(), counts.getTotLen().GetMax(),
		counts.getLen1().GetAvg(), counts.getLen1().GetStdDev(), counts.getLen1().GetMin(), counts.getLen1().GetMax(),
		counts.getLen2().GetAvg(), counts.getLen2().GetStdDev(), counts.getLen2().GetMin(), counts.getLen2().GetMax(),
		counts.getTotQual().GetAvg(), counts.getTotQual().GetStdDev(),counts.getTotQual().GetMin(), counts.getTotQual().GetMax(), 
		counts.getQual1().GetAvg(), counts.getQual1().GetStdDev(), counts.getQual1().GetMin(), counts.getQual1().GetMax(), 
		counts.getQual2().GetAvg(), counts.getQual2().GetStdDev(), counts.getQual2().GetMin(), counts.getQual2().GetMax(), 
		counts.getTotBase(0), counts.getTotBase(1), counts.getTotBase(2), counts.getTotBase(3), counts.getTotBase(4),
		counts.getTotQCounts(), counts.getQCounts1(), counts.getQCounts2());
}


size_t SeqBagInfo::GetNSeqs() const
{
	return nseqs_;
}

size_t SeqBagInfo::GetNPaired() const
{
	return nPaired_;
}

double SeqBagInfo::GetAvgLen() const
{
	return len_avg_;
}

__int64 SeqBagInfo::GetTotLen() const
{
	return ncast<__int64>(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));
}

int SeqBagInfo::GetMinLen() const
{
	return ncast<int>(len_min_);
}

int SeqBagInfo::GetMaxLen() const
{
	return ncast<int>(len_max_);
}

double SeqBagInfo::GetStDevLen() const
{
	return len_stdev_;
}

double SeqBagInfo::GetAvgLenLeft() const
{
	return len_avg_1_;
}

__int64 SeqBagInfo::GetTotLenLeft() const
{
	return ncast<__int64>(len_avg_1_ * ((nseqs_-nPaired_) + nPaired_));
}

int SeqBagInfo::GetMinLenLeft() const
{
	return ncast<int>(len_min_1_);
}

int SeqBagInfo::GetMaxLenLeft() const
{
	return ncast<int>(len_max_1_);
}

double SeqBagInfo::GetStDevLenLeft() const
{
	return len_stdev_1_;
}

double SeqBagInfo::GetAvgLenRight() const
{
	return len_avg_2_;
}

__int64 SeqBagInfo::GetTotLenRight() const
{
	return ncast<__int64>(len_avg_2_ * (nPaired_));
}

int SeqBagInfo::GetMinLenRight() const
{
	return ncast<int>(len_min_2_);
}

int SeqBagInfo::GetMaxLenRight() const
{
	return ncast<int>(len_max_2_);
}

double SeqBagInfo::GetStDevLenRight() const
{
	return len_stdev_2_;
}


bool SeqBagInfo::HasQual() const
{
	return hasQual_;
}

double SeqBagInfo::GetAvgQual() const
{
	return qual_avg_;
}

double SeqBagInfo::GetStDevQual() const
{
	return qual_stdev_;
}

int SeqBagInfo::GetMinQual() const
{
	return ncast<int>(qual_min_);
}

int SeqBagInfo::GetMaxQual() const
{
	return ncast<int>(qual_max_);
}

double SeqBagInfo::GetAvgQualLeft() const
{
	return qual_avg_1_;
}

double SeqBagInfo::GetStDevQualLeft() const
{
	return qual_stdev_1_;
}

int SeqBagInfo::GetMinQualLeft() const
{
	return ncast<int>(qual_min_1_);
}

int SeqBagInfo::GetMaxQualLeft() const
{
	return ncast<int>(qual_max_1_);
}

double SeqBagInfo::GetAvgQualRight() const
{
	return qual_avg_2_;
}

double SeqBagInfo::GetStDevQualRight() const
{
	return qual_stdev_2_;
}

int SeqBagInfo::GetMinQualRight() const
{
	return ncast<int>(qual_min_2_);
}

int SeqBagInfo::GetMaxQualRight() const
{
	return ncast<int>(qual_max_2_);
}

size_t SeqBagInfo::GetNA() const
{
	return nA_;
}
size_t SeqBagInfo::GetNC() const
{
	return nC_;
}
size_t SeqBagInfo::GetNG() const
{
	return nG_;
}
size_t SeqBagInfo::GetNT() const
{
	return nT_;
}
size_t SeqBagInfo::GetNN() const
{
	return nN_;
}
double SeqBagInfo::GetPercentA() const
{
	
	return (100.0*nA_)/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));	
}
double SeqBagInfo::GetPercentC() const
{
	return (100.0*nC_)/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));	
}
double SeqBagInfo::GetPercentG() const
{
	return (100.0*nG_)/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));	
}
double SeqBagInfo::GetPercentT() const
{
	return (100.0*nT_)/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));	
}
double SeqBagInfo::GetPercentN() const
{
	return (100.0*nN_)/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));	
}
size_t SeqBagInfo::GetNGC() const 
{
	return nG_+nC_;
}
double SeqBagInfo::GetPercentGC() const
{
	return (100.0*(nG_+nC_))/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));	
}
size_t  SeqBagInfo::GetQ20() const
{
	return qScores_.size()>20 ? qScores_[20] : 0;
}
size_t  SeqBagInfo::GetQ25() const
{
	return qScores_.size()>25 ? qScores_[25] : 0;
}
size_t  SeqBagInfo::GetQ30() const
{
	return qScores_.size()>30 ? qScores_[30] : 0;
}
size_t  SeqBagInfo::GetQ20Left() const
{
	return qScores1_.size()>20 ? qScores1_[20] : 0;
}
size_t  SeqBagInfo::GetQ25Left() const
{
	return qScores1_.size()>25 ? qScores1_[25] : 0;
}
size_t  SeqBagInfo::GetQ30Left() const
{
	return qScores1_.size()>30 ? qScores1_[30] : 0;
}
size_t  SeqBagInfo::GetQ20Right() const
{
	return qScores2_.size()>20 ? qScores2_[20] : 0;
}
size_t  SeqBagInfo::GetQ25Right() const
{
	return qScores2_.size()>25 ? qScores2_[25] : 0;
}
size_t  SeqBagInfo::GetQ30Right() const
{
	return qScores2_.size()>30 ? qScores2_[30] : 0;
}
double SeqBagInfo::GetPercentQ20() const
{
	return (100.0*GetQ20())/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));
}
double SeqBagInfo::GetPercentQ25() const
{
	return (100.0*GetQ25())/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));
}
double SeqBagInfo::GetPercentQ30() const
{
	return (100.0*GetQ30())/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));
}
double SeqBagInfo::GetPercentQ20Left() const
{
	return (100.0*GetQ20Left())/(len_avg_1_ * ((nseqs_-nPaired_) + nPaired_));
}
double SeqBagInfo::GetPercentQ25Left() const
{
	return (100.0*GetQ25Left())/(len_avg_1_ * ((nseqs_-nPaired_) + nPaired_));
}
double SeqBagInfo::GetPercentQ30Left() const
{
	return (100.0*GetQ30Left())/(len_avg_1_ * ((nseqs_-nPaired_) + nPaired_));
}
double SeqBagInfo::GetPercentQ20Right() const
{
	if ((len_avg_2_ * (nPaired_))>0)
		return (100.0*GetQ20Right())/(len_avg_2_ * (nPaired_));
	else
		return 0;
}
double SeqBagInfo::GetPercentQ25Right() const
{
	if ((len_avg_2_ * (nPaired_))>0)
		return (100.0*GetQ25Right())/(len_avg_2_ * (nPaired_));
	else
		return 0;
}
double SeqBagInfo::GetPercentQ30Right() const
{
	if ((len_avg_2_ * (nPaired_))>0)
		return (100.0*GetQ30Right())/(len_avg_2_ * (nPaired_));
	else
		return 0;
}
void SeqBagInfo::Load(Str::Xml::Arg xml)
{

	if (xml.str().empty()) {
		nseqs_=0;
		return;
	}

	XmlBlock b("seqbag_info");
	b.FromStr(xml);
	
	b.FromXml(PM("nseqs"), nseqs_);
	b.FromXml(PM("npaired"), nPaired_);
	  
	b.FromXml(PM("len_avg"), len_avg_);
	b.FromXml(PM("len_stdev"), len_stdev_);
	b.FromXml(PM("len_min"), len_min_);
	b.FromXml(PM("len_max"), len_max_);

	b.FromXml(PM("qual_avg"), qual_avg_);
	b.FromXml(PM("qual_stdev"), qual_stdev_);
	b.FromXml(PM("qual_min"), qual_min_);
	b.FromXml(PM("qual_max"), qual_max_);

	b.FromXml(PM("qual_present"), hasQual_);

	if (b.HasChild(PM("nA"))) b.FromXml(PM("nA"), nA_);
	if (b.HasChild(PM("nC"))) b.FromXml(PM("nC"), nC_);
	if (b.HasChild(PM("nG"))) b.FromXml(PM("nG"), nG_);
	if (b.HasChild(PM("nT"))) b.FromXml(PM("nT"), nT_);
	if (b.HasChild(PM("nN"))) b.FromXml(PM("nN"), nN_);

	if (b.HasChild(PM("qScores"))) b.FromXml(PM("qScores"), qScores_);
	if (b.HasChild(PM("qScores1"))) b.FromXml(PM("qScores1"), qScores1_);
	if (b.HasChild(PM("qScores2"))) b.FromXml(PM("qScores2"), qScores2_);

	if (b.HasChild(PM("len_avg1"))) b.FromXml(PM("len_avg1"), len_avg_1_);
	if (b.HasChild(PM("len_stdev1"))) b.FromXml(PM("len_stdev1"), len_stdev_1_);
	if (b.HasChild(PM("len_min1"))) b.FromXml(PM("len_min1"), len_min_1_);
	if (b.HasChild(PM("len_max1"))) b.FromXml(PM("len_max1"), len_max_1_);

	if (b.HasChild(PM("qual_avg1"))) b.FromXml(PM("qual_avg1"), qual_avg_1_);
	if (b.HasChild(PM("qual_stdev1"))) b.FromXml(PM("qual_stdev1"), qual_stdev_1_);
	if (b.HasChild(PM("qual_min1"))) b.FromXml(PM("qual_min1"), qual_min_1_);
	if (b.HasChild(PM("qual_max1"))) b.FromXml(PM("qual_max1"), qual_max_1_);

	
	if (b.HasChild(PM("len_avg2"))) b.FromXml(PM("len_avg2"), len_avg_2_);
	if (b.HasChild(PM("len_stdev2"))) b.FromXml(PM("len_stdev2"), len_stdev_2_);
	if (b.HasChild(PM("len_min2"))) b.FromXml(PM("len_min2"), len_min_2_);
	if (b.HasChild(PM("len_max2"))) b.FromXml(PM("len_max2"), len_max_2_);

	if (b.HasChild(PM("qual_avg2"))) b.FromXml(PM("qual_avg2"), qual_avg_2_);
	if (b.HasChild(PM("qual_stdev2"))) b.FromXml(PM("qual_stdev2"), qual_stdev_2_);
	if (b.HasChild(PM("qual_min2"))) b.FromXml(PM("qual_min2"), qual_min_2_);
	if (b.HasChild(PM("qual_max2"))) b.FromXml(PM("qual_max2"), qual_max_2_);
}

void SeqBagInfo::Save(Str::Xml::Val& xml) const
{
	XmlBlock b("seqbag_info");	
	
	b.ToXml(PM("nseqs"), nseqs_);
	b.ToXml(PM("npaired"), nPaired_);
	
	b.ToXml(PM("len_avg"), len_avg_);
	b.ToXml(PM("len_stdev"), len_stdev_);
	b.ToXml(PM("len_min"), len_min_);
	b.ToXml(PM("len_max"), len_max_);
	
	b.ToXml(PM("qual_avg"), qual_avg_);
	b.ToXml(PM("qual_stdev"), qual_stdev_);
	b.ToXml(PM("qual_min"), qual_min_);
	b.ToXml(PM("qual_max"), qual_max_);

	b.ToXml(PM("qual_present"), hasQual_);

	b.ToXml(PM("nA"), nA_);
	b.ToXml(PM("nC"), nC_);
	b.ToXml(PM("nG"), nG_);
	b.ToXml(PM("nT"), nT_);
	b.ToXml(PM("nN"), nN_);

	b.ToXml(PM("qScores"), qScores_);
	b.ToXml(PM("qScores1"), qScores1_);
	b.ToXml(PM("qScores2"), qScores2_);	

	b.ToXml(PM("len_avg1"), len_avg_1_);
	b.ToXml(PM("len_stdev1"), len_stdev_1_);
	b.ToXml(PM("len_min1"), len_min_1_);
	b.ToXml(PM("len_max1"), len_max_1_);
	
	b.ToXml(PM("qual_avg1"), qual_avg_1_);
	b.ToXml(PM("qual_stdev1"), qual_stdev_1_);
	b.ToXml(PM("qual_min1"), qual_min_1_);
	b.ToXml(PM("qual_max1"), qual_max_1_);

	
	b.ToXml(PM("len_avg2"), len_avg_2_);
	b.ToXml(PM("len_stdev2"), len_stdev_2_);
	b.ToXml(PM("len_min2"), len_min_2_);
	b.ToXml(PM("len_max2"), len_max_2_);
	
	b.ToXml(PM("qual_avg2"), qual_avg_2_);
	b.ToXml(PM("qual_stdev2"), qual_stdev_2_);
	b.ToXml(PM("qual_min2"), qual_min_2_);
	b.ToXml(PM("qual_max2"), qual_max_2_);

	xml.clear();
	b.ToStr(xml);
}

//
//SeqBagInfo::SeqBagInfo()
//	: nseqs_(0), nPaired_(0)
//	, len_min_(0), len_max_(0), len_avg_(0), len_stdev_(0)
//	, qual_min_(0), qual_max_(0), qual_avg_(0), qual_stdev_(0), hasQual_(false)
//	, nA_(0), nC_(0), nG_(0), nT_(0), nN_(0)
//	, q20_(0), q25_(0), q30_(0) 
//{
//}
//
//SeqBagInfo::~SeqBagInfo()
//{
//}
//
//void SeqBagInfo::Reset()
//{
//	nseqs_=0;
//	nPaired_=0;
//	len_min_=0;
//	len_max_=0;
//	len_avg_=0;
//	len_stdev_=0;
//	qual_min_=0;
//	qual_max_=0;
//	qual_avg_=0;
//	qual_stdev_=0;
//	nA_=0;
//	nC_=0; 
//	nG_=0; 
//	nT_=0; 
//	nN_=0;
//	q20_=0;
//	q25_=0;
//	q30_=0;
//	hasQual_=false;
//}
//void SeqBagInfo::fromCounts(const SeqBagGeneralStats& counts)
//{
//	nseqs_=counts.getNSeqs();
//	nPaired_=counts.getNPaired();
//	
//	len_min_=counts.getTotLen().GetMin(); 
//	len_max_=counts.getTotLen().GetMax();
//	len_avg_=counts.getTotLen().GetAvg(); 
//	len_stdev_=counts.getTotLen().GetStdDev(); 
//	if (len_min_>len_max_) { len_max_=0; len_min_=0; }
//
//	qual_min_=counts.getTotQual().GetMin();
//	qual_max_=counts.getTotQual().GetMax();
//	qual_avg_=counts.getTotQual().GetAvg();
//	qual_stdev_=counts.getTotQual().GetStdDev();
//	if (qual_min_>qual_max_) { qual_min_=0; qual_max_=0; hasQual_=false; } else hasQual_=true;
//	
//	nA_=counts.getTotBase(0);
//	nC_=counts.getTotBase(1);
//	nG_=counts.getTotBase(2);
//	nT_=counts.getTotBase(3);
//	nN_=counts.getTotBase(4);
//
//	q20_=counts.getQCounts(0);
//	q25_=counts.getQCounts(1);
//	q30_=counts.getQCounts(2);
//}
//void SeqBagInfo::SetInfo(size_t nseqs, size_t nPaired, double len_avg, double len_stdev, double len_min, double len_max, double qual_avg, double qual_stdev, double qual_min, double qual_max, size_t nA, size_t nC, size_t nG, size_t nT, size_t nN, size_t q20, size_t q25, size_t q30)
//{
//	nseqs_=nseqs-nPaired; //paired-end sequences are being counted twice
//	nPaired_=nPaired;
//	len_min_=len_min; len_max_=len_max; len_avg_=len_avg; len_stdev_=len_stdev;
//	if (len_min_>len_max_) { len_max_=0; len_min_=0; }
//	qual_min_=qual_min; qual_max_=qual_max; qual_avg_=qual_avg; qual_stdev_=qual_stdev;
//	if (qual_min_>qual_max_) { qual_min_=0; qual_max_=0; hasQual_=false; } else hasQual_=true;
//	nA_=nA;
//	nC_=nC;
//	nG_=nG;
//	nT_=nT;
//	nN_=nN;
//	q20_=q20;
//	q25_=q25;
//	q30_=q30;
//}
//
//size_t SeqBagInfo::GetNSeqs() const
//{
//	return nseqs_;
//}
//
//size_t SeqBagInfo::GetNPaired() const
//{
//	return nPaired_;
//}
//
//double SeqBagInfo::GetAvgLen() const
//{
//	return len_avg_;
//}
//
//int SeqBagInfo::GetTotLen() const
//{
//	return ncast<int>(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));
//}
//
//int SeqBagInfo::GetMinLen() const
//{
//	return ncast<int>(len_min_);
//}
//
//int SeqBagInfo::GetMaxLen() const
//{
//	return ncast<int>(len_max_);
//}
//
//double SeqBagInfo::GetStDevLen() const
//{
//	return len_stdev_;
//}
//
//bool SeqBagInfo::HasQual() const
//{
//	return hasQual_;
//}
//
//double SeqBagInfo::GetAvgQual() const
//{
//	return qual_avg_;
//}
//
//double SeqBagInfo::GetStDevQual() const
//{
//	return qual_stdev_;
//}
//
//int SeqBagInfo::GetMinQual() const
//{
//	return ncast<int>(qual_min_);
//}
//
//int SeqBagInfo::GetMaxQual() const
//{
//	return ncast<int>(qual_max_);
//}
//size_t SeqBagInfo::GetNA() const
//{
//	return nA_;
//}
//size_t SeqBagInfo::GetNC() const
//{
//	return nC_;
//}
//size_t SeqBagInfo::GetNG() const
//{
//	return nG_;
//}
//size_t SeqBagInfo::GetNT() const
//{
//	return nT_;
//}
//size_t SeqBagInfo::GetNN() const
//{
//	return nN_;
//}
//double SeqBagInfo::GetPercentA() const
//{
//	
//	return (100.0*nA_)/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));	
//}
//double SeqBagInfo::GetPercentC() const
//{
//	return (100.0*nC_)/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));	
//}
//double SeqBagInfo::GetPercentG() const
//{
//	return (100.0*nG_)/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));	
//}
//double SeqBagInfo::GetPercentT() const
//{
//	return (100.0*nT_)/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));	
//}
//double SeqBagInfo::GetPercentN() const
//{
//	return (100.0*nN_)/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));	
//}
//size_t SeqBagInfo::GetNGC() const 
//{
//	return nG_+nC_;
//}
//double SeqBagInfo::GetPercentGC() const
//{
//	return (100.0*(nG_+nC_))/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));	
//}
//size_t  SeqBagInfo::GetQ20() const
//{
//	return q20_;
//}
//size_t  SeqBagInfo::GetQ25() const
//{
//	return q25_;
//}
//size_t  SeqBagInfo::GetQ30() const
//{
//	return q30_;
//}
//double SeqBagInfo::GetPercentQ20() const
//{
//	return (100.0*q20_)/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));
//}
//double SeqBagInfo::GetPercentQ25() const
//{
//	return (100.0*q25_)/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));
//}
//double SeqBagInfo::GetPercentQ30() const
//{
//	return (100.0*q30_)/(len_avg_ * ((nseqs_-nPaired_) + 2.0*nPaired_));
//}
//void SeqBagInfo::Load(const Str::Xml::Val& string)
//{
//	if (string.size()==0) {
//		nseqs_=0;
//		return;
//	}
//
//	XmlBlock b("seqbag_info");
//	b.FromStr(string);
//	
//	b.FromXml(PM("nseqs"), nseqs_);
//	b.FromXml(PM("npaired"), nPaired_);
//	  
//	b.FromXml(PM("len_avg"), len_avg_);
//	b.FromXml(PM("len_stdev"), len_stdev_);
//	b.FromXml(PM("len_min"), len_min_);
//	b.FromXml(PM("len_max"), len_max_);
//
//	b.FromXml(PM("qual_avg"), qual_avg_);
//	b.FromXml(PM("qual_stdev"), qual_stdev_);
//	b.FromXml(PM("qual_min"), qual_min_);
//	b.FromXml(PM("qual_max"), qual_max_);
//
//	b.FromXml(PM("qual_present"), hasQual_);
//
//	if (b.HasChild(PM("nA"))) b.FromXml(PM("nA"), nA_);
//	if (b.HasChild(PM("nC"))) b.FromXml(PM("nC"), nC_);
//	if (b.HasChild(PM("nG"))) b.FromXml(PM("nG"), nG_);
//	if (b.HasChild(PM("nT"))) b.FromXml(PM("nT"), nT_);
//	if (b.HasChild(PM("nN"))) b.FromXml(PM("nN"), nN_);
//
//	if (b.HasChild(PM("q20"))) b.FromXml(PM("q20"), q20_);
//	if (b.HasChild(PM("q25"))) b.FromXml(PM("q25"), q25_);
//	if (b.HasChild(PM("q30"))) b.FromXml(PM("q30"), q30_);
//}
//
//void SeqBagInfo::Save(Str::Xml::Val& string) const
//{
//	XmlBlock b("seqbag_info");	
//	
//	b.ToXml(PM("nseqs"), nseqs_);
//	b.ToXml(PM("npaired"), nPaired_);
//	
//	b.ToXml(PM("len_avg"), len_avg_);
//	b.ToXml(PM("len_stdev"), len_stdev_);
//	b.ToXml(PM("len_min"), len_min_);
//	b.ToXml(PM("len_max"), len_max_);
//	
//	b.ToXml(PM("qual_avg"), qual_avg_);
//	b.ToXml(PM("qual_stdev"), qual_stdev_);
//	b.ToXml(PM("qual_min"), qual_min_);
//	b.ToXml(PM("qual_max"), qual_max_);
//
//	b.ToXml(PM("qual_present"), hasQual_);
//
//	b.ToXml(PM("nA"), nA_);
//	b.ToXml(PM("nC"), nC_);
//	b.ToXml(PM("nG"), nG_);
//	b.ToXml(PM("nT"), nT_);
//	b.ToXml(PM("nN"), nN_);
//
//	b.ToXml(PM("q20"), q20_);
//	b.ToXml(PM("q25"), q25_);
//	b.ToXml(PM("q30"), q30_);	
//
//	Str::Xml::Val str;
//	b.ToStr(str);
//	string=ToRef(str);
//}
//

#pragma once
#include "HashMap.h"
#include "StringDef.h"
#include "PathDef.h"
#include "Sequence.h"

typedef std::hash_map<Str::Text::Val, seq::Sequence> Contigs;

class AllContigs {
private:
	Contigs fwdContigs_, revContigs_;
public:
	AllContigs();
	~AllContigs();

	void load(const Str::Path::Val& seqFile);

	const seq::Sequence& get(const Str::ID::Val& contigId, bool fwd) const;

};

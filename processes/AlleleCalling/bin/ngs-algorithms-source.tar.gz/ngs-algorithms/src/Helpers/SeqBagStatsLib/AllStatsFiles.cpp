#include "stdafx.h"

#include "AllStatsFiles.h"


namespace stats
{

bool AllStatsFiles::IsEmpty() const
{
    return readFiles.isEmpty();
}

} // namespace stats

#pragma once
#include "StringDef.h"
#include "PathDef.h"
#include "helper.h"

namespace runextern {

	class ProcessCmdLine {

    public:
        typedef boost::shared_ptr<char*> ArgvPtr;

	private:
        Str::Text::Val command_;
        Str::Text::Vec arguments_;

		Str::Text::Val cmdline_;

        Str::Path::Val outputFile_;
		bool redirectStderr_; ///< Whether to redirect stderr to stdout. Only meaningful when a custom output file is configured for stdout.
	public:
		ProcessCmdLine();
		ProcessCmdLine(Str::Text::Arg cmdline);
		
		virtual void clearCmdLine();

		virtual Str::Text::Ref getCmdLine() const;

		void setCmdLine(Str::Text::Arg cmdline);

        Str::Text::Ref GetCommand() const;

        ArgvPtr GetArgv() const;

        void AddPath(const Str::Path::Val& path);

        void AddArgument(Str::Text::Arg argument);

        void SetCommand(Str::Text::Arg command);

        ProcessCmdLine& operator<<(const Str::Path::Val& path);

        template<class T> ProcessCmdLine& operator<<(T t)
        {
            AddArgument(ToStr(t));
            return *this;
        }

        //Request that the output of the process is sent to \a outputFile
        void SetOutputFile(const Str::Path::Val outputFile)
        {
            outputFile_ = outputFile;
        }

        Str::Path::Val GetOutputFile() const
        {
            return outputFile_;
        }
		/**
		 * \brief Request additional redirection of standard error to output file.
		 * \sa SetOutputFile
		 * \remark Redirection of stderr to the outfile only effective if SetOutputFile also used.
		 */
		void SetRedirectStderr(bool redirect)
		{
			redirectStderr_ = redirect;
		}
		bool GetRedirectStderr() const
		{
			return redirectStderr_;
		}

    private:
        void addToCmdLine(Str::Text::Arg part);
	};

}
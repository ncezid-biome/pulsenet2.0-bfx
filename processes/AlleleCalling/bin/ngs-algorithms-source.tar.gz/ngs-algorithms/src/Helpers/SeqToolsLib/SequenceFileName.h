#pragma once

#include "PathDef.h"
#include "translate.h"


class SequenceFileName
{
public:
    typedef std::vector<SequenceFileName> List;

public:
    SequenceFileName();
    SequenceFileName( const Str::Path::Val& filename );

    void ReplaceExtension( Str::Text::Val newExtension = PM("") );
    bool Exists() const;

    void operator=( const Str::Path::Val& filename );
    operator const Str::Path::Val&() const;
    Str::Text::Val ToString() const;

private:
    Str::Path::Val filename_;
};

std::ostream &operator<<(std::ostream &stream, const SequenceFileName& file);

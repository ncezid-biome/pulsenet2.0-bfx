#pragma once

#include "CE_ProgramOptions.h"

#include "PathDef.h"
#include "StringDef.h"

#include "AlleleInfoFile.h"
#include "AlleleSequencesFile.h"
#include "BlastDatabase.h"

#include "OrganismSettings.h"

namespace engine { class ExecuteEnvironment; }
namespace communication { class CalcCommunication; }
/**
    \sa BlastAlleleFinderData
*/
class BlastAlleleFinderSettings : public engine::ProgramOptions
{
public:
    //generic
    Str::Path::Val destDataDir;
    Str::Text::Val sequenceFile;

    Str::ID::Val algorithmType;
    size_t       k;
    size_t       maxNHits;
    bool         ungapped;
    int          gapopen;
    int          gapextend;
    int          penalty;
    int          reward;
    double       percentIdentity;
    double       lengthOverlap;
	double		 hitOverlap;
	bool		 huntForStartStop;
	size_t		 extraBasesForStartStop;
	bool		 extrapolateAlignment;
	bool		 doDusting;
	Str::Text::Vec startCodons, stopCodons;

	bool		doRepeatMasking;
	//double		percentIdentityRepeatMasking;
	//int			absOverlapRepeatMasking;
	//double		repeatScoreThreshold;

    size_t clientVersion;

	engine::OrganismSettings organismsettings;
private:
	Str::Text::Val strClientVersion;

public:
    BlastAlleleFinderSettings();

    bool ParseAndSetup(int argc, char* argv[], const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm) override;
	/*
	 * \brief this is passed as a lambda to the more generic LoadEnvSettings in OrganismSettings, so after that is done loading the settings from file it can perform specific processing for this executable.
	 */
	void LoadEnvSettingsImpl(const ProgramOptions::EnvSettings& envSettings, const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm);
	void Finalize();

    void SetData( const Str::Path::Val& database, const Str::Path::Val& alleleInfoFile, const Str::Path::Val& acceptedAllelesFile="" );

	Str::Text::Val GetOrganismFromAlleleInfoPath() const;

private:
    void Init();

private:
    Str::Text::Val database_;
    Str::Text::Val alleleInfoFile_;
    Str::Text::Val acceptedAllelesFile_;

private:
    friend class BlastAlleleFinderData;
};

class BlastAlleleFinderData
{
public:
    BlastAlleleFinderData( const BlastAlleleFinderSettings& settings, const communication::CalcCommunication& comm );

    Str::Path::Val GetBlastDatabaseName() const;
    Str::Path::Val GetAlleleFileName() const;
    Str::Path::Val GetAcceptedAlleleFileName() const;

private:
    AlleleInfoFile alleleInfoFile_;
    BlastDatabase  database_;
    AlleleSequencesFile::Ptr acceptedAllelesFile_;
    AlleleSequencesFile defaultAcceptedAllelesFile_; // used in case acceptedAllelesFile_ is null, but will be protected from throwing in case of missing file.

    /**
        "Frozen" name: get it when this instance is instantiated, ignore later link file
        rotations.
    */
    Str::Path::Val databaseName_;
};

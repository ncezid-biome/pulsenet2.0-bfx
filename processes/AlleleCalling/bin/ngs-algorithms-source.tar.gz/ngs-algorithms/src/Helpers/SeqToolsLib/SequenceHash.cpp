#include "stdafx.h"

#include "SequenceHash.h"

#include "Sequence.h"



size_t seq::SequenceHash::operator()(const Sequence& sequence) const
{
    return sequence.Hash(*this);
}

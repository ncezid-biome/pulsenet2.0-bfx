#pragma once

#include <stdint.h>

#define iupac_A char(65)//A
#define iupac_C char(67)//C
#define iupac_G char(71)//G
#define iupac_T char(84)//T
#define iupac_U char(85)//U
#define iupac_R char(82)//R
#define iupac_Y char(89)//Y
#define iupac_M char(77)//M
#define iupac_K char(75)//K
#define iupac_W char(87)//W
#define iupac_S char(83)//S
#define iupac_B char(66)//B
#define iupac_D char(68)//D
#define iupac_H char(72)//H
#define iupac_V char(86)//V
#define iupac_N char(78)//N

#define iupac_a char(97)
#define iupac_c char(99)
#define iupac_g char(103)
#define iupac_t char(116)
#define iupac_u char(117)
#define iupac_r char(114)
#define iupac_y char(121)
#define iupac_m char(109)
#define iupac_k char(107)
#define iupac_w char(119)
#define iupac_s char(115)
#define iupac_b char(98)
#define iupac_d char(100)
#define iupac_h char(104)
#define iupac_v char(118)
#define iupac_n char(110)

const static char GAP = char(45);
#define UNDEFINED char(95)
#define BASE 12


extern uint32_t counts[256][4];
extern char to_compl[256];
extern char to_code[256];
extern char from_code[256];
extern char consensus_letter[5][5][5];
extern char score[256][256];
extern char to_capital_ref[256];
extern char to_capital_read[256];

int iupac_compare(const char c1, const char c2);
void init_revcompl();
void init_counts();
void init_codes();
void init_consensus();
void init_tocapital();



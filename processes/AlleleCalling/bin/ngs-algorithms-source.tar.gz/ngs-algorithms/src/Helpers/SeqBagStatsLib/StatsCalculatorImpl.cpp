#include "stdafx.h"

#include "StatsCalculatorImpl.h"

#include "BasicSRSStatsCalculator.h"
#include "SplitSequenceFiles.h"
#include "AllStatsFiles.h"
#include "SequenceFilesParser.h"
#include "SRSStatsCalculatorSettings.h"

#include "CE_Communication.h"
#include "seqbagstats_info.h"


class SeqBagInfo;

using namespace stats;


StatsCalculatorImpl::Factory::Ptr StatsCalculatorImpl::CreateFactory()
{
    Factory::Ptr factory( new Factory() );

    factory->RegisterPrototype<BasicSRSStatsCalculator>();

    return factory;
}




void StatsCalculatorImpl::Apply( const SRSStatsCalculatorSettings&       settings,
									const engine::ExecuteEnvironment&       env,
									const communication::CalcCommunication& comm) const
{
	std::string info, stats;
	SeqBagInfo returnInfo;

	Apply(settings, returnInfo, info, stats, env, comm);

    comm.Send( communication::CalcCreateResultFile(settings.outputFileNameInfo, info) );
	comm.Send( communication::CalcCreateResultFile(settings.outputFileNameStats, stats) );

	comm.Send( communication::CalcEnded() ); 
}
void StatsCalculatorImpl::Apply( const SRSStatsCalculatorSettings&       settings,
									SeqBagInfo& returnInfo,
									const engine::ExecuteEnvironment&       env,
									const communication::CalcCommunication& comm) const
{
	std::string info, stats;

	Apply(settings, returnInfo, info, stats, env, comm);

    comm.Send( communication::CalcCreateResultFile(settings.outputFileNameInfo, info) );
	comm.Send( communication::CalcCreateResultFile(settings.outputFileNameStats, stats) );

	comm.Send( communication::CalcEnded() ); 
}

void StatsCalculatorImpl::Apply(
    const SRSStatsCalculatorSettings&       settings,
	SeqBagInfo& returnInfo,
	std::string& info, std::string& stats,
    const engine::ExecuteEnvironment&       env,
    const communication::CalcCommunication& comm) const
{
    CheckPre(settings, env, comm);
    SplitSequenceFiles splitFiles;
    ParseFiles(settings, splitFiles, env, comm);

    // Some sanity checks
    if ( splitFiles.IsEmpty() )
        throw KError(PM("No input files present, unable to compute statistics."));

    ApplyImpl(settings, splitFiles, returnInfo, info, stats, env, comm);
}

void StatsCalculatorImpl::ParseFiles(
    const SRSStatsCalculatorSettings&       settings,
    SplitSequenceFiles&                     downloadedfiles,
    const engine::ExecuteEnvironment&       env, 
    const communication::CalcCommunication& comm) const
{
    AllStatsFiles mydownloadedfiles;
    {
        InputFileParser parser;

        for ( const auto& locator : settings.readFiles )
			parser.AddFile( locator, settings.doSanitizePath );

        mydownloadedfiles.readFiles.merge( parser.GetFiles(settings.doSanitizePath) );
    }

    for (size_t i=0; i<mydownloadedfiles.readFiles.files.size(); ++i) {
        if (mydownloadedfiles.readFiles.files[i].paired)
            downloadedfiles.pairedFiles.files.insert(downloadedfiles.pairedFiles.files.end(), mydownloadedfiles.readFiles.files[i]);
        else
            downloadedfiles.singleFiles.files.insert(downloadedfiles.singleFiles.files.end(), mydownloadedfiles.readFiles.files[i]);
    }
}
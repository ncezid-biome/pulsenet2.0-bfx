#pragma once

#include <set>

#include "StringDef.h"
#include "PathDef.h"

#include "SequenceFiles.h"

class InputFileParser
{
public:
    InputFileParser();

    void          AddFile( const Str::Text::Val& filepath, bool doSanitizePath = true );
    SequenceFiles GetFiles(bool doSanitizePaths=true) const;

    static bool IsPaired( const Str::Text::Val& file1, const Str::Text::Val& file2 );

private:
    void ParseLocalFiles( SequenceFiles& files, bool doSanitizePaths=true ) const;

private:
    mutable std::set<Str::Text::Val> singleFiles_;
    mutable SequenceFiles parsedFiles_;
};

#pragma once
#include "PathDef.h"
#include "Coverage.h"
#include "BAMConsensusCreator.h"

namespace BAM
{

class ConsensusSink
{

public:
    typedef boost::shared_ptr<ConsensusSink> Ptr;

public:
    virtual void ReportConsensus(BAM::ConsensusCreator::Ptr consensor)=0;

    virtual ~ConsensusSink()
    {
    }
};

}


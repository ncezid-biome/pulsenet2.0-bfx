#pragma once
#include "StringDef.h"
#include "PathDef.h"

namespace engine{
	class ExecuteEnvironment;
}
namespace communication {
	class CalcCommunication;
}

#pragma once

#include "boost/program_options.hpp"

#include "PathDef.h"
#include "StringDef.h"


class BlastSettings
{

public:
    Str::ID::Val algorithmType;
    Str::Path::Val dbName;
	size_t       k;
    size_t       maxNHits;
    bool         ungapped;
    int          gapopen;
    int          gapextend;
    int          penalty;
    int          reward;
    double       percentIdentity;
    bool		 doDusting;
	double		 relMinOverlap;

public:
    BlastSettings();

   void addOptions(boost::program_options::options_description& descr);
};


Str::Path::Val RunBlast(const Str::Path::Val& fastaFile, const BlastSettings& settings, 
						const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm
			);

Str::Path::Val RunBlast(const Str::Path::Val& fastaFile, const Str::Text::Val& task, const Str::Path::Val& dbName, int maxNHits, int wordSize, 
				double percentIdentity, int reward, int penalty, bool ungapped, int gapopen, int gapextend, bool doDusting,
				const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm
			);
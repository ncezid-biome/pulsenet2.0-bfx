#include "stdafx.h"

#define BOOST_TEST_MODULE "C++ Unit Tests for AlleleFinderLib"

// Some macros that cause unit_test.hpp to spit out a main
#define BOOST_TEST_MAIN

#include "boost/test/unit_test.hpp"

#include "stdafx.h"

#include "boost/test/unit_test.hpp"
#include "BAMCoverageProvider.h"
#include "ConsoleLogger.h"
#include "CommunicationNoProgress.h"
#include "TempDirectory.h"
#include "BAMFileLoader.h"

struct CoverageProviderTestsFixture {


    CoverageProviderTestsFixture(): cl(ConsoleLogger::LogMode::Text), comm(&cl)
    {
    }

    Str::Path::Val GetDataFilePath(const Str::Text::Val& filename)
    {
        //this needs compiler flag /FC to get the full path
        Str::Path::Val thisFile(__FILE__);

        return (thisFile.parent_path() / "Data" / filename);
    }

    void CheckCoverageVsRef(const SeqBAM::CoverageProvider& cp)
    {
        BOOST_CHECK_EQUAL(cp.contigNames_.size(), 4);
        BOOST_CHECK_EQUAL(cp.coverages_.size(), 4);

        BOOST_CHECK_EQUAL(cp.contigNames_[0], "d1");
        BOOST_CHECK_EQUAL(cp.coverages_[0].size(), 7);
        BOOST_CHECK_EQUAL(cp.contigNames_[1], "d2");
        BOOST_CHECK_EQUAL(cp.coverages_[1].size(), 0);
        BOOST_CHECK_EQUAL(cp.contigNames_[2], "d3");
        BOOST_CHECK_EQUAL(cp.coverages_[2].size(), 8);
        BOOST_CHECK_EQUAL(cp.contigNames_[3], "d4");
        BOOST_CHECK_EQUAL(cp.coverages_[3].size(), 1);
    }

    ConsoleLogger cl;
    communication::CalcCommunication comm;

    TempDirectory bamDir;
};

BOOST_FIXTURE_TEST_SUITE( CoverageProviderTests, CoverageProviderTestsFixture );

BOOST_AUTO_TEST_CASE(coverage_vs_ref)
{
    SeqBAM::CoverageProvider cp(GetDataFilePath("coverage_vs_ref.fasta"));

    //custom loader to avoid creating pile file and level files
    BAM::FileLoader loader(false, false);
    BAM::FileResolver::Ptr files = loader.Load(comm, GetDataFilePath("coverage_vs_ref.sam"), bamDir.path());

    cp.Fill(files);
    CheckCoverageVsRef(cp);
}

BOOST_AUTO_TEST_CASE(coverage_vs_ref_last_extra)
{
    SeqBAM::CoverageProvider cp(GetDataFilePath("coverage_vs_ref.fasta"));

    //this SAM file has an extra contig that is not in the reference
    //this screws up the content of the output, but the reference frame is kept
    BAM::FileLoader loader(false, false);
    BAM::FileResolver::Ptr files = loader.Load(comm, GetDataFilePath("coverage_vs_ref_last_extra.sam"), bamDir.path());

    cp.Fill(files);
    CheckCoverageVsRef(cp);
}

BOOST_AUTO_TEST_CASE(coverage_vs_ref_last_missing)
{
    SeqBAM::CoverageProvider cp(GetDataFilePath("coverage_vs_ref.fasta"));

    //this SAM file has an extra contig that is not in the reference
    BAM::FileLoader loader(false, false);
    BAM::FileResolver::Ptr files = loader.Load(comm, GetDataFilePath("coverage_vs_ref_last_missing.sam"), bamDir.path());

    cp.Fill(files);
    CheckCoverageVsRef(cp);
}

BOOST_AUTO_TEST_CASE(coverage_min_length_filter_not_empty)
{
    SeqBAM::CoverageProvider cp(1);

    //this SAM file has an extra contig that is not in the reference
    BAM::FileLoader loader(false, false);
    BAM::FileResolver::Ptr files = loader.Load(comm, GetDataFilePath("coverage_vs_ref_last_extra.sam"), bamDir.path());
    cp.Fill(files);

    BOOST_CHECK_EQUAL(cp.contigNames_.size(), 2);
    BOOST_CHECK_EQUAL(cp.coverages_.size(), 2);

    BOOST_CHECK_EQUAL(cp.contigNames_[0], "d1");
    BOOST_CHECK_EQUAL(cp.coverages_[0].size(), 15);
    BOOST_CHECK_EQUAL(cp.contigNames_[1], "d_extra_in_sam");
    BOOST_CHECK_EQUAL(cp.coverages_[1].size(), 10000);
}


BOOST_AUTO_TEST_CASE(coverage_min_length_filter_one)
{
    SeqBAM::CoverageProvider cp(10);

    //this SAM file has an extra contig that is not in the reference
    BAM::FileLoader loader(false, false);
    BAM::FileResolver::Ptr files = loader.Load(comm, GetDataFilePath("coverage_vs_ref.sam"), bamDir.path());
    cp.Fill(files);

    BOOST_CHECK_EQUAL(cp.contigNames_.size(), 1);
    BOOST_CHECK_EQUAL(cp.coverages_.size(), 1);

    BOOST_CHECK_EQUAL(cp.contigNames_[0], "d1");
    BOOST_CHECK_EQUAL(cp.coverages_[0].size(), 15);
}

BOOST_AUTO_TEST_CASE(coverage_min_length_filter_all)
{
    SeqBAM::CoverageProvider cp(100);

    //this SAM file has an extra contig that is not in the reference
    BAM::FileLoader loader(false, false);
    BAM::FileResolver::Ptr files = loader.Load(comm, GetDataFilePath("coverage_vs_ref.sam"), bamDir.path());
    cp.Fill(files);

    BOOST_CHECK_EQUAL(cp.contigNames_.size(), 0);
    BOOST_CHECK_EQUAL(cp.coverages_.size(), 0);
}

BOOST_AUTO_TEST_SUITE_END();

/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/
#pragma once

// Legacy: error.h not a sane name, system header with same name exists
#include "ErrorMsg.h"
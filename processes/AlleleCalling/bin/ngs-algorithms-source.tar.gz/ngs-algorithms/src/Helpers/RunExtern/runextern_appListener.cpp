#include "stdafx.h"

#include <cstring>

#include "runextern_appListener.h"

#include "CalcCommunicationImpl.h"
#include "runextern_UnixDefines.h"


namespace runextern
{

    
ExternAppListener::ExternAppListener(Process::Ptr process, const ProcessInfo& info, bool interpretXml)
    : Listener( process )
    , interpretXml_(interpretXml)
    , expectedruntime_(0)
{
    if (info.hasExpectedRuntime()){
        expectedruntime_=info.getExpectedRuntime();
        factor_=-log(0.1)/(1.0*expectedruntime_);
    }
    else factor_=0;

    if (info.hasMemoryLimit()) {
        maxmemory_=info.getMemoryLimit();
        maxmemory_*= 1024*1024;
    }
    else maxmemory_=std::numeric_limits<unsigned __int64>::max();
}


void ExternAppListener::handleMessage(const Str::Text::Val& message, Reporter& comm)
{
    if(interpretXml_ && message.length()>0 && message.at(0)=='<' && message.at(message.length()-1) == '>')
        comm.Send(communication::CalcGeneric(message));
    else
        comm.Message(message);
}

void ExternAppListener::handleProgress(int millisecs, Reporter& comm)
{
    if (expectedruntime_>0) {
        double secs=(1.0*millisecs)/1000.0;
        comm.SetProgress( 100.0* std::min( secs/expectedruntime_, 1.0-exp(-factor_*secs) ), 100.0 );
    }
}

void ExternAppListener::handleEnd(ErrorCode lasterror, Reporter& comm)
{
	if (lasterror)
	{
#ifdef AMGNU
		std::string errorText(std::strerror(lasterror));
#else
		size_t const errmsglen = 120;
		char errmsg[errmsglen];
		strerror_s(errmsg, errmsglen, lasterror);
		std::string errorText = errmsg;
#endif
		comm.Failed(Message(TXT("Process failed (error code %1 - [%2])."), lasterror, errorText).str());
	}
}

void ExternAppListener::handleOutOfMemory(Reporter& comm)
{	
    comm.Failed( TXT("Process terminated (out of memory).") );	
    getProcess()->terminate(ERROR_NOT_ENOUGH_MEMORY);
}

void ExternAppListener::killProcess(ErrorCode errorcode)
{
    getProcess()->terminate(errorcode);
}

bool ExternAppListener::checkMemoryUsage()
{
    return getProcess()->getMemoryUsage() <= maxmemory_;
}



} // namespace runextern

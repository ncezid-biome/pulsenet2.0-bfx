#ifndef THREADING_H
#define THREADING_H

/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele
*/


#include "boost/thread.hpp"
#include "filereader.h"
#include "CalcCommunication.h"
#include "StringCounter.h"


template<class Handler, class Data, class Result>
class PerReadThreading {
private:
	Data& data_;
	size_t nCores_;	
	std::vector<KError> errors_;
private:	
	void execute(const ThreadSafeFileReader* safereader, Handler* handler, char* running, const communication::CalcCommunication& comm) {
		try {
			ThreadSafeFileReader::Chunk chunk;		
			safereader->getNextChunk(chunk, comm);
			while (chunk.size()>0) {		
				for(size_t i=0; i<chunk.size(); ++i) {
					handler->handle(chunk.getName(i), chunk.getSeq(i), chunk.getQual(i), chunk.getIndex(i));
				}
				handler->intermediate();
				safereader->getNextChunk(chunk);
			}
			(*running) = 0;
		}
		catch (std::exception& e) {
			errors_.push_back(KError(e.what()));
			(*running) = 0;
		}
	};
	void executePaired(const ThreadSafeFileReader* safereader, Handler* handler, char* running, const communication::CalcCommunication& comm) {
		try {
			ThreadSafeFileReader::Chunk chunk1, chunk2;		
			safereader->getNextChunk(chunk1, chunk2, comm);			
			while (chunk1.size()>0 && chunk2.size()>0) {		
				for(size_t i=0; i<std::min(chunk1.size(),chunk2.size()); ++i) {
					handler->handle(chunk1.getName(i), chunk1.getSeq(i), chunk1.getQual(i), chunk2.getName(i), chunk2.getSeq(i), chunk2.getQual(i), chunk1.getIndex(i));
				}
				handler->intermediate();
				safereader->getNextChunk(chunk1, chunk2);
			}
			(*running) = 0;
		}
		catch (std::exception& e) {
			errors_.push_back(KError(e.what()));
			(*running) = 0;
		}
	};

public:
	PerReadThreading(size_t nCores, Data& data) 
		: nCores_(nCores), data_(data) { if (nCores_==0) nCores_=1; }
	~PerReadThreading() {}

	void handle(SeqFileReader::Ptr reader, Result& result, size_t chunkSize = 10000, const communication::CalcCommunication& comm=communication::CalcCommunication()) {
		//create the reader 
		ThreadSafeFileReader safereader(reader, chunkSize);

		//create the handlers. unique_ptr instead of the objects themselves to cope with noncopyable handlers.
		std::vector<std::unique_ptr<Handler>> handlers(nCores_);
		std::vector<char> running(nCores_, 1);

		//initialize the handlers
		for( auto& handler : handlers ){
            handler = std::unique_ptr<Handler>(new Handler());
			handler->init(data_);
        }

		//create the threads
		std::vector<boost::shared_ptr<boost::thread>> threads(nCores_);
		for(size_t i=0; i<threads.size(); ++i)
			threads[i].reset(new boost::thread(&PerReadThreading::execute, this, &safereader, handlers[i].get(), &(running[i]), boost::cref(comm)));
		
		bool done = false;
		while (!done) {
			done = true;
			for(size_t i=0; i<threads.size(); ++i)
				done &=  (!running[i]); //) || (threads[i]->try_join_for(boost::chrono::milliseconds(100))));
			comm.Continue();
		}		
		comm.Continue();

		for (size_t i=0; i<handlers.size(); ++i) 
			handlers[i]->finish(result);

		if (!errors_.empty()) {
			std::ostringstream os;
            StringCounter errorstrings(errors_);

            os << "The following errors have occurred:\n";
            errorstrings.Print(os);

			throw KError(os.str());
		}
	}

	void handle(SeqFileReader::Ptr reader1, SeqFileReader::Ptr reader2, Result& result, size_t chunkSize = 10000, const communication::CalcCommunication& comm=communication::CalcCommunication()) {
		//create the reader 				
		ThreadSafeFileReader safereader(reader1, reader2, chunkSize);		

        //create the handlers
        std::vector<std::unique_ptr<Handler>> handlers(nCores_);
		std::vector<char> running(nCores_, 1);

        //initialize the handlers
        for( auto& handler : handlers ){
            handler = std::unique_ptr<Handler>(new Handler());
            handler->init(data_);
        }

		//create the threads
		std::vector<boost::shared_ptr<boost::thread>> threads(nCores_);
		for(size_t i=0; i<threads.size(); ++i)
			threads[i].reset(new boost::thread(&PerReadThreading::executePaired, this, &safereader, handlers[i].get(), &(running[i]), comm));
			
		//keep watching the threads as they do their work
		bool done = false;
		while (!done) {
			comm.Continue();
			done = true;
			for(size_t i=0; i<threads.size(); ++i)
				done &= (!running[i]); // || (threads[i]->try_join_for(boost::chrono::milliseconds(100))));	
		}
		

		//gather results as the threads have finished
		for (size_t i=0; i<handlers.size(); ++i) 
			handlers[i]->finish(result);

		//dump the errors
		if (!errors_.empty()) {
			std::ostringstream os;
            StringCounter errorstrings(errors_);

			os << "The following errors have occurred:\n";
            errorstrings.Print(os);

			throw KError(os.str());
		}
	}
};

#endif
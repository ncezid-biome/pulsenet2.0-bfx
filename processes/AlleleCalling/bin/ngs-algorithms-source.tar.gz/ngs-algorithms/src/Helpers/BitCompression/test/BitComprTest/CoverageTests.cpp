#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "IBuffImpl.h"
#include "mathHelp.h"

#include "BitCompressor.h"
#include "CompressCoverage.h"
#include "Coverage.h"
#include "BitIterators.h"
#include "BitCompressionTestData.h"
#include "debugstr.h"
#include <boost/random/random_device.hpp>
#include <boost/random/uniform_int_distribution.hpp>


using namespace compression;


class CoverageTest
	: public compression::CoverageWriterItf 
{
public:
    CoverageTest()
        : base_(4)
    {
    }

	CoverageTest(int tot[], int a[], int c[], int g[], int t[], size_t length)
        : base_(4)
	{
		if(tot!=nullptr){
			for(size_t i=0; i < length; ++i){
				tot_.push_back(tot[i]);
				base_[0].push_back(a[i]);
				base_[1].push_back(c[i]);
				base_[2].push_back(g[i]);
				base_[3].push_back(t[i]);
				int el[]={a[i],c[i],g[i],t[i]};
				maxBase_.push_back(std::max_element(el, el+4) - el);
			}
		}
	}

    void Append( int a, int c, int g, int t )
    {
        base_[0].push_back(a);
        base_[1].push_back(c);
        base_[2].push_back(g);
        base_[3].push_back(t);
        
        tot_.push_back(a+g+c+t);

        maxBase_.push_back( std::max_element(base_.cbegin(), base_.cend(),
            [this](const std::vector<CountType>& left, const std::vector<CountType>& right){ return left.back() < right.back(); }) - base_.cbegin() );
    }    

	virtual  size_t GetCount() const{
		return tot_.size();
	}
	virtual  CountType  GetTot(size_t i) const{
		return tot_[i];
	}
	virtual  CountType  GetTotDiff(size_t i) const{
		if(i==0)
			return tot_[0];
		return tot_[i] - tot_[i-1];
	}
	virtual  CountType  GetBaseCount(size_t i, size_t base) const{
		return base_[base][i];
	} 
	virtual  size_t			GetMaxBaseNr(size_t i) const{
		return maxBase_[i];
	}

	virtual  void  SetCount(size_t cnt) {
		SetCountTotal(cnt);
		if(base_.empty())
			base_.resize(1);
		for(size_t i=0; i<base_.size(); ++i)
			base_[i].resize(cnt);
		maxBase_.resize(cnt);
	}
    virtual  void  SetCountTotal(size_t cnt) override {
        tot_.resize(cnt);
    }
	virtual  void  SetTot(size_t i, CountType cnt){
		tot_[i] = cnt;
	}
	virtual  void  SetBaseCount(size_t i, size_t base, CountType cnt){
		base_[base][i] = cnt;
	}
	virtual  void			SetMaxBaseNr(size_t i, size_t mx) {
		maxBase_[i] = mx;
	}

	void Test(const CoverageTest& other) const{
		BOOST_REQUIRE_EQUAL(tot_.size(),other.tot_.size());//, L"test coverage: size");
		for(size_t i=0; i < tot_.size(); ++i){
			BOOST_REQUIRE_EQUAL(tot_[i],other.tot_[i]);//, L"test cov: tot");
            BOOST_REQUIRE_EQUAL(maxBase_[i],other.maxBase_[i]);//, L"test cov: maxBase_");
            BOOST_REQUIRE_EQUAL(base_[0][i],other.base_[0][i]);//, L"test cov: base 0");
            BOOST_REQUIRE_EQUAL(base_[1][i],other.base_[1][i]);//, L"test cov: base 1");
            BOOST_REQUIRE_EQUAL(base_[2][i],other.base_[2][i]);//, L"test cov: base 2");
            BOOST_REQUIRE_EQUAL(base_[3][i],other.base_[3][i]);//, L"test cov: base 3");
		}
	}
public:
	std::vector<char>		maxBase_;
	std::vector<CountType>  tot_;
	std::vector<std::vector<CountType>>  base_;

};


void Test(const CoverageTest& test, const CoverageTest& other){
	using namespace compression;
	typedef std::vector<unsigned char> Buffer;
	Buffer  buff;
	OutVecBufferIterator<unsigned char>  buffIt(buff);
	SaveCoverage<4,OutVecBufferIterator<unsigned char>>(buffIt, test);

	CoverageTest reader;
	InputVecBufferIterator<unsigned char> it(buff.begin());
	LoadCoverage<4, InputVecBufferIterator<unsigned char>>(it,reader);

	reader.Test(other);

}

void Test(const CoverageTest& test){
    Test(test, test);
}

BOOST_AUTO_TEST_SUITE( CoverageTests );

BOOST_AUTO_TEST_CASE(TestCov)
{
    int tot[]=	{1,1,1,1};
    int a[]=	{0,0,1,0};
    int c[]=	{0,1,0,0};
    int g[]=	{1,0,0,0};
    int t[]=	{0,0,0,1};
    CoverageTest tst(tot, a,c,g,t, 4);
    Test(tst);
}

BOOST_AUTO_TEST_CASE(TestCov_oneN)
{
    int tot[]=	{1,1,1,1};
    int a[]=	{0,0,1,0};
    int c[]=	{0,1,0,0};
    int g[]=	{1,0,0,0};
    int t[]=	{0,0,0,0}; //one N
    CoverageTest tst(tot, a,c,g,t, 4);
    Test(tst);
}

BOOST_AUTO_TEST_CASE(TestCov_mixed)
{
    int tot[]=	{20,5,45,62};
    int a[]=	{4,1,22,14};
    int c[]=	{3,1,5,12};
    int g[]=	{6,2,8,13};
    int t[]=	{7,1,10,19}; 
    CoverageTest tst(tot, a,c,g,t, 4);
    Test(tst);
}
BOOST_AUTO_TEST_CASE(TestCov_nice)
{
    int tot[]=	{20,5,45,62};
    int a[]=	{19,0,0,1};
    int c[]=	{1,4,0,0};
    int g[]=	{0,1,42,2};
    int t[]=	{0,0,3,60}; 
    CoverageTest tst(tot, a,c,g,t, 4);
    Test(tst);
}
// This test fails spectacularly, no errors nor return code so no way to test for this
BOOST_AUTO_TEST_CASE(TestCov_overflow)
{
    int tot[]=	{1,1,1,1};
    int a[]=	{0,0,2,0};//more than total!
    int c[]=	{0,1,0,0};
    int g[]=	{1,0,0,0};
    int t[]=	{0,0,0,0}; 
    CoverageTest tst(tot, a,c,g,t, 4);

    int a_r[] =	{0, 0, 1, 0};
    CoverageTest tst_r(tot, a_r, c, g, t, 4);

    Test(tst, tst_r);
}
BOOST_AUTO_TEST_CASE(TestCov_overflowMixed)
{
    int tot[]=	{1,1,1,1};
    int a[]=	{0,0,1,0};
    int c[]=	{0,1,1,0};
    int g[]=	{1,0,1,0};
    int t[]=	{0,0,1,0}; 
    CoverageTest tst(tot, a,c,g,t, 4);

    int a_r[]=	{0,0,1,0};
    int c_r[]=	{0,1,0,0};
    int g_r[]=	{1,0,0,0};
    int t_r[]=	{0,0,0,0}; 
    CoverageTest tst_r(tot, a_r, c_r, g_r, t_r, 4);

    Test(tst, tst_r);
}
BOOST_AUTO_TEST_CASE(TestCov_zero)
{
    int tot[]=	{0,0,0,0};
    int a[]=	{0,0,0,0};
    int c[]=	{0,0,0,0};
    int g[]=	{0,0,0,0};
    int t[]=	{0,0,0,0};
    CoverageTest tst(tot, a,c,g,t, 4);
    Test(tst);
}
BOOST_AUTO_TEST_CASE(TestCov_empty)
{
    CoverageTest tst(nullptr,nullptr,nullptr,nullptr,nullptr, 5);
    Test(tst);
}

BOOST_AUTO_TEST_CASE(SingleBase_EqualCoverages_Ok)
{
    int tot[]=	{4};
    int a[]=	{1};
    int c[]=	{1};
    int g[]=	{1};
    int t[]=	{1};
    CoverageTest tst(tot, a,c,g,t,1);

    Test(tst);
}

namespace 
{

void testSingleRow(int a, int c, int g, int t, size_t length)
{
    CoverageTest tester;

    for ( size_t i = 0; i < length; ++i )
        tester.Append(a, c, g, t);

    Test(tester);
}

void testRotating(int a, int c, int g, int t, size_t length)
{
    CoverageTest tester;

    // Round down
    for ( size_t i = 0; i < length/4; ++i ){
        tester.Append(a, c, g, t);
        tester.Append(c, g, t, a);
        tester.Append(g, t, a, c);
        tester.Append(t, a, c, g);
    }

    Test(tester);
}

} // namespace 

BOOST_AUTO_TEST_CASE(SingleRow_L_1000_4_Bases_Ok)
{
    testSingleRow(1,0,0,0,1000);
    testSingleRow(0,1,0,0,1000);
    testSingleRow(0,0,1,0,1000);
    testSingleRow(0,0,0,1,1000);
}

BOOST_AUTO_TEST_CASE(RotatingBases_SingleBaseCovered_Ok)
{
    testRotating(  1,0,0,0,1000);
    testRotating(100,0,0,0,1000);
    testRotating(500,0,0,0,1000);
}

BOOST_AUTO_TEST_CASE(RotatingBases_MultipleBaseCovered_Ok)
{
    testRotating( 10,  5,  2, 1,1000);
    testRotating(100, 50, 20,10,1000);
    testRotating(500,250,100,50,1000);
}

BOOST_AUTO_TEST_CASE(bug_5209)
{
    //this is not exactly a valid profile, but (de)compression should never just hang

    int tot[] =	{14};
    int a[] =	{14};
    int c[] =	{14};
    int g[] =	{30};
    int t[] =	{30};

    CoverageTest tst(tot, a, c, g, t, 1);

    int tot_r[] =	{14};
    int a_r[] =  	{0};
    int c_r[] =  	{0};
    int g_r[] =  	{14};
    int t_r[] =  	{0};

    CoverageTest tst_r(tot_r, a_r, c_r, g_r, t_r, 1);

    Test(tst, tst_r);
}

BOOST_AUTO_TEST_CASE(invalid_tot_zero_run)
{
    using namespace compression;
    typedef std::vector<unsigned char> Buffer;

    int tot[] =	{1, 1, 1, 1};
    int a[] =	{0, 0, 2, 0};
    int c[] =	{0, 2, 0, 0};
    int g[] =	{2, 0, 0, 0};
    int t[] =	{0, 0, 0, 2};
    CoverageTest tst(tot, a, c, g, t, 4);

    for(size_t b = 0; b < 4; b++) {

        Buffer  buff;
        OutVecBufferIterator<unsigned char>  buffIt(buff);
        SaveCovBaseVector<4>(buffIt, tst, b);

        BOOST_REQUIRE_EQUAL(buff.size(), 1);
        BOOST_REQUIRE_EQUAL(buff[0], 0x40); //a run of four zeroes
    }

    for(size_t b = 0; b < 4; b++) {

        Buffer  buff;
        OutVecBufferIterator<unsigned char>  buffIt(buff);

        SaveCovBaseVector<5>(buffIt, tst, b);

        // xxxxxx00 100|00000 fltr
        BOOST_REQUIRE_EQUAL(buff.size(), 2);

        BOOST_REQUIRE_EQUAL(buff[0], 0x80);
        BOOST_REQUIRE_EQUAL(buff[1], 0);

    }

}

BOOST_AUTO_TEST_CASE(invalid_tot_drop)
{
    //expected behaviour: all counts that exceed total are dropped, except for the max
    //in case of an ex-aequo, the first is kept

    int tot[] =	{1, 1, 1, 1};
    int a[] =	{0, 2, 3, 0};
    int c[] =	{0, 3, 3, 2};
    int g[] =	{3, 0, 2, 0};
    int t[] =	{0, 0, 0, 3};
    CoverageTest tst(tot, a, c, g, t, 4);

    int tot_r[] =	{1, 1, 1, 1};
    int a_r[] =	    {0, 0, 1, 0};
    int c_r[] =	    {0, 1, 0, 0};
    int g_r[] =	    {1, 0, 0, 0};
    int t_r[] =	    {0, 0, 0, 1};
    CoverageTest tst_r(tot_r, a_r, c_r, g_r, t_r, 4);

    Test(tst, tst_r);
}

BOOST_AUTO_TEST_CASE(random_input)
{
    boost::random::random_device gen;
    boost::random::uniform_int_distribution<> dist(0, 152654);

    const size_t len = 10000;

    int tot[len];
    int bs[4][len];

    for(size_t m = 0; m < len; m++) {

        if((tot[m] = dist(gen)) == 0) {
            bs[0][m] = bs[1][m] = bs[2][m] = bs[3][m] = 0;
        }
        else {
            bs[0][m] = dist(gen);
            bs[1][m] = dist(gen);
            bs[2][m] = dist(gen);
            bs[3][m] = dist(gen);
        }
    }

    CoverageTest tst(tot, bs[0], bs[1], bs[2], bs[3], len);

    //expected behaviour: all counts that exceed total are dropped, except for the max
    //in case of an ex-aequo, the first is kept

    int bs_r[4][len];

    for(size_t m = 0; m < len; m++) {

        for(size_t b = 0; b < 4; b++) {
            bs_r[b][m] = bs[b][m] >= tot[m] ? 0 : bs[b][m];
        }

        const size_t maxb = tst.GetMaxBaseNr(m);
        if(bs[maxb][m] >= tot[m])
            bs_r[maxb][m] = tot[m];

    }

    CoverageTest tst_r(tot, bs_r[0], bs_r[1], bs_r[2], bs_r[3], len);

    Test(tst, tst_r);
}

BOOST_AUTO_TEST_SUITE_END();

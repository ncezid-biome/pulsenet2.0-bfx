#pragma once
#include "CE_ProgramOptions.h"

namespace engine
{

class OrganismSettings : public engine::ProgramOptions
{
public:
	// typedef to use when passing the lambda to LoadEnvSettings
	typedef std::function<void(const EnvSettings& , const engine::ExecuteEnvironment& , const communication::CalcCommunication& )> LoadSettingsImplementation;

private:
	Str::Path::Val organismSettingsFile_;
	Str::Text::Val organism_;

public:
	OrganismSettings(bool asSub = true);
	~OrganismSettings();

	Str::Text::Val GetOrganism() const;
	void SetOrganism(Str::Text::Arg organism);
	bool HasOrganism() const;
	/*
	 * \brief Tries to load the organismsettings file and then executes a user defined lambda that processes the settings.
	 *
	 * The loading part of the settings is generic and it tries to determine a generic one if there is no file specified, 
	 * but then the lambda that is passed in in impl is executed.
	 * This lambda is defined in the code specific to the executable and handles the settings from the loaded settings that it needs to process. 
	 */
	virtual void LoadEnvSettings(const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm, LoadSettingsImplementation impl);
};

}
#include "stdafx.h"
#include "iupac.h"

char score[256][256];
char to_compl[256];
char to_code[256];
char from_code[256];
char to_capital_ref[256];
char to_capital_read[256];
char consensus_letter[5][5][5];
uint32_t counts[256][4]; //contains the way iUPAC letters should be counted 



void init_revcompl()
{
	for(size_t i=0; i<256; ++i) to_compl[i]=iupac_N; 

	to_compl[GAP]=GAP;
	to_compl[36]=36;
	
	to_compl[iupac_A]=iupac_T;
	to_compl[iupac_C]=iupac_G;
	to_compl[iupac_G]=iupac_C;
	to_compl[iupac_T]=iupac_A;

	to_compl[iupac_a]=iupac_t;
	to_compl[iupac_c]=iupac_g;
	to_compl[iupac_g]=iupac_c;
	to_compl[iupac_t]=iupac_a;
}

void init_consensus()
{
	for(size_t i=0; i<5; ++i) {
		for(size_t j=0; j<5; ++j) {
			for(size_t k=0; k<5; ++k) {
				consensus_letter[i][j][k]=GAP;
			}
		}
	}

	consensus_letter[0][4][4]=iupac_A;
	consensus_letter[1][4][4]=iupac_C;
	consensus_letter[2][4][4]=iupac_G;
	consensus_letter[3][4][4]=iupac_T;

	consensus_letter[0][1][4]=iupac_M;
	consensus_letter[1][0][4]=iupac_M;
	consensus_letter[0][2][4]=iupac_R;
	consensus_letter[2][0][4]=iupac_R;
	consensus_letter[0][3][4]=iupac_W;
	consensus_letter[3][0][4]=iupac_W;
	consensus_letter[1][2][4]=iupac_S;
	consensus_letter[2][1][4]=iupac_S;
	consensus_letter[1][3][4]=iupac_Y;
	consensus_letter[3][1][4]=iupac_Y;
	consensus_letter[2][3][4]=iupac_K;
	consensus_letter[3][2][4]=iupac_K;
	
	consensus_letter[0][1][2]=iupac_V;
	consensus_letter[0][2][1]=iupac_V;
	consensus_letter[1][0][2]=iupac_V;
	consensus_letter[1][2][0]=iupac_V;
	consensus_letter[2][0][1]=iupac_V;
	consensus_letter[2][1][0]=iupac_V;
	consensus_letter[0][1][3]=iupac_H;
	consensus_letter[0][3][1]=iupac_H;
	consensus_letter[1][0][3]=iupac_H;
	consensus_letter[1][3][0]=iupac_H;
	consensus_letter[3][0][1]=iupac_H;
	consensus_letter[3][1][0]=iupac_H;
	consensus_letter[0][2][3]=iupac_D;
	consensus_letter[0][3][2]=iupac_D;
	consensus_letter[2][0][3]=iupac_D;
	consensus_letter[2][3][0]=iupac_D;
	consensus_letter[3][0][2]=iupac_D;
	consensus_letter[3][2][0]=iupac_D;
	consensus_letter[1][2][3]=iupac_B;
	consensus_letter[1][3][2]=iupac_B;
	consensus_letter[2][1][3]=iupac_B;
	consensus_letter[2][3][1]=iupac_B;
	consensus_letter[3][1][2]=iupac_B;
	consensus_letter[3][2][1]=iupac_B;
}
void init_counts()
{
	for(size_t i=0; i<256; ++i) {
		counts[i][0]=0;
		counts[i][1]=0;
		counts[i][2]=0;
		counts[i][3]=0;
	}
	counts[iupac_A][0]=BASE;
	//A=A
	counts[iupac_C][1]=BASE;
	//C=C
	counts[iupac_G][2]=BASE;
	//G=G
	counts[iupac_T][3]=BASE;
	//T=T
	counts[iupac_U][3]=BASE;
	//U=U=T
	counts[iupac_R][0]=BASE/2;
	counts[iupac_R][2]=BASE/2;
	//R=A, G
	counts[iupac_Y][1]=BASE/2;
	counts[iupac_Y][3]=BASE/2;
	//Y=C, T, U
	counts[iupac_M][0]=BASE/2;
	counts[iupac_M][1]=BASE/2;
	//M=A, C
	counts[iupac_K][2]=BASE/2;
	counts[iupac_K][3]=BASE/2;
	//K=G, T, U
	counts[iupac_W][0]=BASE/2;
	counts[iupac_W][3]=BASE/2;
	//W=T, U, or A
	counts[iupac_S][1]=BASE/2;
	counts[iupac_S][2]=BASE/2;
	//S=C,G
	counts[iupac_B][1]=BASE/3;
	counts[iupac_B][2]=BASE/3;
	counts[iupac_B][3]=BASE/3;
	//B=C, G, T, U (not A)
	counts[iupac_D][0]=BASE/3;
	counts[iupac_D][2]=BASE/3;
	counts[iupac_D][3]=BASE/3;
	//D=A, G, T, U (not C)
	counts[iupac_H][0]=BASE/3;
	counts[iupac_H][1]=BASE/3;
	counts[iupac_H][3]=BASE/3;
	//H=A, C, T, U (not G)
	counts[iupac_V][0]=BASE/3;
	counts[iupac_V][1]=BASE/3;
	counts[iupac_V][2]=BASE/3;
	//V=A, C, G (not T, not U)
	counts[iupac_N][0]=BASE/4;
	counts[iupac_N][1]=BASE/4;
	counts[iupac_N][2]=BASE/4;
	counts[iupac_N][3]=BASE/4;
	//N=A, C, G, T, U

	counts[iupac_a][0]=BASE;
	//A=A
	counts[iupac_b][1]=BASE;
	//C=C
	counts[iupac_g][2]=BASE;
	//G=G
	counts[iupac_t][3]=BASE;
	//T=T
	counts[iupac_u][3]=BASE;
	//U=U=T
	counts[iupac_r][0]=BASE/2;
	counts[iupac_r][2]=BASE/2;
	//R=A, G
	counts[iupac_y][1]=BASE/2;
	counts[iupac_y][3]=BASE/2;
	//Y=C, T, U
	counts[iupac_m][0]=BASE/2;
	counts[iupac_m][1]=BASE/2;
	//M=A, C
	counts[iupac_k][2]=BASE/2;
	counts[iupac_k][3]=BASE/2;
	//K=G, T, U
	counts[iupac_w][0]=BASE/2;
	counts[iupac_w][3]=BASE/2;
	//W=T, U, or A
	counts[iupac_s][1]=BASE/2;
	counts[iupac_s][2]=BASE/2;
	//S=C,G
	counts[iupac_b][1]=BASE/3;
	counts[iupac_b][2]=BASE/3;
	counts[iupac_b][3]=BASE/3;
	//B=C, G, T, U (not A)
	counts[iupac_d][0]=BASE/3;
	counts[iupac_d][2]=BASE/3;
	counts[iupac_d][3]=BASE/3;
	//D=A, G, T, U (not C)
	counts[iupac_h][0]=BASE/3;
	counts[iupac_h][1]=BASE/3;
	counts[iupac_h][3]=BASE/3;
	//H=A, C, T, U (not G)
	counts[iupac_v][0]=BASE/3;
	counts[iupac_v][1]=BASE/3;
	counts[iupac_v][2]=BASE/3;
	//V=A, C, G (not T, not U)
	counts[iupac_n][0]=BASE/4;
	counts[iupac_n][1]=BASE/4;
	counts[iupac_n][2]=BASE/4;
	counts[iupac_n][3]=BASE/4;
	//N=A, C, G, T, U

	score[iupac_A][iupac_A]=BASE;
}


void init_codes()
{
	for(size_t i=0; i<256; ++i) {
		to_code[i]=15;
		from_code[i]=GAP;
	}

	to_code[iupac_A]=0; to_code[iupac_a]=0;
	to_code[iupac_C]=1; to_code[iupac_c]=1;
	to_code[iupac_G]=2; to_code[iupac_g]=2;
	to_code[iupac_T]=3; to_code[iupac_t]=3;

	from_code[0]=iupac_A;
	from_code[1]=iupac_C; 
	from_code[2]=iupac_G; 
	from_code[3]=iupac_T;
	from_code[4]=iupac_U;
	from_code[5]=iupac_R;
	from_code[6]=iupac_Y;
	from_code[7]=iupac_M;
	from_code[8]=iupac_K;
	from_code[9]=iupac_W;
	from_code[10]=iupac_S;
	from_code[11]=iupac_B;
	from_code[12]=iupac_D;
	from_code[13]=iupac_H;
	from_code[14]=iupac_V;
	from_code[15]=iupac_N;
	from_code[16]=GAP;
}

void init_tocapital()
{
	for(size_t  i=0; i<256; ++i) to_capital_ref[i]=GAP;
	to_capital_ref[iupac_A]=iupac_A;
	to_capital_ref[iupac_C]=iupac_C;
	to_capital_ref[iupac_G]=iupac_G;
	to_capital_ref[iupac_T]=iupac_T;
	to_capital_ref[iupac_U]=iupac_U;
	to_capital_ref[iupac_R]=iupac_R;
	to_capital_ref[iupac_Y]=iupac_Y;
	to_capital_ref[iupac_M]=iupac_M;
	to_capital_ref[iupac_K]=iupac_K;
	to_capital_ref[iupac_W]=iupac_W;
	to_capital_ref[iupac_S]=iupac_S;
	to_capital_ref[iupac_B]=iupac_B;
	to_capital_ref[iupac_D]=iupac_D;
	to_capital_ref[iupac_H]=iupac_H;
	to_capital_ref[iupac_V]=iupac_V;
	to_capital_ref[iupac_N]=iupac_N;
	to_capital_ref[GAP]=GAP;
	to_capital_ref[124]=char(124);

	to_capital_ref[iupac_a]=iupac_A;
	to_capital_ref[iupac_c]=iupac_C;
	to_capital_ref[iupac_g]=iupac_G;
	to_capital_ref[iupac_t]=iupac_T;
	to_capital_ref[iupac_u]=iupac_U;
	to_capital_ref[iupac_r]=iupac_R;
	to_capital_ref[iupac_y]=iupac_Y;
	to_capital_ref[iupac_m]=iupac_M;
	to_capital_ref[iupac_k]=iupac_K;
	to_capital_ref[iupac_w]=iupac_W;
	to_capital_ref[iupac_s]=iupac_S;
	to_capital_ref[iupac_b]=iupac_B;
	to_capital_ref[iupac_d]=iupac_D;
	to_capital_ref[iupac_h]=iupac_H;
	to_capital_ref[iupac_v]=iupac_V;
	to_capital_ref[iupac_n]=iupac_N;
	to_capital_ref[GAP]=GAP;
	to_capital_ref[124]=char(124);

	for(size_t  i=0; i<256; ++i) to_capital_read[i]=GAP;
	to_capital_read[iupac_A]=iupac_A;
	to_capital_read[iupac_C]=iupac_C;
	to_capital_read[iupac_G]=iupac_G;
	to_capital_read[iupac_T]=iupac_T;
	to_capital_read[iupac_U]=iupac_U;
	to_capital_read[iupac_R]=iupac_R;
	to_capital_read[iupac_Y]=iupac_Y;
	to_capital_read[iupac_M]=iupac_M;
	to_capital_read[iupac_K]=iupac_K;
	to_capital_read[iupac_W]=iupac_W;
	to_capital_read[iupac_S]=iupac_S;
	to_capital_read[iupac_B]=iupac_B;
	to_capital_read[iupac_D]=iupac_D;
	to_capital_read[iupac_H]=iupac_H;
	to_capital_read[iupac_V]=iupac_V;
	to_capital_read[iupac_N]=iupac_N;
	to_capital_read[GAP]=GAP;
	to_capital_read[124]=GAP;

	to_capital_read[iupac_a]=iupac_A;
	to_capital_read[iupac_c]=iupac_C;
	to_capital_read[iupac_g]=iupac_G;
	to_capital_read[iupac_t]=iupac_T;
	to_capital_read[iupac_u]=iupac_U;
	to_capital_read[iupac_r]=iupac_R;
	to_capital_read[iupac_y]=iupac_Y;
	to_capital_read[iupac_m]=iupac_M;
	to_capital_read[iupac_k]=iupac_K;
	to_capital_read[iupac_w]=iupac_W;
	to_capital_read[iupac_s]=iupac_S;
	to_capital_read[iupac_b]=iupac_B;
	to_capital_read[iupac_d]=iupac_D;
	to_capital_read[iupac_h]=iupac_H;
	to_capital_read[iupac_v]=iupac_V;
	to_capital_read[iupac_n]=iupac_N;
	to_capital_read[GAP]=GAP;
	to_capital_read[124]=GAP;

}


int iupac_compare(const char c1, const char c2)
{
	if (counts[c1][0]*counts[c2][0] + counts[c1][1]*counts[c2][1] + counts[c1][2]*counts[c2][2] + counts[c1][3]*counts[c2][3]!=0)
		return 1;
	else 
		return 0;
}

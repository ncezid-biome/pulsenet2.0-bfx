#include "stdafx.h"
#include "BitIterators.h"

namespace compression{
const  char   InputFileBufferIterator::translateBase_[]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+*";
char   InputFileBufferIterator::translate_[256]="";
}

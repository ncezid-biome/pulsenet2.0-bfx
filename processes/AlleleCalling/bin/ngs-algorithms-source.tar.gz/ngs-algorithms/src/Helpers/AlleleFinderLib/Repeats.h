#pragma once
#include "HashMap.h"
#include "StringDef.h"
#include "PathDef.h"
#include "Contigs.h"



struct AlleleHit {	

	int start, stop;
	double score;

	AlleleHit(size_t istart, size_t istop, double iscore)
		: start(istart), stop(istop), score(iscore) {}

};


class AlleleRepeatMask {
	std::hash_map<Str::ID::Val, std::hash_map<Str::ID::Val, std::vector<AlleleHit>>> masks_;
public:
	AlleleRepeatMask();

	void updateRepeatScore(const Str::ID::Val& locusId, const Str::ID::Val& alleleId, size_t size, size_t start, size_t stop, double score);

	double getRepeatScore(const Str::ID::Val& locusId, double minOverlap);
	double getRepeatCount(const Str::ID::Val& locusId, double percentIdentity) const;
};

class RepeatMask {
	std::hash_map<Str::ID::Val, std::vector<double>> masks_;
public:
	RepeatMask(const Contigs& contigs);

	void updateRepeatScore(	const Str::ID::Val& contigId, size_t start, size_t stop, double score);

	double getRepeatScore(const Str::ID::Val& contigId, size_t start, size_t stop) const;
	double getRepeatCount(const Str::ID::Val& contigId, size_t start, size_t stop, double percentIdentity) const;
};

class BlastAlleleFinderSettings;
namespace engine{
	class ExecuteEnvironment;
}
namespace communication {
	class CalcCommunication;
}

void CreateRepeatMask(
		const Str::Path::Val& fastaFile, 
		RepeatMask& repeatMask, 
		const BlastAlleleFinderSettings& settings, 
		const engine::ExecuteEnvironment& env, 
		const communication::CalcCommunication& comm);

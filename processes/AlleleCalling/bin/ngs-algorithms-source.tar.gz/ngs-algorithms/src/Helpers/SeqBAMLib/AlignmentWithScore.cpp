#include "stdafx.h"
#include "AlignmentWithScore.h"
#include "SAMWrapper.h"
#include "BAMAlignmentEvaluator.h"


namespace SeqBAM
{
namespace Bowtie2Filter
{

AlignmentWithScore::AlignmentWithScore(): score(std::numeric_limits<double>::min()), length(0)
{

}

AlignmentWithScore::AlignmentWithScore(AlignmentWithScore&& other): BAM::Read(std::move(other)), score(other.score), length(other.length)
{
}

AlignmentWithScore& AlignmentWithScore::operator=(AlignmentWithScore&& other)
{
    BAM::Read::operator=(std::move(other));
    std::swap(score, other.score);
    std::swap(length, other.length);
    return *this;
}


void AlignmentWithScore::Evaluate()
{
    AlignScores as;
    if(AlignmentEvaluator(this->read).Evaluate(as)) {

        score = as.sequence_identity();
        length = as.length;
    }

}

int AlignmentWithScore::matchPosition() const
{
    return read->core.pos;
}

}
}
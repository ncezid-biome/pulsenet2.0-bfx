#include "stdafx.h"

#include "runextern_process.h"

#include "debugstr.h"


namespace runextern
{

ProcessStatus::ProcessStatus()
    : failed_pipecreation_(false)
    , failed_creation_(false)
    , failed_priorityclass_(false)
    , failed_jobobject_(false)
    , errcode_(-1)
    , errorText_()
{
}
void ProcessStatus::setFailedToCreatePipes(ErrorCode errcode, const Str::Text::Val& message)
{
    failed_pipecreation_=true;
    errcode_=errcode;
    setErrorText(message);
}
void ProcessStatus::setFailedToStart(ErrorCode errcode, const Str::Text::Val& message)
{
    failed_creation_=true;
    errcode_=errcode;
    setErrorText(message);
}
void ProcessStatus::setFailedToSetPriority(ErrorCode errcode, const Str::Text::Val& message)
{
    failed_priorityclass_=true;
    errcode_=errcode;
    setErrorText(message);
}
void ProcessStatus::setFailedToSetMemoryLimit(ErrorCode errcode, const Str::Text::Val& message)
{
    failed_jobobject_=true;
    errcode_=errcode;
    setErrorText(message);
}
ErrorCode ProcessStatus::getErrorCode() const
{
    return errcode_;
}
bool ProcessStatus::failed() const
{
    return failedToCreatePipes() || failedToStart() || failedToSetPriority() || failedToSetMemoryLimit();
}
bool ProcessStatus::failedToCreatePipes() const
{
    return failed_pipecreation_;
}
bool ProcessStatus::failedToStart() const
{
    return failed_creation_;
}
bool ProcessStatus::failedToSetPriority() const
{
    return failed_priorityclass_;
}
bool ProcessStatus::failedToSetMemoryLimit() const
{
    return failed_jobobject_;
}

/**
    Terminate with exit code 0
*/
void Process::killProcess()
{
    terminate( 0 );
}

} // namespace runextern

#pragma once
#include "CalcCommunication.h"
#include "PathDef.h"
#include "CE_ExecuteEnvironment.h"
#include "srsmapping_settings.h"
#include "srsmapping.h"

namespace SeqBAM
{
class CoverageProvider;
class CoverageStatistics;

MappingFiles MappingOutput(const communication::CalcCommunication& comm, const MappingSettings& settings, const engine::ExecuteEnvironment& env, const Str::Path::Val& bamFile);
MappingFiles MappingOutput(const communication::CalcCommunication& comm, const MappingSettings& settings, const engine::ExecuteEnvironment& env, const Str::Path::Val& bamFile, CoverageStatistics& cs);
MappingFiles MappingOutput(const communication::CalcCommunication& comm, const MappingSettings& settings, const engine::ExecuteEnvironment& env, const Str::Path::Val& bamFile, CoverageProvider& cp);

MappingFiles MappingOutput(const communication::CalcCommunication& comm, const MappingSettings& settings, const engine::ExecuteEnvironment& env, const Str::Path::Val& bamFile, CoverageProvider& cp, CoverageStatistics& cs);
}
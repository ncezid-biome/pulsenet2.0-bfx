#pragma once

#include "FileRotator.h"

#include "CalcCommunication.h"


/**
    Wrapper class for creating/accessing blast databases
*/
class BlastDatabase
{
public:
    BlastDatabase( const Str::Path::Val baseName, const communication::CalcCommunication& comm );

    Str::Path::Val GetCurrentName();
    void           Create( const Str::Path::Val& sequenceFile, const communication::CalcCommunication& comm  );

private:
    FileRotatorExtentions fileRotator_;
};

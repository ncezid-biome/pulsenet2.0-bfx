#include "stdafx.h"
#include <translate.h>
#include <string>
#include <exception.h>
#include <PathDef.h>
#include "BAMFileSorter.h"
#include <SAMToolsLib.h>

namespace BAM
{

void FileSorter::SortFile(const Str::Path::Val& input, const Str::Path::Val& output)
{
	// FIXME failing on Ubuntu 20?!

    bam_sort_core_ext(0, ToRef(input), ToRef(output), maxMem_/threads_, 0, threads_, compression_, 1);

    if(!boost::filesystem::exists(output)
        //check modification time to check if bam_sort_core_ext has even touched the file as it might have existed already
       || boost::filesystem::last_write_time(output)<boost::filesystem::last_write_time(input)) {

        throw KError("Sorting of BAM-file %1 failed") << input;
    }

    //TODO: try to open bam-file?
}

bool FileSorter::IsSorted(const Str::Path::Val& file)
{
    bamFile bam=bam_open(file.string().c_str(), PM("rb"));

    if(bam==nullptr) {

        throw KError("Could not open BAM-file %1") << file;
    }

    bam_header_t* header=bam_header_read(bam);

    if(header==nullptr) {

        bam_close(bam);
        throw KError("Could not read header of BAM-file %1") << file;
    }

    //std::cout << header->text << std::endl;

    bool sorted=std::string(header->text).find("\tSO:coordinate")!=std::string::npos;

    bam_header_destroy(header);
    bam_close(bam);
    
    return sorted;
}

}
#include "stdafx.h"

#include "boost/test/unit_test.hpp"

#include "filewriter.h"
#include "WritableDirectory.h"
#include "TestSequenceFiles.h"
#include "textfile.h"
#include "filereader.h"
#include "filewriter.h"

using namespace test;

/**
    Note: fixture is created for every test (-> dir is cleaned before every test)
*/
struct FileReaderFixture {
    FileReaderFixture()
    {
        Str::Path::Val tmpDir = GetTempDir();

        tinyFasta = tmpDir / "tiny.fasta";
        {
            std::ofstream myfile;
            myfile.open(ToRef(tinyFasta));
            myfile << ">s1\nACTG\n>s22\nGAATCA\n";
        }

        multilineFasta = tmpDir / "multiline.fasta";
        {
            std::ofstream myfile;
            myfile.open(ToRef(multilineFasta));
            myfile << ">empty_teehee\n";
            myfile << ">bbbbonfire\n";
            myfile << "C\nGGATATA\nAACA\nG\n\nA\nG\n\n\nAAACGGGC\nGAATATACCT\nA>TTCGTATCGTATCGGTAA>\nATAGCCTCGCGGAGGCATGTGCC\nATGCTAGCCTGC\nGGAGCACTCT\n";
            myfile << ">empty_again\n";
        }

        normalizeFasta = tmpDir / "normalize.fasta";
        {
            std::ofstream myfile;
            myfile.open(ToRef(normalizeFasta));
            myfile << ">norma\n";
            myfile << "!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\n";
        }

		tinyFastaGz = tmpDir / "tiny.fasta.gz";
        {
			FastaFileWriter writer(tinyFastaGz, true);              
			writer.writeSeq("s1", "ACTG");
			writer.writeSeq("s22", "GAATCA");			
        }
    }

    void ReadTinyFasta(size_t buffsize, const Str::Path::Val& flName)
    {
        seq::NamedSequence seq;
        FastaFileReader reader(flName, buffsize);
		
        BOOST_CHECK(reader.hasMore());
        reader.getNextSeq(seq);
        BOOST_CHECK_EQUAL(seq.GetName(), "s1");
        BOOST_CHECK_EQUAL(seq.GetData().c_str(), "ACTG");		

        BOOST_CHECK(reader.hasMore());
        reader.getNextSeq(seq);
        BOOST_CHECK_EQUAL(seq.GetName(), "s22");
        BOOST_CHECK_EQUAL(seq.GetData().c_str(), "GAATCA");

        BOOST_CHECK(!reader.hasMore());
    }

    Str::Path::Val tinyFasta, tinyFastaGz;
    Str::Path::Val multilineFasta;
    Str::Path::Val normalizeFasta;

    Str::Path::Val GetDataFilePath(const Str::Text::Val& filename)
    {
        //this needs compiler flag /FC to get the full path
        Str::Path::Val thisFile(__FILE__);

        return (thisFile.parent_path() / "Data" / filename);
    }
};


BOOST_FIXTURE_TEST_SUITE( FileReaderTests, FileReaderFixture );

BOOST_AUTO_TEST_CASE(readTinyFasta)
{
    ReadTinyFasta(1000000, tinyFasta);
}

BOOST_AUTO_TEST_CASE(readTinyFasta_SmallBuffers)
{
    for(size_t b = 1; b < 20; b++) {
		
        ReadTinyFasta(b, tinyFasta);
	}
}

BOOST_AUTO_TEST_CASE(readTinyFastaGz_SmallBuffers)
{
    for(size_t b = 1; b < 20; b++) {
		std::cout << b << "\n";
        ReadTinyFasta(b, tinyFastaGz);
	}
}

BOOST_AUTO_TEST_CASE(readMultilineFasta)
{
    seq::NamedSequence seq;
    FastaFileReader reader(multilineFasta, 1);

    BOOST_CHECK(reader.hasMore());
    reader.getNextSeq(seq);
    BOOST_CHECK_EQUAL(seq.GetName(), "empty_teehee");
    BOOST_CHECK_EQUAL(seq.GetData().c_str(), "");

    BOOST_CHECK(reader.hasMore());
    reader.getNextSeq(seq);
    BOOST_CHECK_EQUAL(seq.GetName(), "bbbbonfire");
    BOOST_CHECK_EQUAL(seq.GetData().c_str(), "CGGATATAAACAGAGAAACGGGCGAATATACCTANTTCGTATCGTATCGGTAANATAGCCTCGCGGAGGCATGTGCCATGCTAGCCTGCGGAGCACTCT");

    BOOST_CHECK(reader.hasMore());
    reader.getNextSeq(seq);
    BOOST_CHECK_EQUAL(seq.GetName(), "empty_again");
    BOOST_CHECK_EQUAL(seq.GetData().c_str(), "");

    BOOST_CHECK(!reader.hasMore());
}

BOOST_AUTO_TEST_CASE(readNormalizeFasta)
{
    seq::NamedSequence seq;
    FastaFileReader reader(normalizeFasta, 1);

    //the FASTA reader is supposed to convert all IUPAC bases to upper case and everything else to N

    BOOST_CHECK(reader.hasMore());
    reader.getNextSeq(seq);
    BOOST_CHECK_EQUAL(seq.GetName(), "norma");
                                            //!"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~
    BOOST_CHECK_EQUAL(seq.GetData().c_str(), "NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNABCDNNGHNNKNMNNNNRSTUVWNYNNNNNNNABCDNNGHNNKNMNNNNRSTUVWNYNNNNN");

    BOOST_CHECK(!reader.hasMore());
}

BOOST_AUTO_TEST_CASE(corruptFastq_bug4703_read_triplet)
{
    FastQFileReader reader(GetDataFilePath("corrupt.fastq"));

    BOOST_CHECK(reader.hasMore());
    
    Str::Text::Val name;
    Str::Text::Val seq;
    Str::Text::Val qual;
    reader.getNextSeq(name, seq, qual);

    BOOST_CHECK_EQUAL(name, "read1");
    BOOST_CHECK_EQUAL(seq, "CTTTGTAATGGATCTCTAAATTCAACACCTTTAATGCCTTCAGGTCTTGTTTTCGTCTTTGTT");
    {
        std::string invalidQual("CCDD_CAATGTGCCACAAATTTCACTTTAC");
        invalidQual[4]='\0';
        BOOST_CHECK_EQUAL(qual, invalidQual);
    }

    BOOST_CHECK(reader.hasMore());
    reader.getNextSeq(name, seq, qual);
    BOOST_CHECK_EQUAL(name, "read2");
    BOOST_CHECK_EQUAL(seq, "GTGTAGTTACACAAATTACACCTTGGAATTATCCGTTATTACAAGCATCATGGAAAATTGCGCCAGCGCTTGCTACGGGTTGTTC");
    BOOST_CHECK_EQUAL(qual, "AAAABFFFFFFFGGGGGGGGGGHHHHHHHHHHHHGFHGHGHHHHHHHFHGHHHFHHHIHHHGGGGGGGGGGGHHHHGGGFGGGGH");

    BOOST_CHECK(!reader.hasMore());
}

BOOST_AUTO_TEST_CASE(corruptFastq_bug4703_read_named_seq)
{
    seq::NamedSequence seq;
    FastQFileReader reader(GetDataFilePath("corrupt.fastq"));

    BOOST_CHECK(reader.hasMore());

    reader.getNextSeq(seq);
    BOOST_CHECK_EQUAL(seq.GetName(), "read1");
    BOOST_CHECK_EQUAL(seq.GetData().c_str(), "CTTTGTAATGGATCTCTAAATTCAACACCTTTAATGCCTTCAGGTCTTGTTTTCGTCTTTGTT");
    
    BOOST_CHECK(reader.hasMore());
    reader.getNextSeq(seq);
    BOOST_CHECK_EQUAL(seq.GetName(), "read2");
    BOOST_CHECK_EQUAL(seq.GetData().c_str(), "GTGTAGTTACACAAATTACACCTTGGAATTATCCGTTATTACAAGCATCATGGAAAATTGCGCCAGCGCTTGCTACGGGTTGTTC");

    BOOST_CHECK(!reader.hasMore());
}

BOOST_AUTO_TEST_SUITE_END();

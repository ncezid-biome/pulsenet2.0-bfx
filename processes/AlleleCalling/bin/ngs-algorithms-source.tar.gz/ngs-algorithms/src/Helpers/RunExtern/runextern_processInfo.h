#pragma once

#include "StringDef.h"


namespace runextern
{


class ProcessPriorities
{
public:
    typedef unsigned long Priority;

public:
#ifndef AMGNU
    static const Priority realtime = REALTIME_PRIORITY_CLASS;
    static const Priority high     = HIGH_PRIORITY_CLASS;
    static const Priority normal   = NORMAL_PRIORITY_CLASS;
    static const Priority low      = BELOW_NORMAL_PRIORITY_CLASS;
    static const Priority idle     = IDLE_PRIORITY_CLASS;
#else
    static const Priority normal   = 0;
#endif
};
    

class ProcessInfo
{
private:
    ProcessPriorities::Priority priority_; //priority class of the process 
    int maxmemory_; //maximum amount of memory to be used by the child process
    int expected_runtime_; //some upper limit to the expected runtime
    Str::Text::Val workingDir_;
public:
    ProcessInfo();
    ProcessInfo(const ProcessInfo& other);
    ~ProcessInfo();

    ProcessInfo& operator = (const ProcessInfo& other);

    void setPriority(ProcessPriorities::Priority priority);
    ProcessPriorities::Priority getPriority() const;

    void setMemoryLimit(int megabytes);
    void setMemoryUnlimited();

    bool hasMemoryLimit() const;
    int getMemoryLimit() const;		

    void setExpectedRuntime(int seconds);
    bool hasExpectedRuntime() const;
    int getExpectedRuntime() const;

    void setWorkingDir(Str::Text::Arg workingDir);
    bool hasWorkingDir() const;
    Str::Text::Ref getWorkingDir() const;
};



} // namespace runextern

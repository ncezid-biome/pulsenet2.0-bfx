#include "stdafx.h"

#include "runextern_listener.h"

#include "runextern_UnixDefines.h"


namespace runextern
{


Listener::Listener( Process::Ptr process )
    : process_ ( process )
    , continue_( true )
{
}

/**
    Call this method to listen in the calling thread (-> blocks!)

    \sa startListenThread, stopListenThread
*/
void Listener::listen( Reporter& comm )
{
	clock_t start=clock(), current, previous=start;

	Str::Text::Val line;

	int bytesRead = 0;
    MessageBuffer buffer;
	while(continue_ && comm.Continue() && process_->checkForMessage(buffer, bytesRead))
	{ /* got data */
				
		//check the clock to set the progress
		{
			current=clock();
			if ((current-previous)>500) {				
				handleProgress(current-start, comm);
				previous=current;
			}
		}

		if (!checkMemoryUsage()) {
			handleOutOfMemory(comm);
			continue_=false;
		}
		
		if(bytesRead==-1)
			break; // EOF condition

		buffer.getBuffer()[bytesRead] = char(0);
		// Convert to lines
		char* b = buffer.getBuffer();
		while(true)
		{ /* convert and send */
			/* find out if there was a line feed (end of message) */
			char* p = strchr(b, char(10));
			if(p == NULL)
			{ /* incomplete line */
				line += b;
				break; // leave assembly loop
			} /* incomplete line */
			else
			{ /* complete line */
				int offset = 0;
				if(p - b > 0) { /* get rid of \r */
					if(p[-1] == char(13))
					offset = 1;
				} /* get rid of \r */
				line += Str::Text::Val(b, (p - b) - offset);
				handleMessage(line, comm);
                line.clear();
				b = p + 1;
			} /* complete line */
		} /* convert and send */
	} /* got data */

	if(! line.empty()) 
		handleMessage(line, comm);		

	if (!continue_ || ! comm.Continue()) 
		process_->terminate(ERROR_PROCESS_ABORTED);

	handleEnd(process_->GetErrorCode(), comm);
}

void Listener::SetContinue(bool mustContinue)
{
    continue_ = mustContinue;
}

/**
    Threaded listening

    \sa stopListeningInThread
*/
void Listener::startListeningInThread(Reporter& comm)
{
    SetContinue( true );

    listenThread_.reset( new boost::thread([this, &comm](){ this->listen(comm); }) );
}

/**
    \sa startListeningInThread
*/
void Listener::stopListeningInThread()
{
    SetContinue( false );

    if (! listenThread_->timed_join( boost::posix_time::milliseconds(1000) ) ){
#ifndef AMGNU
        TerminateThread( listenThread_->native_handle(), 0 );
#endif
    }
}


} // namespace runextern

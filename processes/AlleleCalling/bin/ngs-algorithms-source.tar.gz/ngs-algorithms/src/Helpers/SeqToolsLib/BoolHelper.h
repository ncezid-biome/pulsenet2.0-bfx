#pragma once


/**
    Humm, why does this exist?
*/
template<bool Val>
class Bool {
private:
    bool val_;
public: 
    Bool() : val_( Val) {}

    Bool& operator=(bool val) { val_=val; return *this; }
    inline operator bool() const { return val_; }
};

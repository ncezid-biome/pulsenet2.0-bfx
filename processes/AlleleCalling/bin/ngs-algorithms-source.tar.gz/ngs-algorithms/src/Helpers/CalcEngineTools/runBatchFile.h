#pragma once
#include "CalcCommunication.h"
#include "CE_ExecuteEnvironment.h"
#include "PathDef.h"
#include "runextern_application.h"

namespace runextern
{

void RunBatchFile(const communication::CalcCommunication& comm, const Str::Path::Val& workingDir, const BatchFile& batchFile);

}


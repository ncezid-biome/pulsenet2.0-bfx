#pragma once

#include "CE_Logger.h"
#include "CE_Communication.h"
#include "CE_ExecuteEnvironment.h"


namespace engine
{

namespace tools
{
class CommandLine;
} // namespace tools

class OptionalExtraArguments;
class FilesCommunication;

/**
    Base class for calculation engine algorithms.

    Interaction with the outside world in derived classes happens through the
    CalcCommunication instance passed into ExecuteImpl. For a list of available
    messages: see CE_Communication.h.

    Handling of the command line argument is done in xsd::CommandLine, where the
    replacement of the xsd::CommandLine::PLACEHOLDER_RESULTSDIR token by the results
    dir is done. This directory is assumed to always be visible for the job/algorithm
    -> to specify additional input files that were transferred to the engine you can use
    [RESULTSDIR]/my_file_name.
*/
class Algorithm
{
public:
    Algorithm();
    virtual ~Algorithm() {}

    int  Execute( int argc, char* argv[] );
    int  ExecuteThrow( int argc, char* argv[] );

    void SetVerbose();

    boost::shared_ptr<FilesCommunication> CreateFilesCommunication();

protected:
    void PrepareManualRun( const ExecuteEnvironment& env );

private:
    Logger* GetLogger();
    void    LogEnvironment( const ExecuteEnvironment& env, const communication::CalcCommunication& comm ) const;

private:
    // Override to add extra arguments. Should not be needed except for testing purposes!
    virtual void AddOptionalExtraArguments( OptionalExtraArguments& extraArguments ){}

    /**
        Implementations should throw on error, the error is caught and dealt
        with appropriately (error message is set so the scheduler can pick
        it up).

        \param comm The communication object. See the Algorithm documentation for more information.

        \return The return value to be given to the OS (0 on success).
        */
    virtual int ExecuteImpl( int                                     argc,
                             char*                                   argv[],
                             const ExecuteEnvironment&               env,
                             const communication::CalcCommunication& comm ) = 0;

private:
    Logger logger_;
};


} // namespace engine

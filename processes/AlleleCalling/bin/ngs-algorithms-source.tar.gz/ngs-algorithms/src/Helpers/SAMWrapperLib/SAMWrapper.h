#pragma once

#include <SAMToolsLib.h>

#ifndef AMGNU

#ifndef STW_STATIC_LIB
#  ifdef STW_BUILD
#    define STW_DLLPORT __declspec(dllexport)
#  else
#    define STW_DLLPORT __declspec(dllimport)
#  endif
#else
#  define STW_DLLPORT
#endif

#else //ifndef AMGNU

#define STW_DLLPORT

#endif

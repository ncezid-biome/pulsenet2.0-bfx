#include "stdafx.h"
#include "TempFileResolver.h"

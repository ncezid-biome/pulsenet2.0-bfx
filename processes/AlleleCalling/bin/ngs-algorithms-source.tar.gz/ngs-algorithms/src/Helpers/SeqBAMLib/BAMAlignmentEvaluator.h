#pragma once
#include "SAMWrapper.h"
#include "align.h"
#include "BAMCigar.h"

namespace SeqBAM
{

class AlignmentEvaluator
{
public:
    AlignmentEvaluator(bam1_t* read);

    AlignmentEvaluator(const BAM::Cigar::CigarOp* cigar, int ciglen, const char* md);

    bool Evaluate(AlignScores& score);

private:

    void ApplyScore(char op, int len, AlignScores& score) const;

    void ReadCigar();

    void AdvanceCigar();

    bool HasCigarLeft();

    void ParseMD();

    bool AdvanceMD(int dist);

    void ConsumeMDLen();

private:

    int cigar_left;
    const BAM::Cigar::CigarOp* cigar;
    char cigar_op;
    int cigar_len;

    const char* md;
    const char* md_end;
    uint32_t md_len;
    char md_char;
    bool md_left;


};

}
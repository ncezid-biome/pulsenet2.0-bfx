#include "stdafx.h"
#include "Repeats.h"
#include <algorithm>
#include "BlastDatabase.h"
#include "CE_ExecuteEnvironment.h"
#include "translate.h"
#include "Blast.h"
#include "BlastAlleleFinderSettings.h"
#include "IBuffImpl.h"
#include "helper.h"
#include "CalcCommunicationImpl.h"
#include "StringDef.h"


AlleleRepeatMask::AlleleRepeatMask()
{
}
void AlleleRepeatMask::updateRepeatScore(const Str::ID::Val& locusId, const Str::ID::Val& contigId, size_t size, size_t start, size_t stop, double score)
{
	masks_[locusId][contigId].push_back(AlleleHit(start, stop, score));
}
double AlleleRepeatMask::getRepeatScore(const Str::ID::Val& locusId, double minOverlap)
{
	auto it1 = masks_.find(locusId);
	
	if (it1!=masks_.end()) {		
		 
		std::vector<double> allScores;

		for(auto it = it1->second.begin(); it!=it1->second.end(); ++it) {
			//per contig

			std::sort(it->second.begin(), it->second.end(), [](const AlleleHit& hit1, const AlleleHit& hit2) -> bool { return hit1.score>hit2.score; });
            
			std::vector<char> toremove_hits(it->second.size(), 0);
			
			for(size_t i=0; i<it->second.size(); ++i) {
                if (toremove_hits[i]) continue;
                for(size_t j=i+1; j<it->second.size(); ++j) {
                    
					if (toremove_hits[j]) continue;

					if (it->second[j].stop<it->second[i].start || it->second[i].stop<it->second[j].start)
						continue;

					double overlap = (double)std::min(it->second[j].stop, it->second[i].stop) - (double)std::max(it->second[j].start, it->second[i].start);
					double minlen = std::min(it->second[j].stop-it->second[j].start, it->second[i].stop-it->second[i].start);
                    
					if (overlap>=minOverlap*minlen)
                       toremove_hits[j] = 1;
                }
            }

			
			for (size_t j=0; j<toremove_hits.size();++j) {
                if (!toremove_hits[j])
					allScores.push_back(it->second[j].score);
            }

        }

		std::sort(allScores.begin(), allScores.end());

		if (allScores.size()==1)
			return 0.0;
		else
			return allScores[allScores.size()-2];
	}	
	return 0.0;
}



RepeatMask::RepeatMask(const Contigs& contigs)
{
	for(auto it = contigs.begin(); it!=contigs.end(); ++it) {
		masks_[it->first].resize(it->second.GetLength(), 0);
	}
}

void RepeatMask::updateRepeatScore(const Str::ID::Val& contigId, size_t start, size_t stop, double score)
{
	if (start>stop) std::swap(start, stop);
	auto it = masks_.find(contigId);
	if (it!=masks_.end())
		std::replace_if(
			it->second.begin()+start, 
			it->second.begin()+stop, 
			[score](const double& val)->bool { return val<score; },
			score
		);				
}
double RepeatMask::getRepeatScore(const Str::ID::Val& contigId, size_t start, size_t stop) const
{
	if (start>stop) std::swap(start, stop);
	auto it = masks_.find(contigId);
	if (it!=masks_.end() && stop!=start)
		return std::accumulate(it->second.begin()+start, it->second.begin()+stop, 0.0) / (1.0*(stop-start));
	else 
		return 0;
}
double RepeatMask::getRepeatCount(const Str::ID::Val& contigId, size_t start, size_t stop, double percentIdentity) const
{
	if (start>stop) std::swap(start, stop);
	auto it = masks_.find(contigId);
	if (it!=masks_.end() && stop!=start) {
		auto func = [&percentIdentity](double init, double x) -> double { return init+(x>=percentIdentity); };
		return std::accumulate(it->second.begin()+start, it->second.begin()+stop, 0.0, func) / (1.0*(stop-start));
	}
	else 
		return 0.0;
}


void CreateRepeatMask(
		const Str::Path::Val& fastaFile, 
		RepeatMask& repeatMask, 
		const BlastAlleleFinderSettings& settings, 
		const engine::ExecuteEnvironment& env, 
		const communication::CalcCommunication& comm)
{

	//--- create the BLAST database ---------------------------------------------------------------
	Str::Path::Val dbName = env.localDir / PM("blastdb_genome");
	{

		BlastDatabase db(dbName, comm);
		db.Create(fastaFile, comm);
		dbName = db.GetCurrentName();
	}
		
	//--- perform self-blast of the sequence ------------------------------------------------------
	Str::Path::Val outputFile = RunBlast(
			fastaFile, 
			"dc-megablast", 
			dbName,
			settings.maxNHits,
			settings.k,
			settings.percentIdentity,
			settings.reward,
			settings.penalty,
			settings.ungapped,
			settings.gapopen,
			settings.gapextend,
			settings.doDusting,
			env, comm);
	
	//--- interpret the BLAST results -------------------------------------------------------------
	{
        
        comm.Send( communication::CalcMessage("Reading BLAST hits for repeat detection... ") );

        TextFileBuffer is( ToRef(outputFile) );
        is.Open();       
        Str::Text::Val line;
        Str::Text::Vec parts;

		size_t repeatCnt =0, totalCnt = 0;
        while (is.IsOk()) {

            is.ReadLine(line);
            if (line.empty() || line.front() == '#' /*a comment line*/)
                continue;

            splitstring(line, parts, "\t");

            if ( parts.size() != 12 ){
                comm.Send( communication::CalcWarning(RawMessage(PM("Unable to parse BLAST output line: '%1'"), line).c_str()) );
                continue;
            }

            const Str::Text::Val contigId1 = parts[0]; //query id
            const Str::Text::Val contigId2 = parts[1]; //ref id
            double score = ParseThrow<double>(parts[2]);
            int length = ParseThrow<int>(parts[3]); // BLAST alignment length
            const int nmismatches = ParseThrow<int>(parts[4]);
            const int ngapopens = ParseThrow<int>(parts[5]);
            int start = ParseThrow<int>(parts[6])-1; //this is the real starting position
            int stop = ParseThrow<int>(parts[7]); //this is the real ending position
            int refstart = ParseThrow<int>(parts[8])-1;
            int refstop = ParseThrow<int>(parts[9]);
            const double evalue = ParseThrow<double>(parts[10]);
            const int bitscore = atoi(parts[11].c_str());

			if (contigId1==contigId2 && refstart==start && refstop==stop)
				continue;

			if (score > settings.percentIdentity) {
				repeatMask.updateRepeatScore(contigId1, start, stop, score);
				repeatMask.updateRepeatScore(contigId2, refstart, refstop, score);
				repeatCnt+=stop-start;
			}
		}
		comm.Send( communication::CalcMessage(RawMessage(PM("Found %1 bases in repeats!"), repeatCnt).str() ) );
	}	
}
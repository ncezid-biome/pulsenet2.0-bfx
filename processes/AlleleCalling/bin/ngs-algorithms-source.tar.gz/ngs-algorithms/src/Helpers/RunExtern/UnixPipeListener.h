#pragma once

#ifdef AMGNU

#include "UnixPipe.h"

#include "runextern_MessageBuffer.h"


namespace runextern
{


class UnixPipeListener
{
public:
    UnixPipeListener();
    UnixPipeListener( UnixPipe::Ptr readPipe, UnixPipe::Ptr writePipe );
	virtual ~UnixPipeListener() {}

    bool   checkForLine   (MessageBuffer& buffer, int &bytesRead);
    void   sendMessage(Str::Text::Arg message);

    static void sendMessage( UnixPipe::Ptr unixPipe, int message );
    static void sendMessage( UnixPipe::Ptr unixPipe, Str::Text::Arg message );

private:
    bool   checkForMessage(MessageBuffer& buffer, int &bytesRead);

private:
    UnixPipe::Ptr readPipe_;
    UnixPipe::Ptr writePipe_;
};



} // namespace runextern


#endif // #ifdef AMGNU

#pragma once

#include <cstdint>
#include "SAMWrapper.h"
#include "BAMLevelFile.h"
#include <boost/interprocess/mapped_region.hpp>
#include <PathDef.h>

namespace BAM
{

class STW_DLLPORT LevelFileReader: protected LevelFile
{

public:
    LevelFileReader(): data_(nullptr), header_(nullptr), blockHeaders_(nullptr) {};

    void Open(Str::Path::Ref file);
    void Close();

    ReadLevel GetLevelForRead(BamTold bamTold) const;

private:
    LevelFileReader(const LevelFileReader&);
    LevelFileReader& operator=(const LevelFileReader&);

    static int CompareByBlockAddress(const BlockHeader* a, const BlockHeader* b);


private:
    const char* data_;
    const Header* header_;
    const BlockHeader* blockHeaders_;
    boost::interprocess::mapped_region mappedRegion_;
};

}
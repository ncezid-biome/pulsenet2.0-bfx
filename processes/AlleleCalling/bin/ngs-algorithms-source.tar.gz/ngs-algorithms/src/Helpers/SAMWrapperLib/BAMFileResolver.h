#pragma once
#include "PathDef.h"
#include <boost/shared_ptr.hpp>

namespace BAM
{

class FileResolver
{
public:
    typedef boost::shared_ptr<FileResolver> Ptr;
public:
    virtual Str::Path::Val GetSortedBAMFile() const=0;
    virtual Str::Path::Val GetBAMIndexFile() const=0;
    virtual Str::Path::Val GetBAMPileFile() const=0;
    virtual Str::Path::Val GetBAMLevelFile() const=0;

    virtual Str::Path::Val GetReferenceFile() const=0;

    virtual ~FileResolver()
    {
    }

    bool CheckFilesExist()
    {
        using namespace boost::filesystem;

        return exists(GetSortedBAMFile()) && file_size(GetSortedBAMFile())>0 &&
            exists(GetBAMIndexFile()) && file_size(GetBAMIndexFile())>0 &&
            exists(GetBAMPileFile()) && file_size(GetBAMPileFile())>0 &&
            exists(GetBAMLevelFile()) && file_size(GetBAMLevelFile())>0;
    }
};

}
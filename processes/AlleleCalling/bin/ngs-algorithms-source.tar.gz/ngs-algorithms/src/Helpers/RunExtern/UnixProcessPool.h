#pragma once

#ifdef AMGNU

#include "runextern_processPool.h"

#include "UnixProcess.h"


namespace runextern
{


class UnixProcessPool : public ProcessPool
{
public:
    UnixProcessPool();

    virtual UnixProcess* CreateProcess() override;

};


} // namespace runextern

#endif // #ifdef AMGNU

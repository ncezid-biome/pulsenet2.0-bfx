#ifndef LOGGING_FILE_H
#define LOGGING_FILE_H
/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#include <fstream>

#include "strdef.h"
#include "logging.h"
#include "CommunicationFromCalc.h"


class LoggerFromCalcCommunication : public communication::CommunicationFromCalc
{
private:
	size_t nTicks_, currTick_;
    bool mustContinue_;
public:
	LoggerFromCalcCommunication();
	~LoggerFromCalcCommunication();

	virtual  void  TransferInfo(Str::Text::Arg message);
	virtual const volatile bool& MustContinue() const;
	virtual bool CanUseInThread() const;
};

#endif
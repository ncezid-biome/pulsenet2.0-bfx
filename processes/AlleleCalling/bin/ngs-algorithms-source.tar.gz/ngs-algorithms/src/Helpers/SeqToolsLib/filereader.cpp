#include "stdafx.h"
#include "filereader.h"

#include <algorithm>

#include "boost/make_shared.hpp"
#include "boost/algorithm/string/trim.hpp"

#include "logging.h"
#include "intdef.h"
#include "filetools.h"
#include "Message.h"

#include "CalcCommunicationImpl.h"

#include "GzipCompressionType.h"

#include "SequenceInspect.h"
#include "SequenceManip.h"


using namespace seq;
using namespace communication;

/**
    \sa getReaderFactory
*/
void fillReaderFactory()
{
	RegisterFactoryTrait<FastaFileReader>::RegisterItem();
    RegisterFactoryTrait<FastQFileReader>::RegisterItem();
}

/**
    \sa fillReaderFactory
*/
OwnedFactory<SeqFileReader>::Ptr getReaderFactory()
{
    OwnedFactory<SeqFileReader>::Ptr factory = boost::make_shared<OwnedFactory<SeqFileReader>>();

    factory->RegisterPrototype<FastaFileReader>();
    factory->RegisterPrototype<FastQFileReader>();

    return factory;
}


void getline(FileReader& reader, Str::Buffer::Val& line)
{
    reader.getNextLine(line, false);
}

FileReader::FileReader()
	: buffer_(0)
    , bufferend_(0)
    , pos_(0)
    , buffersize_(0)
    , sizeleft_(0)
    , compressedreader_(0)
{
}
FileReader::FileReader(const Str::Path::Val& path, size_t  buffsize)
	: buffer_(0)
    , bufferend_(0)
    , pos_(0)
    , buffersize_(0)
    , sizeleft_(0)
    , compressedreader_(0)
{
	init(path, buffsize);
}
FileReader::~FileReader()
{
	free(buffer_);
}
void FileReader::readSome()
{
	if (compressedreader_) {				
		std::streamsize sizeread = compressedreader_->ReadBuffer(buffer_, buffersize_);			
		if (sizeread>=0) {			
			bufferend_=buffer_+sizeread;
			pos_=buffer_;
			sizeleft_= compressedreader_->HasMore()? 1 : 0; //SizeLeft(ifile_); 
		}
		else {
			pos_ = buffer_;
			bufferend_ = buffer_;
			sizeleft_=0;
		}
	}
	else {
        if (!ifile_.eof()) {
			ifile_.read(buffer_, buffersize_);
            // gcount: number of bytes in read operation
			bufferend_ = buffer_ + ifile_.gcount();
			pos_       = buffer_;
            ASSERT( sizeleft_ >= ifile_.gcount() );
			sizeleft_ -= ifile_.gcount();
		}
		else {
			pos_=0;
			bufferend_=0;
		}
	}
}

void FileReader::init(const Str::Path::Val& path, size_t buffsize)
{	
    filepath_ = path;
	OpenBinary(ifile_, path);

    ResetCompressedReader();


	buffersize_=buffsize;
	if (!ifile_.is_open())
		throw KError("Could not open file %1 for reading.")  << path ;
	

	buffer_=(char*)malloc(buffsize);
	if (buffer_==0)
		throw KError("Could not allocate buffer for reading file %1.") << path;

    prepareForReading();
}

void FileReader::rewind()
{
    ifile_.clear();
    ifile_.seekg(0);

    if ( compressedreader_ ){
        // Have not found a proper way to rewind a compressed reader, tried clear and seekg
        // but does not work
        ResetCompressedReader();
    }

    prepareForReading();
}

size_t FileReader::sizeLeft() const
{
	return SizeLeft(const_cast<std::ifstream&>(ifile_));
}
size_t FileReader::totSize() const
{
	return totsize_;
}
bool FileReader::hasMore() const
{
	return pos_!=bufferend_ || (pos_==bufferend_ && sizeleft_>0);
}
char FileReader::peek() 
{
	if (pos_>=bufferend_ && sizeleft_==0) 
		throw InternalError("Cannot peek beyond the end of the file.");

	if (pos_>=bufferend_ && sizeleft_>0) 
		readSome();

	return *pos_;	
}
void FileReader::read(char* buff, size_t len)
{
	if (len<bufferend_-pos_) {
		memcpy(buff, pos_, len);
		pos_+=len;
	}
	else {
		size_t lenLeft=len - (bufferend_-pos_);
		memcpy(buff, pos_,  bufferend_-pos_);
		
		readSome();

		memcpy(buff+len-lenLeft, pos_,  lenLeft);
		pos_+=lenLeft;
	}
}
void FileReader::skipNextLine() 
{
	//find the next appearance of the delimiter 
	char* end = std::find(pos_, bufferend_, '\n');
	
	if (hasMore() && end==bufferend_) {
		readSome();
		skipNextLine();
	}
	else {
		//set the pos_ pointer right
		pos_=end+1;
	}
}
void FileReader::getNextLine(Str::Buffer::Val& line, bool append)
{
	if (!append) line.clear();

	//find the next appearance of the delimiter 
	char* end = 0;
	if (pos_ && bufferend_) end = std::find(pos_, bufferend_, '\n');
	
	//copy what we found so far to the buffer
	if (end) line.append(pos_, end);

	//set the pos_ pointer right
	if (end==bufferend_) pos_=bufferend_;
	else pos_=end+1;

	if (hasMore() && end>=bufferend_) {
		readSome();
		getNextLine(line, true);
	}
	else {
		//fix the Windows line endings
		if (!line.empty() && line.back()=='\r') line.pop_back();
	}
}

void FileReader::prepareForReading()
{
    totsize_   = SizeLeft(ifile_);
    bufferend_ = 0;
    pos_       = 0;

    // Read some data, the determine the size left. This helps reading empty gzip files: the ReadSome
    // then positions the file pointer at the end (past the gzip header) -> sizeleft_ == 0. Also do before
    // the readSome because it is used for the uncompressed reader.
    sizeleft_ = SizeLeft(ifile_);
    readSome();
	if ( compressedreader_ )
		sizeleft_= compressedreader_->HasMore()? 1 : 0; //SizeLeft(ifile_); 
	else
		sizeleft_ = SizeLeft(ifile_);
}

void FileReader::ResetCompressedReader()
{
    compressedreader_.reset();
    CompressionType::Ptr compression = CompressionType::GetNoThrow( filepath_ );

    if ( compression )
        compressedreader_ = boost::make_shared<CompressedReader>(ifile_, compression);
}

SeqFileReader::SeqFileReader()
{
}
SeqFileReader::SeqFileReader(const Str::Path::Val& path, size_t  buffsize)
	: reader_(path, buffsize)
{
}
SeqFileReader::~SeqFileReader()
{
}
void SeqFileReader::init(const Str::Path::Val& path, size_t  buffsize)
{
	reader_.init(path, buffsize);
}
size_t SeqFileReader::sizeLeft() const
{
	return reader_.sizeLeft();
}
size_t SeqFileReader::totSize() const 
{
	return reader_.totSize();
}
bool SeqFileReader::hasMore() const
{
	return reader_.hasMore();
}

void SeqFileReader::Read( const Str::Path::Val& filename,
                          Id                    filetype,
                          std::vector<seq::NamedSequence>&  sequences,
                          const SequenceReadSettings&       settings,
                          const communication::CalcCommunication& comm )
{
	if (settings.append != DoAppend::Yes)
		sequences.clear();

	SeqFileReader::Ptr reader = SeqFileReader::Factory::GetMap(filetype)->Clone();
	if (reader==0)
		throw KError("Unable to read file of type '%1'.") << filetype;
		
	NamedSequence sequence;
	
	reader->init(filename, 5000000);
	size_t totsize = reader->sizeLeft(), cnt=0;
	Logging::AddProgress(0, 100);
	while(reader->hasMore()) {
		reader->getNextSeq(sequence);

		if (AreAllBasesACGTacgt(sequence.GetData())) {
			if (settings.reverse == DoReverse::Yes && settings.complement == DoComplement::Yes)
                ReverseComplement(sequence.GetData());
			else if (settings.reverse == DoReverse::Yes)
                Reverse(sequence.GetData());
			else if (settings.complement == DoComplement::Yes)
                Complement(sequence.GetData());

			sequences.push_back(std::move(sequence));
		} else {
            comm.Send( CalcWarning(pm("sequence %1 has non-standard bases").arg(cnt)) );
        }

		++cnt;
		if (cnt%1000==0)
            Logging::AddProgress(totsize-reader->sizeLeft(), totsize);
	}
}

SeqFileReaderPtr SeqFileReader::FromFactory(Str::Text::Val filetype, bool dothrow)
{
    auto factory = getReaderFactory();

    boost::trim_if( filetype, boost::is_any_of(PM(".")) );

    SeqFileReaderPtr ptr;
    if ( factory->HasMap(filetype) )
        ptr = factory->GetMap(filetype);

	if (ptr==0 && dothrow) 
		throw KError("Unable to find appropriate reader: unable to read file of type '%1'.") << filetype;
	
	if (ptr) return ptr->Clone();
	else return SeqFileReaderPtr();
}
SeqFileReaderPtr SeqFileReader::AutoDetect(const Str::Path::Val& path, Str::Text::Val filetype, bool dothrow)
{
    try {
        // Make sure the factory is filled
        fillReaderFactory();

        boost::trim_if( filetype, boost::is_any_of(PM(".")) );

        FileReader reader(path);

		SeqFileReaderPtr ptr = 0;
		//reading an empty file
		if (!reader.hasMore()) {
			if (!filetype.empty()) {
				ptr = Factory::GetMap(filetype);
			}
			else {
				ptr = Factory::GetMap(FastaFileReader::GetTypeName());
			}
		}
		//reading a non-empty file
		else {        
			if (!filetype.empty()) {
				SeqFileReaderPtr ptr = Factory::GetMap(filetype);
				if (ptr && !ptr->isRightFileType(reader))
					ptr = 0;
			}

			for (auto it = Factory::Begin(); ptr==0 && it!=Factory::End(); ++it) {
				ptr = Factory::GetMap(*it);
				if (ptr && !ptr->isRightFileType(reader))
					ptr = 0;
			}
		}

        if (ptr==0 && dothrow) 
            throw KError("Autodetect error: unable to read file'%1'.") << path;


        if (ptr)
            return ptr->Clone();
        else
            return SeqFileReaderPtr();

    } catch ( std::exception& e ){        
        if ( dothrow ){
            RawMessage message(PM("Autodetect error: %1 (path: %2, type: %3)"), e.what(), path, filetype);
            throw KError( message.c_str() );
        }
    } catch ( ... ){
        if ( dothrow ){
            throw KError( PM("Autodetect error: unknown error when auto-detecting file type for %1 (type: %2)") )
                << path
                << filetype;
        }
    }

    return SeqFileReaderPtr();
}


FastaFileReader::FastaFileReader()
{
}
FastaFileReader::FastaFileReader(const Str::Path::Val& path, size_t  buffsize)
	: SeqFileReader(path, buffsize)
{
}

void FastaFileReader::getNextSeq(NamedSequence& sequence) const
{
    Str::Text::Val name;
    Str::Text::Val seq;

	if (reader_.hasMore())
        reader_.getNextLine(name, false);
	if (!name.empty())
        name.erase(name.begin());

	seq.clear();
	while(reader_.hasMore() && reader_.peek()!='>')
		reader_.getNextLine(seq, true);

    sequence = NamedSequence(name, seq);
}

void FastaFileReader::getNextSeq(Str::Text::Val& name, Str::Text::Val& seq, Str::Text::Val& qual) const
{	
	if (reader_.hasMore()) reader_.getNextLine(name, false);
	if (!name.empty()) name.erase(name.begin());

	seq.clear(); 
	while(reader_.hasMore() && reader_.peek()!='>')
		reader_.getNextLine(seq, true);

	qual.clear();
}

/**
    A fasta file is a file that has a > as the first character on the first line
*/
bool FastaFileReader::isRightFileType(FileReader& reader) const 
{
    if(reader.peek() == std::ifstream::traits_type::eof()) {
        //an empty file is a valid fasta file
        return true;
    }

    char c[2];	
	c[0] = 0; c[1] = 0;
	reader.read(&c[0], 2);	
	bool isRightType = c[0] == '>';
        
    reader.rewind();

    return isRightType;

	///* a fasta file is a file that is 
	//	not gzip compressed 
	//	has a > as the first character on the first line
	//*/

	//if (!IsGZipped(path))
	//	return false;
	//
	//std::ifstream is(path, std::ios::binary);
	//if (!is.is_open()) 
	//	throw KError("Could not open file %1 for reading.")  << path;

	//CompressedStreamBuffer reader(is, CompressionTypes::gzip);
	//reader.Open();
	//
	//std::string line;

 //   try {

 //       if(reader.IsOk()) {

 //           //file is not empty, check if the content matches our expectations

 //           //>...
 //           //...
 //           
 //           //check first line

 //           if(reader.Peek()=='>') {

 //               //first line is ok
	//            reader.ReadLine(line);

 //               //second line should be non-empty
 //               reader.ReadLine(line);

 //               if(!line.empty()) 
	//				return true;
 //           }
 //       }
 //       else {

 //           //file is empty and a valid compressed stream => right file type!
	//        return true;
 //       }
 //   }
 //   catch(...) {
 //   }

 //   return false;
}

FastaFileReader::Ptr FastaFileReader::Clone() const 
{
    return boost::make_shared<FastaFileReader>();
}


FastQFileReader::FastQFileReader()
{
}

FastQFileReader::FastQFileReader(const Str::Path::Val& path, size_t  buffsize)
	: SeqFileReader(path, buffsize)
{
}

void FastQFileReader::getNextSeq(NamedSequence& sequence) const
{
    Str::Text::Val name;
	readName(name);

    Str::Text::Val seq;
	if (reader_.hasMore())
        reader_.getNextLine(seq, false);

	if (reader_.hasMore())
        reader_.skipNextLine(); //skip the repeated name line
	if (reader_.hasMore())
        reader_.skipNextLine(); //skip the qualities

    sequence = NamedSequence(name, seq);
}

void FastQFileReader::getNextSeq(Str::Text::Val& name, Str::Text::Val& seq, Str::Text::Val& qual) const
{
    readName(name);
	
	if (reader_.hasMore()) reader_.getNextLine(seq, false);

	if (reader_.hasMore()) reader_.skipNextLine(); //skip the repeated name line
	
	if (reader_.hasMore()) reader_.getNextLine(qual, false);
}

/**
  Read the sequence name from the file. This method checks if the line
  starts with @ and proceeds to the next line until it does.
*/
void FastQFileReader::readName(Str::Text::Val& name) const
{
    if(reader_.hasMore()) {

        do {
            reader_.getNextLine(name, false);
        }
        //read next line when either name empty or not starting with @
        while(reader_.hasMore() && ( name.empty() || name[0] != '@' ));
    }

    // Remove first character, should be '@'
    if (!name.empty())
        name.erase(name.begin());
}

/**
    A fastq file is a file that is 
		has a @ as the first character on the first line 
		has a + as the first character on the third line

    We don't require the qualities line to be present, there are files fastq
    files "out there" that do not contain quality information.    
*/
bool FastQFileReader::isRightFileType(FileReader& reader) const
{
	std::string line;
	//get the first line
	getline(reader, line);
	if (line.empty() || line[0]!='@')
		return false;
	//get the second line
	getline(reader, line);
	//get the third line
	getline(reader, line);
	if (line.empty() || line[0]!='+')
		return false;

    reader.rewind();

	return true;
	
	
	//CompressedStreamBuffer reader(is, CompressionTypes::gzip);
	//reader.Open();
	//
	//std::string line;

 //   try {

 //       if(reader.IsOk()) {

 //           //file is not empty, check if the content matches our expectations

 //           //@...
 //           //...
 //           //+
 //           //...

 //           //check first line

 //           if(reader.Peek()=='@') {

 //               //first line is ok
	//            reader.ReadLine(line);

 //               //second line should be non-empty
 //               reader.ReadLine(line);

 //               if(!line.empty()) {

 //                   //check third line

 //                   if(reader.Peek()=='+') {

 //                       //third line is ok
	//                    reader.ReadLine(line);

 //                       //fourth line should be non-empty
	//                    reader.ReadLine(line);
 //                       if(!line.empty())
 //                           return true;
 //                   }
 //               }
 //           }
 //       }
 //       else {

 //           //file is empty and a valid compressed stream => right file type!
	//        return true;
 //       }
 //   }
 //   catch(...) {
 //   }

 //   return false;
}

FastQFileReader::Ptr FastQFileReader::Clone() const 
{
    return boost::make_shared<FastQFileReader>();
}

Str::Text::Val FastQFileReader::GetGZippedExtension()
{
    return Str::Text::Val(GetExtension()) + PM(".") + GzipCompressionType::GetExtension();
}

ThreadSafeFileReader::ThreadSafeFileReader()
	: index_(0)
{
}
//ThreadSafeFileReader::ThreadSafeFileReader(SeqFileReader::Id type, const Str::Path::Val& path, size_t  buffsize, size_t chunkSize)
//	: index_(0), reader_(SeqFileReader::Factory::GetMap(type)->Clone()), chunkSize_(chunkSize)
//{
//	reader_->init(path, buffsize);	
//}
ThreadSafeFileReader::ThreadSafeFileReader(SeqFileReader::Ptr reader, size_t chunkSize)
	: index_(0), reader1_(reader),  chunkSize_(chunkSize)
{
}
ThreadSafeFileReader::ThreadSafeFileReader(SeqFileReader::Ptr reader1, SeqFileReader::Ptr reader2, size_t chunkSize)
	: index_(0), reader1_(reader1), reader2_(reader2), chunkSize_(chunkSize)
{
}
void ThreadSafeFileReader::getNextChunk(Chunk& chunk, const communication::CalcCommunication& comm) const
{	
	ASSERT(reader1_!=nullptr);
	ASSERT(reader2_==nullptr);

	boost::mutex::scoped_lock lock(mutex_);
	size_t cnt =0;
	
	Str::Text::Val name, seq;
	chunk.init(chunkSize_);
	chunk.reset();	
	while (cnt < chunkSize_ && reader1_->hasMore()) {
		chunk.addOne(); ++cnt; 
		reader1_->getNextSeq(chunk.getCurrentName(), chunk.getCurrentSeq(), chunk.getCurrentQual());			
		chunk.getCurrentIdx()=index_;
		++index_;
	}	

	comm.Send( communication::CalcLinearProgress(reader1_->totSize() - reader1_->sizeLeft(), reader1_->totSize()) );
}
void ThreadSafeFileReader::getNextChunk(Chunk& chunk1, Chunk& chunk2, const communication::CalcCommunication& comm) const
{	
	ASSERT(reader1_!=nullptr);
	ASSERT(reader2_!=nullptr);

	boost::mutex::scoped_lock lock(mutex_);
	size_t cnt =0;
	
	Str::Text::Val name, seq;
	chunk1.init(chunkSize_);
	chunk1.reset();	
	chunk2.init(chunkSize_);
	chunk2.reset();	
	while (cnt < chunkSize_ && reader1_->hasMore() && reader2_->hasMore()) {
		chunk1.addOne(); 
		chunk2.addOne();
		reader1_->getNextSeq(chunk1.getCurrentName(), chunk1.getCurrentSeq(), chunk1.getCurrentQual());			
		reader2_->getNextSeq(chunk2.getCurrentName(), chunk2.getCurrentSeq(), chunk2.getCurrentQual());			
		chunk1.getCurrentIdx()=index_;
		chunk2.getCurrentIdx()=index_;
		++cnt; 
		++index_;
	}	

	comm.Send( communication::CalcLinearProgress(reader1_->totSize() - reader1_->sizeLeft(), reader1_->totSize()) );
}

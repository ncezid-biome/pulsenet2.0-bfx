#include "stdafx.h"
#include "Bowtie2DiscriminationFilter.h"
#include "BAMIterator.h"
#include <SAMToolsLib.h>
#include "AlignmentWithScore.h"
#include "BestAlignmentPairFinder.h"
#include "BAMFileType.h"
#include "BestAlignmentFinder.h"

namespace SeqBAM
{

namespace Bowtie2Filter
{

void DiscriminationFilter::Filter(const Str::Path::Val& inputFile, const Str::Path::Val& outputPath)
{
    BAM::Iterator it;
    it.Open(inputFile);

    pruned_ = 0;
    retained_ = 0;

    BAM::FileType outputType = BAM::GetFileType(outputPath);

    bamFile outputFile = bam_open(ToRef(outputPath), BAM::GetTypeWriteMode(outputType));
    bam_header_write(outputFile, it.bamFile_->header);

    AlignmentWithScore first;

    bool cont = first.ReadFrom(it);

    while(cont) {

        if(first.isPairedEnd()) {
            cont = ComparePaired(it, outputFile, first);
        }
        else {
            cont = CompareSingle(it, outputFile, first);
        }
    }

    it.Close();
    bam_close(outputFile);

}

bool DiscriminationFilter::CompareSingle(BAM::Iterator& it, bamFile& outputFile, AlignmentWithScore& first)
{
    bool cont;
    AlignmentWithScore next;

    BestAlignmentFinder f(sett.minSeqId);
    const char* first_name = bam1_qname(*first);

    //add all reads with the same name to the appropriate list
    while((cont = next.ReadFrom(it)) && issame(first_name, bam1_qname(*next))) {

        next.Evaluate();
        f.addSwap(next);
    }

    if(f.distinctPositions() > 0) {

        //only evaluate and add the first read when really needed, i.e. when there was at least one other accepted alignment
        first.Evaluate();
        f.addSwap(first);

        const uint16_t degen = f.distinctPositions();
        const float discr = f.scoreDiscrimination(sett.minSeqId);
        const float score = f.first.score;

        //mark as unmapped if discrimination threshold is not met or if degeneracy is too large
        if(discr < sett.minDiscr || degen > sett.maxDegen) {
            f.first.read->core.pos = -1;
            f.first.read->core.mtid = -1;
            f.first.read->core.flag |= BAM_FUNMAP;

            pruned_++;
        }
        else
            retained_++;

        bam_aux_append(f.first.read, "SC", 'f', sizeof(float), (uint8_t*)&score);
        bam_aux_append(f.first.read, "DI", 'f', sizeof(float), (uint8_t*)&discr);
        bam_aux_append(f.first.read, "DG", 'S', sizeof(uint16_t), (uint8_t*)&degen);
        bam_write1(outputFile, f.first.read);
    }
    else {

        //no alternatives to consider, just write the original thing
        bam_write1(outputFile, first.read);
    }

    std::swap(first, next);

    return cont;
}

bool DiscriminationFilter::ComparePaired(BAM::Iterator& it, bamFile& outputFile, AlignmentWithScore& first)
{
    bool cont;
    AlignmentWithScore next;
    const char* first_name = bam1_qname(*first);

    //add the first read to the appropriate list
    {
        AlignmentWithScore tmp;
        std::swap(tmp, first);

        if(tmp.IsFirstRead())
            first_seg.push_back(std::move(tmp));
        else //if(tmp.IsSecondRead())
            last_seg.push_back(std::move(tmp));
    }

    //add all reads with the same name to the appropriate list
    while((cont = next.ReadFrom(it)) && issame(first_name, bam1_qname(*next))) {

        AlignmentWithScore tmp;
        std::swap(tmp, next);

        if(tmp.IsFirstRead())
            first_seg.push_back(std::move(tmp));
        else //if(tmp.IsSecondRead())
            last_seg.push_back(std::move(tmp));
    }

    //can we form other pair?
    if(first_seg.size() > 1 || last_seg.size() > 1 ) {

        //if so, find the pair with the best score
        BestAlignmentPairFinder f(sett.minSeqId);

        //fill in alignment scores
        for(auto& r : first_seg)
            r.Evaluate();

        for(auto& r : last_seg)
            r.Evaluate();

        //add all possible pairs to the finder
        for(auto& a : first_seg) {

            for(auto& b : last_seg) {

                f.addPair(&a, &b);
            }
        }

        const uint16_t degen = f.distinctPositions();

        if(degen >= 1) {

            const float discr = f.scoreDiscrimination(sett.minSeqId);
            const float score = f.first.score;

            auto a1 = f.first.first->read;
            auto a2 = f.first.second->read;

            //mark as unmapped if discrimination threshold is not met or if degeneracy is too large
            if(discr < sett.minDiscr || degen > sett.maxDegen) {
                a1->core.pos = -1;
                a1->core.mtid = -1;
                a1->core.flag |= BAM_FUNMAP;

                a2->core.pos = -1;
                a2->core.mtid = -1;
                a2->core.flag |= BAM_FUNMAP;

                pruned_++;
            }
            else {

                const int p1 = a1->core.pos;
                const int p2 = a2->core.pos;

                //mark the chose ones as paired ends
                a1->core.mpos = p2;
                a2->core.mpos = p1;

                //update template length: "template length equals the number of bases from the leftmost mapped base to the rightmost mapped base"
                const int leftMost = std::min(p1, p2);
                const int rightMost = std::max(p1 + a1->core.l_qseq, p2 + a2->core.l_qseq);
                const int tlen = rightMost - leftMost;

                if(p1 < p2) {
                    a1->core.isize = tlen;
                    a2->core.isize = -tlen;
                }
                else {
                    a1->core.isize = -tlen;
                    a2->core.isize = tlen;
                }

                retained_++;
            }

            bam_aux_append(a1, "SC", 'f', sizeof(float), (uint8_t*)&score);
            bam_aux_append(a1, "DI", 'f', sizeof(float), (uint8_t*)&discr);
            bam_aux_append(a1, "DG", 'S', sizeof(uint16_t), (uint8_t*)&degen);
            bam_write1(outputFile, a1);
            bam_write1(outputFile, a2);
        }
    }
    else {

        //no alternatives to consider, just write the reads
        for(auto& r : first_seg)
            bam_write1(outputFile, *r);

        for(auto& r : last_seg)
            bam_write1(outputFile, *r);
    }

    first_seg.clear();
    last_seg.clear();

    std::swap(first, next);

    return cont;
}

}

}
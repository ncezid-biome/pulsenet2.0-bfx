#ifndef BLASTALLELEFINDER_H
#define BLASTALLELEFINDER_H

#include "boost/shared_ptr.hpp"
#include "factorycounter.h"
#include "CE_Algorithm.h"


class BlastAlleleFinderSettings;
class BlastAlleleFinderData;

typedef engine::ExecuteEnvironment ExecuteEnvironment;

struct SkippedAllellesInfo
{
    SkippedAllellesInfo();

    int alleleTooShort;
    /** Ref allele does not have start and stop codons */
    int partialMatchAndNoStartStop;
    /** No start-stop hunt -> need 100% overlap */
    int partialMatchAndNoStartStopHunt;
    /** Have start-stop hunt but possible overlap is too small */
    int potentialOverlapTooSmall;
};

class BlastAlleleFinderAlgorithm : public engine::Algorithm
{
public:
    BlastAlleleFinderAlgorithm();

    using engine::Algorithm::Execute;
    int Execute( BlastAlleleFinderSettings& settings, const ExecuteEnvironment& env, const communication::CalcCommunication& comm );

protected:	
	virtual int ExecuteImpl(int argc, char* argv[], const ExecuteEnvironment& env, const communication::CalcCommunication& comm) override;
};


class BlastAlleleFinder : public FactoryPrototypeBase<BlastAlleleFinder>
{
public:
    typedef boost::shared_ptr<BlastAlleleFinder> Ptr;

protected:
	virtual void checkPre(BlastAlleleFinderSettings& settings, BlastAlleleFinderData& data, const ExecuteEnvironment& env, const communication::CalcCommunication& comm) const =0;
	virtual void applyImpl(const BlastAlleleFinderSettings& settings, BlastAlleleFinderData& data, const ExecuteEnvironment& env, const communication::CalcCommunication& comm) const =0;

public:
	BlastAlleleFinder();
	virtual ~BlastAlleleFinder();

	void apply(BlastAlleleFinderSettings& settings, const ExecuteEnvironment& env, const communication::CalcCommunication& comm) const;
	
	static void Apply(BlastAlleleFinderSettings& settings, const ExecuteEnvironment& env, const communication::CalcCommunication& comm);
};

class MegaBlastAlleleFinder : public BlastAlleleFinder, public LeafClassBase<MegaBlastAlleleFinder>
{
public:
    MegaBlastAlleleFinder();

	static FactoryIDType::Ref GetTypeName();
	virtual FactoryIDType::Ref	GetFactoryType() const override;

    static double ReduceScore( double score, const Str::Text::Val& reason, const communication::CalcCommunication& comm );

private:
	virtual void checkPre(BlastAlleleFinderSettings& settings, BlastAlleleFinderData& data, const ExecuteEnvironment& env, const communication::CalcCommunication& comm) const override;
	virtual void applyImpl(const BlastAlleleFinderSettings& settings, BlastAlleleFinderData& data, const ExecuteEnvironment& env, const communication::CalcCommunication& comm) const override;
};


#endif
#include "stdafx.h"

#include <cstdlib>

#include "CE_ExecuteEnvironment.h"

#include "extensionbrowser.h"
#include "osUtil.h"

#include "CE_CommandLine.h"


namespace engine
{


ExecuteEnvironment::ExecuteEnvironment()
    : maxNumThreads_( communication::GetMaxThread() )
    , showhelp      ( false )
{
}

void ExecuteEnvironment::SetMaxNumThreads( int numThreads )
{
    if ( numThreads > 0 )
        maxNumThreads_ = std::min<int>(numThreads, communication::GetMaxThread());
}

int ExecuteEnvironment::GetMaxNumThreads() const
{
    return maxNumThreads_;
}

bool ExecuteEnvironment::HasMaxNumThreads() const
{
    return maxNumThreads_ > 0;
}

//The paths that arrive from the CE have single quotes around them... remove them if needed
Str::Text::Val unquote(Str::Text::Val input) {

    if(input.size()>1 && input[0] == '\'' && input.back() == '\'') {
	    input.erase(0, 1);
	    input.erase(input.size()-1);
    }

    return input;
}

/**
    Update the environment
    Set the local path: use the command line if it was specified there, otherwise use the current
    path
*/
void ExecuteEnvironment::Update(const tools::CommandLine& commandLine)
{
    if ( commandLine.HasLocalDir() )
        localDir = commandLine.GetLocalDir();
    else {
        localDir = boost::filesystem::current_path();

        // Make a subdir. Is cleaner + for HT-Condor it is necessary: all files created in the
        // execute directory are copied back to the working directory (which is the shared
        // drive where we want the results, not the temporary files).
        localDir /= PM("local");

        EnsureExists( ToRef(localDir.string()) );
    }
    resultsDir    = unquote(commandLine.GetResultsDir());
    sharedDir     = unquote(commandLine.GetSharedDir());
    sharedTempDir = unquote(commandLine.GetSharedTempDir());

    if ( commandLine.GetExtraArguments().HasNumThreads() )
        SetMaxNumThreads( commandLine.GetExtraArguments().GetNumThreads() );

    showhelp      = commandLine.GetExtraArguments().MustShowHelp();
}

Str::Text::Val ExecuteEnvironment::GetVariable(Str::Text::Val const & variable) const
{
	auto v = std::getenv(variable.c_str());
	if (v != nullptr)
	{
		return Str::Text::Val(v);
	}
	return Str::Text::Val();
}

} // namespace engine

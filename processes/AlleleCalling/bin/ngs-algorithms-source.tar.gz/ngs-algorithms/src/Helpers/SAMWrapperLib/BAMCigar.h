#pragma once
#include "bam.h"
#include "StringDef.h"
#include <boost/shared_ptr.hpp>

namespace BAM
{
namespace Cigar
{

#pragma pack(push, 1)

//this struct provides easy manipulation of a single CIGAR instruction
typedef struct {

    union {

        struct {
            //sizeof Cigar becomes 5 if we use uint8_t for op, and 6 if we use uint16_t...
            //with op=uint32_t, it is indeed 4
            uint32_t op: 4;
            uint32_t length: 28;

            //also, we assume that this is running on a little-endian machine: low bits go first in the struct
        };

        //we also provide access to raw data
        uint32_t raw;
    };

} CigarOp;

typedef std::vector<CigarOp> CigarOps;

typedef boost::shared_ptr<CigarOp[]> Cigar;

static_assert(sizeof(CigarOp) == 4, "sizeof(CigarOp) should be 4 for correct operation");

#pragma pack(pop)

//the values below correspond to an index in "MIDNSHP=XB"
const uint8_t cigarOpToNibble_[] = {0, 0, BAM_CBACK, 0, BAM_CDEL, 0, 0, 0, BAM_CHARD_CLIP, BAM_CINS, 0, 0, 0, 0, BAM_CREF_SKIP, 0, BAM_CPAD, 0, 0, BAM_CSOFT_CLIP, 0, 0, 0, 0, BAM_CDIFF, 0, 0, 0, 0, BAM_CEQUAL, 0, 0};

//convert any of "MIDNSHP=XB" into the index in said string
inline uint8_t GetNibbleForCigarOp(const char c)
{
    return cigarOpToNibble_[c & 0x1F];
}

CigarOps FromRLEString(Str::Text::Arg cigar);

Str::Text::Val ToRLEString(const CigarOps& cigarOps);

Str::Text::Val ToRLEString(const CigarOp* cigarOps, size_t len);

Str::Text::Val ToRLEString(bam1_t* read);

CigarOps FromLongString(const Str::Text::Val& cigarStr);

CigarOps ForMatch(size_t length);

}
}

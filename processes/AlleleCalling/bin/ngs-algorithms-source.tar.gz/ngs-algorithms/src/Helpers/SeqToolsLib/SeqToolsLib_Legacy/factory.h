/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele
*/

#include <vector>
#include <map>
#include "strdef.h"
#include "stlextens.h"

#ifndef FACTORY_H
#define FACTORY_H

template<class T, class PtrType>
class SeqToolsFactory {
public:
	typedef Str::ID::Val Id;
	typedef std::vector<Id> Ids;
private:
	class Compare {
	public:
		bool operator()(const Id& id1, const Id& id2) const {
			return std_ext::CaseInsensitiveLess()(id1, id2);
		}
	};

	typedef std::map<Id, PtrType, Compare> Map;
	static Map& GetMap() {
		static Map map_;
		return map_;
	}
private:
	SeqToolsFactory() {}
	SeqToolsFactory(const SeqToolsFactory& factory) {};
	SeqToolsFactory& operator =(const SeqToolsFactory& factory) { return *this; };
public:
	static const PtrType Get(const Id& id) {
		Map& map(GetMap());
		typename Map::const_iterator it = map.find(id);
		if (it==map.end()) return 0;
		else return it->second;
	}
	static void GetList(Ids& ids) {
		ids.clear();
		Map& map(GetMap());
		for (typename Map::const_iterator it=map.begin(); it!=map.end(); ++it)
			ids.push_back(it->first);
	}

	static void Register(PtrType ptr) {
		Map& map(GetMap());
		if (map.find(ptr->getFactoryId())==map.end())
			map[ptr->getFactoryId()]=ptr;
	}
	
	template<class Concrete>
	static void Register() {
		PtrType ptr = Concrete().clone();
		Register(ptr);
	}
};

template<class T, class PtrType = boost::shared_ptr<T>>
class Prototype {
public:
	typedef typename SeqToolsFactory<T, PtrType>::Id Id;
    typedef PtrType  PrototypePtr;
public:
	Prototype() {}
	virtual ~Prototype() {}

	virtual Id getFactoryId() const =0;
	virtual PtrType clone() const =0;

	typedef SeqToolsFactory<T, PtrType> Factory;
	static PtrType FromFactory(Id id) {
		const PtrType ptr = Factory::Get(id);
		if (ptr==0) return 0;
		else return ptr->clone();
	}
};

template<class T>
class PrototypeAdder {
public:
	PrototypeAdder() {
		T::Factory::Register(T().clone());
	}
	~PrototypeAdder() {}
};

#endif
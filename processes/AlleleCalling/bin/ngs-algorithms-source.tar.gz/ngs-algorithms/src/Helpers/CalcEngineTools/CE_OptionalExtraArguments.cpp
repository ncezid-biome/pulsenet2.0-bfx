#include "stdafx.h"

#include "CE_OptionalExtraArguments.h"

#include "debugstr.h"

#include "CE_FileSystem.h"


namespace engine
{

OptionalExtraArguments::OptionalExtraArguments()
    : options_      ()
    , numThreads_   ( 0 )
    , localDir_     ()
    , ishelp_       ( false )
    , printVersion_ ( false )
{
    Init();
}

void OptionalExtraArguments::Init()
{
    namespace po = boost::program_options;

    options_.add_options()
        ( PM("version,v"),
          PM("Print version info, then exit.") )
        ( PM("help"),
          PM("Print help message, then exit.") )
        ( PM("nThreads"), po::value<int>(&numThreads_),
          PM("Maximum number of threads for this process (0: unlimited).") )
        ( PM("localdir"),  po::value<Str::Text::Val>(&localDir_),
          PM("The algorithm run directory") )
        ;
}

void OptionalExtraArguments::AddOptions(boost::program_options::options_description& options)
{
    options_.add( options );
}

void OptionalExtraArguments::Parse(int argc, char* argv[])
{
    namespace po = boost::program_options;

    po::variables_map vm;
    // Need the allow_unregistered: we only parse a small subset of the command line here
    po::store( po::command_line_parser(argc, argv).options(options_).allow_unregistered().run(), vm);
    po::notify(vm);
    
    sanitizePath( localDir_ );

    ishelp_       = vm.count( PM("help") );
    printVersion_ = vm.count( PM("version") );
}

int OptionalExtraArguments::GetNumThreads() const
{
    return numThreads_;
}

bool OptionalExtraArguments::HasNumThreads() const
{
    return numThreads_ > 0;
}

bool OptionalExtraArguments::HasLocalDir() const
{
    return ! localDir_.empty();
}

Str::Text::Val OptionalExtraArguments::GetLocalDir() const
{
    return localDir_;
}

bool OptionalExtraArguments::PrintVersion() const
{
    return printVersion_;
}

bool OptionalExtraArguments::MustShowHelp() const
{
    return ishelp_;
}


} // namespace engine

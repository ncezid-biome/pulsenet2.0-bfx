#include "stdafx.h"

#include "LocusOutput.h"


#define nodeType_info PM("info")
#define nodeType_valid PM("valid")

template<class T>
void AddNode(XmlBlock& parent, Str::ID::Arg tag, Str::ID::Arg type, const T& val)
{
    XmlBlock n = AddXmlBlock(parent, tag);
    ToXmlAttr(n, PM("type"), type);
    ToXmlAttr(n, PM("val"), val);
}


LocusOutput::LocusOutput()
{
}
LocusOutput::~LocusOutput()
{
}
void LocusOutput::addLocus(const Locus& locus)
{
    loci_[locus.locus]=locus;
}
void LocusOutput::addAllele(Str::Text::Arg locus, const Allele& allele)
{
    loci_[Str::Text::Val(locus)].alleles.push_back(allele);
}
void LocusOutput::toXml(XmlBlock& root) const
{
    for (auto it = loci_.begin(); it!=loci_.end(); ++it) {

        const Locus& locus = it->second;

        //block for the locus
        XmlBlock n = AddXmlBlock(root, PM("l"));
        {
            // block for the name
            ToXml(n, PM("id"), locus.locus);

            //block for the alleles
            XmlBlock n1 = AddXmlBlock(n, PM("as"));
            for (size_t i=0 ;i<locus.alleles.size(); ++i) {

                const Allele& allele = locus.alleles[i];

                if (allele.id!=-1) {
                    //block for one allele
                    XmlBlock n2 = AddXmlBlock(n1, PM("a"));
                    {
                        //allele id
                        ToXml(n2, PM("id"), allele.id);
                        //allele scores
                        if (allele.kwCoverage!=-1) AddNode(n2, PM("kwc"), nodeType_valid, allele.kwCoverage);							
                        if (allele.sequenceIdentity!=-1) AddNode(n2, PM("si"), nodeType_valid, allele.sequenceIdentity);
                        if (allele.eValue!=-1) AddNode(n2, PM("ev"), nodeType_valid, allele.eValue);
                        if (allele.bitScore!=-1) AddNode(n2, PM("bs"), nodeType_valid, allele.bitScore);
                        if (allele.nonACGT!=-1) AddNode(n2, PM("no"), nodeType_valid, allele.nonACGT);
                        //allele alignment
                        if (!allele.contigId.empty()) {
                            AddNode(n2, PM("start"), nodeType_info, allele.start);
                            AddNode(n2, PM("stop"), nodeType_info, allele.stop);
							AddNode(n2, PM("rs"), nodeType_valid, allele.repeatScore);
                            AddNode(n2, PM("al"), nodeType_valid, allele.alignmentLength);
                            AddNode(n2, PM("fwd"), nodeType_info, allele.fwd);
                            AddNode(n2, PM("cid"), nodeType_info, allele.contigId);
                            AddNode(n2, PM("nm"), nodeType_valid, allele.nMismatches);
                            AddNode(n2, PM("ngo"), nodeType_valid, allele.nGapOpens);
                            AddNode(n2, PM("rss"), nodeType_valid, allele.requiresStartStop?"Y":"N");
                            AddNode(n2, PM("bc"), nodeType_valid, allele.startsWithStart?"Y":"N");
                            AddNode(n2, PM("ec"), nodeType_valid, allele.stopsWithStop?"Y":"N");
                            AddNode(n2, PM("fl"), nodeType_valid, allele.fullLength?"Y":"N");
                            AddNode(n2, PM("is"), nodeType_valid, allele.hasInternalStop?"Y":"N");
                        }
                        //allele sequences
                        if (!allele.sequence.empty()) ToXml(n2, PM("s"), allele.sequence);
                        if (!allele.seqBefore.empty()) ToXml(n2, PM("sb"), allele.seqBefore);
                        if (!allele.seqAfter.empty()) ToXml(n2, PM("sa"), allele.seqAfter);
                    }
                }
            }
        }
    }
}
void LocusOutput::toString(Str::Text::Val& xml) const
{
    XmlBlock root = NewXmlBlock(PM("loci"));
    toXml(root);
    XmlBlockToStr(root, xml);
}
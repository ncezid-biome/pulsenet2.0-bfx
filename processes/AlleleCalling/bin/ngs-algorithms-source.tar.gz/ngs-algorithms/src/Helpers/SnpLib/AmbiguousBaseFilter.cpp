#include "stdafx.h"

#include "AmbiguousBaseFilter.h"

#include "Message.h"

#include "CoverageStats.h"
#include "GlobalSnpActivity.h"
#include "SnpSequenceSnpData.h"
#include "SnpAnalysisCache.h"

#include <HashMap.h>
#include "boost/make_shared.hpp"


namespace snp
{


AmbiguousBaseFilterSettings::AmbiguousBaseFilterSettings()
    : options::VertOptionGroup(TXT(""), TXT(""), PM(""), PM("AmbiguousBaseFilterSettings"))
    , maxfreq(PM("ambiguousbase_maxfreq"), TXT("Maximum frequency"), TXT(""), 0, PM("2015-06-18"), PM("%"), this)
	, useRealBasesAnalysis(PM("ambiguousbase_useRealBasesAnalysis"), TXT("Take into account transitional bases"), TXT(""), false, PM("2017-05-05"), this)
{
}


AmbiguousBaseFilter::AmbiguousBaseFilter()
    : settings_()
{
}


SequencesSnpsActivePtr AmbiguousBaseFilter::FilterSNPs(const SNPAnalysisCache& cache, const SnpFilterDataList&, const communication::CalcCommunication&) const 
{
    // gaps (-) are not considered ambigous. So ambiguous bases are anything that's not an A, C, G, T, nor a gap.

    const SequenceCoverageStats& coveragestats = cache.GetCoverageStats();

    const size_t numEntries = coveragestats.GetNumActiveEntries();
    const size_t maxAmbiguous = static_cast<size_t>(std::max(floor(numEntries * settings_.maxfreq / 100.), 0.));
	bool useRealBasesAnalysis  = settings_.useRealBasesAnalysis;

	std::hash_map<char, std::string> toCheck;
	{
		toCheck['R']="AG";
		toCheck['Y']="CT";
		toCheck['S']="GC";
		toCheck['W']="AT";
		toCheck['K']="GT";
		toCheck['M']="AC";
		toCheck['B']="CGT";
		toCheck['D']="AGT";
		toCheck['H']="ACT";
		toCheck['V']="ACG";
		toCheck['N']="ACGT";
	}

    auto snpsactive = boost::make_shared<GlobalSnpActivity>(coveragestats.coverage.size());	

	std::vector<size_t> index(numEntries, 0);
	std::vector<char> allCalls(numEntries, 0);
    for ( size_t ibase = 0; ibase < coveragestats.coverage.size(); ++ibase )
    {
		assert(coveragestats.coverage[ibase].GetTotal() == numEntries);

		
		size_t cntRealBases = 0;
		if (useRealBasesAnalysis) {
			
			for (size_t iseq=0; iseq<numEntries; ++iseq) {
				if (index[iseq]>=cache.GetSequenceSNPs()[iseq].size() || cache.GetSequenceSNPs()[iseq].positions[index[iseq]]>ibase) {
					allCalls[iseq] = cache.GetReference().sequence[ibase];
				}
				else {
					assert(cache.GetSequenceSNPs()[iseq].positions[index[iseq]]==ibase);
					allCalls[iseq] = cache.GetSequenceSNPs()[iseq].seqdata[index[iseq]];
					index[iseq] += 1;
				}
			}

		
			//check how many unreal bases we have here
			hash_set<char> chars;
			for(size_t iseq=0; iseq<numEntries; ++iseq) {
				chars.insert(allCalls[iseq]);
			}
			chars.insert(cache.GetReference().sequence[ibase]);
		
			for(size_t iseq=0; iseq<numEntries; ++iseq) {
				char call = allCalls[iseq];

				if (call=='A' || call=='C' || call=='G' || call=='T') 
					cntRealBases+=1;
				else {
					auto rule = toCheck.find(call);
					if (rule!=toCheck.end()) {
						bool allThere = true;
						for (char b: rule->second) {
							allThere &= (chars.find(b)!=chars.end());
						}
						cntRealBases+=allThere;
					}
				}
			}
		}		
		else {
			cntRealBases = numEntries-coveragestats.coverage[ibase].GetAmbiguous();
		}
		        
       if ( (numEntries-cntRealBases) > maxAmbiguous) {
            snpsactive->DeactivatePosition(ibase);
        }
    }

    return snpsactive;
}


Str::Text::Val AmbiguousBaseFilter::GetDisplayName() const 
{
    return TXT("Ambiguous bases");
}


Str::Text::Val AmbiguousBaseFilter::GetShortInfo() const 
{
    const int maxfreq = settings_.maxfreq;
    if ( maxfreq <= 0)
    {
        return TXT("Remove positions with at least one ambiguous base.");
    }
    if ( maxfreq >= 100 )
    {
        return TXT("Positions may have any number of ambiguous bases.");
    }
    return tr("Remove positions with more than %1% ambiguous bases.").arg( maxfreq );
}


Str::Text::Val AmbiguousBaseFilter::GetDescription() const 
{
    return TXT("Remove SNP positions that have too many ambiguous bases (non-ACGT nor gaps) across all experiments.");
}


Str::Text::Val AmbiguousBaseFilter::GetSnpDisplayInfo(const SnpCache& snp, int, const SNPAnalysisCache& cache, const SnpFilterData& filterData) const 
{
    return GetPositionDisplayInfo(snp.position, cache, filterData);
}


Str::Text::Val AmbiguousBaseFilter::GetPositionDisplayInfo(SnpPosition position, const SNPAnalysisCache& cache, const SnpFilterData&) const
{
    const SequenceCoverageStats& coveragestats = cache.GetCoverageStats();
    const BaseCoverageStats& stat = coveragestats.coverage[position];

    const size_t numEntries = coveragestats.GetNumActiveEntries();
    assert(stat.GetTotal() == numEntries);
    if ( numEntries <= 0 )
    {
        return PM("--");
    }

    const size_t numAmbiguous = stat.GetAmbiguous();
    return pm("%1% (%2/%3) ambiguous")
        .arg(static_cast<size_t>(ceil((100. * numAmbiguous) / numEntries)))
        .arg(numAmbiguous)
        .arg(numEntries);
}


/**
    Sorting: numNonIupacOrNotAllowed first, then numIupacAllowed
*/
double AmbiguousBaseFilter::GetSnpSortValue(const SnpCache& snp, int, const SNPAnalysisCache& cache, const SnpFilterData& filterData) const 
{
    return GetPositionSortValue(snp.position, cache, filterData);
}


double AmbiguousBaseFilter::GetPositionSortValue(SnpPosition position, const SNPAnalysisCache& cache, const SnpFilterData&) const 
{
    const SequenceCoverageStats& coveragestats = cache.GetCoverageStats();
    const BaseCoverageStats& stat = coveragestats.coverage[position];
    const size_t numEntries = coveragestats.GetNumActiveEntries();
    return stat.GetAmbiguous();
}

Str::Text::Val AmbiguousBaseFilter::GetTypeID() const 
{
    return GetTypeName();
}


AmbiguousBaseFilterSettings* AmbiguousBaseFilter::GetOptions()
{
    return &settings_;
}


SNPFilter* AmbiguousBaseFilter::Clone() const 
{
    return new AmbiguousBaseFilter();
}


FilterCategory AmbiguousBaseFilter::GetCategory() const 
{
    return FilterCategory::Any;
}


Str::Text::Val AmbiguousBaseFilter::GetTypeName()
{
    return PM("AmbiguousBaseFilter");
}

} // namespace snp

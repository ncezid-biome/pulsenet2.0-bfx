#include "stdafx.h"

#include "BlastAlleleFinderSettings.h"

#include <fstream>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>
#include "exception.h"
#include "CalcCommunication.h"
#include "CalcCommunicationImpl.h"

#include "CE_FileSystem.h"
#include "CE_ExecuteEnvironment.h"

#include "helper.h"
#include <boost/regex.hpp>


#define OPTION_HELP "help"
#define OPTION_SETTINGSFILE "settingsFile"
#define OPTION_CLIENTVERSION "clientVersion"


BlastAlleleFinderSettings::BlastAlleleFinderSettings()
	: engine::ProgramOptions("Assembly-based allele finder")
	, organismsettings(true)
    , algorithmType         ( PM("MegaBlast") )
    , k                     ( -1 )
    , maxNHits              ( 1000000 )
    , reward                (  2 )
    , penalty               ( -3 )
    , ungapped              ( false )
    , gapopen               ( 5 )
    , gapextend             ( 2 )
    , percentIdentity       ( 70 )
    , lengthOverlap         ( 0.7 )
	, hitOverlap			( 0.1 )
    , huntForStartStop      ( true )
    , extraBasesForStartStop( 18 )
    , extrapolateAlignment  ( true )
	, doDusting				( true )
	, doRepeatMasking		(true)
	//, percentIdentityRepeatMasking  (0.9)
	//, absOverlapRepeatMasking		(150)
	//, repeatScoreThreshold			(0.5)
    , clientVersion( 1 ) // only first generation clients don't specify version, so that's version 1
{
    //add the generic options
    AddOption("algorithm", "BLAST identification algorithm", algorithmType, algorithmType);
    AddOption("dataDir", "data destination directory", destDataDir);
    AddOption("query", "query sequences", sequenceFile);
	AddOption("db", "blast database", database_);
	AddOption("alleleInfo", "allele info file", alleleInfoFile_);
	AddOption("k", "keyword size (if set to -1, the default value is used)", k, k);
	AddOption("maxNHits", "maximum number of hits", maxNHits, maxNHits);
	AddOption("reward", "match score", reward, reward);
	AddOption("penalty", "mismatch score", penalty, penalty);
	AddOption("ungapped", "allow gapped alignment", ungapped, ungapped);
	AddOption("gapopen", "gap open cost", gapopen, gapopen);
	AddOption("gapextend", "gap extend cost", gapextend, gapextend);
	AddOption("percentIdentity", "percent identity (0-1)", percentIdentity, percentIdentity);
    AddOption("relAlignmentLength", "relative alignment length", lengthOverlap, lengthOverlap);
	AddOption("relOverlap", "relative overlap", hitOverlap, hitOverlap);
    AddListOption("startCodon", "start codons", startCodons);
	AddListOption("stopCodon", "stop codons", stopCodons);
	AddOption("huntForStartStop", "hunt for start and stop codons", huntForStartStop, huntForStartStop);
	AddOption("extraBasesForStartStop", "extra bases to hunt for start and stop codons", extraBasesForStartStop, extraBasesForStartStop);
	AddOption("extrapolateAlignment", "extrapolate alignment to predict start and stop position", extrapolateAlignment, extrapolateAlignment);
	AddOption("doDusting", "perform dusting procedure to mask low-complexity regions", doDusting, doDusting);
	AddOption(OPTION_CLIENTVERSION, "client version", strClientVersion, Str::Text::Val());
	AddOption("acceptedAlleles", "rotating link file to sequence files with accepted alleles", acceptedAllelesFile_);
	AddOption("doRepeatMasking", "peform repeat masking", doRepeatMasking, doRepeatMasking);

	//add the organism settings
	AddProgramOptions(organismsettings);

	//call this to add start codons and stop codons of they are not there
    Init();
}

bool BlastAlleleFinderSettings::ParseAndSetup(int argc, char* argv[], const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm)
{

	bool showHelp = ParseCmdLine(argc, argv, env, comm);

	if(!strClientVersion.empty()) {

        //proudly contributing to the ever-growing pile of WTFs that is related to the command line clusterfuck
        strClientVersion = boost::regex_replace(strClientVersion, boost::regex("[^0-9]"), "");

        size_t parsedVersion;
        if(Parse(strClientVersion, parsedVersion) && parsedVersion > 0)
            clientVersion = parsedVersion;
    }
    
    Finalize();

    //true = everything ok, false = show the help stuff
    return !showHelp;
	}

void BlastAlleleFinderSettings::LoadEnvSettingsImpl(const EnvSettings& envSettings, const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm)
{
	Str::Text::Val strStartCodons;
	for(size_t i=0; i<startCodons.size(); ++i) { //startCodons is not empty, filled in with defaults at end of constructor due to call to Init()
		if (i>0) strStartCodons+=',';
		strStartCodons+=startCodons[i];
	}

	Str::Text::Val startCodonsSetting = envSettings.get("StartCodons", strStartCodons);
	splitstring(startCodonsSetting, startCodons, ",");

	//load the hunt for start/stop from environment
	huntForStartStop = envSettings.get("huntForStartStop", std::string("1"))=="1";
}

void BlastAlleleFinderSettings::Finalize()
{
    // Sanitize the paths
    sanitizePath( destDataDir     );
    sanitizePath( sequenceFile    );
    sanitizePath( database_       );
    sanitizePath( alleleInfoFile_ );
    sanitizePath( acceptedAllelesFile_ );
}

void BlastAlleleFinderSettings::SetData(const Str::Path::Val& database, const Str::Path::Val& alleleInfoFile, const Str::Path::Val& acceptedAllelesFile )
{
    database_            = database.string();
    alleleInfoFile_      = alleleInfoFile.string();
    acceptedAllelesFile_ = acceptedAllelesFile.string();

    Finalize();
}

void BlastAlleleFinderSettings::Init()
{
    if (startCodons.empty()) {
        startCodons.push_back(PM("ATG"));
        startCodons.push_back(PM("GTG"));
        startCodons.push_back(PM("TTG"));
    }                                  
    if (stopCodons.empty()) {
        stopCodons.push_back(PM("TAG"));
        stopCodons.push_back(PM("TAA"));
        stopCodons.push_back(PM("TGA"));
    }
}


Str::Text::Val BlastAlleleFinderSettings::GetOrganismFromAlleleInfoPath() const
{
	/*
	we expect the allele info file to be at 
		/storage/flavours/dev/shared/test_hannes/CAMP/alleleinfo.txt
	this corresponds to 
		[SHAREDDIR] / [ORGANISM ABBREVIATION] / alleleinfo.txt
	hence the parsing below
	*/


	if (alleleInfoFile_.empty())
		return PM("");

	return Str::Path::Val(alleleInfoFile_).parent_path().filename().string();
}

BlastAlleleFinderData::BlastAlleleFinderData(const BlastAlleleFinderSettings& settings, const communication::CalcCommunication& comm)
    : alleleInfoFile_( settings.alleleInfoFile_, comm )
    , database_      ( settings.database_, comm )
    , defaultAcceptedAllelesFile_ ( Str::Path::Val(settings.alleleInfoFile_).parent_path() / "acceptedalleles.fasta", comm )
    , databaseName_  ()
{
    if ( !settings.acceptedAllelesFile_.empty() )
    {
        acceptedAllelesFile_.reset(new AlleleSequencesFile( settings.acceptedAllelesFile_, comm ));
    }

    databaseName_ = database_.GetCurrentName();
}

/**
    \return The blast database name, this is the blast database that was active when
            this instance was created (ignoring later link file rotations).
*/
Str::Path::Val BlastAlleleFinderData::GetBlastDatabaseName() const
{
    return databaseName_;
}

Str::Path::Val BlastAlleleFinderData::GetAlleleFileName() const
{
    return alleleInfoFile_.GetFilename();
}

Str::Path::Val BlastAlleleFinderData::GetAcceptedAlleleFileName() const
{
    if (acceptedAllelesFile_)
    {
        return acceptedAllelesFile_->GetFilename(); // since it was passed explicitly, we demand it exists.
    }
    try
    {
        return defaultAcceptedAllelesFile_.GetFilename();
    }
    catch (const KError&) 
    {
        // we're more forgiving for the default file location. If it doesn't exit, we'll skip it silently.
        return Str::Path::Val();
    }
}


#include "stdafx.h"

#include "JobObject.h"

#include "runextern_process.h"
#include "WindowsProcess.h"
#include "mathHelp.h"


namespace runextern
{

JobObject::JobObject()
    : jobhandle_()
{
    CreateHandle( nullptr );
}

/**
    Create a JobObject with identifier \a jobName. Creating a JobObject instance with an existing
    name will results in both JobObject instances being the same for all practical consequences.

    If you want to reuse a JobObject you can thus either store a JobObject or store the 
    name and use this constructor over and over.
*/
JobObject::JobObject(const JobName& jobName)
    : jobhandle_()
{
    CreateHandle( ToRef(jobName) );
}

/**
    Can fail if we are not allowed to create new job objects (e.g. in a citrix environment) or
    if the setting of the memory limit itself fails.
*/
bool JobObject::SetMaxMemory(int maxMemoryMB, ProcessStatus& status)
{
    if ( ! WindowsProcess::CanCreateJobObject() )
        return false;

    //figure out how many bytes to use
    SIZE_T maxmemory; 
    {
        unsigned __int64 maxmemory64 = maxMemoryMB;
        maxmemory64 *= 1024*1024;
        unsigned __int64 maxint = std::numeric_limits<SIZE_T>::max();
        if(maxmemory64>maxint)
            maxmemory=ncast<SIZE_T>(maxint-1);
        else
            maxmemory=ncast<SIZE_T>(maxmemory64);

        if (maxmemory<0.8*std::numeric_limits<unsigned __int64>::max()) {
            maxmemory+=ncast<SIZE_T>(0.1*maxmemory);
        }
    }	

    //create the information object
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limitinfo;
    ::ZeroMemory(&limitinfo, sizeof(limitinfo));
    limitinfo.BasicLimitInformation.LimitFlags=JOB_OBJECT_LIMIT_JOB_MEMORY|JOB_OBJECT_LIMIT_PROCESS_MEMORY;
    limitinfo.ProcessMemoryLimit=maxmemory;
    limitinfo.JobMemoryLimit=maxmemory;

    //load the information into the job
    if ( ! SetInformationJobObject(
                jobhandle_,
                JobObjectExtendedLimitInformation,
                &limitinfo,
                sizeof(JOBOBJECT_EXTENDED_LIMIT_INFORMATION)) ) {
        status.setFailedToSetMemoryLimit(GetLastError(), WindowsProcess::getLastErrorText());
        return false;
    }

    return true;
}

bool JobObject::AssignProcess(ProcessPtr process, ProcessStatus& status)
{
    if ( ! AssignProcessToJobObject(jobhandle_, process) ) {
        status.setFailedToSetMemoryLimit(GetLastError(), WindowsProcess::getLastErrorText());
        return false;
    }

    return true;
}

/**
    \param jobName Can be a valid name or nullptr. If \a jobName is valid and a job
                   with that name already exists this job will be the same as the
                   other job object. If nullptr then this job object is always
                   unique.
*/
void JobObject::CreateHandle(LPCTSTR jobName)
{
    jobhandle_ = CreateJobObject(0, jobName);

    if ( jobhandle_ == INVALID_HANDLE_VALUE)
        throw KError( TXT("Failed to create job: %1") )
            << GetLastError();

    //if ( GetLastError() == ERROR_ALREADY_EXISTS )
    //    debug_str << "I already existed" << std::endl;
}

} // namespace runextern

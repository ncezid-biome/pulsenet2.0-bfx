#pragma once
#include "helper.h"
#include "CalcCommunicationImpl.h"

#include "CE_Logger.h"
#include "CE_Communication.h"
#include "CE_ExecuteEnvironment.h"

#include <boost/program_options.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>


namespace engine
{

class ProgramOptions {
private:
	boost::program_options::options_description options_;

	class Reportable {
	public:
		typedef boost::shared_ptr<Reportable> Ptr;
	private:
		Str::Text::Val id_, descr_;
	protected:
		virtual Str::Text::Val GetValue() const =0;
	public:
		Reportable (Str::Text::Arg id, Str::Text::Arg descr) 
			: id_(id), descr_(descr) {}
		virtual ~Reportable() {}
		Str::Text::Val const & GetId() const {return id_;}

		virtual void LogSetting(const communication::CalcCommunication& calc, int level) const {
			calc.Send( communication::CalcMessage((IndentedMessage(TXT("%1 (%3): %2"), level) << id_ << GetValue() << descr_).str()) );
		}	
		virtual Str::ID::Val GetTypeId() const =0;
		virtual bool IsSameOptionAs(const Reportable& other) const {
			return id_==other.id_ && GetTypeId()==other.GetTypeId();
		}
		virtual void CopyValueTo(Reportable& other) const =0;
	};


	template<class T> class ConcreteReportable : public Reportable {
	private:
		T& value_;
	protected:
		virtual Str::Text::Val GetValue() const { return ToStr(value_); }
	public:
		ConcreteReportable (Str::Text::Arg id, Str::Text::Arg descr, T& value) 
			: Reportable(id, descr), value_(value) {}
		virtual Str::ID::Val GetTypeId() const {
			return typeid(T).name();
		}
		virtual void CopyValueTo(Reportable& other) const {
			ConcreteReportable<T>* otherPtr = dynamic_cast<ConcreteReportable<T>*>(&other);
			otherPtr->value_ = value_;
		}
	};
	template<class T> class ConcreteListReportable : public Reportable {
	private:
		T& value_;
	protected:
		virtual Str::Text::Val GetValue() const { 
			Str::Text::Val strVal;
			for(size_t i=0; i<value_.size(); ++i) {
				if (i>0) strVal+=", ";
				strVal+=ToStr(value_[i]); 
			}
			return strVal;
		}
	public:
		ConcreteListReportable (Str::Text::Arg id, Str::Text::Arg descr, T& value) 
			: Reportable(id, descr), value_(value) {}
		virtual Str::ID::Val GetTypeId() const override {
			return typeid(T).name();
		}
		virtual void CopyValueTo(Reportable& other) const {
			ConcreteListReportable<T>* otherPtr = dynamic_cast<ConcreteListReportable<T>*>(&other);
			otherPtr->value_ = value_;
		}
	};

	class ProgramOptionsReportable : public Reportable {
	protected:
		virtual Str::Text::Val GetValue() const { ASSERT(0); return ""; }
	private:
		ProgramOptions& options_;
	public:

		ProgramOptionsReportable (ProgramOptions& options) : Reportable(options.GetName(), options.GetName()), options_(options) {}
		virtual void LogSetting(const communication::CalcCommunication& calc, int level) const override {
			options_.LogSettings(calc, level);
		}
		static Str::ID::Val GetProgramOptionsTypeId() {return "ProgramOptions";}
		virtual Str::ID::Val GetTypeId() const {
			return GetProgramOptionsTypeId();
		}
		virtual void CopyValueTo(Reportable& other) const {
			ProgramOptionsReportable* otherPtr = dynamic_cast<ProgramOptionsReportable*>(&other);
			options_.TransferReportablesTo(otherPtr->options_);
		}
	};
	
	class Flag {
	public:
		Str::Text::Val id;
		bool& value;
	public:
		Flag(Str::Text::Arg iid, bool& ivalue): id(iid), value(ivalue) {} 
		Flag(const Flag& other) : id(other.id), value(other.value) {}
	};

	std::vector<Reportable::Ptr> reportables_;
	Str::Text::Val name_;
	std::vector<Flag> flags_;

public:
	typedef boost::property_tree::ptree EnvSettings;

	ProgramOptions(const Str::Text::Val& name, bool asSub=false);
	virtual ~ProgramOptions() {}

	Str::Text::Val GetName() const;

	ProgramOptions& AddFlag(Str::Text::Arg id, Str::Text::Arg descr, bool& value);

	// Used to indicate if the program option should be shown or hidden when adding them with AddOption and variants of it.
	enum class Visibility { SHOW, HIDE };
	
	template<class T> ProgramOptions& AddOption(Str::Text::Arg id, Str::Text::Arg descr) {
		options_.add_options()(id, boost::program_options::value<T>(), descr);
		return *this;
	}
	
	template<class T> ProgramOptions& AddOption(Str::Text::Arg id, Str::Text::Arg descr, T& value, Visibility reportable = Visibility::SHOW) {
		options_.add_options()(id, boost::program_options::value<T>(&value), descr);
		if (reportable == Visibility::SHOW) {
			reportables_.push_back(Reportable::Ptr(new ConcreteReportable<T>(id, descr, value)));
		}
		return *this;
	}
	template<class T> ProgramOptions& AddRequiredOption(Str::Text::Arg id, Str::Text::Arg descr, T& value, Visibility reportable = Visibility::SHOW) {
		options_.add_options()(id, boost::program_options::value<T>(&value)->required(), descr);
		if (reportable == Visibility::SHOW) {
			reportables_.push_back(Reportable::Ptr(new ConcreteReportable<T>(id, descr, value)));
		}
		return *this;
	}

	template<class T> ProgramOptions& AddOption(Str::Text::Arg id, Str::Text::Arg descr, T& value, const T& defaultValue, Visibility reportable= Visibility::SHOW) {
		options_.add_options()(id, boost::program_options::value<T>(&value)->default_value(defaultValue), descr);
		if (reportable == Visibility::SHOW){
			reportables_.push_back(Reportable::Ptr(new ConcreteReportable<T>(id, descr, value)));
		}
		return *this;
	}

	template<class T> ProgramOptions& AddListOption(Str::Text::Arg id, Str::Text::Arg descr, T& value, Visibility reportable = Visibility::SHOW) {
		options_.add_options()(id, boost::program_options::value<T>(&value)->composing(), descr);
		if (reportable == Visibility::SHOW) {
			reportables_.push_back(Reportable::Ptr(new ConcreteListReportable<T>(id, descr, value)));
		}
		return *this;
	}
	template<class T> ProgramOptions& AddRequiredListOption(Str::Text::Arg id, Str::Text::Arg descr, T& value, Visibility reportable = Visibility::SHOW) {
		options_.add_options()(id, boost::program_options::value<T>(&value)->composing()->required(), descr);
		if (reportable == Visibility::SHOW) {
			reportables_.push_back(Reportable::Ptr(new ConcreteListReportable<T>(id, descr, value)));
		}
		return *this;
	}
	
	ProgramOptions& AddProgramOptions(ProgramOptions& subOptions);
	virtual void TransferReportablesTo(ProgramOptions& other) const;

	/**
	 * \brief Suppress the default reporting of all the options in the passed in ProgramOptions object.
	 * \sa LogSettings
	 */
	void SuppressReporting(ProgramOptions const & subOptions);
	/**
	 * \brief Suppress a single command line option by ID used from a ProgramOptions object
	*/
	void SuppressReporting(std::string idToRemove);
	/**
	 * \brief Suppress all command line options by ID used passed in in a vector from a ProgramOptions object
	*/
	void SuppressReporting(std::vector<std::string> idsToRemove);

	virtual void showHelp(std::ostream& os) const;

	virtual bool ParseCmdLine(int argc, char* argv[], const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm);
	virtual void LogSettings(const communication::CalcCommunication& calc, int level=0) const;
	/**
	 * \brief Parses the command line and sets settings according to what was passed in.
	 *
	 */
	virtual bool ParseAndSetup(int argc, char* argv[], const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm);

};

} // namespace engine

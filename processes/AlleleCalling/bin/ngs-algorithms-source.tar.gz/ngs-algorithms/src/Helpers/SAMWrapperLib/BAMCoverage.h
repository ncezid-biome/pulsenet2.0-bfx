#pragma once
#include <Coverage.h>
#include <vector>

namespace BAM
{

class Coverage: public compression::CoverageReaderItf
{

public:

    void Reset(size_t minLength);

    void AppendCoverageCounts(CountType a, CountType c, CountType g, CountType t, CountType total);

    virtual size_t GetCount() const;

    virtual CountType GetTot(size_t basePos) const;

    virtual CountType GetBaseCount(size_t basePos, size_t baseNr) const;

private:

    std::vector<CountType> coverages_[5];
    
};

}
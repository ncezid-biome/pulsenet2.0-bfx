#pragma once

#include "StringDef.h"


//maximum size of a message
#define MAX_MESSAGE_SIZE 2048 


namespace runextern
{


class MessageBuffer
{
public:
    typedef char Buffer[MAX_MESSAGE_SIZE+1];

    void reset();

    Buffer&  getBuffer()       { return buffer_; }
    const Buffer&  getBuffer() const { return buffer_; }

    void truncate(int len);

    size_t         getBufferSize() const { return sizeof(buffer_) - sizeof(char); }

    Str::Text::Vec getBufferLines() const;

private:
    Buffer buffer_;
};



} // namespace runextern
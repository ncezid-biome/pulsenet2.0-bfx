#pragma once

#include "BoolHelper.h"

namespace seq
{

/**
    Use this for fast upper-casing of a sequence while maintaining ambiguous bases

   \note every non-IUPAC base is turned into 'N'; U/u is maintained
    Singleton implementation, should remove that
*/
class IUPACCapitalTable
{
public:
    typedef std::vector<char> Table;
private:
    static void Initialize(Table& table)
    {
        table.resize(256, 'N');
        table['A'] = 'A';
        table['C'] = 'C';
        table['G'] = 'G';
        table['T'] = 'T';

        table['a'] = 'A';
        table['c'] = 'C';
        table['g'] = 'G';
        table['t'] = 'T';

        //yes, we also keep U, this is supposed to be a very broad normalization
        table['U'] = 'U';
        table['u'] = 'U';

        //ambiguous bases
        table['R'] = 'R';
        table['Y'] = 'Y';
        table['S'] = 'S';
        table['W'] = 'W';
        table['K'] = 'K';
        table['M'] = 'M';
        table['B'] = 'B';
        table['D'] = 'D';
        table['H'] = 'H';
        table['V'] = 'V';

        table['r'] = 'R';
        table['y'] = 'Y';
        table['s'] = 'S';
        table['w'] = 'W';
        table['k'] = 'K';
        table['m'] = 'M';
        table['b'] = 'B';
        table['d'] = 'D';
        table['h'] = 'H';
        table['v'] = 'V';

    }
    static Table& GetTable()
    {
        static Table table_;
        static Bool<false> initialized_;
        if (!initialized_) {
            Initialize(table_);
            initialized_ = true;
        }
        return table_;
    }
private:
    IUPACCapitalTable() {}
public:
    static const Table& Get()
    {
        return GetTable();
    }
};



} // namespace seq
#pragma once

#include "PathDef.h"
#include "CalcCommunication.h"
#include "NamedSequence.h"
#include "filereader.h"


namespace seq
{

template<typename F> void EnumerateSequenceFile(const Str::Path::Val& inputfile, F f)
{
    SeqFileReader::Ptr reader = SeqFileReader::AutoDetect(inputfile);
    reader->init(inputfile, 4000000);

    seq::NamedSequence sequence;
    for (size_t iread = 0; reader->hasMore(); ++iread) {

        reader->getNextSeq(sequence);
        f(iread, sequence);
    }
}

template<typename F> void ProcessSequenceFile(const Str::Path::Val& inputfile, const Str::Path::Val& ouputfile, F f)
{
    std::ofstream os(ouputfile.string());

    EnumerateSequenceFile(inputfile, [&os, &f](size_t iread, seq::NamedSequence & sequence) {

        if(f(iread, sequence)) {

            os << '>' << sequence.GetName() << '\n';
            os << sequence.GetData() << '\n';
        }
    });
}

void UnzipSequenceFile( const Str::Path::Val& inputfile,
                        const Str::Path::Val& ouputfile );
void UnzipSequenceFileForBLAST
                      ( const Str::Path::Val& inputfile,
                        const Str::Path::Val& ouputfile,
                        const communication::CalcCommunication& comm);

void MergeSequenceFiles(const Str::Path::Vec& inputfiles, const Str::Path::Val& outputfile);

} // namespace  seq

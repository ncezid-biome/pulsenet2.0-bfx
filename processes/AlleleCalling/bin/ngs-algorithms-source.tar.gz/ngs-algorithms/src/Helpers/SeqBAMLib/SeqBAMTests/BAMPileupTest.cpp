﻿#include "stdafx.h"

#include "boost/test/unit_test.hpp"
#include "BAMConsensusCreator.h"
#include "BAMConsensusCaller.h"
#include "BasicFileResolver.h"
#include <boost/make_shared.hpp>
#include "ConsoleLogger.h"
#include "CalcCommunication.h"
#include "BAMFileLoader.h"
#include "TempFileResolver.h"
#include "TempDirectory.h"

//I'm too lazy to create a SamToolsLibTests projects, so I put this here. Deal with it (⌐■_■)

struct BAMPileupTestsFixture {

    BAMPileupTestsFixture(): cl(ConsoleLogger::LogMode::Text), comm(&cl)
    {
        sett.minCoverage = 1;
        sett.minFwdCoverage = 0;
        sett.minRevCoverage = 0;
    }

    Str::Path::Val getDataFilePath(const Str::Text::Val& filename)
    {
        //this needs compiler flag /FC to get the full path
        Str::Path::Val thisFile(__FILE__);

        return (thisFile.parent_path() / "Data" / filename);
    }

    BAM::FileResolver::Ptr getSBAMFileResolver(const Str::Path::Val& filepath)
    {
        BAM::FileLoader loader(false, false);
        return loader.Load(comm, filepath, boost::make_shared<BAM::TempFileResolver>(bamDir.path()));
    }

    TempDirectory bamDir;

    ConsoleLogger cl;
    communication::CalcCommunication comm;

    BAM::ConsensusCaller::Settings sett;

};

BOOST_FIXTURE_TEST_SUITE( BAMPileupTests, BAMPileupTestsFixture );

BOOST_AUTO_TEST_CASE(keepFrame)
{
    sett.keepFrame = true;
    BAM::ConsensusCreator cc(sett);

    auto files = getSBAMFileResolver(getDataFilePath("empty_contigs.sam"));

    cc.CreateConsensus(comm, files);

    BOOST_CHECK_EQUAL(cc.GetConsensus(), "NNN|NN|N|NATCGNNNNN||T|");
    BOOST_CHECK_EQUAL(cc.GetForwardCoverage().GetCount(), 23);
    BOOST_CHECK_EQUAL(cc.GetReverseCoverage().GetCount(), 23);
}

BOOST_AUTO_TEST_CASE(noKeepFrame)
{
    BAM::ConsensusCreator cc(sett);

    auto files = getSBAMFileResolver(getDataFilePath("empty_contigs.sam"));

    cc.CreateConsensus(comm, files);

    BOOST_CHECK_EQUAL(cc.GetConsensus(), "ATGCG|TACGCG");
    BOOST_CHECK_EQUAL(cc.GetForwardCoverage().GetCount(), 12);
    BOOST_CHECK_EQUAL(cc.GetReverseCoverage().GetCount(), 12);
}

BOOST_AUTO_TEST_CASE(oneContig)
{
    sett.keepFrame = true;
    BAM::ConsensusCreator cc(sett);

    auto files = getSBAMFileResolver(getDataFilePath("empty_contigs.sam"));

    cc.CreateConsensus(comm, files, 3, 0, 8);

    BOOST_CHECK_EQUAL(cc.GetConsensus(), "NATCGNNNN");
    BOOST_CHECK_EQUAL(cc.GetForwardCoverage().GetCount(), 9);
    BOOST_CHECK_EQUAL(cc.GetReverseCoverage().GetCount(), 9);
}

BOOST_AUTO_TEST_CASE(oneContignoKeepFrame)
{
    BAM::ConsensusCreator cc(sett);

    auto files = getSBAMFileResolver(getDataFilePath("empty_contigs.sam"));

    cc.CreateConsensus(comm, files, 3, 3, 8);

    BOOST_CHECK_EQUAL(cc.GetConsensus(), "ATGCG");
    BOOST_CHECK_EQUAL(cc.GetForwardCoverage().GetCount(), 5);
    BOOST_CHECK_EQUAL(cc.GetReverseCoverage().GetCount(), 5);
}

BOOST_AUTO_TEST_CASE(keepFrameCoverage)
{
    sett.keepFrame = true;
    sett.minCoverage = 2;
    BAM::ConsensusCreator cc(sett);

    auto files = getSBAMFileResolver(getDataFilePath("empty_contigs.sam"));

    cc.CreateConsensus(comm, files);

    BOOST_CHECK_EQUAL(cc.GetConsensus(), "NNN|NN|N|NNNNNNNNNN||N|");
    BOOST_CHECK_EQUAL(cc.GetForwardCoverage().GetCount(), 23);
    BOOST_CHECK_EQUAL(cc.GetReverseCoverage().GetCount(), 23);
}

BOOST_AUTO_TEST_CASE(noKeepFrameCoverage)
{
    sett.minCoverage = 2;
    BAM::ConsensusCreator cc(sett);

    auto files = getSBAMFileResolver(getDataFilePath("empty_contigs.sam"));

    cc.CreateConsensus(comm, files);

    BOOST_CHECK_EQUAL(cc.GetConsensus(), "");
    BOOST_CHECK_EQUAL(cc.GetForwardCoverage().GetCount(), 0);
    BOOST_CHECK_EQUAL(cc.GetReverseCoverage().GetCount(), 0);
}

BOOST_AUTO_TEST_CASE(outOfBounds)
{
    sett.keepFrame = true;
    BAM::ConsensusCreator cc(sett);

    //the file has one alignment that is mapped to a position outside of the contig
    auto files = getSBAMFileResolver(getDataFilePath("out-of-bounds.sam"));

    cc.CreateConsensus(comm, files);

    BOOST_CHECK_EQUAL(cc.GetConsensus(), "NNNNNNATCG");
    BOOST_CHECK_EQUAL(cc.GetForwardCoverage().GetCount(), 10);
    BOOST_CHECK_EQUAL(cc.GetReverseCoverage().GetCount(), 10);
}

BOOST_AUTO_TEST_SUITE_END();

#pragma once
#include "StringDef.h"
#include "seqbagstats_general.h"

/**
	The SeqBagInfo class provides elementary information about the sequence bag: 
		- total number of sequences
		- length statistics: average, standard deviation, min, max
		- quality statistics: average, standard deviation, min, max
	This can be used for querying and displaying purposes.
**/

class SeqBagInfo {
private:
	size_t nseqs_;
	size_t nPaired_;
	double len_avg_, len_stdev_, len_min_, len_max_;
	double qual_avg_, qual_stdev_, qual_min_, qual_max_;
	double len_avg_1_, len_stdev_1_, len_min_1_, len_max_1_;
	double qual_avg_1_, qual_stdev_1_, qual_min_1_, qual_max_1_;
	double len_avg_2_, len_stdev_2_, len_min_2_, len_max_2_;
	double qual_avg_2_, qual_stdev_2_, qual_min_2_, qual_max_2_;
	size_t nA_, nC_, nG_, nT_, nN_;
	SeqBagGeneralStats::CountVector qScores_, qScores1_, qScores2_;
	bool hasQual_;
public:
	SeqBagInfo();
	~SeqBagInfo();

	void Reset();

	void SetInfo(
		size_t nseqs, size_t nPaired, 
		double len_avg, double len_stdev, double len_min, double len_max, 
		double len_avg1, double len_stdev1, double len_min1, double len_max1,
		double len_avg2, double len_stdev2, double len_min2, double len_max2,
		double qual_avg, double qual_stdev, double qual_min, double qual_max, 
		double qual_avg1, double qual_stdev1, double qual_min1, double qual_max1,
		double qual_avg2, double qual_stdev2, double qual_min2, double qual_max2,
		size_t nA, size_t nC, size_t nG, size_t nT, size_t nN, 
		const SeqBagGeneralStats::CountVector& qScores,const SeqBagGeneralStats::CountVector& qScores1,const SeqBagGeneralStats::CountVector& qScores2
	);

	void fromCounts(const SeqBagGeneralStats& counts);
	
	size_t GetNSeqs() const;
	size_t GetNPaired() const;

	double GetAvgLen() const;
	double GetStDevLen() const;
	__int64 GetTotLen() const;
	int GetMinLen() const;
	int GetMaxLen() const;

	double GetAvgLenLeft() const;
	double GetStDevLenLeft() const;
	__int64 GetTotLenLeft() const;
	int GetMinLenLeft() const;
	int GetMaxLenLeft() const;

	double GetAvgLenRight() const;
	double GetStDevLenRight() const;
	__int64 GetTotLenRight() const;
	int GetMinLenRight() const;
	int GetMaxLenRight() const;

	bool HasQual() const;
	double GetAvgQual() const;
	double GetStDevQual() const;
	int GetMinQual() const;
	int GetMaxQual() const;

	double GetAvgQualLeft() const;
	double GetStDevQualLeft() const;
	int GetMinQualLeft() const;
	int GetMaxQualLeft() const;

	double GetAvgQualRight() const;
	double GetStDevQualRight() const;
	int GetMinQualRight() const;
	int GetMaxQualRight() const;

	size_t GetNA() const;
	size_t GetNC() const;
	size_t GetNG() const;
	size_t GetNT() const;
	size_t GetNN() const;
	size_t GetNGC() const;

	double GetPercentA() const;
	double GetPercentC() const;
	double GetPercentG() const;
	double GetPercentT() const;
	double GetPercentN() const;
	double GetPercentGC() const;
	
	size_t  GetQ20() const;
	size_t  GetQ25() const;
	size_t  GetQ30() const;

	double GetPercentQ20() const;
	double GetPercentQ25() const;
	double GetPercentQ30() const;

	size_t  GetQ20Left() const;
	size_t  GetQ25Left() const;
	size_t  GetQ30Left() const;

	double GetPercentQ20Left() const;
	double GetPercentQ25Left() const;
	double GetPercentQ30Left() const;

	size_t  GetQ20Right() const;
	size_t  GetQ25Right() const;
	size_t  GetQ30Right() const;

	double GetPercentQ20Right() const;
	double GetPercentQ25Right() const;
	double GetPercentQ30Right() const;

	void Load(Str::Xml::Arg string);
	void Save(Str::Xml::Val& string) const;
};


//class SeqBagInfo {
//private:
//	size_t nseqs_;
//	size_t nPaired_;
//	double len_avg_, len_stdev_, len_min_, len_max_;
//	double qual_avg_, qual_stdev_, qual_min_, qual_max_;
//	size_t nA_, nC_, nG_, nT_, nN_;
//	size_t q20_, q25_, q30_;
//	bool hasQual_;
//public:
//	SeqBagInfo();
//	~SeqBagInfo();
//
//	void Reset();
//
//	void fromCounts(const SeqBagGeneralStats& counts);
//
//	void SetInfo(size_t nseqs, size_t nPaired, double len_avg, double len_stdev, double len_min, double len_max, double qual_avg, double qual_stdev, double qual_min, double qual_max, size_t nA, size_t nC, size_t nG, size_t nT, size_t nN, size_t q20, size_t q25, size_t q30);
//	
//	size_t GetNSeqs() const;
//	size_t GetNPaired() const;
//
//	double GetAvgLen() const;
//	double GetStDevLen() const;
//	int GetTotLen() const;
//	int GetMinLen() const;
//	int GetMaxLen() const;
//	
//	bool HasQual() const;
//	double GetAvgQual() const;
//	double GetStDevQual() const;
//	int GetMinQual() const;
//	int GetMaxQual() const;
//
//	size_t GetNA() const;
//	size_t GetNC() const;
//	size_t GetNG() const;
//	size_t GetNT() const;
//	size_t GetNN() const;
//	size_t GetNGC() const;
//
//	double GetPercentA() const;
//	double GetPercentC() const;
//	double GetPercentG() const;
//	double GetPercentT() const;
//	double GetPercentN() const;
//	double GetPercentGC() const;
//	
//	size_t  GetQ20() const;
//	size_t  GetQ25() const;
//	size_t  GetQ30() const;
//
//	double GetPercentQ20() const;
//	double GetPercentQ25() const;
//	double GetPercentQ30() const;
//	
//	void Load(const Str::Xml::Val& string);
//	void Save(Str::Xml::Val& string) const;
//};
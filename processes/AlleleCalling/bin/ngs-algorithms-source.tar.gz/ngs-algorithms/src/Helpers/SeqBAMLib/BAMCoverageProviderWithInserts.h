#pragma once

#include <cstdint>
#include "SAMWrapper.h"
#include "BAMPileup.h"
#include "BAMPileFileTypes.h"
#include "BAMConsensusCaller.h"
#include <boost/shared_ptr.hpp>
#include "BAMCoverage.h"
#include "CalcCommunication.h"
#include "srsmapping_coverage.h"

//#define private protected
#include "BAMCoverageProvider.h"

namespace SeqBAM
{

class CoverageProviderWithInserts: public CoverageProvider
{

public:
    CoverageProviderWithInserts(): CoverageProvider(0)
    {
    }

private:

    virtual int PileupCallback(ReferenceID tid, ReferencePosition pos, int n, const bam_pileup1_t pl[]);

    virtual void ReferenceChanged(ReferenceID refID);

public:
    std::vector<std::vector<ReferencePosition>> insertPositions;
    std::vector<std::vector<SRSMappingCoverage::Counts>> insertCoverage;

};

}

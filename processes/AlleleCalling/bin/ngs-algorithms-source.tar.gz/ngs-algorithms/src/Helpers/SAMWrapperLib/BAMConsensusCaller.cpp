#include "BAMConsensusCaller.h"

char BAM::ConsensusCaller::GetConsensusBase(int n, const bam_pileup1_t pl[], int offset)
{
    //avoid the base count if possible
    if(n<settings_.minCoverage)
        return INSUFFICIENT_COVERAGE;

    //do a base count
    size_t hits[16];
    std::fill(hits, hits+16, 0);

    size_t totalHits=0;
    size_t fwdHits=0;
    size_t revHits=0;

    for(size_t m=0; m<n; m++) {

        //skip positions that are either deletions (A) or paddings to allow for inserts in other reads (B)
        //in case of padding, skip only if the read has run out of contributions (C)
        //  (A)             (B)        (C)
        if(pl[m].is_del || (offset && offset>pl[m].indel))
            continue;

        hits[bam1_seqi(bam1_seq(pl[m].b), pl[m].qpos+offset)]+=100;
        totalHits++;

        if(bam1_strand(pl[m].b))
            revHits++;
        else
            fwdHits++;
    }

    //return INSUFFICIENT_COVERAGE if insufficient non-empty hits
    if(totalHits<settings_.minCoverage || fwdHits<settings_.minFwdCoverage || revHits<settings_.minRevCoverage)
        return INSUFFICIENT_COVERAGE;

    //at least 50% of the reads covering this position should contribute a non-gap base
    const size_t gapThreshold=settings_.gapThreshold*n;
    if(n==0 || totalHits*100<gapThreshold)
        return INSUFFICIENT_COVERAGE;

    //75% of all bases are x? => x
    const size_t singleThreshold=settings_.singleThreshold*totalHits;
    //85% of all bases are x or y? => x|y
    const size_t doubleThreshold=settings_.doubleThreshold*totalHits;
    //95% of all bases are x, y, z? => x|y|z
    const size_t tripleThreshold=settings_.tripleThreshold*totalHits;

    if(hits[1]>=singleThreshold)
        return 'A';
    else if(hits[2]>=singleThreshold)
        return 'C';
    else if(hits[4]>=singleThreshold)
        return 'G';
    else if(hits[8]>=singleThreshold)
        return 'T';
    //  W	Weak	A   T
    else if(hits[1]+hits[8]>=doubleThreshold)
        return 'W';
    //  S	Strong	C	G
    else if(hits[2]+hits[4]>=doubleThreshold)
        return 'S';
    //  M	aMino	A	C
    else if(hits[1]+hits[2]>=doubleThreshold)
        return 'M';
    //  K	Keto    G	T
    else if(hits[4]+hits[8]>=doubleThreshold)
        return 'K';
    //  R	puRine  A	G
    else if(hits[1]+hits[4]>=doubleThreshold)
        return 'R';
    //  Y	pYrimidine  C	T
    else if(hits[2]+hits[8]>=doubleThreshold)
        return 'Y';

    //in the cases below, we plainly ignore that there might be non-ACGT elements...

    //  B	not A   C	G	T
    else if(n-hits[1]>=tripleThreshold)
        return 'B';
    //  D	not C   A	G	T
    else if(n-hits[2]>=tripleThreshold)
        return 'D';
    //  H	not G   A	C	T
    else if(n-hits[4]>=tripleThreshold)
        return 'H';
    //  V	not T   A	C	G
    else if(n-hits[8]>=tripleThreshold)
        return 'V';

    //gaps are already handled, so we can safely
    return 'N';
}

#include "stdafx.h"

#define BOOST_TEST_MODULE "C++ Unit Tests for SRSMapping"

// Some macros that cause unit_test.hpp to spit out a main
#ifdef AMGNU

#define BOOST_TEST_MAIN

#else

#define BOOST_TEST_NO_MAIN

#endif // AMGNU

#include "boost/test/unit_test.hpp"

#ifndef AMGNU

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
    return ::boost::unit_test::unit_test_main( &init_unit_test, argc, argv );
}

#endif // AMGNU

#pragma once

#include <cstdint>
#include "SAMWrapper.h"
#include "BAMLevelFile.h"
#include <PathDef.h>
#include "BAMPileup.h"
#include "BAMFileResolver.h"
#include <fstream>

namespace BAM
{

class STW_DLLPORT LevelFileCreator: protected LevelFile, protected Pileup
{

public:
    LevelFileCreator(): Pileup(false) {}

    void CreateLevelFile(FileResolver::Ptr files);
    
    static bool HasLevelFile(FileResolver::Ptr files);

private:

    void AddRead(BamTold bam_told, ReadLevel level);
    void Complete();

    int FetchCallback(bam1_t& b);

    virtual int PileupCallback(uint32_t tid, uint32_t pos, int n, const bam_pileup1_t pl[]);

private:
    std::ofstream output_;
    BlockAddress currentBlock_;
    Header header;
    std::vector<BlockHeader> blockHeaders;
};

}

#pragma once

#include "boost/smart_ptr.hpp"


#include "runextern_process.h"


namespace runextern
{


class ProcessPool
{
public:
    typedef boost::shared_ptr<ProcessPool> Ptr;

public:
    virtual ~ProcessPool(){}

    static Ptr Create();

    virtual Process* CreateProcess() = 0;
};



} // namespace runextern

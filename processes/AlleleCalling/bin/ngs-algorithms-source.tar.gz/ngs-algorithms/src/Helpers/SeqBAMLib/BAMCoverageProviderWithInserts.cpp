#include "stdafx.h"
#include "BAMCoverageProviderWithInserts.h"
#include <boost/smart_ptr/make_shared_array.hpp>
#include "BAMUtils.h"

namespace SeqBAM
{

int CoverageProviderWithInserts::PileupCallback(ReferenceID tid, ReferencePosition pos, int n, const bam_pileup1_t pl[])
{
    CoverageProvider::PileupCallback(tid, pos, n, pl);

    if(tid >= insertPositions.size())
        throw KError("lists too small: %1 vs %2") << tid << insertPositions.size();

    size_t max_ins = 0;

    // calculate maximum insert
    for(int i = 0; i < n; ++i) {
        if (pl[i].indel > 0 && max_ins < pl[i].indel)
            max_ins = pl[i].indel;
    }

    for(int j = 1; j <= max_ins; j++) {

        insertPositions[tid].push_back(pos);

        SRSMappingCoverage::Counts c;

        for (int i = 0; i < n; ++i) {

            const bool isFwd = !bam1_strand(pl[i].b);

            if(j <= pl[i].indel) {

                uint8_t b = bam1_seqi(bam1_seq(pl[i].b), pl[i].qpos + j);
                c.add(BAM::Utils::Convert4BitsToChar(b), isFwd);
            }
            else
                c.add(GAP, isFwd);
        }

        insertCoverage[tid].push_back(c);
    }

    return 0;
}

void CoverageProviderWithInserts::ReferenceChanged(ReferenceID refID)
{
    if(refID >= insertPositions.size() && refID != NOREFERENCE) {

        insertPositions.resize(refID + 1);
        insertCoverage.resize(refID + 1);
    }
}

}
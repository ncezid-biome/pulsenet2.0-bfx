#include "stdafx.h"

#include "AlleleSequencesFile.h"

#include "boost/algorithm/string/predicate.hpp"

#include "exception.h"
#include "CalcCommunicationImpl.h"

#include "compression.h"
#include "CompressedFile.h"
#include "CE_LogAction.h"
#include "extensionbrowser.h"



AlleleSequencesFile::AlleleSequencesFile(const Str::Path::Val& filename, const communication::CalcCommunication& comm)
    : fileInfo_    ( filename, comm )
    , filename_    ()
{
    if(filename.extension() != ".gz") {

        //try the .gz version first: the compressed version might exist
        Str::Path::Val gzippedFilename=filename;
        gzippedFilename+=".gz";

        FinalSequenceFile gzFile(gzippedFilename, comm);

        if(VerifyFilename(gzFile)) {

            fileInfo_ = gzFile;
            return;
        }
    }

    //gzipped did not exist, or input ends in .gz: use input as-is
	if (!VerifyFilename(fileInfo_))
	{
		throw KError(TXT("Allele sequences file not found: '%1'.")) << filename.string();

	}
}

bool AlleleSequencesFile::VerifyFilename(const FinalSequenceFile& fileInfo)
{
    Str::Path::Val fileName = fileInfo.fileRotator->GetCurrentFile();

    if ( boost::filesystem::exists(fileName) ) {

        filename_ = fileName;
        return true;
    }

    return false;
}

/**
    Get the name of the current all sequences file to use.
*/
Str::Path::Val AlleleSequencesFile::GetFilename() const
{
    if ( filename_.empty() )
        throw KError( PM("Allele sequences file does not exist (original file: '%1')") )
            << fileInfo_.originalName;

    return filename_;
}

/**
    Decompress e.g. allalleles.fasta.gz to allalleles_0.fasta (or allalleles_1.fasta).
    Afterwards, this instance points to the newly created decompressed file
*/
void AlleleSequencesFile::DecompressIfNeeded( const communication::CalcCommunication& comm )
{
    filename_ = CompressedFile::DecompressIfNeeded( filename_, comm );
}

/**
    Copies the given file to the shared location, but keeps using the input file.
*/
void AlleleSequencesFile::FromLocalFile(const communication::CalcCommunication& comm, const Str::Path::Val& localFile)
{
    const Str::Path::Val target=GetNextSharedName();

    engine::LogBlock log(
        RawMessage(
        PM("Copying sequence file '%1' to '%2'"),
        localFile,
        target).c_str(), comm );

    // Make sure the necessary directories exist
    if (   ! target.parent_path().empty()
        && ! boost::filesystem::exists(target.parent_path()) ){
            engine::LogAction action( comm, RawMessage(PM("Creating '%1' directory hierarchy"), target.parent_path()).c_str() );
            EnsureExists( ToRef(target.parent_path()) );
    }

    // Remove the old file first, if it exists (needed or copyFile fails if the destination file existed)
    if (    boost::filesystem::exists(target)
        && boost::filesystem::is_regular_file(target) ){
            engine::LogAction action( comm, RawMessage(PM("Removing old file: '%1'"), target.string()).c_str() );
            boost::filesystem::remove( target );
    }

    // Just make a copy to the right name
    boost::filesystem::copy_file( localFile, target );

    log.LogSuccess();

    fileInfo_.fileRotator->RotateLinkfile( comm );

    //and now the old switcharoo: we'll use the local file from now on
    filename_=localFile;
}


/**
    Does the whole link rotating shebang, but then for a non-existing file.  So the link will point to file 1 for instance, but that won't exist.
    This is the rotating link file's equivalent of deleting a file.
*/
void AlleleSequencesFile::MakeMissingFile(const communication::CalcCommunication& comm)
{
    const Str::Path::Val target=GetNextSharedName();

    engine::LogBlock log(
        RawMessage(
        PM("Deleting sequence file '%1'"),
        target).c_str(), comm );

    // Make sure the necessary directories exist
    if (   ! target.parent_path().empty()
        && ! boost::filesystem::exists(target.parent_path()) ){
            engine::LogAction action( comm, RawMessage(PM("Creating '%1' directory hierarchy"), target.parent_path()).c_str() );
            EnsureExists( ToRef(target.parent_path()) );
    }

    // Remove the old file first, if it exists (needed or copyFile fails if the destination file existed)
    if (    boost::filesystem::exists(target)
        && boost::filesystem::is_regular_file(target) ){
            engine::LogAction action( comm, RawMessage(PM("Removing file: '%1'"), target.string()).c_str() );
            boost::filesystem::remove( target );
    }

    log.LogSuccess();

    fileInfo_.fileRotator->RotateLinkfile( comm );

    //and now the old switcharoo: we'll use the local file from now on
    filename_.clear();
}

Str::Path::Val AlleleSequencesFile::GetNextSharedName() const
{
    return fileInfo_.fileRotator->GetNextFile();
}

/**
    Don't check for file existence here: can only do that when trying to open the file
    or when doing DecompressOrCopy.
*/
AlleleSequencesFile::FinalSequenceFile::FinalSequenceFile(const Str::Path::Val& ioriginalName, const communication::CalcCommunication& comm)
    : originalName( ioriginalName )
    , fileRotator ()
{
    Str::Path::Val basename=ioriginalName;
    Str::Text::Val extension=basename.extension().string();

    basename.replace_extension();

    //logic: a compressed file may have a double file extension, such as .fastq.gz
    //pop the second extension if there is one
    if(basename.has_extension()) {

        extension=basename.extension().string() + extension;
        basename.replace_extension();
    }

    // Make sure extension starts with "."
    if (   ! extension.empty()
        && ! boost::starts_with(extension, PM(".")) )
        extension = PM(".") + extension;

    try {
        // If the input allele file points to a rotated link file: just use that file, don't
        // do any rotations
        Str::Path::Val unrotated;
        if ( FileRotator::GetUnrotatedName(basename, unrotated) ){
            comm.Send( communication::CalcMessage(RawMessage(PM("Initializing allele sequence file '%1' as non-rotating single file"), ioriginalName).c_str()));
            fileRotator.reset( new FileNoRotator(ioriginalName) );
        } else {
            comm.Send( communication::CalcMessage(RawMessage(PM("Initializing allele sequence file as rotating file with base name '%1'"), basename).c_str()));
            // Update the rotator based on the basename
            fileRotator.reset( new FileRotatorExtention( basename, 2, extension, comm ) );
        }
    } catch ( std::exception& e ){
        throw KError( PM("Unable to initialize allele sequences file (%1): %2") )
            << ioriginalName
            << e.what();
    }
}

#pragma once

#include "intdef.h"


class AlleleInfo {
public:
    class ScreenData {
    public:
        ScreenData() {}
        ScreenData(Str::Text::Arg name, size_t index) {}

        inline void loadSeq(Str::Text::Arg seq, size_t size) {}
        inline void add(const ScreenData& data, size_t pos) {}			
    };
private:
    UInt16 cntReadsFwd_, cntReadsRev_;	
public:
    AlleleInfo() : cntReadsFwd_(0), cntReadsRev_(0) {}
    AlleleInfo(Str::Text::Arg name, size_t index)		
        : cntReadsFwd_(0), cntReadsRev_(0)
    {}
    inline void loadSeq(Str::Text::Arg seq, size_t size) {}
    inline void add(const AlleleInfo& data, size_t pos, bool fwd) { 		
    }	
    inline void screen(const ScreenData& data, size_t pos, bool fwd) { cntReadsFwd_+=fwd; cntReadsRev_+=(!fwd);}	
    inline size_t getCntFwd() const { return cntReadsFwd_; }	
    inline size_t getCntRev() const { return cntReadsRev_; }	
    inline size_t getCnt() const { return cntReadsFwd_+cntReadsRev_; }	

    void toStream(std::ostream& os) const {
        os.write((const char*)(&cntReadsFwd_), sizeof(UInt16));
        os.write((const char*)(&cntReadsRev_), sizeof(UInt16));
    }
    void fromStream(std::istream& is) {
        is.read((char*)(&cntReadsFwd_), sizeof(UInt16));	
        is.read((char*)(&cntReadsRev_), sizeof(UInt16));	
    }
};

#include "stdafx.h"

#include "CE_CommandLine.h"

#include "boost/tokenizer.hpp"
#include "boost/program_options.hpp"

#include "translate.h"
#include "exception.h"
#include "CommandLine.h"

#include "CE_StringManip.h"
#include "CE_Logger.h"



namespace engine
{

namespace tools
{

CommandLine::CommandLine()
    : argv_        ()
    , oldstyleArgv_( nullptr)
    , resultsdir_  ()
{
}

void CommandLine::Init( int argc, char* argv[], Logger& logger )
{
    Str::Text::Val commandLine;
    // Print version -> don't parse anything else, we will just print the version and be done.
        if ( GetExtraArguments().PrintVersion() )
            return;

    // Always need at least one: the executable name
    if ( argc < 1 )
        throw KError( PM("Invalid number of command line arguments (%1)"))
                << argc;

    // No need to call ParseOptionalExtraArgs: handled by the ParseOptionalExtraArgs call
    // further on

    // Create the command line.
    for ( size_t i = 1; i < argc; ++i ) {
        // Surround with "" to deal with e.g. paths with spaces
        commandLine  = commandLine + PM("\"") + argv[i] + PM("\"");
        commandLine += ' ';
    }

    // Now parse into a new array
    stringToCommandline( argv[0], commandLine, argv_ );

    // This also prepares the old-style arguments vector
    ParseArguments( logger );

    logger.SetResultsDir  ( GetResultsDir() );
    
    // Look for the optional args
    ParseOptionalExtraArgs( GetArgCount(), GetOldstyleArgVector() );
}

void CommandLine::ParseArguments( Logger& logger )
{
    // Construct old-style argument list
    oldstyleArgv_ = getOldStyleArguments( argv_ );

    namespace po = boost::program_options;

    bool isVerbose = false;
	Str::Text::Val compressionType;

    po::options_description config( PM("Fixed algorithm options") );
    config.add_options()
    ( PM("resultsdir"),  po::value<Str::Text::Val>(&resultsdir_),
      PM("The algorithm base results directory. Actual results are written into a 'results' subfolder.") )
    ( PM("shareddir"),  po::value<Str::Text::Val>(&shareddir_)->default_value(PM("shared")),
      PM("The algorithm shared directory") )
    ( PM("tempdir"),  po::value<Str::Text::Val>(&sharedtempdir_)->default_value(PM("temp")),
      PM("The algorithm shared temporary directory") )
    ( PM("verbose"), po::value<bool>(&isVerbose),
      ( PM("Make log output verbose")) )
	( PM("compressiontype"), po::value<Str::Text::Val>(&compressionType)->default_value(""),	//default empty (no compression) for backward compatibility
      ( PM("Make output compressed")) )
    ;

    po::command_line_parser parser( GetArgCount(), GetOldstyleArgVector() );
    parser.options( config )
    .allow_unregistered();

    po::variables_map vm;
    po::store( parser.run(), vm );
    po::notify(vm);

    // Set correct values in the logger
    logger.SetVerbose( isVerbose );
	logger.SetDoCompressionType( compressionType );
}

bool CommandLine::HasLocalDir() const
{
    return extraArguments_.HasLocalDir();
}

Str::Text::Val CommandLine::GetLocalDir() const
{
    return extraArguments_.GetLocalDir();
}

Str::Text::Val CommandLine::GetSharedTempDir() const
{
    return sharedtempdir_;
}

Str::Text::Val CommandLine::GetSharedDir() const
{
    return shareddir_;
}

Str::Text::Val CommandLine::GetResultsDir() const
{
    return resultsdir_;
}

char** CommandLine::GetOldstyleArgVector() const
{
    return oldstyleArgv_.get();
}

Str::Text::Vec CommandLine::GetArgVector() const
{
    return argv_;
}

int CommandLine::GetArgCount() const
{
    return static_cast<int>(argv_.size());
}

Str::Text::Val CommandLine::GetArg(int index) const
{
    return argv_[index];
}

// Parse algorithm-wide optional arguments from the command line.
void CommandLine::ParseOptionalExtraArgs(int argc, char* argv[])
{
    return extraArguments_.Parse( argc, argv );
}

const OptionalExtraArguments& CommandLine::GetExtraArguments() const
{
    return extraArguments_;
}

OptionalExtraArguments& CommandLine::GetExtraArguments()
{
    return extraArguments_;
}

} // namespace tools

} // namespace engine

#ifndef ALLELEFINDERSETTINGS_H
#define ALLELEFINDERSETTINGS_H

#include "CE_ProgramOptions.h"

#include "PathDef.h"

#include "AlleleSequencesFile.h"
#include "AlleleKMerTable.h"
#include "AlleleInfoFile.h"


/**
    \sa AlleleFinderData
*/
class AlleleFinderSettings : public engine::ProgramOptions
{
public:
    Str::Path::Val logDir, resultDir;
    Str::ID::Val alleleFileType;
    Str::ID::Val algorithmType;
    Str::Text::Vec readFiles;
    Str::ID::Vec readFileTypes;
    size_t k;
    size_t minCoverage, minCoverageFwd, minCoverageRev;
    size_t minQual, maxNViolations, qualOffset;
    double thresholdForLocusPresence, thresholdForKeywordCoverage;

	//bool findNewAlleles;
	//Str::Text::Vec startCodons, stopCodons;
	//bool		 huntForStartStop;
	//size_t		 extraBasesForStartStop;

private:
	//void Init();

public:
    AlleleFinderSettings();
    ~AlleleFinderSettings();

    bool ParseAndSetup(int argc, char* argv[], const engine::ExecuteEnvironment& env, const communication::CalcCommunication& comm) override;
   

    bool HasAlleleFile() const;

private:
    Str::Path::Val      alleleFileName_;
	Str::Path::Val      alleleInfoFileName_;
    bool                createKMerTable_;
    Str::Path::Val      kmerTableFile_;

private:
    friend class AlleleFinderData;
};

/**
    \note Only create one instance of this class, based on the program settings. Re-use
          this one instance afterwards. Do this to prevent reading a different
          allele info file afterwards (can happen if the link has been rotated)
*/
class AlleleFinderData
{
public:
    typedef boost::shared_ptr<AlleleFinderData> Ptr;
public:

public:
    AlleleFinderData( const AlleleFinderSettings& settings, const communication::CalcCommunication& comm );

    bool                          HasAlleleFile() const;
    AlleleSequencesFile::Ptr      GetAlleleFile();
    AlleleSequencesFile::ConstPtr GetAlleleFile() const;

	Str::Path::Val					GetAlleleInfoFileName() const;

    AlleleKMerTable::Ptr          GetKMerTable();
    size_t                        GetAlleleCount() const;
    AlleleKMerTable::AllelesInfo&			  GetAllelesInfo();
    const AlleleKMerTable::AllelesInfo&           GetAllelesInfo() const;

private:
    void                      CreateAlleleFile( const AlleleFinderSettings& settings, const communication::CalcCommunication& comm  );
    void                      CreateKMerTable ( const AlleleFinderSettings& settings, const communication::CalcCommunication& comm );

private:
    AlleleSequencesFile::Ptr		alleleFile_;
    AlleleKMerTable::AllelesInfo	allelesInfo_;

    AlleleKMerTable::Ptr			kmerTable_;

	AlleleInfoFile					alleleInfoFile_;
};

#endif

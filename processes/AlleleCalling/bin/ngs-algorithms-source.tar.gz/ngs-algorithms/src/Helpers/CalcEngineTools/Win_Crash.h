#pragma once

#include "StringDef.h"
#include "PathDef.h"

#ifndef AMGNU

LONG WINAPI serviceExceptionFilter(_EXCEPTION_POINTERS* info);

#endif // #ifndef AMGNU

/**
    Declared here, define in your own code!
*/
void           addmess( const Str::Text::Val& message );
Str::Path::Val G_homedir();
Str::Text::Val GetCrashdumpFilename();
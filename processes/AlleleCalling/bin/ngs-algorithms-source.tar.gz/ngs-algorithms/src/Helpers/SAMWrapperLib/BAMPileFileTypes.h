#pragma once
#include <cstdint>
#include "BAMTypes.h"

namespace BAM
{

class PileFileTypes: public BAMTypes
{

public:

    typedef uint32_t DrawPosition;

    typedef uint8_t PileHeight;
    typedef uint32_t FullPileHeight;
    static const PileHeight MAXHEIGHT = UINT8_MAX;

    typedef uint32_t FileOffset;

    typedef uint16_t MateDistance;
    typedef uint32_t FullMateDistance;
    static const MateDistance MAXDISTANCE = UINT16_MAX;

    //pack the structs below tightly
#pragma pack(1)

    typedef struct {
        FullMateDistance max;
        FullMateDistance median;
        FullMateDistance mad;
        FullMateDistance rangeMax;
    } MateDistanceInfo;

    typedef struct {

        DrawPosition length;
        FullPileHeight maxFwdCoverage;
        FullPileHeight maxRevCoverage;
        FileOffset offset;

        MateDistanceInfo mateDistanceInfo;

    } ReferenceCoverageInfo;

    typedef struct {
        char signature[4];
        uint16_t referenceCount;
    } Header;


    typedef struct {
        ReferencePosition refPosition;
        PileHeight fwdCoverage;
        PileHeight revCoverage;
        MateDistance mateDistance;
    } PositionInfo;

#pragma pack()

};

}
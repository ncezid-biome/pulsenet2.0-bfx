/*
Property of 
	Applied Maths NV
	Keistraat 120
	Sint-Martens-Latem 
	Belgium
	info@applied-maths.com

Written by 
	Hannes Pouseele

Part of
	MODAPEP project
*/

#ifndef INTDEF_H
#define INTDEF_H

typedef __int64 Int64;
typedef __int32 Int32;
typedef __int16 Int16;

typedef unsigned __int64 UInt64;
typedef unsigned __int32 UInt32;

#ifndef AMGNU
typedef unsigned __int16 UInt16;
#else
typedef uint16_t         UInt16;
#endif

typedef unsigned long ULong;
typedef unsigned long long ULongLong;

#endif
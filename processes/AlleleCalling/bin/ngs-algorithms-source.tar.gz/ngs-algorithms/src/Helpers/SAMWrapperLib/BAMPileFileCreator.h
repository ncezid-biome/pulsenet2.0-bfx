#pragma once

#include <cstdint>
#include "SAMWrapper.h"
#include "BAMPileup.h"
#include "BAMPileFileTypes.h"
#include "BAMFileResolver.h"

namespace BAM
{

class STW_DLLPORT PileFileCreator: public Pileup, public PileFileTypes
{

private:

    typedef struct {
        ReferencePosition refPosition;
        FullPileHeight fwdCoverage;
        FullPileHeight revCoverage;
        FullMateDistance mateDistance;
    } FullPositionInfo;

public:
    PileFileCreator(): Pileup(true), maxFwdCoverage_(0), maxRevCoverage_(0), maxMateDistance_(0)
    {
    }

    void CreatePileFile(FileResolver::Ptr files);

    static bool HasPileFile(FileResolver::Ptr files);

private:

    int PileupCallback(ReferenceID refId, ReferencePosition pos, int n, const bam_pileup1_t pl[]);

    void AddPositionInfo(ReferencePosition pos, FullPositionInfo& fpi);

    template<int M, typename R> inline R ScaleIfNeeded(uint32_t input, uint32_t max)
    {
        if(max > M)
            return std::min<uint32_t>((uint64_t)input * M / max, max);
        return std::min(input, max);
    }

private:

    Str::Path::Val bamFile_;

    FullPileHeight maxFwdCoverage_;
    FullPileHeight maxRevCoverage_;

    FullMateDistance maxMateDistance_;

    std::vector<FullPositionInfo> positions_;
};

}

#!/bin/sh

echo oi
#include "Coverage.h"
#include "BitCompressor.h"
#include "exception.h"


namespace compression{

#pragma region Write coverage

/**
Write a vector of coverages for a certain nucleotide (A, C, T, G) in a N-bit comperssed buffer
Stores a zero when
 - the value is actually zero AND there is an other base that is MAX or
 - the value is equal to the total
otherwise, store
 - the value or
 - total - the value if is MAX
Counts that exceed total are stored as zero. Only the max (or the first in case of ex-eaquo)
will be decompresses as total.
*/
template<int N, typename Iterator>
void  SaveCovBaseVector(Iterator& it, const CoverageReaderItf& cov, size_t baseNr){
	int currentOffset = 0;
	size_t cnt=cov.GetCount();
	for(size_t i=0; i<cnt ;++i){
		CoverageReaderItf::CountType nr = cov.GetBaseCount(i, baseNr);
		if((nr==0 &&  cov.GetMaxBaseNr(i)!=baseNr) || nr >= cov.GetTot(i)){//specialleke
			size_t nrOfZero=1;
			while(i+nrOfZero!=cnt  && nrOfZero < (1<<N)-1 &&  
							((cov.GetBaseCount(i+nrOfZero, baseNr) == 0 &&  cov.GetMaxBaseNr(i+nrOfZero)!=baseNr)|| 
							(cov.GetBaseCount(i+nrOfZero, baseNr) >= cov.GetTot(i+nrOfZero)))){
				++nrOfZero;
			}
			i += nrOfZero-1;
			SaveNumber<N,Iterator, CoverageReaderItf::CountType, false>(it, 0, currentOffset, false);
			//even more optimezed: no sign bit, no next bit
			CompressNumber<N,Iterator>(it, currentOffset, nrOfZero);
		}
		else{
			CoverageReaderItf::CountType guide = cov.GetTot(i);
			bool isMax = baseNr==cov.GetMaxBaseNr(i); 
			if(isMax){
				nr  = guide - nr; //store total-max
			}
			ASSERT(nr>=0);
			SaveNumber<N,Iterator, CoverageReaderItf::CountType, false>(it, nr, currentOffset, false);
		}
	}
}

/**
Writes the total coverage a N-bit compressed buffer
*/
template<int N, typename Iterator>
void  SaveTotVector(Iterator& it, const CoverageReaderItf& cov){
	int currentOffset = 0;
	size_t cnt=cov.GetCount();
	for(size_t i=0; i<cnt ;++i){
		int nr=cov.GetTotDiff(i);
		bool neg = nr<0; 
		if(neg){
			nr  = - nr; //remove sign
		}
		SaveNumber<N,Iterator, CoverageReaderItf::CountType, true>(it, nr, currentOffset, neg);
	}
}

/**
Store which nucleotide has the maximum base at a certain position
*/
template<int N, typename Iterator>
void  SaveMaxVector(Iterator& it, const CoverageReaderItf& cov){
	int currentOffset = 0;
	size_t cnt=cov.GetCount();
	for(size_t i=0; i<cnt ;++i){
		CompressNumber<N,Iterator>(it, currentOffset, cov.GetMaxBaseNr(i));
	}
}


template<int N, typename Iterator>
void  SaveCoverage(Iterator& buffIt, const CoverageReaderItf& reader){
	int currentOffset = 0;
	SaveNumber<8,Iterator, size_t, false>(buffIt, reader.GetCount(), currentOffset, false);
	SaveTotVector<N,Iterator>(buffIt, reader);
	SaveMaxVector<2,Iterator>(buffIt, reader);
	SaveCovBaseVector<N,Iterator>(buffIt, reader, 0);
	SaveCovBaseVector<N,Iterator>(buffIt, reader, 1);
	SaveCovBaseVector<N,Iterator>(buffIt, reader, 2);
	SaveCovBaseVector<N,Iterator>(buffIt, reader, 3);
}

#pragma endregion 

#pragma region Read Coverage


template<int N, typename Iterator>
void  LoadCovBase(Iterator& it, CoverageWriterItf& cov, size_t baseNr){
	int currentOffset = 0;
	for(size_t i=0; i < cov.GetCount(); ){
		bool neg=false;
		CoverageWriterItf::CountType nr = LoadNumber<N,Iterator, CoverageWriterItf::CountType, false>(it, currentOffset, neg);
		//We know that for individual bases there will be long stretches of zeros (especially because we write a zero when
		//the count of a base is equal to the total coverage too!)
		//so when we encounter a zero: encode the number of zeros that will come in the next N-bit
		if(nr==0){
			CoverageWriterItf::CountType nrOfZeros = DecompressNumber<N,Iterator>(it,  currentOffset);

            if(nrOfZeros <= 0)
                throw KError("Compressed coverage: invalid bitstream");

			while(nrOfZeros>0){
				if(cov.GetMaxBaseNr(i)==baseNr)
					cov.SetBaseCount(i, baseNr, cov.GetTot(i));
				else
					cov.SetBaseCount(i, baseNr, 0);
				++i;
				--nrOfZeros;
			}
		}
		else{
			if(cov.GetMaxBaseNr(i)==baseNr){
				CoverageWriterItf::CountType guide = cov.GetTot(i);
				cov.SetBaseCount(i, baseNr, guide-nr);
			}
			else
				cov.SetBaseCount(i, baseNr, nr);
			++i;
		}
	}
	if(currentOffset!=0)
		++it;
}

/**
Write away the total coverage: we use the fact that this is continuous and store the difference with the previous value
*/
template<int N, typename Iterator>
void  LoadCovTot(Iterator& it, CoverageWriterItf& cov)
{	
    // Must check as we will always try to read the first element further on
    if ( cov.GetCount() == 0 )
        return;

    int currentOffset = 0;
	
    // First base: do by hand
    bool neg = false;
    CoverageWriterItf::CountType nr = LoadNumber<N,Iterator, CoverageWriterItf::CountType, true>(it, currentOffset, neg);
    cov.SetTot(0, nr);

    // Cache the old number (nr) and don't use GetTot: GetTot is virtual and too expensive.
    for ( size_t thisCnt = 1, tot = cov.GetCount(); thisCnt < tot; ++thisCnt ){
        neg = false;
        nr += LoadNumber<N,Iterator, CoverageWriterItf::CountType, true>(it, currentOffset, neg);

        cov.SetTot(thisCnt, nr);
	}

	if(currentOffset!=0)
		++it;
}

/**
Store the vector containing the max base (0,..,3)
*/
template<int N, typename Iterator>
void  LoadMaxVector(Iterator& it, CoverageWriterItf& cov){
	int currentOffset = 0;
	size_t cnt=cov.GetCount();
	for(size_t i=0; i<cnt ;++i){
		cov.SetMaxBaseNr(i, DecompressNumber<N, Iterator>(it, currentOffset));
	}
	if(currentOffset!=0)
		++it;
}


template<int N, typename BufferIt>
void  LoadCoverage(BufferIt& it, CoverageWriterItf& writer){
	int currentOffset = 0;
	bool neg=false;
	size_t cnt = LoadNumber<8,BufferIt, size_t, false>(it, currentOffset, neg);
	writer.SetCount(cnt);
	LoadCovTot<N, BufferIt>(it,writer);
	LoadMaxVector<2, BufferIt>(it,writer);
	LoadCovBase<N, BufferIt>(it, writer, 0);
	LoadCovBase<N, BufferIt>(it, writer, 1);
	LoadCovBase<N, BufferIt>(it, writer, 2);
	LoadCovBase<N, BufferIt>(it, writer, 3);
}

/**
    Load total coverage only
*/
template<int N, typename BufferIt>
void  LoadTotalCoverage(BufferIt& it, CoverageWriterItf& writer){
    int currentOffset = 0;
    bool neg=false;
    size_t cnt = LoadNumber<8,BufferIt, size_t, false>(it, currentOffset, neg);
    writer.SetCountTotal(cnt);
    LoadCovTot<N, BufferIt>(it,writer);
}


#pragma endregion 

}//namespace compression{

